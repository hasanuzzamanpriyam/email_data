<?php
require_once 'assets/php/header.php';
$servername = "premium103.web-hosting.com";
    $username = "mailrqyk_mailerstation";
    $password = "mailrqyk_mailerstation";
    $dbname = "mailrqyk_mailerstation";


    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

if (isset($_POST['insertBlog'])) {
    $category = $_POST['page'];
    $title = $_POST['title'];
    $description = $_POST['editor1'];
    $seoTitle = $_POST['seoTitle'];
    $seoUrl = $_POST['seoUrl'];
    $seoKey = $_POST['seoKeyword'];
    $seoDesc = $_POST['seoDescription'];

    $sql = "INSERT INTO `blogs`(`category`, `title`, `description`, `seo_title`, `seo_url`, `seo_key`, `seo_desc`) VALUES ('$category','$title','$description','$seoTitle','$seoUrl','$seoKey','$seoDesc')";

    mysqli_query($conn, $sql);
    
    echo '<script>alert("Data inserted successfully!")</script>';
    echo "<meta http-equiv='refresh' content='0'>";
}
if (isset($_POST['updateBlog'])) {
    $updateId = $_POST['updateBlogId'];
    $category = $_POST['updateBlogCategory'];
    $title = $_POST['updateBlogTitle'];
    $description = $_POST['updateBlogEditor1'];
    $seoTitile = $_POST['seoUpdateTitle'];
    $seoUrl = $_POST['seoUpdateUrl'];
    $seoKey = $_POST['seoUpdateKey'];
    $seoDesc = $_POST['updateSeoDesc'];

    $sql2 = "UPDATE `blogs` SET `category`='$category',`title`='$title',`description`='$description',`seo_title`='$seoTitile',`seo_url`='$seoUrl',`seo_key`='$seoKey',`seo_desc`='$seoDesc'  WHERE id= $updateId";

    mysqli_query($conn, $sql2);
    echo '<script>alert("Data updated  successfully!")</script>';
    echo "<meta http-equiv='refresh' content='0'>";
}
?>
<script src="https://cdn.ckeditor.com/4.8.0/full-all/ckeditor.js"></script>
<main>
    <div class="seo-details">
        <h3>Insert New Blog Post According to Category</h3>
        <form id="insert-blog-form"  method="POST" action="#">
            <div class="form-floating mb-3" id="showPage">
                <h3 class="text-center font-weight-bold">Please Wait....</h3>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="floatingInput" name="title" required placeholder="Enter Blog Title">
                <label for="floatingInput">Blog Title</label>
            </div>
            <div class="form-floating mb-3">
                <textarea name="editor1" id="summernote" cols="30" rows="10"></textarea>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="seoTitle" placeholder="Enter SEO Title" name="seoTitle" required>
                <label for="seoTitle">SEO Title</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="seoUrl" placeholder="Enter SEO URL" name="seoUrl"required>
                <label for="seoUrl">SEO URL</label>
            </div>
            <div class="form-floating mb-3">
                <textarea class="form-control" placeholder="Write Key-word" id="seoKeyword" style="height: 100px" name="seoKeyword"required></textarea>
                <label for="seoKeyword">Key-word</label>
            </div>
            <div class="form-floating mb-3">
                <textarea class="form-control" placeholder="Write short description" id="seoDescription" style="height: 100px" name="seoDescription"required></textarea>
                <label for="seoDescription">Description</label>
            </div>
            <div class="row justify-content-end">
                <div class="col-lg-3">
                    <input type="submit" class="btn btn-primary btn-block" id="insert-blog-btn" value="Insert Blog" name="insertBlog">
                </div>
            </div>
        </form>
    </div>

    <div class="seo-update-details" style="display: none;">
        <h3>Edit Blog To Update</h3>
        <form id="update-blog-form"  method="POST" action="#">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="updateBlogCategory" name="updateBlogCategory" readonly placeholder="Enter blog title">
                <label for="updateBlogCategory">Category</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="updateBlogTitle" name="updateBlogTitle" required placeholder="Enter Blog Category">
                <label for="updateBlogTitle">Title</label>
            </div>
            <div class="form-floating mb-3">
                <ul id="fieldList" style="list-style: none; margin-left: -33px;">
                    <li>
                        <label for="updateBlogEditor1">Blog Description</label>
                        <textarea class='form-control fixborder' id="updateBlogEditor1" name="updateBlogEditor1" placeholder='File description' required></textarea>
                    </li>
                </ul>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="seoUpdateTitle" name="seoUpdateTitle" required placeholder="Enter Blog title">
                <label for="seoUpdateTitle">SEO Title</label>
            </div>
             <div class="form-floating mb-3">
                <input type="text" class="form-control" id="seoUpdateUrl" name="seoUpdateUrl" required placeholder="Enter Blog title">
                <label for="seoUpdateUrl">SEO URL</label>
            </div>
             <div class="form-floating mb-3">
                <input type="text" class="form-control" id="seoUpdateKey" name="seoUpdateKey" required placeholder="Enter Blog title">
                <label for="seoUpdateKey">SEO Key-word</label>
            </div>
            <div class="form-floating mb-3">
                <textarea class="form-control" placeholder="Short Description" id="updateSeoDesc" name="updateSeoDesc" required style="height: 100px" ></textarea>
                <label for="updateSeoDesc">SEO Description</label>
            </div>
            <div class="row justify-content-end">
                <div class="col-lg-3">
                    <input type="hidden" name="updateBlogId" id="updateBlogId">
                    <input type="submit" class="btn btn-primary btn-block" id="update-blog-btn" value="Update Email" name="updateBlog">
                </div>
            </div>
        </form>
    </div>
    <section class="recent">
        <div class="activity-grid">
            <div class="activity-card">
                <h3 class="text-dark">All Blog List</h3>
                <div class="table-responsive p-3" id="showBlogTable">
                    <h3 class="text-center font-weight-bold">Please Wait....</h3>
                </div>
            </div>
        </div>
    </section>
</main>
<?php
require_once 'assets/php/footer.php';
?>
<script>
    $(document).ready(function () {
        $("body").on("click", ".editBlogBtn", function (e) {
            e.preventDefault();

            editBlogId = $(this).attr("id");
            $.ajax({
                url: 'assets/php/process',
                type: 'post',
                data: {editBlogId: editBlogId},
                success: function (response) {
                    $(".seo-update-details").attr('style', 'display:block');
                    $(".seo-details").attr('style', 'display:none');
                    $("#updateTitle").attr('disabled', true);

                    data = JSON.parse(response);
                    $("#updateBlogCategory").val(data.category);
                    $("#updateBlogTitle").val(data.title);
                    CKEDITOR.instances['updateBlogEditor1'].setData(data.description);
                    $("#seoUpdateTitle").val(data.seo_title);
                    $("#seoUpdateUrl").val(data.seo_url);
                    $("#seoUpdateKey").val(data.seo_key);
                    $("#updateSeoDesc").val(data.seo_desc);
                    $("#updateBlogId").val(data.id);
                }
            });
        });
        $("body").on("click", ".deleteBlogBtn", function (e) {
            e.preventDefault();

            let deleteBlogBtn = $(this).attr("id");

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'assets/php/process',
                        type: 'post',
                        data: {deleteBlogBtn: deleteBlogBtn},
                        success: function (response) {
                            Swal.fire(
                                    'Deleted!',
                                    'Your file has been deleted.',
                                    'success'
                                    )
                            location.reload();
                        }
                    });
                }
            })
        });
        displayAllPage();
        function displayAllPage() {
            $.ajax({
                url: 'assets/php/process',
                type: 'post',
                data: {
                    action: 'display-page'
                },
                success: function (response) {
                    $("#showPage").html(response);
                }
            });
        }
        displayAllBlog();
        function displayAllBlog() {
            $.ajax({
                url: 'assets/php/process',
                type: 'post',
                data: {
                    action: 'display-blog'
                },
                success: function (response) {
                    $("#showBlogTable").html(response);
                    $("table").DataTable();
                }
            });
        }
    });
</script>

<script>
    $(document).ready(function() {
      $('#summernote').summernote({
        tabsize: 2,
        height: 200
      });
    });
</script>

