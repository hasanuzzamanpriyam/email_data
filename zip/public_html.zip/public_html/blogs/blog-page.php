<?php
require_once '../assets/php/auth.php';
$user = new Auth();
$siteUrl = 'https://mailerstation.com/';

function slugify($text, string $divider = '-'){
	  $text = preg_replace('~[^\pL\d]+~u', $divider, $text);
	  $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
	  $text = preg_replace('~[^-\w]+~', '', $text);
	  $text = trim($text, $divider);
	  $text = preg_replace('~-+~', $divider, $text);
	  $text = strtolower($text);

	  if (empty($text)) {
	    return 'n-a';
	  }

	  return $text;
	}


$recourd_per_page = 5;
$page = '';

$output = '';

if (isset($_POST['page'])) {
    $page = $_POST['page'];
} else {
    $page = 1;
}
$start_form = ($page - 1) * $recourd_per_page;

$result = $user->get_blogs_records( $start_form, $recourd_per_page);

if ($result) {
        foreach ($result as $row) {
            $day = date("d", strtotime($row['created_at']));
            $month = date("M", strtotime($row['created_at']));
            $title = slugify($row['title']);
            $output .= '<li class="iconic-content iconic-content--blog-post">
                        <div class="iconic-content__icon-area iconic-content__icon-area--medium">
                            <time class="blog-post-date" datetime="2017-12-15">
                                <span class="blog-post-date__day">' . $day . '</span>
                                <span class="blog-post-date__month">' . $month . '</span>
                            </time>
                        </div>
                        <div class="iconic-content__content">
                            <h4 class="iconic-content__title iconic-content__title--primary mb-3">
                                <a class="link-tertiary" href="'.$siteUrl.'blogs/data/' . $title . '">' . $row['title'] . '</a>
                            </h4>
                            <hr class="hr-small">
                            <p class="gap-bottom-small">' . substr($row['description'], 0, 350) . '..</p>
                            <a class="button button--tertiary" href="'.$siteUrl.'blogs/data/' . $title . '">Read More <i class="icon icon-arrow-forward button--tertiary__icon"></i></a>
                            <hr class="hr-large">
                        </div>
                    </li>';
        }
    } else {
        echo '<h3 class="text-center text-secondary">No recourd Found!</h3>';
    }
    
$output .= "<div class='pad-vertical-small container'>
        <h6 class='pagination-title'>Page</h6>
        <div class='pagination inline-block align-middle'>";

$page_sql = $user->get_blogs();
$total_records = 0;
foreach ($page_sql as $row) {
    $total_records++;
}

$total_page = ceil($total_records / $recourd_per_page);

for ($i = 1; $i <= $total_page; $i++) {
    $output .= "
            <button class='pagination__item is-active' id='".$i."' style='background: none;'>".$i."</button>
        ";
}
$output .= '</div></div>';
echo $output;
?>