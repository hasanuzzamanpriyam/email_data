<?php $seoUrl = 'https://bookyourdata.io/'; ?>
<div class="chat-demo">
    <div class="chat-live">
        <span style="--i:1;"></span>
    </div>
    <div class="chat-btn" id="chat-btn" onclick="myFunctionNew()"><img src="<?= $seoUrl; ?>bundles/bydhome/img/chat/messagebtn.png" alt="messagebtn" ></div>
    <div id="chat-option">
        <a href="skype:live:.cid.77e4a8ee4a4b02af?chat" target="_blank"><img src="<?= $seoUrl; ?>bundles/bydhome/img/chat/skype.png" alt="skype"></a>
        <a href="https://t.me/mailerstation" target="_blank"><img src="<?= $seoUrl; ?>bundles/bydhome/img/chat/telegram.png" alt="telegram"></a>
        <a href="https://icq.im/mailerstation" target="_blank"><img src="<?= $seoUrl; ?>bundles/bydhome/img/chat/icq.png" alt="icq"></a>
        <a href="https://api.whatsapp.com/send/?phone=44%207441442048&text&app_absent=0" target="_blank"><img src="<?= $seoUrl; ?>bundles/bydhome/img/chat/whatsapp.png" alt="whatsapp"></a>
        <a href="https://www.messenger.com/t/mailerstation" target="_blank"><img src="<?= $seoUrl; ?>bundles/bydhome/img/chat/messenger.png" alt="messenger"></a>
        <a href="mailto:support@mailerstation.com" target="_blank"><img src="<?= $seoUrl; ?>bundles/bydhome/img/chat/email.png" alt="email"></a>
        <a href="tel: +44 7441442048" target="_blank"><img src="<?= $seoUrl; ?>bundles/bydhome/img/chat/call.png" alt="call"></a>
    </div>
</div>
<footer class="footer" id="footer">
    <div class="pad-vertical bg-concrete">
        <div class="container">
            <div class="row">
                <div class="col-md-3 gap-bottom-tld">
                    <h6 class="text-uppercase">Mailerstation</h6>
                    <a href="<?= $seoUrl; ?>contact">Send Message</a>
                    <address>
                        27 Old Gloucester Street.<br>
                        LONDON , WC1N 3AX <br>
                        United Kingdom
                    </address>
                </div>
                <div class="col-md-2 gap-bottom-tld">
                    <h6 class="text-uppercase">Community</h6>
                    <div class="menu menu--primary">
                        <a href="<?= $seoUrl; ?>events" class="menu__item">Events</a>
                        <a href="<?= $seoUrl; ?>resources" class="menu__item">Resources</a>
                        <a href="<?= $seoUrl; ?>blogs" class="menu__item">Blogs</a>
                        <a
                            href="<?= $seoUrl; ?>case-study"
                            class="menu__item">Case Study</a>
                        <a href="<?= $seoUrl; ?>faq" class="menu__item">FAQ</a>
                        <a href="<?= $seoUrl; ?>sitemap.xml" class="menu__item">Sitemap</a>
                    </div>
                </div>
                <div class="col-md-2 gap-bottom-tld">
                    <h6 class="text-uppercase">Products</h6>
                    <div class="menu menu--primary">
                        <a href="<?= $seoUrl; ?>custom-order/business-contacts" class="menu__item
                           hidden-dd">Online List Builder</a>
                        <a href="<?= $seoUrl; ?>ready-made/job-levels"
                           class="menu__item">Lists By Job Levels</a>
                        <a href="<?= $seoUrl; ?>ready-made/job-titles"
                           class="menu__item">Lists By Job Titles</a>
                        <a href="<?= $seoUrl; ?>ready-made/job-functions"
                           class="menu__item">Lists By Job Functions</a>
                        <a href="<?= $seoUrl; ?>ready-made/industries"
                           class="menu__item">Lists By Industries</a>
                        <a
                            href="<?= $seoUrl; ?>ready-made/healthcare-professionals"
                            class="menu__item">Healthcare Professionals</a>
                        <a href="<?= $seoUrl; ?>ready-made/international"
                           class="menu__item">International</a>
                        <a href="<?= $seoUrl; ?>ready-made/real-estate"
                           class="menu__item">Real Estate Lists</a>
                        <a href="<?= $seoUrl; ?>ready-made/states"
                           class="menu__item">States</a>
                    </div>
                </div>
                <div class="col-md-2 gap-bottom-tld">
                    <h6 class="text-uppercase">Company</h6>
                    <div class="menu menu--primary">
                        <a href="<?= $seoUrl; ?>about" class="menu__item">About Us</a>
                        <a href="<?= $seoUrl; ?>contact" class="menu__item">Contact</a>
                        <a href="<?= $seoUrl; ?>pricing" class="menu__item">Pricing</a>
                        <a href="<?= $seoUrl; ?>our-guarantees"
                           class="menu__item">Our Guarantees</a>
                        <a href="<?= $seoUrl; ?>community-relations"
                           class="menu__item">Community Relations</a>
                        <a href="<?= $seoUrl; ?>careers" class="menu__item">Careers</a>
                        <a href="<?= $seoUrl; ?>leadership" class="menu__item">Leadership</a>
                        <a
                            href="<?= $seoUrl; ?>how-to-build-list"
                            class="menu__item">How To Build A List</a>
                    </div>
                </div>
                <div class="col-md-3">
                    <h6 class="text-uppercase">Newsletter</h6>
                    <form method="post"  class="hs-form stacked hs-form-private" action="#" id="email-collect-from">
                        <div class="hs_email hs-email hs-fieldtype-text
                             field hs-form-field">
                            <legend class="hs-field-desc"
                                    style="display:block;">We will never
                                share your email with third parties.</legend>
                            <div class="input">
                                <input type="email" id="newsletter_email" name="newsletter_email"required class="hs-input" placeholder="Your Email Address"autocomplete="email" />
                            </div>
                        </div>
                        <div class="hs_submit hs-submit">
                            <div class="actions">
                                <button type="submit" class="hs-button primary large" id="email-collect-btn" value="Submit">Submit</button>
                            </div>
                        </div>
                        <div class="hs_email hs-email hs-fieldtype-text
                             field hs-form-field" id="emailAlert" style="margin: 15px Opx; text-align: center; color: green; font-weight: 600; font-size: 18px;"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__brands">
        <div class="container">
            <div class="footer-logos gap-bottom-small-tld">
                <span class="footer-logos__title">Secured <br>By</span>
                <a
                    href="#"
                    target="_blank" class="footer-logos__item"><img
                        src="<?= $seoUrl;?>bundles/bydhome/img/logos/norton.png"
                        alt="buy email list"></a>
                <a
                    href="#"
                    target="_blank" class="footer-logos__item"><img
                        src="<?= $seoUrl;?>bundles/bydhome/img/logos/mcafee.png"
                        alt="buy email list"></a>
            </div>
            <div class="footer-logos pull-right-tlnu">
                <span class="footer-logos__title">Proud <br>Member Of</span>
                <span class="footer-logos__item"><img
                        src="<?= $seoUrl;?>bundles/bydhome/img/logos/dma.png" alt="buy email list"></span>
                <span class="footer-logos__item"><img
                        src="<?= $seoUrl;?>bundles/bydhome/img/logos/ama.png" alt="buy email list"></span>
                <span class="footer-logos__item"><img
                        src="<?= $seoUrl;?>bundles/bydhome/img/logos/nyama.png"
                        alt="buy email list"></span>
                <span class="footer-logos__item"><img
                        src="<?= $seoUrl;?>bundles/bydhome/img/logos/bma.png" alt="buy email list"></span>
                <span class="footer-logos__item"><img
                        src="<?= $seoUrl;?>bundles/bydhome/img/logos/pma.png" alt="buy email list"></span>
            </div>
        </div>
    </div>
    <hr class="hr-line">
    <div class="footer__bottom text-gray-chateau">
        <div class="container font-small">
            <ul class="list list--primary footer__bottom-links">
                <li class="list__item">Copyright &copy; 2021
                    Mailerstation - All Rights Reserved</li>
                <li class="list__item"><a class="link-quaternary"
                                          href="<?= $seoUrl; ?>terms-of-use">Terms of Use</a></li>
                <li class="list__item"><a class="link-quaternary"
                                          href="<?= $seoUrl; ?>privacy-policy">Privacy Policy</a></li>
                <li class="list__item"><a class="link-quaternary"
                                          href="<?= $seoUrl; ?>legal-notice">Legal Notice</a></li>
            </ul>
            <div class="footer__social-menu">
               <!-- <a href="#">
                    <img src="bundles/bydhome/img/logos/gdpr.svg"
                         alt="GDPR">
                </a>-->
                <span>Find us on</span>
                <div class="social-menu gap-left align-middle">
                    <a
                        href="https://www.facebook.com/mailerstation/"
                        target="_blank" class="social-menu__item
                        icon-facebook"></a>
                    <a href="https://twitter.com/mailerstation"
                       target="_blank" class="social-menu__item
                       icon-twitter"></a>
                    <a
                        href="https://www.linkedin.com/company/mailerstation/"
                        target="_blank" class="social-menu__item
                        icon-linkedin"></a>
                   <!-- <a
                        href="#"
                        target="_blank" class="social-menu__item
                        icon-google-plus"></a>-->
                </div>
            </div>
        </div>
    </div>
</footer>


<script>
    function myFunctionNew() {
      var x = document.getElementById("chat-option");
      if (x.style.display === "block") {
        x.style.display = "none";
        document.getElementById("chat-btn").innerHTML = '<img src="/bundles/bydhome/img/chat/messagebtn.png" alt="messagebtn" >';
      } else {
         x.style.display = "block";
        document.getElementById("chat-btn").innerHTML = '<img class="closeBtn" src="/bundles/bydhome/img/chat/close.png" alt="messagebtn" >';
      }
    }
</script>

<script src="../ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
    window.jQuery || document.write('<script src="./../bundles/bydhome/libs/jquery.min8939.js"><\/script>');
</script>
<script src="./../bundles/bydhome/js/app.min3860.js" type="text/javascript"></script>
<script type="text/javascript" src="https://cdn.ywxi.net/js/1.js" async></script>
<script>
    $(document).ready(function () {
//Message Ajax Request
        $("#email-collect-btn").click(function (e) {
            if ($("#email-collect-from")[0].checkValidity()) {
                e.preventDefault();
                $("#email-collect-btn").val('Please Wait...');
                    $.ajax({
                        url: 'assets/php/action',
                        type: 'post',
                        data: $("#email-collect-from").serialize() + '&action=email-register',
                        success: function (response) {
                            $("#email-collect-btn").val('Submit');
                            $("#email-collect-from")[0].reset();
                            $("#emailAlert").html(response);
                        }
                    });
                }
        });
    });
</script>

<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4592147,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4592147&101" alt="site stats" border="0"></a></noscript>
<!-- Histats.com  END  -->

</body>
</html>

