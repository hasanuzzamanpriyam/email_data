<?php
//Silace is Golden 