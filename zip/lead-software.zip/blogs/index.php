<?php include_once '../assets/php/header.php'; ?>
<div class="jumbotron jumbotron--regular jumbotron--regular-bg">
    <div class="container jumbotron__container">
        <div class="jumbotron__inner">
            <div class="row">
                <div class="col-md-5">
                    <h1 class="jumbotron__title">Blogs</h1>
                    <div class="breadbrumb">
                        <a href="https://mailerstation.com/" class="breadbrumb__item">Home</a>
                        <span class="breadbrumb__item">Blogs</span>
                    </div>
                </div>
                <div class="col-md-7">
                    <p class="clear-gap-bottom">Learn about the latest tricks in marketing from data experts on
                        our blog. Uncover the secrets of finding the best business leads, gain insider knowledge,
                        and become a marketing master!</p>
                </div>
            </div>
        </div>
    </div>
</div>
<main>
    <div class="container section">
        <div class="row">
            <div class="col-md-8">
                <ul class="list" id="showBlog">
                    <h3>Please Wait...</h3>
                </ul>
            </div>
            <div class="col-md-4 pad-top-tld">
                <ul class="list list--tertiary shadow-primary gap-bottom">
                    <li class="list__item">
                        <h6 class="secondary-title font-xsmall">Categories</h6>
                    </li>
                    <li class="list__item list--tertiary__item--no-pad">
                        <div class="sidebar-nav sidebar-nav--without-icon">
                            <a class="sidebar-nav__item" href="https://mailerstation.com/blog">Data</a>
                            <a class="sidebar-nav__item" href="https://mailerstation.com/blog">Marketing</a>
                            <a class="sidebar-nav__item" href="https://mailerstation.com/blog">Lifestyle</a>
                            <a class="sidebar-nav__item" href="https://mailerstation.com/blog">Sales Prospecting</a>
                            <a class="sidebar-nav__item" href="https://mailerstation.com/blog">Email Marketing</a>
                        </div>
                    </li>
                </ul>
                <ul class="list list--tertiary shadow-primary gap-bottom">
                    <li class="list__item">
                        <h6 class="secondary-title font-xsmall">Recent Posts</h6>
                    </li>
                    <li class="list__item list--tertiary__item--no-pad">
                        <div class="sidebar-nav">
                            <a class="sidebar-nav__item" href="#">New feature launches on Mailerstation - web technologies</a>
                            <a class="sidebar-nav__item" href="#">Cold Emailing - The most effective marketing channel</a>
                            <a class="sidebar-nav__item" href="#">3 Essentials to targeting and prospecting b2b leads effectively</a>
                            <a class="sidebar-nav__item" href="https://mailerstation.com/blog">Need leads? 5 factors to consider when you buy leads online</a>
                            <a class="sidebar-nav__item" href="https://mailerstation.com/blog">4 sales prospecting tools to engage leads online</a>
                            <a class="sidebar-nav__item" href="https://mailerstation.com/blog">5 ways to increase your return on ceo email addresses</a>
                        </div>
                    </li>
                </ul>
                <ul class="list list--tertiary shadow-primary gap-bottom">
                    <li class="list__item">
                        <h6 class="secondary-title font-xsmall">Newsletter</h6>
                        <p class="clear-gap-bottom">Subscribe to our email newsletter for useful articles and valuable resources.</p>
                    </li>
                    <li class="list__item">
                        <form class="form form-single-line ajaxRequest" data-input="newsletter_input" action="/newsletter/save" method="POST">
                            <input class="form-single-line__input form__control" id="newsletter_input" type="email" name="email" placeholder="name@email.com">
                            <button class="form-single-line__submit" type="submit"><i class="icon icon-arrow-forward"></i></button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <hr class="hr-line">
    <div class="pad-vertical-small container">
        <h6 class="pagination-title">Page</h6>
        <div class="pagination inline-block align-middle">
            <a class="pagination__item is-active" href="https://mailerstation.com/blog">1</a>
        </div>
    </div>
</main>
<div class="lead hidden-dd">
    <div class="container lead__container">
        <div class="lead__col lead__col--left">
            <h5 class="lead__text gap-bottom-tld">Ready To Boost Your Sales Like Your Competitors? Try Our Tool For Free.</h5>
        </div>
        <div class="lead__col lead__col--right">
            <a class="button button--quaternary full-width" href="https://mailerstation.com/tool/business">
                Custom Order <i class="icon icon-arrow-forward button--quaternary__icon"></i>
            </a>
        </div>
    </div>
</div>
<?php include_once '../assets/php/footer.php'; ?>

<script>
    $(document).ready(function(){
        load_data();
        function load_data(page){
            $.ajax({
                url: 'blog-page',
                method: 'post',
                data: {page:page},
                success: function(response){
                    $("#showBlog").html(response);
                }
            })
        }
        $(document).on('click','.pagination__item',function(){
            var page = $(this).attr("id");
            load_data(page);
        })
    });
</script>

