<?php
    require 'stripe-php/init.php';
    
    //Test API
    
    // $publishable_key = "pk_test_51I1CtPCg1HV0bMpvKfefs3XZbr2S0BzuoimDGI8JB1PBHjI3IQhcAehNa7vgKzbHWcNG4EkagTVwhviBsydEfKHa00jjiceGMQ";
    // $secret_key = "sk_test_51I1CtPCg1HV0bMpvBaHHxYkeGRJTT2g2JZOmNVp7kUEBgoZPpor3jqZuU5HN3gQHAzmxEfLKE90yYEBR20iw8ZjD00UWc1xIEy";
    
    $publishable_key = "pk_live_51I1CtPCg1HV0bMpvuvUJfgDSLmz9ycpHlWxVIWnPDyd2FBTSHTHC24aqWgFxgkl60Ok3HQegldfGN4XlJS5tuytU00EjEydVrz";
    $secret_key = "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";
    
    \Stripe\Stripe::setApiKey($secret_key );


?>