<?php
/*
	CoinPayments.net API Class - v1.1
	Copyright 2014-2018 CoinPayments.net. All rights reserved.	
	License: GPLv2 - http://www.gnu.org/licenses/gpl-2.0.txt
*/
require "Coin.php";

$coin = new CoinPaymentsAPI();
$coin->Setup("169391eFfDC3DD85b03cA6f6a0e3d18d8801382B10a5a6E65a617e4280563C4A"," d350f6476cf5c991e18fc26880d073f2a15619929b0820a0eb32c16d968edc80");