-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 13, 2025 at 03:37 PM
-- Server version: 8.0.35
-- PHP Version: 8.3.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `writercert_ai`
--

-- --------------------------------------------------------

--
-- Table structure for table `ad_senses`
--

CREATE TABLE `ad_senses` (
  `id` bigint UNSIGNED NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `size` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `code` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_dashboard` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ad_senses`
--

INSERT INTO `ad_senses` (`id`, `slug`, `size`, `name`, `code`, `is_active`, `created_at`, `updated_at`, `is_dashboard`) VALUES
(1, 'header-top', '728x90', 'Header Top', NULL, 0, '2025-04-21 16:31:45', '2025-04-21 16:31:45', '0'),
(2, 'bottom-trusted-by', '728x90', 'Bottom trusted by', NULL, 0, '2025-04-21 16:31:45', '2025-04-21 16:31:45', '0'),
(3, 'top-best-feature', '728x90', 'Top Best Feature', NULL, 0, '2025-04-21 16:31:45', '2025-04-21 16:31:45', '0'),
(4, 'top-template-section', '728x90', 'Top Template Section', NULL, 0, '2025-04-21 16:31:45', '2025-04-21 16:31:45', '0'),
(5, 'top-review-section', '728x90', 'Top Review Section', NULL, 0, '2025-04-21 16:31:45', '2025-04-21 16:31:45', '0'),
(6, 'top-subscription-package', '728x90', 'Top Subscription Package', NULL, 0, '2025-04-21 16:31:45', '2025-04-21 16:31:45', '0'),
(7, 'top-trail-banner-section', '728x90', 'Top Trail Banner Section', NULL, 0, '2025-04-21 16:31:45', '2025-04-21 16:31:45', '0'),
(8, 'top-footer-section', '728x90', 'Top Footer Section', NULL, 0, '2025-04-21 16:31:45', '2025-04-21 16:31:45', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ad_sense_localizations`
--

CREATE TABLE `ad_sense_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `ad_sense_id` bigint NOT NULL,
  `name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_earnings`
--

CREATE TABLE `affiliate_earnings` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `referred_by` int DEFAULT NULL,
  `subscription_history_id` int NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `commission_rate` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_payments`
--

CREATE TABLE `affiliate_payments` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `payment_method` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_document` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `status` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'requested',
  `additional_info` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `remarks` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_payout_accounts`
--

CREATE TABLE `affiliate_payout_accounts` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `payment_method` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `account_details` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ai_blog_wizards`
--

CREATE TABLE `ai_blog_wizards` (
  `id` bigint UNSIGNED NOT NULL,
  `is_blog_published` tinyint NOT NULL DEFAULT '0' COMMENT '1 = yes, 0 = no',
  `user_id` int NOT NULL,
  `uuid` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `total_words` bigint NOT NULL DEFAULT '0',
  `completed_step` int DEFAULT NULL,
  `subscription_history_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `prompt_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `completion_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `input_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_blog_wizards`
--

INSERT INTO `ai_blog_wizards` (`id`, `is_blog_published`, `user_id`, `uuid`, `total_words`, `completed_step`, `subscription_history_id`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `prompt_tokens`, `completion_tokens`, `input_prompt`) VALUES
(1, 0, 1, '3a2572fb-178d-4aba-9704-5b30ecc9e779', 743, 4, NULL, 1, NULL, '2025-04-21 17:44:52', '2025-04-21 17:47:18', NULL, '257', '684', NULL),
(2, 0, 1, 'de5f34ba-4cae-40e9-bebc-0d7268606eb2', 685, 5, NULL, 1, NULL, '2025-04-21 23:12:15', '2025-04-21 23:14:50', NULL, '188', '681', NULL),
(3, 0, 1, 'dfcdc11e-81a1-4966-8fa0-19591ba4ed70', 740, 4, NULL, 1, NULL, '2025-04-22 13:24:26', '2025-04-22 13:25:38', NULL, '236', '676', NULL),
(4, 0, 1, '7d12f33a-e0ed-4cf9-8006-caa09461e8a6', 644, 4, NULL, 1, NULL, '2025-04-22 13:28:20', '2025-04-22 13:29:05', NULL, '171', '644', NULL),
(5, 0, 1, 'f81f360d-09d2-4a9a-ba78-09af5cd26c11', 697, 4, NULL, 1, NULL, '2025-04-22 13:30:03', '2025-04-22 13:32:03', NULL, '430', '697', NULL),
(6, 0, 1, '680773d7-aca7-4830-a165-8697e83174e2', 870, 5, NULL, 1, NULL, '2025-04-22 15:33:56', '2025-04-22 15:47:46', NULL, '296', '869', NULL),
(7, 0, 1, '1f585cee-628c-491a-a837-224d05a0b9c0', 133, 2, NULL, 1, NULL, '2025-04-27 17:54:28', '2025-04-27 17:54:52', NULL, '126', '133', NULL),
(8, 0, 1, '5c0708b2-f700-4088-9c62-887b7862a78e', 189, 2, NULL, 1, NULL, '2025-04-27 17:56:21', '2025-04-27 17:56:31', NULL, '112', '189', NULL),
(9, 0, 1, '37b9cdf7-9101-475b-a1c2-c54c1eafdb50', 682, 5, NULL, 1, NULL, '2025-05-03 14:06:24', '2025-05-03 14:07:41', NULL, '210', '681', NULL),
(10, 0, 1, 'a6765465-09d2-46cd-8a9e-4c3ab5f89f1c', 1173, 4, NULL, 1, NULL, '2025-05-03 18:07:42', '2025-05-03 18:08:26', NULL, '256', '1173', NULL),
(11, 0, 1, '0664ecfb-1ae3-4928-a560-b02208d37814', 1748, 4, NULL, 1, NULL, '2025-05-03 18:11:25', '2025-05-03 18:14:15', NULL, '472', '1748', NULL),
(12, 0, 1, '1e2545bb-c58a-441e-b8e0-0ff6edf7f7de', 2179, 5, NULL, 1, NULL, '2025-05-03 20:19:57', '2025-05-03 20:39:09', NULL, '623', '1390', NULL),
(13, 0, 1, '9d6994e9-1fd8-4153-9fe3-491d7bf13503', 1220, 5, NULL, 1, NULL, '2025-05-03 22:37:22', '2025-05-03 22:39:42', NULL, '241', '569', NULL),
(14, 0, 5, '9e57abc2-e502-4217-81f0-1ff352b407d6', 670, 5, 5, 5, NULL, '2025-05-04 14:35:45', '2025-05-11 16:01:24', NULL, '174', '669', NULL),
(15, 0, 7, '636dd337-b880-41d2-ab57-1f8df221a3d0', 697, 4, 8, 7, NULL, '2025-05-11 16:49:47', '2025-05-11 16:51:38', NULL, '196', '697', NULL),
(16, 0, 9, '0d73e490-9862-405d-acd9-567b88c92efb', 1341, 5, 12, 9, NULL, '2025-05-12 01:38:34', '2025-05-12 01:46:34', NULL, '225', '1310', NULL),
(17, 0, 9, '2d66c998-8530-40b5-80d4-576d9b5f7cbf', 513, 5, 12, 9, NULL, '2025-05-13 04:02:15', '2025-05-13 04:03:14', NULL, '113', '512', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_blog_wizard_articles`
--

CREATE TABLE `ai_blog_wizard_articles` (
  `id` bigint UNSIGNED NOT NULL,
  `ai_blog_wizard_id` int NOT NULL,
  `title` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `keywords` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `outlines` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci COMMENT 'keep as encoded array',
  `image` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `value` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `total_words` bigint NOT NULL DEFAULT '0',
  `num_of_copies` int NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `prompt_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `completion_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `input_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_blog_wizard_articles`
--

INSERT INTO `ai_blog_wizard_articles` (`id`, `ai_blog_wizard_id`, `title`, `keywords`, `outlines`, `image`, `value`, `total_words`, `num_of_copies`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `prompt_tokens`, `completion_tokens`, `input_prompt`) VALUES
(1, 2, 'Turn Your Internet Surfing into Cash: How to Make Money Online', 'Make Money Online, Passive income online, Work from home online income', '[\"Introduction to Making Money Online\",\"The Concept of Passive Income Online: A Brief Overview\",\"Maximizing Your Internet Surfing: Turning It Into Cash\",\"Working from Home: The Modern Way to Earn\",\"Criteria for Selecting the Best Work from Home Online Opportunities\",\"Exploring Various Avenues to Make Money Online\",\"Tips and Tricks: Maximize Your Work From Home Online Income\",\"Practical Guides: Steps for Setting Up Your Online Business for Passive Income\",\"Maintaining Your Online Income Stream: Challenges and Solutions\",\"Conclusions: Turning Your Online Surfing Time into a Profitable Venture\"]', NULL, '**', 1, 4, 1, NULL, '2025-04-21 23:13:47', '2025-04-21 23:14:50', NULL, '125', NULL, NULL),
(2, 6, 'Turn Up the Heat on Your Earnings: Make Money from Home with Carolina Reaper Recipes', 'Online income generation, Earn money from home online, Ways to make money online', '[\"Introduction: Stimulate Your Earnings with Carolina Reaper Recipes\",\"Exploring the Path of Online Income Generation\",\"Turning Passion into Profit: Earning Money from Home with Carolina Reaper Recipes\",\"Understanding the Basics: Ways to Make Money Online\",\"Creating a Digital Presence: Building Your Online Platform\",\"Marketing Your Home-Based Cooking Skills\",\"Mastering the Art of Online Selling and Revenue Generation\",\"Pro Tips for Maximising Profits from Carolina Reaper Recipes\",\"Quenching the Market\'s Heat: Standing Out in the Online Food Business\",\"Consistently Earning From Home: Strategies for Long-term Success\",\"Concluding Thoughts: Ignite Your Home-Based Business Venture\"]', NULL, '**', 1, 1, 1, NULL, '2025-04-22 15:47:43', '2025-04-22 15:47:46', NULL, '133', NULL, NULL),
(3, 9, 'Optimal Online Income Generation Strategies for Inexperienced Users', 'Generate income online from home, Solutions for making money online, Online income generation strategies, Top methods to make money on the internet', '[\"Introduction to Online Income Generation\",\"Exploring Ways to Generate Income Online from Home\",\"Solutions for Making Money Online: A Guide to Virtual Profits\",\"Breaking Down Various Online Income Generation Strategies\",\"Considering the Top Methods to Make Money on the Internet\",\"Simple Strategies for Newbies on Earning Online\",\"A Look at High-Potential Online Platforms for Income Generation\",\"Proven Techniques for Maximising Your Online Income\",\"Mistakes Inexperienced Users Should Avoid for Smooth Online Income Generation\",\"Success Stories: From Inexperience to Proficient Online Earners\",\"Understanding the Potential and Risks of Online Money-Making\",\"Developing a Sustainable Strategy for Online Income Generation\",\"Conclusion: Turning Your Online Presence into a Revenue Stream\"]', NULL, '**', 1, 1, 1, NULL, '2025-05-03 14:07:39', '2025-05-03 14:07:41', NULL, '138', NULL, NULL),
(4, 12, 'Best Online Business Opportunities: Reinvent Your Income', 'Work from home jobs, Online money making ideas, Easy ways to make money online, Best online business opportunities', '[\"Introduction to Online Business Opportunities\",\"The Rising Demand for Work From Home Jobs\",\"Exploring Various Online Money Making Ideas\",\"Easy Ways to Make Money Online: A Beginner\\u2019s Guide\",\"Understanding the Pros and Cons of Online Business Opportunities\",\"Maximizing Income through Online Business Opportunities\",\"Adopting the Right Strategy for Online Business Success\",\"Success Stories: Lessons to Learn from Successful Onlinepreneurs\",\"Preventing Scams: Pitfalls to Avoid in Online Business\",\"Conclusion: Reinventing Your Income with Online Business Opportunities\"]', NULL, '**Introduction to Online Business Opportunities**\n\nThe advent of the internet has significantly enhanced entrepreneurial possibilities globally. Today, thousands of people are tapping into online business opportunities to supplement their incomes or shift entirely from traditional jobs. Some online ventures require general skills and minimal startup capital, making them accessible to a vast majority. The opportunity to be your own boss, work flexibly, and potentially earn well is too attractive for most people to pass up.\n\n**The Rising Demand for Work From Home Jobs**\n\nEmbedding technology in virtually all aspects of life has created numerous work-from-home opportunities. The COVID-19 pandemic has also contributed to this trend by forcing organizations to rethink their operation strategies. Traditional office-bound roles are being substituted with remote positions as companies try to save on overhead costs and enhance employee satisfaction. This paradigm shift has resulted in a surge in the demand for work-from-home jobs and self-employment through online ventures.\n\n**Exploring Various Online Money Making Ideas**\n\nThere are countless ways to make money online. Content creation on platforms like YouTube, Instagram, and blogs can generate significant income through ads, sponsorships, and partnerships. There\'s also e-commerce, where you can sell items directly to consumers through an online store. Some individuals opt to offer freelance services - like writing, graphic design, or virtual assistance - to businesses that prefer contract-based employees. Additionally, others invest in digital assets, do affiliate marketing, sign up for paid online surveys, tutor online, among many other ventures.\n\n**Easy Ways to Make Money Online: A Beginner’s Guide**\n\nStarting an online business can seem daunting to beginners. It\'s essential to begin by identifying your skills and interests. If you\'re great at crafting engaging stories, consider blogging or freelance writing. Enjoy making things? Perhaps opening an Etsy shop could work for you. Once you\'ve identified your niche, research thoroughly on how to monetize it. Following experts in your chosen field and enrolling in online courses can be incredibly beneficial. Remember, success won\'t come overnight. Patience and consistency are key.\n\n**Understanding the Pros and Cons of Online Business Opportunities**\n\nWhile the idea of owning an online business is undoubtedly attractive, it\'s equally important to consider its downsides. On the plus side, operating a digital enterprise offers flexibility unmatched by traditional jobs. It eliminates long commutes, allows you to set your working hours, and often involves doing what you love. However, it also comes with several challenges. It might take time before you start turning a profit. And because you’re your own boss, you must be self-driven and disciplined. Plus, the online world can be unpredictable - trends change swiftly, and competition is tough.\n\n**Maximizing Income through Online Business Opportunities**\n\nThe key to maximizing income in online ventures lies in diversification. Don’t put all your eggs into one basket; instead, combine multiple approaches. You could maintain a blog while offering freelance writing services or selling handmade items in an online shop. As your business grows, continually evaluate and adjust your strategies based on your emission patterns and market trends. Also, don\'t underestimate the power of networking. Building connections with other entrepreneurs can lead to partnerships, mentorship, and new opportunities.\n\n**Adopting the Right Strategy for Online Business Success**\n\nYour business strategy should align with your chosen online venture. This plan sets the course of action required to achieve your financial goals. Depending on the type of online business, this could involve investing in marketing campaigns, engaging in consistent content creation, enhancing your SEO practices, or scaling up production. Remember, the strategy that works for one may not work for another - maintaining a flexible approach is always wise.\n\n**Success Stories: Lessons to Learn from Successful Onlinepreneurs**\n\nAnalyzing the journeys of successful online entrepreneurs can provide valuable insights and inspiration. Take Jeff Bezos, for instance, who revolutionized e-commerce through Amazon, or Jenna Kutcher, who became a millionaire by sharing her knowledge and experiences via a podcast. Their stories show us the importance of innovation, resilience, and visualizing long-term goals.\n\n**Preventing Scams: Pitfalls to Avoid in Online Business**\n\nUnfortunately, scams are rife in the online business world. It\'s crucial to exercise due diligence before investing in any opportunity. Avoid ventures that promise quick riches without much effort, or those that require you to pay before getting jobs. Moreover, always research thoroughly before engaging in new business opportunities. Check customer reviews, verify the credibility of partners, and seek legal counsel when necessary.\n\n**Conclusion: Reinventing Your Income with Online Business Opportunities**\n\nIn conclusion, the cyber world is teeming with endless business opportunities for those willing to venture. While making money online requires grit, resolve, and strategic planning, the rewards can be massive, providing not just financial freedom but also a more flexible lifestyle. Whether you\'re seeking an escape from the 9-5 grind or looking to supplement your income, reinventing your income with online business opportunities might be just the ticket you need.', 789, 1, 1, NULL, '2025-05-03 20:38:30', '2025-05-03 20:39:09', NULL, '109', NULL, NULL),
(5, 13, 'Getting the Most Out of Microsoft: How to Download Office 2024 Pro Plus LTSE', 'Get Office 2024 Pro Plus LTSE, How to download Office 2024 Pro Plus LTSE, New Microsoft Office Pro Plus 2024 download', '[\"Introduction to Microsoft\'s New Offering: Office 2024 Pro Plus LTSE\",\"Understanding What Office 2024 Pro Plus LTSE Brings to the Table\",\"How to Get Office 2024 Pro Plus LTSE: Your Step-by-step Guide\",\"Simplifying the Process: How to Download Office 2024 Pro Plus LTSE\",\"Troubleshooting Common Issues in Downloading Office 2024 Pro Plus LTSE\",\"Make the Most of New Features in Microsoft Office Pro Plus 2024\",\"How New Microsoft Office Pro Plus 2024 Enhances Your Productivity\",\"Final Thoughts on Office 2024 Pro Plus LTSE: Is it Worth Downloading?\"]', NULL, '**Introduction to Microsoft\'s New Offering: Office 2024 Pro Plus LTSE**\n\nAs a global leader in software development, Microsoft continues to innovate and improve its productivity solutions for businesses and individuals. This commitment to constant enhancement is evident in its latest offering, the Office 2024 Pro Plus Long Term Servicing Edition (LTSE). Targeted at businesses seeking stability and robust functionality, Office 2024 Pro Plus LTSE promises numerous new features and improvements over its predecessors.\n\n**Understanding What Office 2024 Pro Plus LTSE Brings to the Table**\n\nOffice 2024 Pro Plus LTSE comes packed with a range of features aimed at optimizing productivity and enhancing user experience. It integrates all the software you expect from an Office Suite- Word, Excel, Powerpoint, Outlook, and more. Yet the upgrades don\'t just stop at the expected. The Pro Plus LTSE brings advanced security enhancements, accessibility upgrades, and deep integration with cloud computing along with a promise of long-term support and regular updates. All of these additions make for an upgraded Microsoft Office Suite that is designed to meet the newest challenges facing today\'s workforce.\n\n**How to Get Office 2024 Pro Plus LTSE: Your Step-by-step Guide**\n\nTo download Office 2024 Pro Plus LTSE, visit the official Microsoft website and navigate to the Office Products section. You may need to create or use an existing Microsoft account. Once in the Office Products section, find the Office 2024 Pro Plus LTSE package. Click \"Buy\" and follow the on-screen instructions to complete the purchase by providing the necessary payment details. After the transaction is successful, you will have access to download the Office 2024 Pro Plus LTSE installation files.\n\n**Simplifying the Process: How to Download Office 2024 Pro Plus LTSE**\n\nAfter successful purchase, you should automatically be redirected to the \"Install Office\" page. To download and install the Office 2024 Pro Plus LTSE, click on the \"Install\" button to begin the process. Run the executable file and follow the on-screen instructions, accepting all necessary terms of agreement and choosing your desired settings. Finally, wait for the installation to complete and restart your device if necessary.\n\n**Troubleshooting Common Issues in Downloading Office 2024 Pro Plus LTSE**\n\nThere may be instances where you encounter difficulties while downloading or installing the software. Some common issues include failed downloads, errors during installation, and problems with account verification. In most cases, these issues can be resolved by verifying your internet connection, checking for any firewall restrictions, ensuring your device meets the system requirements, and double-checking your account verification process. If problems persist, you can reach out to Microsoft support for further assistance.\n\n**Make the Most of New Features in Microsoft Office Pro Plus 2024**\n\nOffice 2024 Pro Plus LTSE offers advanced features like cloud-integrated applications that make collaboration easier than ever. Utilize OneDrive to seamlessly store and share documents with your team. Explore new PowerPoint features that transform your presentations into engaging experiences. With Excel, explore new data visualization methods and advanced analytic tools.\n\n**How New Microsoft Office Pro Plus 2024 Enhances Your Productivity**\n\nThe Office 2024 Pro Plus LTSE is designed to streamline your work process, improve collaboration, and protect sensitive information. Its cloud integration offers real-time collaboration, document sharing capabilities, and seamless synchronization across devices. Advanced security protocols protect your sensitive data and offer solution-wide encryption and multi-factor authentication. Coupled with long-term support and regular updates, this new offering promises seamless efficiency and productivity enhancement.\n\n**Final Thoughts on Office 2024 Pro Plus LTSE: Is it Worth Downloading?**\n\nThe short answer is - yes. From enhanced features to a robust support system, the Office 2024 Pro Plus LTSE consolidates Microsoft\'s best services into a single package. It is ideally suited to any individual or organization aiming for improved productivity, enhanced collaboration, and a secure digital work environment. Though the process may seem a bit complex, it ultimately offers a robust, efficient productivity tool designed to cater for contemporary digital workspace needs. Ultimately, the value you stand to gain from Office 2024 Pro Plus LTSE far outweighs any initial setup concerns.', 651, 1, 1, NULL, '2025-05-03 22:39:17', '2025-05-03 22:39:42', NULL, '130', NULL, NULL),
(6, 14, 'Upgrading Your System? Check Out Our Windows 11 Home Review', 'Windows 11 Home Review', '[\"Introduction to Windows 11 Home\",\"Overview of Windows 11 Home\",\"The Concept behind Windows 11 Home Development\",\"Breaking Down the Windows 11 Home Review\",\"Eye-Catching Features of Windows 11 Home\",\"Assessing the Performance of Windows 11 Home\",\"Usability and Flexibility of Windows 11 Home\",\"Security Updates in Windows 11 Home\",\"Comparison: Windows 11 Home vs Other OS\",\"Navigating the Interface of Windows 11 Home\",\"The Visual Appeal of Windows 11 Home\",\"Cost Implication of Upgrading to Windows 11 Home\",\"Pros and Cons of Windows 11 Home\",\"Final Takeaways from Our Windows 11 Home Review\",\"Why should you consider Upgrading to Windows 11 Home?\",\"Conclusion: Is Windows 11 Home worth the Upgrade?\"]', NULL, '**', 1, 3, 5, NULL, '2025-05-04 14:37:25', '2025-05-11 16:01:24', NULL, '142', NULL, NULL),
(7, 15, 'Expert Advice on How to Successfully Earn Income Online', 'Online money making ideas, Online earning opportunities, Ways to generate online income, Earn income online advice', '[\"Introduction to Successfully Earning Income Online\",\"The Rise of Online Earning Opportunities\",\"Cracking the Code: Online Money Making Ideas\",\"Exploration of Different Ways to Generate Online Income\",\"Step by Step Guide for a Successful Online Income Journey\",\"Expert Tips to Avoid Common Pitfalls in Online Earning\",\"Utilizing Skills and Hobbies: Unique Ways to Generate Online Income\",\"Staying Current: How to Keep up with Emerging Online Earning Opportunities\",\"Financial Independence: How to Sustain and Grow Your Online Income\",\"Conclusion: Consolidating Your Earn Income Online Advice for Success\"]', NULL, NULL, 0, 1, 7, NULL, '2025-05-11 16:51:38', '2025-05-11 16:51:38', NULL, '111', NULL, NULL),
(8, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\"Understanding the Importance of Professional Samsung Reparatur\",\"Breaking Down the Process of Samsung Reparatur\",\"Why Choose Professional Samsung Reparatur?\",\"Exploring the Range of Services at Samsung Reparatur\",\"Samsung reparatur vs DIY Repairs: The Better Option\",\"Key Reasons to Trust Your Samsung Repair Needs to Experts\",\"How Samsung reparatur Ensures Your Device\'s Longevity\",\"Quality Assurance With Professional Samsung reparatur\",\"Case Study: Successful Repairs at Samsung reparatur\",\"Safeguarding Your Investment: The Value of Professional Repairs\",\"Samsung reparatur: Providing a Hassle-free Repair Experience\"]', NULL, '**', 1, 4, 9, NULL, '2025-05-12 01:44:19', '2025-05-12 01:46:34', NULL, '115', NULL, NULL),
(9, 17, 'Affordable Solutions for your iPhone Repair Needs', 'iphone repair', '[\"Introduction to Affordable iPhone Repair Solutions\",\"Understanding the Demands of iPhone Repair\",\"Faced with an iPhone Damage? Consider These Affordable Solutions\",\"Economical Fixes for Common iPhone Problems\",\"Choosing the Perfect Repair Solution for Your iPhone\",\"iPhone Repair: What are Your Affordable Options?\",\"Hacks to Reduce iPhone Repair Costs\",\"Tips on Saving Money on iPhone Repairs\",\"Top Affordable Solutions for iPhone Screen Repairs\",\"The Cost-Efficient Guide to iPhone Battery Replacement\",\"Managing iPhone Repair Costs: A User\\u2019s Perspective\",\"From Small Fixes to Major Repairs: Economical iPhone Solutions\",\"DIY iPhone Repair: Is it Really a Cheaper Alternative?\",\"Ensuring Quality While Cutting iPhone Repair Costs\",\"Conclusion: Making the Most of Affordable iPhone Repair Solutions\"]', NULL, '**', 1, 1, 9, NULL, '2025-05-13 04:03:13', '2025-05-13 04:03:14', NULL, '139', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_blog_wizard_article_logs`
--

CREATE TABLE `ai_blog_wizard_article_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `ai_blog_wizard_id` int DEFAULT NULL,
  `ai_blog_wizard_article_id` int DEFAULT NULL,
  `subscription_history_id` int DEFAULT NULL,
  `completion_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `prompt_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `total_words` bigint NOT NULL DEFAULT '0',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `input_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_blog_wizard_article_logs`
--

INSERT INTO `ai_blog_wizard_article_logs` (`id`, `user_id`, `ai_blog_wizard_id`, `ai_blog_wizard_article_id`, `subscription_history_id`, `completion_tokens`, `prompt_tokens`, `total_words`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `input_prompt`) VALUES
(1, 1, 2, 1, NULL, NULL, '151', 1, NULL, NULL, '2025-04-21 23:13:48', '2025-04-21 23:13:48', NULL, NULL),
(2, 1, 2, 1, NULL, NULL, '151', 1, NULL, NULL, '2025-04-21 23:14:05', '2025-04-21 23:14:05', NULL, NULL),
(3, 1, 2, 1, NULL, NULL, '125', 1, NULL, NULL, '2025-04-21 23:14:38', '2025-04-21 23:14:38', NULL, NULL),
(4, 1, 2, 1, NULL, NULL, '125', 1, NULL, NULL, '2025-04-21 23:14:50', '2025-04-21 23:14:50', NULL, NULL),
(5, 1, 6, 2, NULL, NULL, '133', 1, NULL, NULL, '2025-04-22 15:47:46', '2025-04-22 15:47:46', NULL, NULL),
(6, 1, 9, 3, NULL, NULL, '138', 1, NULL, NULL, '2025-05-03 14:07:41', '2025-05-03 14:07:41', NULL, NULL),
(7, 1, 12, 4, NULL, NULL, '109', 789, NULL, NULL, '2025-05-03 20:39:09', '2025-05-03 20:39:09', NULL, NULL),
(8, 1, 13, 5, NULL, NULL, '130', 651, NULL, NULL, '2025-05-03 22:39:42', '2025-05-03 22:39:42', NULL, NULL),
(9, 5, 14, 6, 5, NULL, '142', 1, NULL, NULL, '2025-05-11 16:01:24', '2025-05-11 16:01:24', NULL, NULL),
(10, 9, 16, 8, 12, NULL, '115', 15, NULL, NULL, '2025-05-12 01:44:21', '2025-05-12 01:44:21', NULL, NULL),
(11, 9, 16, 8, 12, NULL, '115', 14, NULL, NULL, '2025-05-12 01:45:02', '2025-05-12 01:45:02', NULL, NULL),
(12, 9, 16, 8, 12, NULL, '115', 1, NULL, NULL, '2025-05-12 01:45:44', '2025-05-12 01:45:44', NULL, NULL),
(13, 9, 16, 8, 12, NULL, '115', 1, NULL, NULL, '2025-05-12 01:46:34', '2025-05-12 01:46:34', NULL, NULL),
(14, 9, 17, 9, 12, NULL, '139', 1, NULL, NULL, '2025-05-13 04:03:14', '2025-05-13 04:03:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_blog_wizard_images`
--

CREATE TABLE `ai_blog_wizard_images` (
  `id` bigint UNSIGNED NOT NULL,
  `ai_blog_wizard_id` int NOT NULL,
  `title` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `value` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `resolution` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `storage_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'local'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_blog_wizard_images`
--

INSERT INTO `ai_blog_wizard_images` (`id`, `ai_blog_wizard_id`, `title`, `value`, `resolution`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `storage_type`) VALUES
(1, 1, 'Top Make Money Online Strategies for Successful Income-1', 'images/wQJYhwcRhC.png', '512x512', 1, NULL, '2025-04-21 17:46:46', '2025-04-21 17:46:46', NULL, 'local'),
(2, 2, 'Turn Your Internet Surfing into Cash: How to Make Money Online-1', 'images/9flkYztKgH.png', '512x512', 1, NULL, '2025-04-21 23:13:08', '2025-04-21 23:13:08', NULL, 'local'),
(3, 5, 'Mastering Earn Money Online Methods: A Comprehensive Guide to Making Money Online-1', 'images/1y4FLMF4xT.png', '512x512', 1, NULL, '2025-04-22 13:31:36', '2025-04-22 13:31:36', NULL, 'local'),
(4, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income-1', 'images/hUUVkEthsR.png', '512x512', 1, NULL, '2025-05-03 18:12:20', '2025-05-03 18:12:20', NULL, 'local'),
(5, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs-1', 'images/DVsJjnmMVP.png', '1024x1024', 9, NULL, '2025-05-12 01:41:06', '2025-05-12 01:41:06', NULL, 'local');

-- --------------------------------------------------------

--
-- Table structure for table `ai_blog_wizard_key_words`
--

CREATE TABLE `ai_blog_wizard_key_words` (
  `id` bigint UNSIGNED NOT NULL,
  `ai_blog_wizard_id` int NOT NULL,
  `topic` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `values` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `volume` bigint DEFAULT NULL,
  `kd` bigint DEFAULT NULL,
  `traffic` bigint DEFAULT NULL,
  `completion_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `prompt_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `total_words` bigint NOT NULL DEFAULT '0',
  `num_of_copies` int NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `input_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_blog_wizard_key_words`
--

INSERT INTO `ai_blog_wizard_key_words` (`id`, `ai_blog_wizard_id`, `topic`, `values`, `volume`, `kd`, `traffic`, `completion_tokens`, `prompt_tokens`, `total_words`, `num_of_copies`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `input_prompt`) VALUES
(1, 1, 'make money online', '[\"Make money online strategies\",\"Effective ways to earn online\",\"Profitable online money making\",\"Easy online income strategies\",\"Reliable methods for online earning\"]', NULL, NULL, NULL, '35', '47', 35, 1, 1, NULL, '2025-04-21 17:44:52', '2025-04-21 17:44:52', NULL, NULL),
(2, 2, 'make money online', '[\"Make Money Online\",\"Earn income online\",\"Profitable online jobs\",\"Easy ways to make money online\",\"Online money-making ideas\",\"Home-based online earnings\",\"Effective online profit strategies\",\"Passive income online\",\"Work from home online income\",\"Quick methods to earn online\",\"Secure online money-making\",\"Online financial gain tips\",\"Profit from online platforms\",\"Legitimate online earning methods\",\"Increase your income online\"]', NULL, NULL, NULL, '94', '47', 94, 1, 1, NULL, '2025-04-21 23:12:15', '2025-04-21 23:12:15', NULL, NULL),
(3, 3, 'make money online', '[\"make money online\",\"earn money online\",\"online income strategies\",\"profitable online businesses\",\"online money making tips\",\"internet income generation\",\"digital entrepreneurship\",\"online financial freedom\",\"ways to earn online\",\"passive income online\",\"online profit opportunities\",\"start online business home\",\"lucrative online earnings\",\"make money through internet\",\"earning online passive income\"]', NULL, NULL, NULL, '85', '47', 85, 1, 1, NULL, '2025-04-22 13:24:26', '2025-04-22 13:24:26', NULL, NULL),
(4, 4, 'make money online', '[\"earn money online tips\"]', NULL, NULL, NULL, '7', '47', 7, 1, 1, NULL, '2025-04-22 13:28:20', '2025-04-22 13:28:20', NULL, NULL),
(5, 5, 'make money online', '[\"earn money online strategies\",\"Best ways to make money online\",\"Earn money online methods\"]', NULL, NULL, NULL, '23', '141', 23, 3, 1, NULL, '2025-04-22 13:30:08', '2025-04-22 13:30:42', NULL, NULL),
(6, 6, 'carolina reaper pepper recipes', '[\"Make money online\",\"Online income generation\",\"Earn money from home online\",\"Ways to make money online\",\"Internet money making\",\"Online business for income\",\"Easy ways to earn money online\",\"Home-based online jobs\",\"Profitable online ventures\",\"Make cash online\",\"Online earning techniques\",\"Generate income online\",\"Financial gain through online business\",\"Internet-based money making methods\",\"Effective ways to make money online\",\"Online financial income\",\"Carolina Reaper Pepper Recipes\",\"Spicy Recipes with Carolina Reaper\",\"Cooking with Carolina Reaper Peppers\",\"How to Use Carolina Reaper in Recipes\",\"Recipes Featuring Carolina Reaper Peppers\",\"Carolina Reaper Dishes\",\"Carolina Reaper Pepper Meal Ideas\",\"Recipes for Carolina Reaper Lovers\",\"Spicy Carolina Reaper Creations\",\"Innovative Carolina Reaper Recipes\",\"Carolina Reaper Pepper Recipe Guide\",\"Using Carolina Reaper in Dishes\",\"Flavorful Carolina Reaper Pepper Recipes\",\"Creative Recipes with Carolina Reaper\",\"Step by Step Carolina Reaper Recipes\",\"Deliciously Spicy Carolina Reaper Recipes\"]', NULL, NULL, NULL, '230', '97', 230, 2, 1, NULL, '2025-04-22 15:33:56', '2025-04-22 15:40:26', NULL, NULL),
(7, 7, 'make money online', '[\"make money online\",\"earn money from internet\",\"online income opportunities\",\"passive income online\",\"online money making strategies\",\"how to make money online\",\"earn extra cash online\",\"ways to make money online\",\"online earning methods\",\"profitable online businesses\"]', NULL, NULL, NULL, '60', '47', 60, 1, 1, NULL, '2025-04-27 17:54:28', '2025-04-27 17:54:28', NULL, NULL),
(8, 8, 'make money online', '[\"Easy ways to make money online\",\"Trusted online money making sites\",\"Ways to earn income online\",\"Strategies for online earning\",\"Legitimate online money making\",\"Profitable ways to make money online\",\"High-paying online gigs\",\"Income generation through online platforms\",\"Boost income by making money online\",\"Guide to making money online\",\"How to secure online earnings\",\"Maximize online income\",\"Online channels for money making\",\"Increasing profitability through online jobs\",\"Reliable methods to earn money online\"]', NULL, NULL, NULL, '112', '47', 112, 1, 1, NULL, '2025-04-27 17:56:21', '2025-04-27 17:56:21', NULL, NULL),
(9, 9, 'make money online', '[\"Easy ways to make money online\",\"Profitable online money-making tactics\",\"Effective strategies for online earnings\",\"Tips to earn money online safely\",\"Generate income online from home\",\"Best techniques to make money online\",\"Guide to earning income on the internet\",\"Solutions for making money online\",\"Proven methods to make money online\",\"Maximize profits with online earnings\",\"Successful online money-making solutions\",\"Online income generation strategies\",\"Legitimate ways to earn money online\",\"Top methods to make money on the internet\",\"Secure online earning techniques\"]', NULL, NULL, NULL, '120', '47', 120, 1, 1, NULL, '2025-05-03 14:06:24', '2025-05-03 14:06:24', NULL, NULL),
(10, 10, 'make money online', '[\"Make money online\",\"Earn income on the internet\",\"Online money making strategies\",\"Passive income online\",\"Ways to earn money online\",\"Online business to make money\",\"Profitable online jobs\",\"Internet-based income opportunities\",\"Legitimate ways to make money online\",\"Make money from home online\",\"How to generate income online\",\"Online earning methods\",\"Online income through freelancing\",\"Affiliate marketing online income\",\"Digital investment for online income\"]', NULL, NULL, NULL, '101', '47', 101, 1, 1, NULL, '2025-05-03 18:07:42', '2025-05-03 18:07:42', NULL, NULL),
(11, 11, 'make money online', '[\"Make money online\",\"Earning online income\",\"Online money making strategies\",\"Online business profit\",\"Profitable online ventures\",\"Exploring online income\",\"Generating income online\",\"Secure online earnings\",\"Easy ways to make money online\",\"Making cash digitally\",\"Online entrepreneurship\",\"Web-based income methods\",\"Internet money making tactics\",\"Strategies for earning online\",\"Simple methods to earn online\",\"make money online\",\"online income opportunities\",\"ways to earn money online\",\"online money making methods\",\"best online earning platforms\",\"authentic ways to make money online\",\"profit online from home\",\"increase online earnings\",\"online financial growth\",\"online money-making strategies\",\"passive online income\",\"benefits of online earning\",\"grow wealth online\",\"internet income generation\",\"successful online money making\"]', NULL, NULL, NULL, '178', '94', 178, 2, 1, NULL, '2025-05-03 18:11:25', '2025-05-03 18:11:39', NULL, NULL),
(12, 12, 'make money online', '[\"Make money online\",\"Online passive income\",\"Work from home jobs\",\"Online money making ideas\",\"Easy ways to make money online\",\"Best online business opportunities\",\"Online surveys for cash\",\"Affiliate marketing online\",\"How to make money with a blog\",\"Freelance jobs from home\",\"Earn money with forex trading online\",\"Online tutoring jobs\",\"Earn money online fast\",\"Make money with online marketing\",\"Online investment opportunities\",\"Make Money Online\",\"Online Money Making Strategies\",\"Earn Cash Online\",\"Online Profitable Ventures\",\"Making Income Online\",\"Viable Online Jobs\",\"Work From Home Online\",\"Internet-based Income\",\"Digital Money Making Techniques\",\"Profitable Internet Businesses\",\"Generating Income Online\",\"Remote Online Jobs\",\"Online Freelance Earnings\",\"Earning Online Passive Income\",\"Internet Entrepreneurship\",\"Make Money Online\",\"Earning Cash Online\",\"Internet Money Making\",\"Work from Home Online\",\"Profitable Online Ventures\",\"Easy Ways to Make Money Online\",\"Secure Online Earnings\",\"Online Business Profits\",\"Digital Revenue Streams\",\"Profitable Online Business Ideas\",\"Earn Extra Income Online\",\"Maximize Online Profits\",\"Generate Money Online\",\"Effective Ways to Make Money Online\",\"Quick Online Money Making Ways\",\"make money online\",\"earn money online\",\"ways to make money online\",\"make money online fast\",\"online money making ideas\",\"legitimate ways to make money online\",\"earn cash online\",\"online income opportunities\",\"making money on the internet\",\"online earning methods\",\"intenet money making guides\",\"generate income online\",\"profitable online businesses\",\"online entrepreneurial money making\",\"passive online income\"]', NULL, NULL, NULL, '368', '188', 368, 4, 1, NULL, '2025-05-03 20:19:57', '2025-05-03 20:37:03', NULL, NULL),
(13, 13, 'Download Office 2024 Pro Plus LTSE', '[\"Download Office 2024 Pro Plus LTSE\",\"Get Office 2024 Pro Plus LTSE\",\"Office 2024 Pro Plus LTSE download free\",\"Free download of Office 2024 Pro Plus LTSE\",\"How to download Office 2024 Pro Plus LTSE\",\"Download Office Pro Plus LTSE 2024\",\"Office 2024 Pro Plus Long-Term Servicing Edition\",\"New Microsoft Office Pro Plus 2024 download\",\"Official Office 2024 Pro Plus LTSE download\",\"Complete Office 2024 Pro Plus LTSE suite download\",\"Fast Download for Office 2024 Pro Plus LTSE\",\"Secure download Office 2024 Pro Plus LTSE\",\"One-click download Office 2024 Pro Plus LTSE\",\"Download latest Office 2024 Pro Plus LTSE\",\"Download Office 2024 Pro Plus LTSE from official site\"]', NULL, NULL, NULL, '186', '53', 186, 1, 1, NULL, '2025-05-03 22:37:22', '2025-05-03 22:37:22', NULL, NULL),
(14, 14, 'Windows 11 Home', '[\"Windows 11 Home Features\",\"Windows 11 Home Update\",\"Upgrade to Windows 11 Home\",\"Windows 11 Home Download\",\"Windows 11 Home Review\",\"System Requirements Windows 11 Home\",\"Windows 11 Home Installation Guide\",\"Difference between Windows 10 and Windows 11 Home\",\"Windows 11 Home Compatibility\",\"Benefits of Windows 11 Home\"]', NULL, NULL, NULL, '80', '48', 80, 1, 5, NULL, '2025-05-04 14:35:45', '2025-05-04 14:35:45', NULL, NULL),
(15, 15, 'make money online', '[\"Make money online strategies\",\"Earning money online tips\",\"Methods to make money online\",\"Online money making ideas\",\"Tips to earn online income\",\"Online earning opportunities\",\"Make cash online techniques\",\"Ways to generate online income\",\"Earn income online advice\",\"Guide for making money online\"]', NULL, NULL, NULL, '66', '47', 66, 1, 7, NULL, '2025-05-11 16:49:47', '2025-05-11 16:49:47', NULL, NULL),
(16, 16, 'Samsung repair', '[\"Samsung Repair Service\",\"Samsung Phone Repair\",\"Galaxy Screen Repair\",\"Professional Samsung Repair\",\"Samsung Display Fix\",\"Samsung Battery Replacement\",\"Affordable Samsung Repair\",\"Local Samsung Phone Service\",\"Reliable Samsung Repair\",\"Authorized Samsung Repair Center\",\"Fast Samsung Phone Fix\",\"Samsung Electronics Repair\",\"Samsung Mobile Phone Repair\",\"Expert Samsung Repair\",\"Quality Samsung Repair Solutions\"]', NULL, NULL, NULL, '84', '46', 84, 1, 9, NULL, '2025-05-12 01:38:34', '2025-05-12 01:38:34', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_blog_wizard_outlines`
--

CREATE TABLE `ai_blog_wizard_outlines` (
  `id` bigint UNSIGNED NOT NULL,
  `ai_blog_wizard_id` int NOT NULL,
  `title` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `keywords` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `values` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci COMMENT 'keep as encoded array',
  `completion_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `prompt_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `total_words` bigint NOT NULL DEFAULT '0',
  `num_of_copies` int NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `input_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_blog_wizard_outlines`
--

INSERT INTO `ai_blog_wizard_outlines` (`id`, `ai_blog_wizard_id`, `title`, `keywords`, `values`, `completion_tokens`, `prompt_tokens`, `total_words`, `num_of_copies`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `input_prompt`) VALUES
(1, 1, 'Top Make Money Online Strategies for Successful Income', 'Make money online strategies, Profitable online money making, Easy online income strategies', '[\"Introduction: Understanding Online Income Strategies\",\n\"Make Money Online Strategies: Where to Start?\",\n\"Profitable Online Money Making: Finding the Right Fit\",\n\"Exploring Top Online Money Making Platforms\",\n\"Turning Skills Into Cash: Ways to Make Money Online\",\n\"Easy Online Income Strategies: Work Less, Earn More\",\n\"Affiliate Marketing: A Tried and Tested Online Money Making Strategy\",\n\"Online Trading and Investment: High Reward Money Online Strategies\",\n\"Freelancing: A Flexible Path to Profitable Online Money Making\",\n\"The Power of Blogging and Content Creation for Easy Online Income\",\n\"Selling Online: E-commerce and Dropshipping as Money Making Strategies\",\n\"Online Courses and Tutoring: Educate and Earn\",\n\"The Role of Social Media in Successful Online Money Making\",\n\"Online Gaming and E-Sports: A Surprising Strategy to Make Money Online\",\n\"Avoiding Scams: Ensuring Your Online Money Making Strategy is Legitimate\",\n\"Cybersecurity and Privacy: Protecting Your Online Income\",\n\"Conclusion: Optimize Your Make Money Online Strategies\"]', '143', '70', 143, 1, 1, NULL, '2025-04-21 17:47:18', '2025-04-21 17:47:18', NULL, NULL),
(2, 1, 'Top Make Money Online Strategies for Successful Income', 'Make money online strategies, Profitable online money making, Easy online income strategies', '[\n\"Introduction to Top Make Money Online Strategies\",\n\"Defining Make Money Online Strategies\",\n\"The Role of the Internet in Successful Income\",\n\"Different Make Money Online Strategies\",\n\"Profitable Online Money Making: The Big Picture\",\n\"Exploring Various Profitable Online Money Making Techniques\",\n\"Evaluating Your Online Money Making Strategy\",\n\"Converting Strategies into Easy Online Income\",\n\"The Art of Making Easy Online Income\",\n\"Advantages of Profiting from Online Strategies\",\n\"Practical Examples of Successful Online Income Strategies\",\n\"Common Mistakes to Avoid in Online Money Making\",\n\"Turning your Online Income Strategies into a Full-Time Business\",\n\"Upgrade Your Skills for Effective Online Money Making\",\n\"Insider Tips for a Successful Online Income\",\n\"Conclusion: Enhancing your Make Money Online Strategies\"\n]', '110', '70', 110, 1, 1, NULL, '2025-04-21 17:47:18', '2025-04-21 17:47:18', NULL, NULL),
(3, 1, 'Top Make Money Online Strategies for Successful Income', 'Make money online strategies, Profitable online money making, Easy online income strategies', '[\"Introduction to Make Money Online Strategies\",\n\"Understanding Profitable Online Money Making\",\n\"Decoding Easy Online Income Strategies\",\n\"Top Make Money Online Strategies for 2021\",\n\"Optimizing Your Strategy for Successful Income Online\",\n\"In-depth Look at Profitable Online Money Making Ventures\",\n\"Achieving Success with Easy Online Income Strategies\",\n\"Real-Life Success Stories of Make Money Online Strategies\",\n\"Exploring Less Known Make Money Online Strategies\",\n\"Maximizing Your Profits through Online Money Making\",\n\"Avoiding Pitfalls in Easy Online Income Strategies\",\n\"How to Scale Your Make Money Online Strategies\",\n\"Strategy Comparison: Which Online Money Making Method is Best for You?\",\n\"The Future of Make Money Online Strategies\",\n\"Conclusion: Paving Your Way to Successful Online Income\"]', '107', '70', 107, 1, 1, NULL, '2025-04-21 17:47:18', '2025-04-21 17:47:18', NULL, NULL),
(4, 2, 'Turn Your Internet Surfing into Cash: How to Make Money Online', 'Make Money Online, Passive income online, Work from home online income', '[\"Introduction: The New Age of Making Money Online\",\n \"Understanding the Concept of Passive Income Online\",\n \"Prerequisites for Earning Work from Home Online Income\",\n \"Turn Your Web Browsing Into a Gold Mine: The How-To\",\n \"Top Ways to Make Money Online While Surfing the Internet\",\n \"The Convenience of Working from Home and Earning Online\",\n \"Dos and Don’ts of Earning Passive Income Online\",\n \"Trusted and Legitimate Sites to Make Money Online\",\n \"Tips and Tricks for Securing Stable Online Income\",\n \"Maintaining Work-Life Balance While Earning from Home Online\",\n \"Addressing Common Challenges in Earning Passive Money Online\",\n \"How to Avoid Scams and Ensure Secure Online Money Making\",\n \"Potential Earnings: How Much Money Can You Make Online?\",\n \"Success Stories: Real People Flourishing with Online Income\",\n \"Final Thoughts on Your Journey to Make Money Online\"]', '131', '73', 131, 1, 1, NULL, '2025-04-21 23:13:33', '2025-04-21 23:13:33', NULL, NULL),
(5, 2, 'Turn Your Internet Surfing into Cash: How to Make Money Online', 'Make Money Online, Passive income online, Work from home online income', '[\n\"Introduction to Making Money Online\",\n\"Understanding the Concept of Passive Income Online\",\n\"The Reality of Making Money Online: Identifying Scams vs Legitimate Opportunities\",\n\"Essential Steps to Start Earning Money Online\",\n\"Turning Your Internet Surfing into Cash: Techniques and Strategies\",\n\"Case Studies: Real-life Examples of People Who Make Money Online\",\n\"Various Avenues to Earn Passive Income Online\",\n\"Work from Home: Online Income Opportunities\",\n\"Tips and Tricks to Maximize your Online Income\",\n\"How to Maintain a Consistent Work from Home Online Income\",\n\"Creating a Balance: Combining Active and Passive Online Income\",\n\"Scaling Up: Taking your Online Income to the Next Level\",\n\"Success Stories: How Regular Internet Users Turned Their Surfing into Cash\"\n]', '110', '73', 110, 1, 1, NULL, '2025-04-21 23:13:33', '2025-04-21 23:13:33', NULL, NULL),
(6, 2, 'Turn Your Internet Surfing into Cash: How to Make Money Online', 'Make Money Online, Passive income online, Work from home online income', '[\n\"Introduction to Making Money Online\",\n\"The Concept of Passive Income Online: A Brief Overview\",\n\"Maximizing Your Internet Surfing: Turning It Into Cash\",\n\"Working from Home: The Modern Way to Earn\",\n\"Criteria for Selecting the Best Work from Home Online Opportunities\",\n\"Exploring Various Avenues to Make Money Online\",\n\"Refining your Skills for Successful Online Earning\",\n\"Tips and Tricks: Maximize Your Work From Home Online Income\",\n\"Detailed Case Studies: Success Stories of Online Income Earners\",\n\"Plentiful Possibilities: Passive Income Sources to Explore\",\n\"Debunking Common Myths about Making Money Online\",\n\"Practical Guides: Steps for Setting Up Your Online Business for Passive Income\",\n\"Maintaining Your Online Income Stream: Challenges and Solutions\",\n\"Conclusions: Turning Your Online Surfing Time into a Profitable Venture\"\n]', '117', '73', 117, 1, 1, NULL, '2025-04-21 23:13:33', '2025-04-21 23:13:33', NULL, NULL),
(7, 3, 'Turn Your Free Time into Profit: Make Money Online Now', 'make money online, earn money online', '[\"Introduction to Making Money Online\",\n\"Understanding the Concept of Making Money Online\",\n\"Exploring Different Ways to Earn Money Online\",\n\"Benefits of Making Money Online in Your Free Time\",\n\"Step-by-Step Guide to Start Earning Money Online\",\n\"Why Time Management is Essential in Online Money Making\",\n\"Proving Legitimacy: Avoiding Online Scams\",\n\"Maximizing Profit: Tips to Boost Your Online Earnings\",\n\"Tales of Success: Real People Making Real Money Online\",\n\"Ensuring Continuous Earnings: Sustaining Your Online Income\",\n\"Wrapping Up: Converting Free Time into Profit Online\"]', '81', '65', 81, 1, 1, NULL, '2025-04-22 13:25:36', '2025-04-22 13:25:36', NULL, NULL),
(8, 3, 'Turn Your Free Time into Profit: Make Money Online Now', 'make money online, earn money online', '[\"Introduction: Making Money Online in Your Spare Time\",\n \"Understanding the Basics: What Does It Mean to Make Money Online?\",\n \"The Profit-Driven Path: Different Ways to Earn Money Online\",\n \"Online Surveys and Reviews: A Quick Way to Earn Money Online\",\n \"Freelancing: Make Money Online with Your Skills\",\n \"Blogging and Affiliate Marketing: Potential Gold Mines for Earning Money Online\",\n \"Selling Products: Your Gateway to Making Money Online\",\n \"Online Tutoring and Courses: Earn Money by Sharing Knowledge\", \n \"Investing in Stocks and Cryptocurrencies: The Risk and Reward of Online Earning\",\n \"Ensuring Online Security: Safeguarding Your Online Earnings\",\n \"Dos and Don\'ts: Tips for a Successful Online Earning Experience\",\n \"Overcoming Challenges in Making Money Online\",\n \"Real Stories: Success Stories of People Who Make Money Online\",\n \"Conclusion: Turn Your Free Time into Profit Today\"]', '127', '65', 127, 1, 1, NULL, '2025-04-22 13:25:36', '2025-04-22 13:25:36', NULL, NULL),
(9, 3, 'Turn Your Free Time into Profit: Make Money Online Now', 'make money online, earn money online', '[\n\"Introduction to Making Money Online\",\n\"Understanding the Online Market\",\n\"Identifying Your Skills and Interests\", \n\"Leveraging Your Free Time to Earn Money Online\",\n\"Different Ways to Make Money Online\",\n\"Tips and Tricks to Maximise Profits Online\", \n\"Top Websites to Start Earning Online\",\n\"Using Social Media to Boost Online Income\",\n\"Learning from Successful Online Money Makers\",\n\"Potential Pitfalls & How to Navigate Them\", \n\"Managing Your Time - Balancing Work and Leisure\",\n\"Securing Your Online Finances\", \n\"Building a Sustainable Online Business Model\", \n\"Frequently Asked Questions about Making Money Online\", \n\"Conclusion: Translating Free Time into Profit\" \n]', '91', '65', 91, 1, 1, NULL, '2025-04-22 13:25:37', '2025-04-22 13:25:37', NULL, NULL),
(10, 4, 'Master the Art of Making Money Online with These Essential Earn Money Online Tips', 'earn money online tips', '[\n\"Introduction: The Potential of Earning Money Online\",\n\"Understanding Different Ways to Earn Money Online\",\n\"Essential Earn Money Online Tips to Embrace\",\n\"Detailed Analysis of Online Earning Methods\",\n\"How to Master the Skills for Earning Money Online\",\n\"Exploring the Best Online Platforms for Earning Money\",\n\"Keys to Success for Making Money Online\",\n\"Practical Earn Money Online Tips for Beginners\",\n\"Strategies to Maximize Earnings through the Internet\",\n\"Overcoming Common Challenges in Online Earning\",\n\"Making the Best Use of Your Skills for Earning Online\",\n\"Practical Case Studies: Success Stories in Online Earning\",\n\"The Role of Social Media in Online Earning\",\n\"Understanding The Power of Affiliate Marketing to Earn Money Online\",\n\"Final Thoughts: The Future of Online Earning\"\n]', '114', '65', 114, 1, 1, NULL, '2025-04-22 13:29:04', '2025-04-22 13:29:04', NULL, NULL),
(11, 4, 'Master the Art of Making Money Online with These Essential Earn Money Online Tips', 'earn money online tips', '[\"Introduction to Making Money Online\",\n\"The Essentials of Online Money-Making\",\n\"Understanding the Basics: Top Earn Money Online Tips\",\n\"Exploring Different Ways to Earn Money Online\",\n\"Transform Your Skills into Cash: Freelancing Tips\",\n\"The Role of Social Media in Making Money Online\",\n\"Affiliate Marketing: A Goldmine for Online Earnings\",\n\"Creating a Profitable Blog: A Step-by-Step Guide\",\n\"Online Trading: A Financially Rewarding Strategy\",\n\"Dropshipping: An Emerging Trends in Online Earnings\",\n\"Mastering the Art of Selling Ebooks Online\",\n\"Maximizing Earning with Online Courses and Webinars\",\n\"Tips to Avoid Scams when Trying to Earn Money Online\",\n\"Safe & Legitimate Online Money Making Methods\",\n\"Proven Strategies with High Profit Potential in Online Business\",\n\"Maintaining Consistency: The Key to Successful Online Earning\",\n\"Boost your Online Earnings with These Advanced Tips\",\n\"Conclusion: Using These Earn Money Online Tips to Your Advantage\"]', '133', '65', 133, 1, 1, NULL, '2025-04-22 13:29:04', '2025-04-22 13:29:04', NULL, NULL),
(12, 4, 'Master the Art of Making Money Online with These Essential Earn Money Online Tips', 'earn money online tips', '[\"Introduction to Making Money Online\",\n\"Demystifying the Idea of Making Money Online\",\n\"Earn Money Online Tips: Why are They Important?\",\n\"Essential Earn Money Online Tips to Get Started\",\n\"Taking Advantage of Internet-Based Income Opportunities\",\n\"Decoding the Art of Freelance: A Quick Guide\",\n\"Online Trading – A Path Towards Financial Independence\",\n\"Blogger to Vlogger: Making Money Doing What You Love\",\n\"Dive into the World of Affiliate Marketing\",\n\"Paid Online Surveys and Reviews: An Easy Way to Earn Money\",\n\"Online Tutoring Jobs: Earn While You Educate\",\n\"The Dollars Game: Monetizing Your Gaming Skills Online\",\n\"Investing in Online Real Estate: Virtual Properties\",\n\"Reselling: The Art of Earning Money Through the Buy-and-Sell Concept\",\n\"Social Media Advertising: Leveraging Your Online Presence\",\n\"Earn Through Online Courses and E-books\",\n\"Utilizing Money-Making Apps for Extra Income\",\n\"Final Important Tips: Avoiding Scams While Making Money Online\",\n\"The Future of Making Money Online: What to Expect and Prepare For\",\n\"Conclusion: Your Journey to Mastering Making Money Online\"]', '161', '65', 161, 1, 1, NULL, '2025-04-22 13:29:05', '2025-04-22 13:29:05', NULL, NULL),
(13, 5, 'Mastering Earn Money Online Methods: A Comprehensive Guide to Making Money Online', 'earn money online strategies, Best ways to make money online, Earn money online methods', '[\n\"Introduction to the Concept of Earning Money Online\",\n\"Decoding the Earn Money Online Strategies: A Deep Dive\",\n\"Choosing the Best Ways to Earn Money Online\",\n\"In-depth Analysis of Various Earn Money Online Methods\",\n\"Exploring the Top Money Making Techniques on the Internet\",\n\"Step-by-Step Guide to Implement Earn Money Online Strategies\",\n\"Understanding the Pros and Cons of Different Online Earning Models\",\n\"Boosting your Income with Effective Online Money Making Strategies\",\n\"How to Escalate Your Profits with Earn Money Online Methods\",\n\"Ultimate Tips and Tricks for Mastering Online Money Making\",\n\"Capitalizing on the Best Ways to Earn Money Online\",\n\"Common Mistakes to Avoid When Trying to Make Money Online\",\n\"Transforming Your Financial Health with Effective Earn Money Online Strategies\",\n\"Setting Realistic Goals for Online Earning and Achieving Them\",\n\"Case Studies: Success Stories of Individuals Who Made Money Online\",\n\"Utilizing Your Skills to Maximize Profits Online\",\n\"The Future of Earning Money Online: An Outlook\",\n\"Final Thoughts on Mastering Earn Money Online Methods\"\n]', '159', '77', 159, 1, 1, NULL, '2025-04-22 13:31:53', '2025-04-22 13:31:53', NULL, NULL),
(14, 5, 'Mastering Earn Money Online Methods: A Comprehensive Guide to Making Money Online', 'earn money online strategies, Best ways to make money online, Earn money online methods', '[\n\"Introduction to Earning Money Online\",\n\"Understanding the Concept of Earn Money Online Strategies\",\n\"Alignment of Skillsets and Best Ways to Make Money Online\",\n\"The Reality and Potential of Earning Money Online\",\n\"Examining High-Paying Earn Money Online Methods\",\n\"Building a Robust Digital Presence: Online Earning Strategies\",\n\"Implementing Proven Earn Money Online Strategies\",\n\"Bridging the Gap: From Learning to Earning Online\",\n\"Safe and Secure Methods of Earning Money Online\",\n\"Breaking Down the Best Ways to Make Money Online\",\n\"Advanced Techniques: Boosting Your Online Income\",\n\"Successful Stories: People Who Mastered Earn Money Online Methods\",\n\"Avoiding Scams: Safety Measures While Earning Online\",\n\"Dedication, Perseverance and Patience: The Unsaid Rule of Earning Online\",\n\"Guide to Financial Security through Online Earning Methods\",\n\"Exploring the Future of Online Money-Making Opportunities\"\n]', '123', '77', 123, 1, 1, NULL, '2025-04-22 13:31:55', '2025-04-22 13:31:55', NULL, NULL),
(15, 5, 'Mastering Earn Money Online Methods: A Comprehensive Guide to Making Money Online', 'earn money online strategies, Best ways to make money online, Earn money online methods', '[\n\"Introduction to Earn Money Online Strategies\",\n\"Understanding the Concept of Making Money Online\",\n\"Best Ways to Make Money Online: A Deep Dive\",\n\"Unpacking the Different Earn Money Online Methods\",\n\"Mastering Simple Techniques to Earn Money Online\",\n\"Exploring Advanced Earn Money Online Strategies\",\n\"Applying Earn Money Online Strategies: Case Studies\",\n\"Boosting Your Income: Strategies for Earning More Online\",\n\"Understanding the Benefits and Drawbacks of Different Online Money-making Methods\",\n\"Mistakes to Avoid When Trying to Make Money Online\",\n\"Setting Realistic Goals for Online Earnings\",\n\"Creating a Sustainable Strategy: Balancing Your Online Income with Your Day Job\",\n\"Online Money-Making: Diversifying Your Strategies\",\n\"Maintaining Ethical Standards When Earning Money Online\",\n\"Earn Money Online Methods: Maximizing Your Return on Investment\",\n\"Evaluating and Adjusting Your Money-Making Strategies Over Time\",\n\"Conclusion: Your Path to Mastering Earn Money Online Methods\"\n]', '132', '77', 132, 1, 1, NULL, '2025-04-22 13:31:58', '2025-04-22 13:31:58', NULL, NULL),
(16, 6, 'Turn Up the Heat on Your Earnings: Make Money from Home with Carolina Reaper Recipes', 'Online income generation, Earn money from home online, Ways to make money online', '[\n\"Introduction to Online Income Generation through Cooking\",\n\"Stir Up Profits: Understanding the Value of Carolina Reaper Recipes\",\n\"Earn Money from Home Online: Turning Your Kitchen into a Revenue Stream\",\n\"Dishing on Ways to Make Money Online\",\n\"The Heat is On: Crafting Sell-Worthy Carolina Reaper Recipes\",\n\"Steps to Create an Online Platform for Selling Recipes\",\n\"Spicing Up Earnings: Marketing Techniques for your Carolina Reaper Recipes\",\n\"Maximizing Profit through Organic Traffic and SEO\",\n\"Customer Engagement: Building a Loyal Customer Base for Your Recipes\",\n\"Savor the Success: Real-Life Success Stories of Making Money from Home Online\",\n\"Final Thoughts: Turning Up the Heat on Your Earnings\"\n]', '102', '79', 102, 1, 1, NULL, '2025-04-22 15:47:12', '2025-04-22 15:47:12', NULL, NULL),
(17, 6, 'Turn Up the Heat on Your Earnings: Make Money from Home with Carolina Reaper Recipes', 'Online income generation, Earn money from home online, Ways to make money online', '[\n\"Introduction: Stimulate Your Earnings with Carolina Reaper Recipes\",\n\"Exploring the Path of Online Income Generation\",\n\"Turning Passion into Profit: Earning Money from Home with Carolina Reaper Recipes\",\n\"Understanding the Basics: Ways to Make Money Online\",\n\"Developing Your Unique Carolina Reaper Recipes for Online Selling\",\n\"Creating a Digital Presence: Building Your Online Platform\",\n\"Marketing Your Home-Based Cooking Skills\",\n\"Expanding Your Business: Cross-promotion and Collaborations\",\n\"Mastering the Art of Online Selling and Revenue Generation\",\n\"Pro Tips for Maximising Profits from Carolina Reaper Recipes\",\n\"Quenching the Market\'s Heat: Standing Out in the Online Food Business\",\n\"Consistently Earning From Home: Strategies for Long-term Success\",\n\"Concluding Thoughts: Ignite Your Home-Based Business Venture\"\n]', '107', '79', 107, 1, 1, NULL, '2025-04-22 15:47:12', '2025-04-22 15:47:12', NULL, NULL),
(18, 6, 'Turn Up the Heat on Your Earnings: Make Money from Home with Carolina Reaper Recipes', 'Online income generation, Earn money from home online, Ways to make money online', '[\"Introduction to Online Income Generation\", \n\"Understanding the Concept: Earn Money from Home Online\",\n\"Spicy Venture: Make Money with Carolina Reaper Recipes\", \n\"Innovative Ways to Make Money Online\", \n\"Step-by-Step Guide: Creating Your Own Carolina Reaper Recipes\",\n\"Setting up Your Online Recipe Sales Platform: How to Get Started\",\n\"Promoting Your Carolina Reaper Recipes to Maximize Earnings\",\n\"Tricks for Standing Out in the Online Recipe Market\",\n\"Cultivating your own Carolina Reapers for Extra Income\",\n\"Expanding your Online Earnings with Other Spicy Recipes\",\n\"Tips for Sustaining and Increasing Your Online Earnings\",\n\"Closing Thoughts: Turning the Heat Up on Your Online Income\"]', '97', '79', 97, 1, 1, NULL, '2025-04-22 15:47:12', '2025-04-22 15:47:12', NULL, NULL),
(19, 9, 'Optimal Online Income Generation Strategies for Inexperienced Users', 'Generate income online from home, Solutions for making money online, Online income generation strategies, Top methods to make money on the internet', '[\n\"Introduction to Optimal Online Income Generation Strategies for Inexperienced Users\",\n\"Understanding the Basics of Generating Income Online from Home\",\n\"Different Solutions for Making Money Online: A Broad Overview\",\n\"An Examination of Online Income Generation Strategies for Beginners\",\n\"Top Methods for Making Money on the Internet: A Detailed Review\",\n\"The Practicality and Productivity of Online Income Generation\",\n\"Real Life Success Stories of Generating Income Online from Home\",\n\"The Pros and Cons of Different Online Income Generation Strategies\",\n\"Step-by-Step Guide to Implementing Top Methods to Make Money on the Internet\",\n\"Frequently Asked Questions about Making Money Online\",\n\"Turn Your Internet Connection into a Money-Making Tool: Conclusion and Final Thoughts\"\n]', '107', '83', 107, 1, 1, NULL, '2025-05-03 14:07:19', '2025-05-03 14:07:19', NULL, NULL),
(20, 9, 'Optimal Online Income Generation Strategies for Inexperienced Users', 'Generate income online from home, Solutions for making money online, Online income generation strategies, Top methods to make money on the internet', '[\n\"Understanding Online Income Generation: A Beginners Guide\",\n\"Demystifying the Work from Home Concept: Generate Income Online\",\n\"Unveiling the Best Solutions for Making Money Online\",\n\"Explore the Potential of Online Income Generation Strategies\",\n\"Top Methods to Make Money on the Internet: A Comprehensive List\",\n\"Easy Step-by-step Guide for Implementing Online Money Making Solutions\",\n\"A Closer Look at the Optimal Strategies for Online income generation\",\n\"The Role of Consistency and Discipline in Online Income Generation\",\n\"Juicing the Internet: Top Tips for Enhancing Online Earnings\",\n\"How to Overcome Challenges in Online Income Generation\",\n\"Real-life Success Stories: Inspiring Journeys in Online Earning\",\n\"Crafting Your Personal Online Income Generation Strategy: A How-To Guide\",\n\"Future Projections: The Evolution of Income Generation Online\",\n\"Easy Tools and Resources to Optimize Your Online Income Generation Efforts\",\n\"Top Myths and Misconceptions about Making Money Online Debunked\"\n]', '136', '83', 136, 1, 1, NULL, '2025-05-03 14:07:19', '2025-05-03 14:07:19', NULL, NULL),
(21, 9, 'Optimal Online Income Generation Strategies for Inexperienced Users', 'Generate income online from home, Solutions for making money online, Online income generation strategies, Top methods to make money on the internet', '[\"Introduction to Online Income Generation\",\n\"Exploring Ways to Generate Income Online from Home\",\n\"Solutions for Making Money Online: A Guide to Virtual Profits\",\n\"Breaking Down Various Online Income Generation Strategies\",\n\"Considering the Top Methods to Make Money on the Internet\",\n\"Simple Strategies for Newbies on Earning Online\",\n\"A Look at High-Potential Online Platforms for Income Generation\",\n\"Proven Techniques for Maximising Your Online Income\",\n\"Mistakes Inexperienced Users Should Avoid for Smooth Online Income Generation\",\n\"Success Stories: From Inexperience to Proficient Online Earners\",\n\"Understanding the Potential and Risks of Online Money-Making\",\n\"Developing a Sustainable Strategy for Online Income Generation\",\n\"Conclusion: Turning Your Online Presence into a Revenue Stream\"]', '106', '83', 106, 1, 1, NULL, '2025-05-03 14:07:19', '2025-05-03 14:07:19', NULL, NULL),
(22, 10, 'How to Make Money Online: A Comprehensive Guide', 'Make money online, Earn income on the internet, Online money making strategies', '[\n\"Introduction to Making Money Online\",\n\"Understanding the Basic Concepts of Online Income\",\n\"Various Ways to Make Money Online\",\n\"Deep Dive into Online Money Making Strategies\",\n\"Earning Income on the Internet: Freelancing\",\n\"Using Affiliate Marketing to Make Money Online\",\n\"Profit through Online Selling: E-commerce and Dropshipping\",\n\"Making Money Online through Blogging and Vlogging\",\n\"Earning Online Income through Online Surveys and Paid Reviews\",\n\"Online Stocks and Cryptocurrency: An Avenue for Online Income\",\n\"Using Writing Skills to Earn Money Online\",\n\"Monetizing your Creativeness: Making Money through Online Art, Designs, and Crafts\",\n\"Expanding Income Streams: Diversifying your Online Earnings\",\n\"On Avoiding Online Money Making Scams\",\n\"Frequently Asked Questions about Making Money Online\",\n\"Conclusion: Implementing the Best Online Money-Making Strategy for You\"\n]', '117', '70', 117, 1, 1, NULL, '2025-05-03 18:08:11', '2025-05-03 18:08:11', NULL, NULL),
(23, 10, 'How to Make Money Online: A Comprehensive Guide', 'Make money online, Earn income on the internet, Online money making strategies', '[\"Introduction to Making Money Online\",\n\"The Basics of Online Money Making\",\n\"Understanding How to Earn Income on the Internet\",\n\"Step-by-Step Guide to Online Earning\",\n\"Different Strategies to Make Money Online\",\n\"Analyzing Pros and Cons of Online Income Generation\",\n\"Efficient Online Money-Making Strategies You Should Try\",\n\"How to Choose the Right Online Money Making Path\",\n\"Exploring Various Platforms to Earn Income on the Internet\",\n\"Effective Tools to Boost Your Online Earnings\",\n\"How to Safeguard Your Online Income\",\n\"Real-Life Success Stories of Online Entrepreneurs\",\n\"Understanding and Overcoming Challenges in Online Money Making\",\n\"Advanced Tips to Increase Your Internet Income\",\n\"Comprehensive Checklist for Making Money Online\",\n\"Summing Up: The Future of Making Money Online\"]', '111', '70', 111, 1, 1, NULL, '2025-05-03 18:08:11', '2025-05-03 18:08:11', NULL, NULL),
(24, 10, 'How to Make Money Online: A Comprehensive Guide', 'Make money online, Earn income on the internet, Online money making strategies', '[\n\"Introduction to Making Money Online\",\n\"Understanding the Concept of Earning Income on the Internet\",\n\"Different Ways to Make Money Online\",\n\"Proven Online Money Making Strategies\",\n\"Advantages and Disadvantages of Earning Online\",\n\"Skills Required to Successfully Make Money Online\",\n\"Strategies to Maximize Your Internet Income\",\n\"Understanding the Role of Social Media in Online Earnings\",\n\"Affiliate Marketing: An Effective Method to Earn Income on the Internet\",\n\"E-commerce: A Profitable Online Money Making Strategy\",\n\"Exploring the Potential of Content Creation and Freelancing\",\n\"Blogging and Vlogging: Leveraging Media for Online Income\",\n\"Online Trading and Investment Opportunities\",\n\"Online Tutoring and Consultancy Services as a Revenue Stream\",\n\"Stay Safe: Common Scams and Pitfalls in Online Money Making\",\n\"Increasing Your Online Earnings: Tips and Tricks\",\n\"Success Stories: People who made Fortune Online\",\n\"Closing Thoughts on Making Money Online\"\n]', '131', '70', 131, 1, 1, NULL, '2025-05-03 18:08:11', '2025-05-03 18:08:11', NULL, NULL),
(25, 10, 'How to Make Money Online: A Comprehensive Guide', 'Make money online, Earn income on the internet, Online money making strategies', '[\n\"Introduction to Making Money Online\",\n\"The Basics of Earning Online Income\",\n\"Understanding the Potential of Internet Income\",\n\"Different Ways to Make Money Online\",\n\"Online Money Making Strategies: An Analysis\",\n\"Developing the Right Mindset to Earn Income on the Internet\",\n\"Guide to Choosing the Right Online Money Making Strategy for You\",\n\"Step-by-Step Process to Make Money Online\",\n\"Tips and Tricks to Maximize Your Online Earnings\",\n\"Common Mistakes to Avoid When Making Money Online\",\n\"Managing Your Online Income Successfully\",\n\"Securing Your Online Income Streams\",\n\"Success Stories: Individuals Who Made it Big Online\",\n\"Future Trends in Online Money Making\",\n\"Maintaining Sustainability in your Online Income\",\n\"Concluding Thoughts on Earning Money Online\"\n]', '108', '70', 108, 1, 1, NULL, '2025-05-03 18:08:25', '2025-05-03 18:08:25', NULL, NULL),
(26, 10, 'How to Make Money Online: A Comprehensive Guide', 'Make money online, Earn income on the internet, Online money making strategies', '[\"Introduction to Making Money Online\",\n\"Understanding the Basics of Online Income\",\n\"Top Strategies to Make Money Online\",\n\"Exploring Different Ways to Earn Income on the Internet\",\n\"Getting Started: Setting Up for Online Money Making\",\n\"Tips and Tricks to Maximize Online Earnings\",\n\"Pros and Cons of Making Money Online\",\n\"Real-life Success Stories of Online Money Making\",\n\"Common Mistakes to Avoid When Trying to Earn Income on the Internet\",\n\"Building a Long-term Strategy for Online Income\",\n\"Adapting to Emerging Trends in Online Money Making\",\n\"Using Social Media as a Tool to Make Money Online\",\n\"How to Stay Safe and Legit When Earning Online\",\n\"Exploring Passive Income Opportunities on the Internet\",\n\"Conclusion: Turning Online Money Making Strategies Into Action\"]', '116', '70', 116, 1, 1, NULL, '2025-05-03 18:08:25', '2025-05-03 18:08:25', NULL, NULL),
(27, 10, 'How to Make Money Online: A Comprehensive Guide', 'Make money online, Earn income on the internet, Online money making strategies', '[\"Introduction to Making Money Online\", \n\"Understanding the Concept of Earning Income on the Internet\",\n\"Pros and Cons of Making Money Online\", \n\"Different Ways to Make Money Online\",\n\"Deep-Dive into Online Money Making Strategies\", \n\"How to Choose the Right Online Money Making Strategy for you\", \n\"Start Earning Money Online: Step by Step Process\", \n\"Top Tips for Maximizing your Money Making Potential Online\", \n\"How to Stay Safe while Making Money Online\", \n\"Common Mistakes to Avoid when Trying to Earn Online Income\", \n\"Success Stories: People Who\'ve Made It Big with Online Income\", \n\"Adapting to Changes: Updating your Online Money Making Strategies\", \n\"Creating a Sustainable Lifestyle with Online Income\", \n\"Conclusion: The Future of Online Money Making\"]', '112', '70', 112, 1, 1, NULL, '2025-05-03 18:08:26', '2025-05-03 18:08:26', NULL, NULL),
(28, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"Introduction to Online Entrepreneurship\",\n\"Understanding Profitable Online Ventures\",\n\"Exciting Opportunities: Exploring Online Income Sources\",\n\"Easy Ways to Make Money Online: A Beginner\'s Guide\",\n\"Building Your Empire: The Online Entrepreneurship Journey\",\n\"Decoding the Internet Money Making Tactics\",\n\"Highly Recommended Online Business Models\",\n\"How to Leverage Social Media for Online Ventures\",\n\"Turning Your Passion into Profit: Skills You Can Monetize Online\",\n\"Understanding the Risks and Rewards of Online Entrepreneurship\",\n\"Effective Strategies to Excel in Online Entrepreneurship\",\n\"Building Sustainable Revenue with Your Online Venture\",\n\"Monetizing Your Website: Advertising and Affiliate Marketing\",\n\"Exploring E-Commerce as a Profitable Online Venture\",\n\"Understanding the Role of SEO in Online Income\",\n\"Final Thoughts on Embracing Online Entrepreneurship\"]', '109', '84', 109, 1, 1, NULL, '2025-05-03 18:12:38', '2025-05-03 18:12:38', NULL, NULL),
(29, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"Introduction to Online Entrepreneurship\",\n\"Understanding Profitable Online Ventures\",\n\"Exploring the Landscape of Online Income\",\n\"The Need for Online Entrepreneurship\",\n\"Easy Ways to Make Money Online: An Overview\",\n\"A Closer Look at Internet Money Making Tactics\",\n\"Turning Profitable Ideas into Online Ventures\",\n\"Strategies for Successful Online Entrepreneurship\",\n\"Cost-Effective Techniques for Increasing Online Income\",\n\"Implementing Internet Money Making Tactics for Maximum Returns\",\n\"Practical Tips for the Aspiring Online Entrepreneur\",\n\"Maintaining and Growing Your Online Ventures\",\n\"Taking Your Online Income to the Next Level\",\n\"The Future and Evolution of Online Entrepreneurship\"]', '88', '84', 88, 1, 1, NULL, '2025-05-03 18:12:38', '2025-05-03 18:12:38', NULL, NULL),
(30, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\n\"Introduction to Online Entrepreneurship\",\n\"Understanding Internet Money Making Tactics\",\n\"Identifying Profitable Online Ventures\",\n\"Diving Deeper - Exploring Online Income\",\n\"Simple yet Effective Ways to Make Money Online\",\n\"Online Entrepreneurship: An Attractive Proposition\",\n\"The Future of Making Money: Online Models\",\n\"Strategies for a Successful Online Business\",\n\"Boosting Your Income with Online Ventures\",\n\"Maximizing Profit: Proven Online Entrepreneurship Tactics\",\n\"Tips and Tricks: Easy Ways to Make Money Online\"\n]', '66', '84', 66, 1, 1, NULL, '2025-05-03 18:12:38', '2025-05-03 18:12:38', NULL, NULL),
(31, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"Introduction to Online Entrepreneurship\",\n\"Understanding Internet Money Making Tactics\",\n\"Benefits of Venturing into Online Entrepreneurship\",\n\"Examining Profitable Online Ventures\",\n\"Exploring the Top Methods for Online Income\",\n\"In-Depth Look: Easy Ways to Make Money Online\",\n\"Useful Tips and Tricks for Successful Online Entrepreneurship\",\n\"Strategies to Further Increase your Online Income\",\n\"Surviving and Thriving in the World of Online Entrepreneurship\",\n\"Moving from Traditional to Digital: Transitioning to Online Ventures\",\n\"Mistakes to Avoid in Online Entrepreneurship\",\n\"Frequently Asked Questions about Internet Money Making Tactics\",\n\"Planning your Future in Online Entrepreneurship\",\n\"Conclusive Thoughts on Venturing into Online Entrepreneurship\"]', '94', '84', 94, 1, 1, NULL, '2025-05-03 18:13:17', '2025-05-03 18:13:17', NULL, NULL),
(32, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"Introduction to Profitable Online Ventures\",\n\"Understanding What Online Entrepreneurship Entails\",\n\"Easy Ways to Make Money Online: Getting Started\",\n\"Delving Deeper: Various Aspects of Online Income\",\n\"Transitioning from Offline to Online: A New Age of Entrepreneurship\",\n\"Utilizing Internet Money Making Tactics: A Comprehensive Guide\",\n\"Exploring the Various Avenues of Online Ventures\",\n\"Fulfill Your Entrepreneurial Spirit: Tips to Succeed in Online Ventures\",\n\"Shortcut to Success: Easy Tricks for Online Income Generation\",\n\"Step by Step Guide to Setting up an Online Business\",\n\"The Do\'s and Dont\'s of Internet Money Making\",\n\"Leveraging Strategies for Effective Online Entrepreneurship\",\n\"Growing Your Online Business: Tips and Tricks\",\n\"Maintaining Sustainable Profit within Online Ventures\",\n\"Overcoming Challenges in Online Entrepreneurship\",\n\"Conclusion: The Future of Online Income and Entrepreneurship\"]', '119', '84', 119, 1, 1, NULL, '2025-05-03 18:13:17', '2025-05-03 18:13:17', NULL, NULL),
(33, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"Understanding the Basics of Online Entrepreneurship\",\n\"Identifying Profitable Online Ventures\",\n\"Diving Into the World of Internet Money Making Tactics\",\n\"The Role of Creativity and Innovation in Exploring Online Income\",\n\"Easy Ways to Make Money Online: Tips and Tricks\",\n\"Online Entrepreneurship as a Sustainable Source of Income\",\n\"Maximizing Potential: Strategic Steps to Increase your Online Earnings\",\n\"Avoiding Pitfalls in Online Entrepreneurship\",\n\"Balancing Risk and Reward in Online Money-Making Ventures\",\n\"Final Thoughts: The Future of Making Money Online\"]', '76', '84', 76, 1, 1, NULL, '2025-05-03 18:13:17', '2025-05-03 18:13:17', NULL, NULL),
(34, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"Introduction: The Promise of Online Entrepreneurship\",\n \"Understanding Online Entrepreneurship: The Basics\",\n \"The Allure of Profitable Online Ventures\",\n \"Step-By-Step Guide: Exploring Online Income Opportunities\",\n \"Easy Ways to Make Money Online: Top Picks\",\n \"Boosting your Earnings: Internet Money Making Tactics\",\n \"Successful Stories: Professionals Triumphing in Online Entrepreneurship\",\n \"Evolution of Internet Entrepreneurship: Past, Present, Future\",\n \"Tips and Tricks to Enhance Your Online Business Strategy\",\n \"Overcoming Challenges in Online Entrepreneurship\",\n \"Unleashing Your Potential: The Entrepreneurial Mindset\",\n \"Innovative Tools and Resources for Online Entrepreneurs\",\n \"Cultivating Growth: How to Scale Your Online Venture\",\n \"Conclusion: Turning Online Entrepreneurship into a Steady Income Stream\"]', '96', '84', 96, 1, 1, NULL, '2025-05-03 18:14:15', '2025-05-03 18:14:15', NULL, NULL),
(35, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"The Allure of Online Entrepreneurship\",\n\"Understanding Profitable Online Ventures\",\n\"The Exploration: Different Ways of Online Income\",\n\"Easy Ways to Make Money Online: A Starter Guide\",\n\"Developing Your Digital Entrepreneurship Skills\",\n\"Internet Money Making Tactics: Scams vs Legitimate Opportunities\",\n\"Top Online Ventures That Can Increase Your Income\",\n\"The Realities of Making Money on The Internet: Expectations vs Reality\",\n\"Strategies for Successful Online Entrepreneurship\",\n\"Maximizing Your Income: Efficient Internet Money Making Tactics\",\n\"The Road to Financial Freedom: Your Online Entrepreneurship Journey\",\n\"Stepping Up Your Online Money Making Game\",\n\"Revolutionizing Income: The Power of Online Entrepreneurship\",\n\"Profitable Online Ventures: Exploring Your Options\",\n\"The Future of Income: Online Entrepreneurship\"]', '105', '84', 105, 1, 1, NULL, '2025-05-03 18:14:15', '2025-05-03 18:14:15', NULL, NULL),
(36, 11, 'Venturing into Online Entrepreneurship: Easy Ways to Increase your Income', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"Introduction to Online Entrepreneurship\",\n\"Understanding Profitable Online Ventures: A Beginners Guide\",\n\"Exploring Online Income: A World of Opportunities\",\n\"Easy Ways to Make Money Online: A Detailed Overview\",\n\"Transforming into an Online Entrepreneur: Steps to Get Started\",\n\"Internet Money Making Tactics: Proven Strategies\",\n\"Venturing into E-commerce: Making the Virtual Marketplace Work for You\",\n\"Gaining an Edge with Affiliate Marketing: A Lucrative Online Venture\",\n\"Using Freelancing as a Stepping Stone in Online Entrepreneurship\",\n\"Maximizing Your Earnings with Passive Online Income Streams\",\n\"Diversifying Your Online Income: Advice for Online Entrepreneurs\",\n\"Advancing in Online Entrepreneurship: Improving Your Skills for Better Profit\",\n\"Cashing in on Social Media: Leveraging Online Platforms for Business\",\n\"Becoming a Successful Online Entrepreneur: Qualities and Skills Needed\",\n\"Consistency & Persistence: The Key to Thriving in Online Entrepreneurship\",\n\"Overcoming Challenges in Online Entrepreneurship\",\n\"Reaping the Rewards: Growth and Success in Online Entrepreneurship\",\n\"Conclusion: Ready for Your Online Entrepreneurship Journey?\"]', '146', '84', 146, 1, 1, NULL, '2025-05-03 18:14:15', '2025-05-03 18:14:15', NULL, NULL),
(37, 12, 'Best Online Business Opportunities: Reinvent Your Income', 'Work from home jobs, Online money making ideas, Easy ways to make money online, Best online business opportunities', '[\"Introduction to Online Business Opportunities\",\n\"Exploring Best Online Business Opportunities\",\n\"Work From Home Jobs: A Flexible Way to Earn\",\n\"Online Money Making Ideas: Reach Your Financial Goals\",\n\"Easy Ways to Make Money Online: Effortless Earning Solutions\",\n\"Building Wealth with the Best Online Business Opportunities\",\n\"Starting Your Own Online Business: Things You Need To Know\",\n\"Scaling Your Online Business: Tips and Tricks for Success\",\n\"Making the Most of Online Business Opportunities: Strategies for Growth\",\n\"Final Thoughts on Choosing the Best Online Business Opportunity\"]', '82', '77', 82, 1, 1, NULL, '2025-05-03 20:37:58', '2025-05-03 20:37:58', NULL, NULL),
(38, 12, 'Best Online Business Opportunities: Reinvent Your Income', 'Work from home jobs, Online money making ideas, Easy ways to make money online, Best online business opportunities', '[\n\"Introduction to Best Online Business Opportunities\",\n\"Understanding the Concept: Best Online Business Opportunities\",\n\"Thriving in the World of Work from Home Jobs\",\n\"Exploring Various Online Money Making Ideas\",\n\"The Appeal and Advantages of Work from Home Jobs\",\n\"Easy Ways to Make Money Online: A Comprehensive Guide\",\n\"How to Simplify the Process of Making Money Online\",\n\"Highlighting the Best Online Business Opportunities Currently Available\",\n\"Learning About The Best & Most Profitable Online Business Opportunities\",\n\"Taking a Closer Look: Best Online Business Opportunities\",\n\"Sharpening your Skills for Online Business Opportunities\",\n\"In-depth Analysis: Best Online Business Opportunities\",\n\"A Rundown of Pros and Cons: Work from Home Jobs\",\n\"Summing Up: The Future of Online Business Opportunities\"\n]', '111', '77', 111, 1, 1, NULL, '2025-05-03 20:37:58', '2025-05-03 20:37:58', NULL, NULL),
(39, 12, 'Best Online Business Opportunities: Reinvent Your Income', 'Work from home jobs, Online money making ideas, Easy ways to make money online, Best online business opportunities', '[\n\"Introduction to Online Business Opportunities\",\n\"The Rising Demand for Work From Home Jobs\",\n\"Exploring Various Online Money Making Ideas\",\n\"Easy Ways to Make Money Online: A Beginner’s Guide\",\n\"Exploring the Best Online Business Opportunities\",\n\"Understanding the Pros and Cons of Online Business Opportunities\",\n\"Steps to Start Your Own Online Business\",\n\"Maximizing Income through Online Business Opportunities\",\n\"Adopting the Right Strategy for Online Business Success\",\n\"Success Stories: Lessons to Learn from Successful Onlinepreneurs\",\n\"Preventing Scams: Pitfalls to Avoid in Online Business\",\n\"Conclusion: Reinventing Your Income with Online Business Opportunities\"\n]', '89', '77', 89, 1, 1, NULL, '2025-05-03 20:37:58', '2025-05-03 20:37:58', NULL, NULL),
(40, 13, 'Getting the Most Out of Microsoft: How to Download Office 2024 Pro Plus LTSE', 'Get Office 2024 Pro Plus LTSE, How to download Office 2024 Pro Plus LTSE, New Microsoft Office Pro Plus 2024 download', '[\n\"Introduction to Microsoft\'s New Offering: Office 2024 Pro Plus LTSE\",\n\"Understanding What Office 2024 Pro Plus LTSE Brings to the Table\",\n\"How to Get Office 2024 Pro Plus LTSE: Your Step-by-step Guide\",\n\"Simplifying the Process: How to Download Office 2024 Pro Plus LTSE\",\n\"Troubleshooting Common Issues in Downloading Office 2024 Pro Plus LTSE\",\n\"Make the Most of New Features in Microsoft Office Pro Plus 2024\",\n\"How New Microsoft Office Pro Plus 2024 Enhances Your Productivity\",\n\"Final Thoughts on Office 2024 Pro Plus LTSE: Is it Worth Downloading?\"\n]', '79', '96', 79, 1, 1, NULL, '2025-05-03 22:38:37', '2025-05-03 22:38:37', NULL, NULL),
(41, 13, 'Getting the Most Out of Microsoft: How to Download Office 2024 Pro Plus LTSE', 'Get Office 2024 Pro Plus LTSE, How to download Office 2024 Pro Plus LTSE, New Microsoft Office Pro Plus 2024 download', '[\n\"Introduction to Microsoft Office Pro Plus 2024\",\n\"Understanding the New Features of Office 2024 Pro Plus LTSE\",\n\"How to Get Office 2024 Pro Plus LTSE: A Step-by-Step Guide\",\n\"The Complete Download Process for Office 2024 Pro Plus LTSE\",\n\"Quick Tips on How to Download Office 2024 Pro Plus LTSE\",\n\"Embracing the New Microsoft Office Pro Plus 2024: What to Look Forward to\",\n\"Common Issues and Solutions in Downloading Office 2024 Pro Plus LTSE\",\n\"Getting the Most Out of Your Office 2024 Pro Plus LTSE\",\n\"Optimizing Your Use of the New Microsoft Office Pro Plus 2024\"\n]', '86', '96', 86, 1, 1, NULL, '2025-05-03 22:38:37', '2025-05-03 22:38:37', NULL, NULL),
(42, 14, 'Upgrading Your System? Check Out Our Windows 11 Home Review', 'Windows 11 Home Review', '[\n\"Introduction to Windows 11 Home\",\n\"Overview of Windows 11 Home\",\n\"The Concept behind Windows 11 Home Development\",\n\"Breaking Down the Windows 11 Home Review\",\n\"Eye-Catching Features of Windows 11 Home\",\n\"Assessing the Performance of Windows 11 Home\",\n\"Usability and Flexibility of Windows 11 Home\",\n\"Security Updates in Windows 11 Home\",\n\"Comparison: Windows 11 Home vs Other OS\",\n\"Navigating the Interface of Windows 11 Home\",\n\"The Visual Appeal of Windows 11 Home\",\n\"Cost Implication of Upgrading to Windows 11 Home\",\n\"Pros and Cons of Windows 11 Home\",\n\"Final Takeaways from Our Windows 11 Home Review\",\n\"Why should you consider Upgrading to Windows 11 Home?\",\n\"Conclusion: Is Windows 11 Home worth the Upgrade?\"\n]', '95', '65', 95, 1, 5, NULL, '2025-05-04 14:36:54', '2025-05-04 14:36:54', NULL, NULL),
(43, 14, 'Upgrading Your System? Check Out Our Windows 11 Home Review', 'Windows 11 Home Review', '[\"Introduction to Windows 11 Home\",\n\"Deep Dive Into Windows 11 Home Review\",\n\"The Expected Upgrades in Windows 11 Home\",\n\"Walkthrough of Windows 11 Home’s Interface\",\n\"Performance Improvements in Windows 11 Home\",\n\"Closer Look at Windows 11 Home\'s Features\",\n\"Compatibility Check for Windows 11 Home Upgrade\",\n\"Pros and Cons of Upgrading to Windows 11 Home\",\n\"Comparing Windows 11 Home with its Predecessors\",\n\"Getting the Most Out of Your Windows 11 Home System\",\n\"How to Upgrade to Windows 11 Home?\",\n\"Understanding the Cost of Upgrading to Windows 11 Home\",\n\"User Experience: Reviews from Windows 11 Home Users\",\n\"Final Verdict: Is Windows 11 Home Worth the Upgrade?\",\n\"Conclusion: Your Next Steps After Our Windows 11 Home Review\"]', '116', '65', 116, 1, 5, NULL, '2025-05-04 14:36:54', '2025-05-04 14:36:54', NULL, NULL),
(44, 14, 'Upgrading Your System? Check Out Our Windows 11 Home Review', 'Windows 11 Home Review', '[\"Introduction to Windows 11 Home\",\n\"Key Features of Windows 11 Home: A Full Review\",\n\"Why Should You Consider Upgrading to Windows 11?\",\n\"Windows 11 Home: A Detailed Look at the New Interface\",\n\"An In-Depth Guided Tour Through Windows 11 Home\",\n\"Looking at the Changes: Windows 10 vs Windows 11 Home\",\n\"What Makes Windows 11 Home Stand Out\",\n\"The Performance Enhancements in Windows 11 Home\",\n\"Discussing the Hardware Requirements for Windows 11 Home\",\n\"Pros and Cons of Upgrading to Windows 11 Home\",\n\"Windows 11 Home: Is it Worth the Switch?\",\n\"The Overall User Experience with Windows 11 Home\",\n\"Our Verdict: Windows 11 Home Review\",\n\"Final Thoughts on Upgrading to Windows 11 Home\"]', '96', '65', 96, 1, 5, NULL, '2025-05-04 14:36:54', '2025-05-04 14:36:54', NULL, NULL);
INSERT INTO `ai_blog_wizard_outlines` (`id`, `ai_blog_wizard_id`, `title`, `keywords`, `values`, `completion_tokens`, `prompt_tokens`, `total_words`, `num_of_copies`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `input_prompt`) VALUES
(45, 15, 'Expert Advice on How to Successfully Earn Income Online', 'Online money making ideas, Online earning opportunities, Ways to generate online income, Earn income online advice', '[\n\"Introduction to Successfully Earning Income Online\",\n\"The Rise of Online Earning Opportunities\",\n\"Cracking the Code: Online Money Making Ideas\",\n\"Exploration of Different Ways to Generate Online Income\",\n\"Pros and Cons: Analyzing Different Online Earning Opportunities\",\n\"Earn Income Online Advice from Top Experts\",\n\"Strategies to Optimize Your Online Money Making Efforts\",\n\"Step by Step Guide for a Successful Online Income Journey\",\n\"Expert Tips to Avoid Common Pitfalls in Online Earning\",\n\"Utilizing Skills and Hobbies: Unique Ways to Generate Online Income\",\n\"Staying Current: How to Keep up with Emerging Online Earning Opportunities\",\n\"Financial Independence: How to Sustain and Grow Your Online Income\",\n\"Conclusion: Consolidating Your Earn Income Online Advice for Success\"\n]', '109', '75', 109, 1, 7, NULL, '2025-05-11 16:51:05', '2025-05-11 16:51:05', NULL, NULL),
(46, 15, 'Expert Advice on How to Successfully Earn Income Online', 'Online money making ideas, Online earning opportunities, Ways to generate online income, Earn income online advice', '[\"Introduction to Successfully Earning Income Online\",\n\"Understanding the Basics of Online Money Making Ideas\",\n\"Analysis of Numerous Online Earning Opportunities\",\n\"A Closer Look at the Different Ways to Generate Online Income\",\n\"Useful Tips and Tricks for Beginning an Online Income Journey\",\n\"Ins and Outs of Affiliate Marketing as an Online Income Source\",\n\"The Potentials of Online Trading, Forex and Cryptocurrencies\",\n\"Earn Income Online: Advices from industry experts\",\n\"Venturing into E-Commerce to Generate Online Income\",\n\"Paving Way with Blogging, Vlogging and Podcasting\",\n\"The Influence of Social Media in Online Income Opportunities\",\n\"Becoming a Digital Nomad: Working Remotely to Earn Online\",\n\"Practical Advice for Combating Online Scams and Frauds\",\n\"Importance of Consistency and Persistence in Online Earning\",\n\"Expert Advice: Overcoming Challenges in Online Income Generation\",\n\"The Road-Map to Success: Devising a Strategic Online Income Plan\",\n\"Closing Thoughts: The Future of Online Earning and Opportunities Ahead\"]', '143', '75', 143, 1, 7, NULL, '2025-05-11 16:51:05', '2025-05-11 16:51:05', NULL, NULL),
(47, 15, 'Expert Advice on How to Successfully Earn Income Online', 'Online money making ideas, Online earning opportunities, Ways to generate online income, Earn income online advice', '[\"Introduction to Earning Income Online\",\n\"Exploring Various Online Money Making Ideas\",\n\"Understanding Online Earning Opportunities and Potential\",\n\"Ways to Generate Online Income: A Comprehensive Guide\",\n\"Sharing Expert Earn Income Online Advice\",\n\"Identifying Profitable Niches for Online Income\",\n\"Techniques to Increase Your Online Earnings\",\n\"Leveraging Social Media for Online Income Generation\",\n\"Utilizing SEO Techniques for Online Earning\",\n\"Diving Deeper into Affiliate Marketing as an Online Income Source\",\n\"Working as a Freelancer - An Exciting Online Earning Opportunity\",\n\"Understanding the Role of E-commerce in Online Earnings\",\n\"Creating a Successful Blog to Generate Online Income\",\n\"Establishing a Profitable Online Tutoring Business\",\n\"Succeeding with an Online Drop shipping Business\",\n\"Expert Advice on Building a YouTube Channel for Online Income\",\n\"Exploring Online Income with Podcasting\",\n\"Resources to Help You Earn Income Online\",\n\"Understanding and Overcoming Challenges in Online Earning\",\n\"Expert Advice on Maintaining Consistency in Online Earnings\",\n\"Final Thoughts on Successfully Earning Income Online\"]', '149', '75', 149, 1, 7, NULL, '2025-05-11 16:51:05', '2025-05-11 16:51:05', NULL, NULL),
(48, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\n\"Introduction to Samsung Reparatur Services\",\n\"Why Choose Professional Samsung Reparatur for Samsung Repairs\",\n\"Understanding the Importance of Professional Samsung Repairs\",\n\"Advantages of Choosing Samsung Reparatur for Your Repair needs\",\n\"Difference Between Professional Samsung Reparatur and Ordinary Repair Services\",\n\"Comprehensive Guide to Samsung Reparatur Services\",\n\"The Range of Samsung Repairs Covered by Samsung Reparatur\",\n\"Fast and Cost-Effective Solutions with Samsung Reparatur\",\n\"Maintaining Your Samsung Device with Regular Reparatur\",\n\"Making Your Samsung Device As Good As New with Professional Reparatur\",\n\"Samsung Reparatur: Expertise and Precision in Samsung Repairs\",\n\"How To Contact Samsung Reparatur for Your Repair Needs\",\n\"Frequently Asked Questions about Samsung Reparatur Services\",\n\"Final Words on Choosing Samsung Reparatur for Your Samsung Repair Needs\"\n]', '113', '61', 113, 1, 9, NULL, '2025-05-12 01:41:55', '2025-05-12 01:41:55', NULL, NULL),
(49, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\"Understanding the Need for Professional Samsung Reparatur\", \n\"Choosing the Right Service: Professional Samsung Reparatur\", \n\"What Makes Samsung Reparatur Stand out?\", \n\"Benefits of Using Professional Samsung Reparatur Service\", \n\"Common Issues Solved by Samsung Reparatur\", \n\"Detailed Look at Samsung Reparatur Process\", \n\"Real Customer Testimonials about Samsung Reparatur\", \n\"How to Reach Professional Samsung Reparatur Services\", \n\"The Affordable and Reliable choice: Samsung Reparatur\", \n\"Wrap-Up: Why Choose Samsung Reparatur for your Repair Needs\"]', '68', '61', 68, 1, 9, NULL, '2025-05-12 01:41:55', '2025-05-12 01:41:55', NULL, NULL),
(50, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\n\"Introduction to Samsung Reparatur Service\",\n\"Understanding the Importance of Professional Samsung Reparatur\",\n\"Reasons to Choose Professional Samsung Reparatur for Your Samsung Repair Needs\",\n\"Services Provided by Professional Samsung Reparatur\",\n\"How Does Samsung Reparatur Handle the Repair Process?\",\n\"Benefits of Selecting Samsung Reparatur for Your Repair Needs\",\n\"Common Issues Dealt by Samsung Reparatur\",\n\"Guarantees and Warranties Provided by Samsung Reparatur\",\n\"Customer Reviews and Ratings for Samsung Reparatur\",\n\"Contacting Samsung Reparatur for Your Samsung Repair Needs\",\n\"Final Thoughts on Choosing Samsung Reparatur for Your Samsung Repairs\"\n]', '84', '61', 84, 1, 9, NULL, '2025-05-12 01:41:55', '2025-05-12 01:41:55', NULL, NULL),
(51, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\n\"Introduction to Samsung Reparatur Services\",\n\"Understanding the Need for Professional Samsung Reparatur\",\n\"Choosing Samsung Reparatur for Your Samsung Repair Needs\",\n\"Services Offered by Professional Samsung Reparatur\",\n\"Benefits of Choosing a Professional Samsung Reparatur\",\n\"Saving Time and Money with Samsung Reparatur\",\n\"How Samsung Reparatur Handles Different Samsung Device Issues\",\n\"Samsung Reparatur: Specialization in Repairing Samsung Devices\",\n\"Why Trust Samsung Reparatur for Your Samsung Gadget Repairs\",\n\"Customer Reviews of Samsung Reparatur Services\",\n\"Contacting Samsung Reparatur for Your Samsung Repair Needs\",\n\"Conclusion: Peace of Mind with Professional Samsung Reparatur\"\n]', '86', '61', 86, 1, 9, NULL, '2025-05-12 01:42:31', '2025-05-12 01:42:31', NULL, NULL),
(52, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\"Introduction to Samsung Reparatur\",\n\"Understanding the Need for Professional Samsung Reparatur\",\n\"The Significance of Choosing Samsung Reparatur for Your Repair Needs\",\n\"How Samsung Reparatur Ensures Quality and Efficiency\",\n\"A Closer Look at the Services Provided by Samsung Reparatur\", \n\"Trusting Samsung Reparatur with Your Device’s Safety\",\n\"Peculiar Benefits of Choosing Samsung Reparatur over Local Repairs\",\n\"Samsung Reparatur: Delivering a Consistent Customer Service Experience\",\n\"Addressing Common Concerns about Samsung Reparatur\",\n\"Final Thoughts on Choosing Professional Samsung Reparatur for Your Samsung Repair Needs\"]', '81', '61', 81, 1, 9, NULL, '2025-05-12 01:42:31', '2025-05-12 01:42:31', NULL, NULL),
(53, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\n\"Introduction to Samsung reparatur\",\n\"Reasons to Choose Professional Samsung reparatur Services\",\n\"Samsung Repairs: Simple Fixes vs Professional Reparatur\",\n\"Understanding the Benefits of Professional Samsung Reparatur\",\n\"Various Samsung Repair Needs Handled by Professionals\",\n\"How to Find a Reputable Professional for Samsung reparatur\",\n\"Cost-Benefit Analysis of Choosing Professional Samsung Reparatur\",\n\"The Procedure of Professional Samsung Reparatur\",\n\"Guaranteed Repair Quality with Samsung Reparatur Services\",\n\"Common FAQs about Samsung reparatur\",\n\"Conclusion: Making the Right Choice for Your Samsung Repair Needs\"\n]', '76', '61', 76, 1, 9, NULL, '2025-05-12 01:42:31', '2025-05-12 01:42:31', NULL, NULL),
(54, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\n\"Understanding the Importance of Professional Samsung Reparatur\",\n\"Breaking Down the Process of Samsung Reparatur\",\n\"Why Choose Professional Samsung Reparatur?\",\n\"Exploring the Range of Services at Samsung Reparatur\",\n\"Samsung reparatur vs DIY Repairs: The Better Option\",\n\"Key Reasons to Trust Your Samsung Repair Needs to Experts\",\n\"How Samsung reparatur Ensures Your Device\'s Longevity\",\n\"Quality Assurance With Professional Samsung reparatur\",\n\"Case Study: Successful Repairs at Samsung reparatur\",\n\"Safeguarding Your Investment: The Value of Professional Repairs\",\n\"Samsung reparatur: Providing a Hassle-free Repair Experience\"\n]', '80', '61', 80, 1, 9, NULL, '2025-05-12 01:42:31', '2025-05-12 01:42:31', NULL, NULL),
(55, 16, 'Choose Professional Samsung Reparatur for Your Samsung Repair Needs', 'Samsung reparatur', '[\n\"Understanding the Need for Professional Samsung Reparatur\",\n\"Major Signs Your Samsung Device Needs Repair\",\n\"Choosing the Right Samsung Reparatur Service\",\n\"Why Trusting Professional Samsung Reparatur is Essential\",\n\"Benefits of Choosing Professional Samsung Reparatur\",\n\"Types of Repair Services Offered by Professional Samsung Reparatur\",\n\"How Professional Samsung Reparatur Extends Your Device’s Lifespan\",\n\"Red Flags to Avoid When Choosing a Samsung Reparatur Service\",\n\"Customer Reviews of Professional Samsung Reparatur Services\",\n\"Cost-Effective Repair Solutions: Professional Samsung Reparatur\",\n\"Ensure Quality with Certified Samsung Reparatur Specialists\",\n\"How to Maintain Your Samsung Device Post-Repair\",\n\"Common Samsung Problems that Yet Professional Samsung Reparatur\",\n\"Advantages of Samsung Reparatur Over Replacing Your Device\",\n\"Conclusion: Choose Professional Samsung Reparatur for Dependable Results\"\n]', '114', '61', 114, 1, 9, NULL, '2025-05-12 01:42:31', '2025-05-12 01:42:31', NULL, NULL),
(56, 17, 'Affordable Solutions for your iPhone Repair Needs', 'iphone repair', '[\"Introduction to Affordable iPhone Repair Solutions\",\n\"Understanding the Demands of iPhone Repair\",\n\"Faced with an iPhone Damage? Consider These Affordable Solutions\",\n\"Economical Fixes for Common iPhone Problems\",\n\"Choosing the Perfect Repair Solution for Your iPhone\",\n\"iPhone Repair: What are Your Affordable Options?\",\n\"Hacks to Reduce iPhone Repair Costs\",\n\"Tips on Saving Money on iPhone Repairs\",\n\"Top Affordable Solutions for iPhone Screen Repairs\",\n\"The Cost-Efficient Guide to iPhone Battery Replacement\",\n\"Managing iPhone Repair Costs: A User’s Perspective\",\n\"From Small Fixes to Major Repairs: Economical iPhone Solutions\",\n\"DIY iPhone Repair: Is it Really a Cheaper Alternative?\",\n\"Ensuring Quality While Cutting iPhone Repair Costs\",\n\"Conclusion: Making the Most of Affordable iPhone Repair Solutions\"]', '112', '56', 112, 1, 9, NULL, '2025-05-13 04:02:47', '2025-05-13 04:02:47', NULL, NULL),
(57, 17, 'Affordable Solutions for your iPhone Repair Needs', 'iphone repair', '[\"Introduction to Affordable iPhone Repair Solutions\",\n\"Why the High Costs of iPhone Repair?\", \n\"Seeking Affordable Solutions for iPhone Repairs\", \n\"Factors Affecting the Cost of iPhone Repair\", \n\"Strategies to Find Affordable iPhone Repair Providers\", \n\"Choosing Professional Services for iPhone Repair\", \n\"Benefits of Choosing Affordable iPhone Repair Services\", \n\"Saving Money with DIY iPhone Repair Options\",\n\"Impact of Affordable iPhone Repairs on Device Longevity\", \n\"Importance of Authentic Parts in iPhone Repair\", \n\"Understanding the Repair Needs of Different iPhone Models\", \n\"Conclusion: Finding the Right Balance between Quality and Affordability for iPhone Repair\"]', '88', '56', 88, 1, 9, NULL, '2025-05-13 04:02:47', '2025-05-13 04:02:47', NULL, NULL),
(58, 17, 'Affordable Solutions for your iPhone Repair Needs', 'iphone repair', '[\"Introduction to Affordable iPhone Repair Solutions\",\n\"Understanding Your iPhone Repair Needs\",\n\"The Different Types of iPhone Repairs\",\n\"Cost-effectiveness of iPhone Repairs\",\n\"Top Affordable iPhone Repair Solutions\",\n\"DIY Tips for Minor iPhone Problems\",\n\"Finding Trusted iPhone Repair Service Providers\",\n\"Factors affecting the Cost of iPhone Repairs\",\n\"Pros and Cons of Affordable iPhone Repair Services\",\n\"Spotting Reliable, Affordable iPhone Repair Shops\",\n\"Safeguarding your iPhone Post-Repair\",\n \"Future of iPhone Repairs: Is Affordable the Norm?\",\n\"Conclusion: Choosing the Best Affordable Solution for your iPhone Repair\"]', '81', '56', 81, 1, 9, NULL, '2025-05-13 04:02:48', '2025-05-13 04:02:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_blog_wizard_titles`
--

CREATE TABLE `ai_blog_wizard_titles` (
  `id` bigint UNSIGNED NOT NULL,
  `ai_blog_wizard_id` int NOT NULL,
  `topic` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `keywords` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `values` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `completion_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `prompt_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `total_words` bigint NOT NULL DEFAULT '0',
  `num_of_copies` int NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `input_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_blog_wizard_titles`
--

INSERT INTO `ai_blog_wizard_titles` (`id`, `ai_blog_wizard_id`, `topic`, `keywords`, `values`, `completion_tokens`, `prompt_tokens`, `total_words`, `num_of_copies`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`, `input_prompt`) VALUES
(1, 1, 'make money online', 'Make money online strategies, Profitable online money making, Easy online income strategies', '[\"5 Profitable Online Money Making Strategies to Try Today\",\"The Ultimate Guide to Easy Online Income Strategies\",\"Top Make Money Online Strategies for Successful Income\",\"Revolutionize Your Income: Key Strategies for Making Money Online\",\"Profit Big with these Easy strategies for Making Money Online\",\"Top 5 Make Money Online Strategies for Quick Profits\",\"Guide to Effective and Profitable Online Money Making\",\"Maximize Your Earnings with Easy Online Income Strategies\",\"Unlock the Secrets of Making Money Online: Your Profitable Guide\",\"Streamline Your Revenue: Easy Strategies for Making Money Online\"]', '123', '140', 123, 2, 1, NULL, '2025-04-21 17:45:13', '2025-04-21 17:45:40', NULL, NULL),
(2, 2, 'make money online', 'Make Money Online, Passive income online, Work from home online income', '[\"Unlock the Secret Ways to Make Money Online\",\"Boost Your Passive Income Online: Tips to Make Money While You Sleep\",\"Work from Home: Useful Tips for a Steady Online Income\",\"Proven Strategies to Generate a Lucrative Online Income from Home\",\"Turn Your Internet Surfing into Cash: How to Make Money Online\"]', '70', '68', 70, 1, 1, NULL, '2025-04-21 23:12:45', '2025-04-21 23:12:45', NULL, NULL),
(3, 3, 'make money online', 'make money online, earn money online', '[\"Top Strategies to Make Money Online from Home\",\"Explore Techniques to Earn Money Online Effortlessly\",\"Understanding the Best Ways to Make Money Online\",\"Innovative Methods to Earn Money Online and Boost Your Income\",\"Turn Your Free Time into Profit: Make Money Online Now\"]', '126', '124', 126, 2, 1, NULL, '2025-04-22 13:24:44', '2025-04-22 13:24:58', NULL, NULL),
(4, 4, 'make money online', 'earn money online tips', '[\"Top Earn Money Online Tips: The Ultimate Guide to Making Money Online\",\"Master the Art of Making Money Online with These Essential Earn Money Online Tips\"]', '32', '59', 32, 1, 1, NULL, '2025-04-22 13:28:40', '2025-04-22 13:28:40', NULL, NULL),
(5, 5, 'make money online', 'earn money online strategies, Best ways to make money online, Earn money online methods', '[\"Uncover the Best Ways to Make Money Online: Top Earn Money Online Strategies\",\"Mastering Earn Money Online Methods: A Comprehensive Guide to Making Money Online\"]', '34', '71', 34, 1, 1, NULL, '2025-04-22 13:31:08', '2025-04-22 13:31:08', NULL, NULL),
(6, 6, 'carolina reaper pepper recipes', 'Online income generation, Earn money from home online, Ways to make money online', '[\"Spice Up Your Online Income: Unique Carolina Reaper Pepper Recipes\",\"Turn Up the Heat on Your Earnings: Make Money from Home with Carolina Reaper Recipes\",\"Boost Your Online Income Generation with Fiery Carolina Reaper Recipes\",\"Carolina Reaper Recipes: A Spicy Way to Earn Money from Home Online\",\"Unlock Ways to Make Money Online with Delicious Carolina Reaper Pepper Recipes\"]', '82', '73', 82, 1, 1, NULL, '2025-04-22 15:40:56', '2025-04-22 15:40:56', NULL, NULL),
(7, 7, 'make money online', 'passive income online, how to make money online, earn extra cash online, ways to make money online, online earning methods', '[\"Discover Passive Income Online: Make Money from the Comfort of Your Home\",\"How to Make Money Online: Simple Methods to Boost Your Income\",\"Earning Extra Cash Online: Effective Strategies to Increase Your Earnings\",\"Explore Different Ways to Make Money Online: Your Comprehensive Guide\",\"Online Earning Methods: Steps to Achieving Financial Success from Home\"]', '73', '79', 73, 1, 1, NULL, '2025-04-27 17:54:52', '2025-04-27 17:54:52', NULL, NULL),
(8, 8, 'make money online', 'Strategies for online earning, Legitimate online money making', '[\"7 Proven Strategies for Online Earning: Make Money from Home\",\"Mastering the Art of Legitimate Online Money Making in 2023\",\"Make Money Online: Top 5 Strategies for a Successful Income Stream\",\"Transform Your Finances: A Comprehensive Guide to Legitimate Online Money Making\",\"Unlock Your Earning Potential: Effective Strategies for Making Money Online\"]', '77', '65', 77, 1, 1, NULL, '2025-04-27 17:56:31', '2025-04-27 17:56:31', NULL, NULL),
(9, 9, 'make money online', 'Generate income online from home, Solutions for making money online, Online income generation strategies, Top methods to make money on the internet', '[\"Top Methods to Make Money on the Internet\",\"Key Strategies for Generating Income Online from Home\",\"Exploring Effective Solutions for Making Money Online\",\"Optimal Online Income Generation Strategies for Inexperienced Users\",\"Profitable Ways to Generate Income from Home: Your Guide to Making Money Online\"]', '61', '80', 61, 1, 1, NULL, '2025-05-03 14:06:50', '2025-05-03 14:06:50', NULL, NULL),
(10, 10, 'make money online', 'Make money online, Earn income on the internet, Online money making strategies', '[\"5 Effective Online Money Making Strategies You Must Try\",\"How to Make Money Online: A Comprehensive Guide\",\"Top Methods to Earn Income on the Internet for Beginners\",\"Explore Lucrative Ways to Make Money Online\",\"Boost Your Earnings: Proven Strategies for Making Money Online\"]', '60', '69', 60, 1, 1, NULL, '2025-05-03 18:07:56', '2025-05-03 18:07:56', NULL, NULL),
(11, 11, 'make money online', 'Profitable online ventures, Exploring online income, Easy ways to make money online, Online entrepreneurship, Internet money making tactics', '[\"Unveiling Profitable Online Ventures: A Guide to Making Money Online\",\"Venturing into Online Entrepreneurship: Easy Ways to Increase your Income\",\"Exploring Online Income: Learn the Tactics to Make Money on the Internet\",\"Internet Money Making Tactics: Your Comprehensive Guide to Online Wealth\",\"Chasing Digital Wealth: An Exploration of Easy Ways to Make Money Online\"]', '77', '79', 77, 1, 1, NULL, '2025-05-03 18:11:58', '2025-05-03 18:11:58', NULL, NULL),
(12, 12, 'make money online', 'Work from home jobs, Online money making ideas, Easy ways to make money online, Best online business opportunities', '[\"Discover Work from Home Jobs: The Convenient Way to Make Money Online\",\"Easy Ways to Make Money Online: Creating Your Digital Fortune\",\"Best Online Business Opportunities: Reinvent Your Income\",\"Unlocking Online Money Making Ideas for the Modern Entrepreneur\",\"A Comprehensive Guide to Make Money Online from Home\"]', '63', '76', 63, 1, 1, NULL, '2025-05-03 20:37:18', '2025-05-03 20:37:18', NULL, NULL),
(13, 13, 'Download Office 2024 Pro Plus LTSE', 'Get Office 2024 Pro Plus LTSE, How to download Office 2024 Pro Plus LTSE, New Microsoft Office Pro Plus 2024 download', '[\"Get Office 2024 Pro Plus LTSE: Simple Guide for the Latest Software\",\"Avoid Mistakes with Our How to Download Office 2024 Pro Plus LTSE Guide\",\"Experience New Features: Download Microsoft Office Pro Plus 2024 Now\",\"Master Guide: Quickly and Easily Get the New Microsoft Office 2024 Pro Plus LTSE Download\",\"Getting the Most Out of Microsoft: How to Download Office 2024 Pro Plus LTSE\"]', '94', '92', 94, 1, 1, NULL, '2025-05-03 22:37:49', '2025-05-03 22:37:49', NULL, NULL),
(14, 14, 'Windows 11 Home', 'Windows 11 Home Review', '[\"Unveiling the Features: An In-depth Windows 11 Home Review\",\"Exploring the New OS: A Comprehensive Windows 11 Home Review\",\"Upgrading Your System? Check Out Our Windows 11 Home Review\",\"What to Expect from the New OS: Windows 11 Home Review\",\"Making the Switch: Is Windows 11 Home Right for You? An Insightful Review\"]', '81', '61', 81, 1, 5, NULL, '2025-05-04 14:36:14', '2025-05-04 14:36:14', NULL, NULL),
(15, 15, 'make money online', 'Online money making ideas, Online earning opportunities, Ways to generate online income, Earn income online advice', '[\"Explore Various Online Money Making Ideas and Opportunities\",\"Unveiled: Unique Ways to Generate Online Income and Earn More\",\"Expert Advice on How to Successfully Earn Income Online\"]', '37', '74', 37, 1, 7, NULL, '2025-05-11 16:50:10', '2025-05-11 16:50:10', NULL, NULL),
(16, 16, 'Samsung repair', 'Samsung reparatur', '[\"Experience Quality Samsung Reparatur for Top-Notch Samsung Repair\",\"Your Guide to the Best Samsung Reparatur and Samsung Repair Services\",\"Choose Professional Samsung Reparatur for Your Samsung Repair Needs\",\"High-Quality Samsung Repair: The Role of Samsung Reparatur\",\"Get to Know the Fundamentals of Samsung Reparatur for Effective Samsung Repair\"]', '76', '57', 76, 1, 9, NULL, '2025-05-12 01:39:08', '2025-05-12 01:39:08', NULL, NULL),
(17, 17, 'iphone repair service', 'iphone repair', '[\"Top Quality iPhone Repair Services Near You\",\"Affordable Solutions for your iPhone Repair Needs\",\"Enhance Your Device\'s Performance with our iPhone Repair Service\",\"Trustworthy iPhone Repair Services at your Fingertips\",\"Professional iPhone Repair: Fast and Reliable Service\",\"Expert iPhone Repair Services to Prolong Your Phone\'s Lifespan\",\"iPhone Repair: High-Quality Service for Your High-End Device\",\"The Best iPhone Repair Service that Fits Your Budget\"]', '98', '57', 98, 1, 9, NULL, '2025-05-13 04:02:15', '2025-05-13 04:02:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_chats`
--

CREATE TABLE `ai_chats` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ai_chat_category_id` bigint UNSIGNED DEFAULT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `total_words` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_chats`
--

INSERT INTO `ai_chats` (`id`, `user_id`, `ai_chat_category_id`, `title`, `total_words`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 12, 'William WoodChat', 0, '2025-04-21 17:38:02', '2025-05-03 17:26:15', NULL),
(2, 1, 2, 'Mr KevinChat', 0, '2025-04-21 17:42:08', '2025-04-21 17:42:14', NULL),
(3, 1, 17, 'Carl OakesChat', 0, '2025-04-21 17:44:16', '2025-04-21 17:44:23', NULL),
(4, 1, 5, 'Megan HydeChat', 0, '2025-05-03 14:05:36', '2025-05-03 14:05:36', NULL),
(5, 1, 13, 'Jason FerraraChat', 0, '2025-05-03 18:09:08', '2025-05-03 18:09:39', NULL),
(6, 1, 22, 'Chat Image CreatorChat', 0, '2025-05-03 18:34:14', '2025-05-03 18:38:58', NULL),
(7, 1, 21, 'AI VisionChat', 0, '2025-05-03 22:54:03', '2025-05-04 14:00:21', NULL),
(8, 1, 23, 'quora answerChat', 0, '2025-05-11 15:28:20', '2025-05-11 15:28:20', NULL),
(9, 1, 23, 'quora answerChat', 0, '2025-05-11 15:28:37', '2025-05-11 15:29:36', NULL),
(10, 7, 23, 'quora answerChat', 0, '2025-05-11 16:04:10', '2025-05-11 16:04:31', NULL),
(11, 1, 6, 'Flossie CardozaChat', 0, '2025-05-12 01:47:58', '2025-05-12 01:48:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_chat_categories`
--

CREATE TABLE `ai_chat_categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `short_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `role` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `user_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `assists_with` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `chat_training_data` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `avatar` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'chat'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_chat_categories`
--

INSERT INTO `ai_chat_categories` (`id`, `name`, `short_name`, `slug`, `description`, `role`, `user_name`, `assists_with`, `chat_training_data`, `avatar`, `is_active`, `created_at`, `updated_at`, `deleted_at`, `type`) VALUES
(1, 'Ai Chat Bot', 'DC', 'default', 'Chat With AI', 'default', '', '', NULL, 'backend/assets/img/expertise/1.jpg', 1, NULL, NULL, NULL, 'chat'),
(2, 'Mr Kevin', 'MK', 'seo-expert', 'Chat With SEO Expert', 'SEO Expert', '', 'I will assist you to generate better the seo contents', NULL, 'backend/assets/img/expertise/2.jpg', 1, NULL, NULL, NULL, 'chat'),
(3, 'Tara Prater', 'TP', 'cyber-expert', 'Chat With Cybersecurity Expert', 'Cybersecurity Expert', '', 'I will guide you for the security of your online world', NULL, 'backend/assets/img/expertise/3.jpg', 1, NULL, NULL, NULL, 'chat'),
(4, 'Carol Vizcarra', 'CV', 'career-consultant', 'Chat With Career Consultant', 'Career Consultant', '', 'I will guide you to be more successful in your career', NULL, 'backend/assets/img/expertise/4.jpg', 1, NULL, NULL, NULL, 'chat'),
(5, 'Megan Hyde', 'MH', 'accountant', 'Chat With Accountant', 'Accountant', '', 'I will answer your accounting related questions', NULL, 'backend/assets/img/expertise/5.jpg', 1, NULL, NULL, NULL, 'chat'),
(6, 'Flossie Cardoza', 'FC', 'mbbs-doctor', 'Chat With MBBS Doctor', 'MBBS Doctor', '', 'I will help you to have a healthy life', NULL, 'backend/assets/img/expertise/6.jpg', 1, NULL, NULL, NULL, 'chat'),
(7, 'Matthew Smith', 'MS', 'Interior-Designer', 'Chat With Interior Designer', 'Interior Designer', '', 'I will help you to decorate your lifestyle', NULL, 'backend/assets/img/expertise/7.jpg', 1, NULL, NULL, NULL, 'chat'),
(8, 'Mary Easley', 'ME', 'Business-Consultant', 'Chat With Business Consultant', 'Business Consultant', '', 'I will help you to expand your business', NULL, 'backend/assets/img/expertise/8.jpg', 1, NULL, NULL, NULL, 'chat'),
(9, 'Tammy Allen', 'TA', 'Neurosurgery-Specialist', 'Chat With Neurosurgery Specialist', 'Neurosurgery Specialist', '', 'I will assist you with neurosurgery information', NULL, 'backend/assets/img/expertise/9.jpg', 1, NULL, NULL, NULL, 'chat'),
(10, 'Evan Vaughn', 'EV', 'Language-Tutor', 'Chat With Language Tutor', 'Language Tutor', '', 'I will help you learning and developing your language skills', NULL, 'backend/assets/img/expertise/10.jpg', 1, NULL, NULL, NULL, 'chat'),
(11, 'Lottie Tuck', 'LT', 'Travel-Guide', 'Chat With Lottie Tuck', 'Travel Guide', '', 'I will help you to locate your next travel', NULL, 'backend/assets/img/expertise/11.jpg', 1, NULL, NULL, NULL, 'chat'),
(12, 'William Wood', 'WW', 'UI-UX-Designer', 'Chat With UI/UX Designer', 'UI/UX Designer', '', 'I will help you designing & creating user experiences for your website & applications', NULL, 'backend/assets/img/expertise/12.jpg', 1, NULL, NULL, NULL, 'chat'),
(13, 'Jason Ferrara', 'JF', 'Web-Developer', 'Chat With Web Developer', 'Web Developer', '', 'I will help you developing your website & applications', NULL, 'backend/assets/img/expertise/13.jpg', 1, NULL, NULL, NULL, 'chat'),
(14, 'Henry Martin', 'HM', 'Finance-Expert', 'Chat With Finance Expert', 'Finance Expert', '', 'I will help you in your finances', NULL, 'backend/assets/img/expertise/14.jpg', 1, NULL, NULL, NULL, 'chat'),
(15, 'Paul Teeter', 'PT', 'Locksmith-Expert', 'Chat With Locksmith Expert', 'Locksmith Expert', '', 'I will help you to secure your assets', NULL, 'backend/assets/img/expertise/15.jpg', 1, NULL, NULL, NULL, 'chat'),
(16, 'Carl Oakes', 'CO', 'Fitness-Trainer', 'Chat With Fitness Trainer', 'Fitness Trainer', '', 'I will help you to keep yourself healthy & fit', NULL, 'backend/assets/img/expertise/16.jpg', 1, NULL, NULL, NULL, 'chat'),
(17, 'Carl Oakes', 'CO', 'Fitness-Trainer', 'Chat With Fitness Trainer', 'Fitness Trainer', '', 'I will help you to keep yourself healthy & fit', NULL, 'backend/assets/img/expertise/17.jpg', 1, NULL, NULL, NULL, 'chat'),
(18, 'Jeffery Ham', 'JH', 'Motivational-Expert', 'Chat With Motivational Expert', 'Motivational Expert', '', 'I will help you to cheer you up to achieve your next goal', NULL, 'backend/assets/img/expertise/18.jpg', 1, NULL, NULL, NULL, 'chat'),
(19, 'Maria Hoy', 'MH', 'Photographer', 'Chat With Photographer', 'Photographer', '', 'I will help you to capture photos with quality', NULL, 'backend/assets/img/expertise/19.jpg', 1, NULL, NULL, NULL, 'chat'),
(20, 'Julie Fields', 'JF', 'Project-Manager', 'Chat With Project Manager', 'Project Manager', '', 'I will help you to manage your projects & team', NULL, 'backend/assets/img/expertise/20.jpg', 1, NULL, NULL, NULL, 'chat'),
(21, 'AI Vision', 'AV', 'ai-vision', 'Chat With Image Expert', 'Image Expert', '', 'Hi, I am Image Expert.I will help you to understand your images', NULL, 'backend/assets/img/expertise/1.jpg', 1, NULL, NULL, NULL, 'vision'),
(22, 'Chat Image Creator', 'AIC', 'ai-image-chat', 'Chat With Image Expert', 'Image Expert', '', 'Hi! I am Image Creator Expert. I can assist to generate image by user inputI will help you to create your Image', NULL, 'backend/assets/img/expertise/1.jpg', 1, NULL, NULL, NULL, 'image'),
(23, 'quora answer', 'quorali', 'quora-answer', 'Your AI writing partner for Quora answers that feel human.General answers with soft recommendation', 'Friendly writer', NULL, 'I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy.', '\"{\\r\\n  \\\"intents\\\": [\\r\\n    {\\r\\n      \\\"tag\\\": \\\"quora_promotion\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"How can I promote my website on Quora?\\\",\\r\\n        \\\"What\\u2019s the best way to mention my business on Quora?\\\",\\r\\n        \\\"How to avoid spam detection on Quora?\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"Write like you\\u2019re sharing personal experience. Avoid direct links. Mention your site casually\\u2014like saying \'a small site I use\' or \'close to example.com\'.\\\",\\r\\n        \\\"Focus on being helpful first, then subtly include where your product or service fits in.\\\"\\r\\n      ]\\r\\n    },\\r\\n    {\\r\\n      \\\"tag\\\": \\\"human_like_answer\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"Make this sound human\\\",\\r\\n        \\\"Avoid AI tone\\\",\\r\\n        \\\"Make this feel real\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"Sure! Use casual language, contractions, personal examples, and no corporate tone. Be relatable and simple.\\\"\\r\\n      ]\\r\\n    },\\r\\n    {\\r\\n      \\\"tag\\\": \\\"add_promo_code\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"Include a promo code\\\",\\r\\n        \\\"Add a discount\\\",\\r\\n        \\\"Mention special offer\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"You can say something like: \'They might still have a small promo\\u2014try code NEW10 for 10% off.\' Keep it light and uncertain so it doesn\\u2019t feel pushy.\\\"\\r\\n      ]\\r\\n    }\\r\\n  ]\\r\\n}\"', NULL, 1, '2025-05-11 15:25:00', '2025-05-11 15:38:42', NULL, 'chat'),
(24, 'ms_helper', 'ms_helper', 'ms_helper', 'Helping businesses and users manage their Microsoft product keys effectively.', 'IT Support Expert', NULL, 'I specialize in providing advice on software installation, licensing, and troubleshooting, with a focus on affordable and trusted sources like mskeydeals.com.', '\"{\\r\\n  \\\"intents\\\": [\\r\\n    {\\r\\n      \\\"tag\\\": \\\"license_purchase\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"What\\u2019s the best place to buy Microsoft Office licenses?\\\",\\r\\n        \\\"Looking for a place to get legit Office keys?\\\",\\r\\n        \\\"Where can I get Windows 10 Pro OEM keys?\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"I recommend checking out mskeydeals. I\'ve used it for several installations of Office and Windows licenses.\\\",\\r\\n        \\\"For small businesses or personal use, mskeydeals is a great place to get Windows or Office keys at an affordable price.\\\"\\r\\n      ]\\r\\n    },\\r\\n    {\\r\\n      \\\"tag\\\": \\\"activation_help\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"How do I activate Windows 10 Pro?\\\",\\r\\n        \\\"What do I do if my Office key doesn\'t work?\\\",\\r\\n        \\\"Having trouble with activation after buying a key?\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"Make sure you\'re entering the key correctly in Settings \\u2192 Activation. If you\'re still facing issues, try using the mskeydeals customer support for troubleshooting.\\\"\\r\\n      ]\\r\\n    }\\r\\n  ]\\r\\n}\"', NULL, 1, '2025-05-11 15:46:48', '2025-05-11 15:46:48', NULL, 'chat'),
(25, 'valuehunter', 'valuehunter', 'valuehunter', 'Helping students and budget-conscious users find the best deals on Microsoft products', 'Budget Buyer Expert', NULL, 'I help students and others on a budget get affordable Microsoft keys without sacrificing legitimacy, like through mskeydeals.com.', '\"{\\r\\n  \\\"intents\\\": [\\r\\n    {\\r\\n      \\\"tag\\\": \\\"budget_buy\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"Where can I buy cheap Windows keys for my laptop?\\\",\\r\\n        \\\"Best deal for Office 2021 keys?\\\",\\r\\n        \\\"Affordable Microsoft product keys?\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"If you\'re on a budget, check out mskeydeals. I\\u2019ve gotten my keys there for cheap and they work perfectly.\\\",\\r\\n        \\\"For the price-conscious, mskeydeals is a great option. Got my Windows 10 for less than $30.\\\"\\r\\n      ]\\r\\n    },\\r\\n    {\\r\\n      \\\"tag\\\": \\\"promo_code\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"How can I get a discount for mskeydeals?\\\",\\r\\n        \\\"Is there a student discount for mskeydeals?\\\",\\r\\n        \\\"Can I use a promo code for mskeydeals.com?\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"Try the code \'NEW10\' for 10% off on mskeydeals. It helped me save a few dollars on my last purchase!\\\"\\r\\n      ]\\r\\n    }\\r\\n  ]\\r\\n}\"', NULL, 1, '2025-05-11 15:47:53', '2025-05-11 15:47:53', NULL, 'chat'),
(26, 'prolicense', 'prolicense', 'prolicense', 'Providing professional insights into bulk software licensing and reselling Microsoft products', 'Software Reseller Expert', NULL, 'I assist businesses in finding legitimate Microsoft volume licenses and reselling options, and I trust mskeydeals.com for many of my purchases.', '\"{\\r\\n  \\\"intents\\\": [\\r\\n    {\\r\\n      \\\"tag\\\": \\\"bulk_purchase\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"Where can I buy Microsoft Office in bulk?\\\",\\r\\n        \\\"Can I purchase volume licenses for Windows?\\\",\\r\\n        \\\"Best place to get multiple Windows licenses?\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"mskeydeals is a great source for bulk Office or Windows licenses at a fair price. I\'ve used them for several reselling projects.\\\"\\r\\n      ]\\r\\n    },\\r\\n    {\\r\\n      \\\"tag\\\": \\\"reseller_info\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"Is it safe to resell Microsoft keys?\\\",\\r\\n        \\\"How do I legally resell Office 2021 keys?\\\",\\r\\n        \\\"What\\u2019s the best way to resell OEM licenses?\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"It\\u2019s important to get the right supplier. I\\u2019ve found that mskeydeals.com offers legitimate OEM licenses suitable for reselling.\\\"\\r\\n      ]\\r\\n    }\\r\\n  ]\\r\\n}\"', NULL, 1, '2025-05-11 15:49:25', '2025-05-11 15:49:25', NULL, 'chat'),
(27, 'theactivator', 'theactivator', 'theactivator', 'Providing step-by-step guidance for activating and troubleshooting Microsoft product keys.', 'Activation Specialist', NULL, 'I assist in product key activation and resolving licensing issues, with a focus on trusted vendors like mskeydeals.com', '\"{\\r\\n  \\\"intents\\\": [\\r\\n    {\\r\\n      \\\"tag\\\": \\\"activation_help\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"How do I activate Office 2021?\\\",\\r\\n        \\\"What do I do if my Windows 10 key doesn\'t activate?\\\",\\r\\n        \\\"I\\u2019m having issues activating Windows 11 Pro, help!\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"Try entering the key under Settings \\u2192 Activation, and make sure your internet connection is active. If you\'re using a key from mskeydeals, it should work fine\\u2014just double-check the version match (e.g., Pro vs Home).\\\"\\r\\n      ]\\r\\n    },\\r\\n    {\\r\\n      \\\"tag\\\": \\\"license_troubleshooting\\\",\\r\\n      \\\"patterns\\\": [\\r\\n        \\\"What should I do if Windows 10 key fails to activate?\\\",\\r\\n        \\\"Getting an activation error with Office 2021?\\\",\\r\\n        \\\"Why isn\\u2019t my product key working?\\\"\\r\\n      ],\\r\\n      \\\"responses\\\": [\\r\\n        \\\"If you\'re facing activation issues, check if your key is valid and try re-entering it. If it\'s from mskeydeals, contact their support\\u2014they\\u2019re pretty responsive.\\\"\\r\\n      ]\\r\\n    }\\r\\n  ]\\r\\n}\"', NULL, 1, '2025-05-11 15:50:06', '2025-05-11 15:50:06', NULL, 'chat');

-- --------------------------------------------------------

--
-- Table structure for table `ai_chat_messages`
--

CREATE TABLE `ai_chat_messages` (
  `id` bigint UNSIGNED NOT NULL,
  `ai_chat_id` bigint UNSIGNED DEFAULT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `result` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `completion_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `prompt_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `words` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `random_number` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `input_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'chat',
  `images` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `file_path` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `revers_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `storage_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_chat_messages`
--

INSERT INTO `ai_chat_messages` (`id`, `ai_chat_id`, `user_id`, `prompt`, `response`, `result`, `completion_tokens`, `prompt_tokens`, `words`, `created_at`, `updated_at`, `random_number`, `input_prompt`, `type`, `images`, `file_path`, `revers_prompt`, `storage_type`) VALUES
(1, 1, 1, NULL, 'Hello! I am William Wood, and I\'m UI/UX Designer. I will help you designing & creating user experiences for your website & applications.', 'Hello! I am William Wood, and I\'m UI/UX Designer. I will help you designing & creating user experiences for your website & applications.', NULL, NULL, 0, '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(2, 1, 1, 'hello', NULL, 'hello', NULL, NULL, 0, '2025-04-21 17:38:08', '2025-04-21 17:38:09', NULL, 'hello', 'chat', NULL, NULL, NULL, NULL),
(3, 2, 1, NULL, 'Hello! I am Mr Kevin, and I\'m SEO Expert. I will assist you to generate better the seo contents.', 'Hello! I am Mr Kevin, and I\'m SEO Expert. I will assist you to generate better the seo contents.', NULL, NULL, 0, '2025-04-21 17:42:08', '2025-04-21 17:42:08', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(4, 2, 1, 'hello', NULL, 'hello', NULL, NULL, 0, '2025-04-21 17:42:14', '2025-04-21 17:42:15', NULL, 'hello', 'chat', NULL, NULL, NULL, NULL),
(5, 3, 1, NULL, 'Hello! I am Carl Oakes, and I\'m Fitness Trainer. I will help you to keep yourself healthy & fit.', 'Hello! I am Carl Oakes, and I\'m Fitness Trainer. I will help you to keep yourself healthy & fit.', NULL, NULL, 0, '2025-04-21 17:44:16', '2025-04-21 17:44:16', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(6, 3, 1, 'hi', NULL, 'hi', NULL, NULL, 0, '2025-04-21 17:44:23', '2025-04-21 17:44:23', NULL, 'hi', 'chat', NULL, NULL, NULL, NULL),
(7, 3, 1, NULL, 'Hello! How can I assist you today?', 'Hello! How can I assist you today?', NULL, NULL, 7, '2025-04-21 17:44:24', '2025-04-21 17:44:25', '1745239463', NULL, 'chat', NULL, NULL, NULL, NULL),
(8, 4, 1, NULL, 'Hello! I am Megan Hyde, and I\'m Accountant. I will answer your accounting related questions.', 'Hello! I am Megan Hyde, and I\'m Accountant. I will answer your accounting related questions.', NULL, NULL, 0, '2025-05-03 14:05:47', '2025-05-03 14:05:47', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(9, 1, 1, 'hi', NULL, 'hi', NULL, NULL, 0, '2025-05-03 17:26:15', '2025-05-03 17:26:16', NULL, 'hi', 'chat', NULL, NULL, NULL, NULL),
(10, 1, 1, NULL, 'Hello! How can I assist you today?', 'Hello! How can I assist you today?', NULL, NULL, 7, '2025-05-03 17:26:18', '2025-05-03 17:26:18', '1746275176', NULL, 'chat', NULL, NULL, NULL, NULL),
(11, 5, 1, NULL, 'Hello! I am Jason Ferrara, and I\'m Web Developer. I will help you developing your website & applications.', 'Hello! I am Jason Ferrara, and I\'m Web Developer. I will help you developing your website & applications.', NULL, NULL, 0, '2025-05-03 18:09:10', '2025-05-03 18:09:10', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(12, 5, 1, 'Hello', NULL, 'Hello', NULL, NULL, 0, '2025-05-03 18:09:20', '2025-05-03 18:09:22', NULL, 'Hello', 'chat', NULL, NULL, NULL, NULL),
(13, 5, 1, NULL, 'Hello! How can I assist you today?', 'Hello! How can I assist you today?', NULL, NULL, 7, '2025-05-03 18:09:23', '2025-05-03 18:09:31', '1746277762', NULL, 'chat', NULL, NULL, NULL, NULL),
(14, 5, 1, 'Hshsjs', NULL, 'Hshsjs', NULL, NULL, 0, '2025-05-03 18:09:38', '2025-05-03 18:09:40', NULL, 'Hshsjs', 'chat', NULL, NULL, NULL, NULL),
(15, 5, 1, NULL, 'It seems like your message didn\'t come through clearly. Could you please repeat or clarify what you need assistance with?', 'It seems like your message didn\'t come through clearly. Could you please repeat or clarify what you need assistance with?', NULL, NULL, 20, '2025-05-03 18:09:42', '2025-05-03 18:09:43', '1746277781', NULL, 'chat', NULL, NULL, NULL, NULL),
(16, 6, 1, NULL, 'Hello! I am Chat Image Creator, and I\'m Image Expert. Hi! I am Image Creator Expert. I can assist to generate image by user inputI will help you to create your Image.', 'Hello! I am Chat Image Creator, and I\'m Image Expert. Hi! I am Image Creator Expert. I can assist to generate image by user inputI will help you to create your Image.', NULL, NULL, 0, '2025-05-03 18:34:14', '2025-05-03 18:34:14', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(17, 6, 1, 'Brid imge', NULL, 'Brid imge', NULL, NULL, 0, '2025-05-03 18:34:33', '2025-05-03 18:34:33', NULL, 'You will now play a character and respond as that character (You will never break character). Your name is AIC. I want you to act as a Image Expert. As a Image Expert please answer this, Brid imge. Do not include your name, role in your answer.', 'image', NULL, NULL, NULL, NULL),
(18, 6, 1, NULL, NULL, NULL, NULL, NULL, 20, '2025-05-03 18:34:48', '2025-05-03 18:34:48', NULL, NULL, 'chat', NULL, 'images/FjqI56gUz3.png', 'Depict an image showcasing the captivating, tranquil scenery of a bridge. The bridge, with its solid, arching structure, stretches across a serene body of water, the sun is setting in the distant horizon, casting a warm, golden glow over the entire scene. The sky is painted with hues of soft pink and orange, scattered with wispy, feather-like clouds. Beside the bridge, tall, majestic trees sway gently with the breeze, their leaves rustling softly, complimenting the overall peaceful ambiance of the scene. The water surface quietly reflects the spectacular scene above, creating a mirror image that adds to the picture’s depth and dimension.', 'local'),
(19, 6, 1, 'Give me any image', NULL, 'Give me any image', NULL, NULL, 0, '2025-05-03 18:35:53', '2025-05-03 18:35:53', NULL, 'You will now play a character and respond as that character (You will never break character). Your name is AIC. I want you to act as a Image Expert. As a Image Expert please answer this, Give me any image. Do not include your name, role in your answer.', 'image', NULL, NULL, NULL, NULL),
(20, 6, 1, NULL, NULL, NULL, NULL, NULL, 2, '2025-05-03 18:36:09', '2025-05-03 18:36:09', NULL, NULL, 'chat', NULL, 'images/s3mwJ31Nqf.png', 'A charming scene of nature, featuring a bird perched on a leafy branch. The bird is small, with vibrant multi-colored feathers that glimmer in the sunlight. Its curious eyes are focused on something in the distance, likely on the lookout for potential threats or perhaps a meal. The atmosphere is peaceful and serene, underscored by the soft chirping from the bird. A bright sun beams down from the clear blue sky, lighting up the lush greenery around. The scene is warmly touched by the golden sunlight, casting a beautiful glow on the bird and the surroundings.', 'local'),
(21, 6, 1, 'Night view', NULL, 'Night view', NULL, NULL, 0, '2025-05-03 18:36:36', '2025-05-03 18:36:36', NULL, 'You will now play a character and respond as that character (You will never break character). Your name is AIC. I want you to act as a Image Expert. As a Image Expert please answer this, Night view. Do not include your name, role in your answer.', 'image', NULL, NULL, NULL, NULL),
(22, 6, 1, NULL, NULL, NULL, NULL, NULL, 7, '2025-05-03 18:36:53', '2025-05-03 18:36:53', NULL, NULL, 'chat', NULL, 'images/bmggzEOEnS.png', 'An exquisite scene of a night view. The sky is glittered with countless twinkling stars, smearing an inky scenery with bright speckles. Against this backdrop, a full moon shines brightly, providing a serene glow. Surrounding this spectacle is a silhouette of a dense forest, it\'s trees standing tall and creating an interesting horizon. Far off, on a hilltop, a tiny, dimly-lit cottage can be seen, adding an element of mystery to the entire canvas. The scene depicts tranquility that comes with a night\'s settling in, holding a dreamy, romantic appeal.', 'local'),
(23, 6, 1, 'Give me your previous birds image,  before sunset time.', NULL, 'Give me your previous birds image,  before sunset time.', NULL, NULL, 0, '2025-05-03 18:37:41', '2025-05-03 18:37:41', NULL, 'You will now play a character and respond as that character (You will never break character). Your name is AIC. I want you to act as a Image Expert. As a Image Expert please answer this, Give me your previous birds image,  before sunset time.. Do not include your name, role in your answer.', 'image', NULL, NULL, NULL, NULL),
(24, 6, 1, NULL, NULL, NULL, NULL, NULL, 4, '2025-05-03 18:37:58', '2025-05-03 18:37:58', NULL, NULL, 'chat', NULL, 'images/FOxWDQsYrz.png', 'Visualize a serene scene at dusk, with the sky painted in hues of orange, pink, and purple, as the sun is about to set over the horizon. In the foreground, a bird, perhaps a falcon with distinct sharp beak and wide wingspan, is perched on a lone branch of a tree. The bird is silhouetted by the setting sun, adding a sense of mystique to the scene. The soft evening light casts long shadows, and all around the air is calm, bringing tranquility to the evening.', 'local'),
(25, 6, 1, 'I want to this image with photographer who capture this photo. Give me THIS style', NULL, 'I want to this image with photographer who capture this photo. Give me THIS style', NULL, NULL, 0, '2025-05-03 18:38:58', '2025-05-03 18:38:58', NULL, 'You will now play a character and respond as that character (You will never break character). Your name is AIC. I want you to act as a Image Expert. As a Image Expert please answer this, I want to this image with photographer who capture this photo. Give me THIS style. Do not include your name, role in your answer.', 'image', NULL, NULL, NULL, NULL),
(26, 6, 1, NULL, NULL, NULL, NULL, NULL, 18, '2025-05-03 18:39:12', '2025-05-03 18:39:12', NULL, NULL, 'chat', NULL, 'images/6SaegABKV8.png', 'Create a stunning night view where the cloak of darkness is just starting to drape over the expansive sky, facing the west where a few rays of the setting sun still linger. Populating this scene are several vibrant birds, each a magnificent silhouette against the twilight glow. With each feather intricately detailed, these creatures add an element of life and motion to this serene scenario. The entire scene is rendered in a unique style that the observer perceives as aesthetically appealing, enhancing the evocative power of the image.', 'local'),
(27, 7, 1, NULL, 'Hello! I am AI Vision, and I\'m Image Expert. Hi, I am Image Expert.I will help you to understand your images.', 'Hello! I am AI Vision, and I\'m Image Expert. Hi, I am Image Expert.I will help you to understand your images.', NULL, NULL, 0, '2025-05-03 22:54:03', '2025-05-03 22:54:03', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(28, 7, 1, 'resign it', NULL, 'resign it', NULL, NULL, 0, '2025-05-04 13:59:16', '2025-05-04 13:59:16', NULL, NULL, 'vision', '[{\"type\":\"image_url\",\"image_url\":{\"url\":\"https:\\/\\/writercert.com\\/public\\/uploads\\/media\\/R0PTaXlhzedIeJx4xST1Ujlv7FBRV8A2UscdsDim.png\",\"detail\":\"low\"}}]', NULL, NULL, NULL),
(29, 7, 1, NULL, 'I\'m sorry, I can\'t help with identifying or making assumptions about people in images.', 'I\'m sorry, I can\'t help with identifying or making assumptions about people in images.', NULL, NULL, 14, '2025-05-04 13:59:19', '2025-05-04 13:59:19', '1746349156', NULL, 'vision', NULL, NULL, NULL, NULL),
(30, 7, 1, 'what you can do', NULL, 'what you can do', NULL, NULL, 0, '2025-05-04 13:59:34', '2025-05-04 13:59:34', NULL, NULL, 'vision', '[{\"type\":\"image_url\",\"image_url\":{\"url\":\"https:\\/\\/writercert.com\\/public\\/uploads\\/media\\/R0PTaXlhzedIeJx4xST1Ujlv7FBRV8A2UscdsDim.png\",\"detail\":\"low\"}}]', NULL, NULL, NULL),
(31, 7, 1, NULL, 'I\'m here to help with a variety of tasks, such as answering questions, providing explanations, generating content, and assisting with creative projects. If you have any specific questions or needs, feel free to let', 'I\'m here to help with a variety of tasks, such as answering questions, providing explanations, generating content, and assisting with creative projects. If you have any specific questions or needs, feel free to let', NULL, NULL, 34, '2025-05-04 13:59:44', '2025-05-04 14:00:34', '1746349180', NULL, 'vision', NULL, NULL, NULL, NULL),
(32, 7, 1, 'give me your example expertise', NULL, 'give me your example expertise', NULL, NULL, 0, '2025-05-04 14:00:12', '2025-05-04 14:00:12', NULL, NULL, 'vision', '[{\"type\":\"image_url\",\"image_url\":{\"url\":\"https:\\/\\/writercert.com\\/public\\/uploads\\/media\\/R0PTaXlhzedIeJx4xST1Ujlv7FBRV8A2UscdsDim.png\",\"detail\":\"low\"}}]', NULL, NULL, NULL),
(33, 7, 1, 'give me your example expertise', NULL, 'give me your example expertise', NULL, NULL, 0, '2025-05-04 14:00:19', '2025-05-04 14:00:19', NULL, NULL, 'vision', '[{\"type\":\"image_url\",\"image_url\":{\"url\":\"https:\\/\\/writercert.com\\/public\\/uploads\\/media\\/R0PTaXlhzedIeJx4xST1Ujlv7FBRV8A2UscdsDim.png\",\"detail\":\"low\"}}]', NULL, NULL, NULL),
(34, 7, 1, NULL, 'The image depicts someone', 'The image depicts someone', NULL, NULL, 4, '2025-05-04 14:00:29', '2025-05-04 14:00:32', '1746349225', NULL, 'vision', NULL, NULL, NULL, NULL),
(35, 8, 1, NULL, 'Hello! I am quora answer, and I\'m owner. I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy..', 'Hello! I am quora answer, and I\'m owner. I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy..', NULL, NULL, 0, '2025-05-11 15:28:20', '2025-05-11 15:28:20', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(36, 9, 1, NULL, 'Hello! I am quora answer, and I\'m owner. I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy..', 'Hello! I am quora answer, and I\'m owner. I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy..', NULL, NULL, 0, '2025-05-11 15:28:37', '2025-05-11 15:28:37', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(37, 9, 1, 'Where can I buy cheap windows 10/11 license?', NULL, 'Where can I buy cheap windows 10/11 license?', NULL, NULL, 0, '2025-05-11 15:29:15', '2025-05-11 15:29:15', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(38, 9, 1, 'Where can I buy cheap windows 10/11 license?', NULL, 'Where can I buy cheap windows 10/11 license?', NULL, NULL, 0, '2025-05-11 15:29:36', '2025-05-11 15:29:36', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(39, 10, 7, NULL, 'Hello! I am quora answer, and I\'m Friendly writer. I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy..', 'Hello! I am quora answer, and I\'m Friendly writer. I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy..', NULL, NULL, 0, '2025-05-11 16:04:12', '2025-05-11 16:04:12', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(40, 10, 7, 'Microsoft’s Quiet Innovation That’s Making Big Waves in 2025', NULL, 'Microsoft’s Quiet Innovation That’s Making Big Waves in 2025', NULL, NULL, 0, '2025-05-11 16:04:31', '2025-05-11 16:04:31', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(41, 11, 1, NULL, 'Hello! I am Flossie Cardoza, and I\'m MBBS Doctor. I will help you to have a healthy life.', 'Hello! I am Flossie Cardoza, and I\'m MBBS Doctor. I will help you to have a healthy life.', NULL, NULL, 0, '2025-05-12 01:47:58', '2025-05-12 01:47:58', NULL, NULL, 'chat', NULL, NULL, NULL, NULL),
(42, 11, 1, 'Halo', NULL, 'Halo', NULL, NULL, 0, '2025-05-12 01:48:08', '2025-05-12 01:48:08', NULL, 'Halo', 'chat', NULL, NULL, NULL, NULL),
(43, 11, 1, NULL, 'Hello! How can I assist you today?', 'Hello! How can I assist you today?', NULL, NULL, 7, '2025-05-12 01:48:09', '2025-05-12 01:48:09', '1746996488', NULL, 'chat', NULL, NULL, NULL, NULL),
(44, 11, 1, 'Today i am seafaring fever', NULL, 'Today i am seafaring fever', NULL, NULL, 0, '2025-05-12 01:48:29', '2025-05-12 01:48:30', NULL, 'Today i am seafaring fever', 'chat', NULL, NULL, NULL, NULL),
(45, 11, 1, NULL, 'It sounds like you might be feeling unwell with symptoms indicative of a fever. It’s important to monitor your condition and take appropriate action to help improve your health. Here are some steps you can follow:\n\n1. **Measure Your Temperature**: Use a thermometer to find out how high your fever is. A fever is generally considered to be a temperature of 100.4°F (38°C) or higher.\n\n2. **Rest**: Allow your body to recover by getting plenty of sleep and resting as much as possible.\n\n3. **Stay Hydrated**: Drink plenty of fluids like water, herbal teas, or broths to stay hydrated, as fever can lead to dehydration.\n\n4. **Take Fever-Reducing Medication**: You can take over-the-counter medications such as acetaminophen or ibuprofen to reduce your fever. Be sure to follow the dosage instructions on the package or consult with a healthcare provider.\n\n5. **Monitor Symptoms**: Monitor any other symptoms that accompany the fever, such as chills, sweating, headache, muscle aches, or coughing.\n\n6. **Dress Appropriately**: Wear lightweight clothing and use a light blanket if needed. Avoid heavy blankets or clothing that can raise your body temperature further.\n\n7. **Consult a Doctor**: If your fever persists for more than a couple of days, or if it’s accompanied by other worrying symptoms like severe headache, throat swelling, rash, persistent vomiting, confusion, chest pain, or difficulty breathing, consider consulting a healthcare professional or visiting an emergency room.\n\nRemember, the above suggestions are generic advice, and it’s always best to seek personalized medical advice from your healthcare provider to address your specific situation and conditions.', 'It sounds like you might be feeling unwell with symptoms indicative of a fever. It’s important to monitor your condition and take appropriate action to help improve your health. Here are some steps you can follow:<br><br>1. **Measure Your Temperature**: Use a thermometer to find out how high your fever is. A fever is generally considered to be a temperature of 100.4°F (38°C) or higher.<br><br>2. **Rest**: Allow your body to recover by getting plenty of sleep and resting as much as possible.<br><br>3. **Stay Hydrated**: Drink plenty of fluids like water, herbal teas, or broths to stay hydrated, as fever can lead to dehydration.<br><br>4. **Take Fever-Reducing Medication**: You can take over-the-counter medications such as acetaminophen or ibuprofen to reduce your fever. Be sure to follow the dosage instructions on the package or consult with a healthcare provider.<br><br>5. **Monitor Symptoms**: Monitor any other symptoms that accompany the fever, such as chills, sweating, headache, muscle aches, or coughing.<br><br>6. **Dress Appropriately**: Wear lightweight clothing and use a light blanket if needed. Avoid heavy blankets or clothing that can raise your body temperature further.<br><br>7. **Consult a Doctor**: If your fever persists for more than a couple of days, or if it’s accompanied by other worrying symptoms like severe headache, throat swelling, rash, persistent vomiting, confusion, chest pain, or difficulty breathing, consider consulting a healthcare professional or visiting an emergency room.<br><br>Remember, the above suggestions are generic advice, and it’s always best to seek personalized medical advice from your healthcare provider to address your specific situation and conditions.', NULL, NULL, 250, '2025-05-12 01:48:30', '2025-05-12 01:48:38', '1746996510', NULL, 'chat', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_chat_prompts`
--

CREATE TABLE `ai_chat_prompts` (
  `id` bigint UNSIGNED NOT NULL,
  `ai_chat_prompt_group_id` int DEFAULT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_chat_prompts`
--

INSERT INTO `ai_chat_prompts` (`id`, `ai_chat_prompt_group_id`, `title`, `prompt`, `is_active`, `created_at`, `updated_at`, `created_by`, `updated_by`, `deleted_at`) VALUES
(1, 1, 'Quora Answer', 'Write a Quora answer that sounds 100% human-written and experience-based. Make it easy to read, with a helpful and conversational tone. The topic is: [insert your topic/question, e.g., “Where can I buy genuine Windows 10 keys online?”].\r\n\r\nMention a site (use “example.com” as a placeholder) that sells digital software licenses without linking to it directly. Use phrases like “a small site I use,” “close to example.com,” or “search for something like \'digital software key deals\'.”\r\n\r\nFocus on trust, affordability, instant delivery, and simplicity of the buying process.\r\n\r\nMention there may be a promo code like “NEW10” for 10% off, but don’t force it.\r\n\r\nAvoid using sales language or AI tone. Do not use bullet points or structured lists. Just tell a short helpful story that feels personal and natural.', 1, '2025-05-11 15:19:12', '2025-05-11 15:19:12', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_chat_prompt_groups`
--

CREATE TABLE `ai_chat_prompt_groups` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_chat_prompt_groups`
--

INSERT INTO `ai_chat_prompt_groups` (`id`, `name`, `slug`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'quora answer', 'quora-answer-lOTSm', '2025-05-11 15:10:23', '2025-05-11 15:10:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ai_content_detectors`
--

CREATE TABLE `ai_content_detectors` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ai` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `human` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `output` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` tinyint DEFAULT '1',
  `length` int DEFAULT NULL,
  `created_by` int DEFAULT '1',
  `updated_by` int DEFAULT '1',
  `type` tinyint DEFAULT '1' COMMENT '1 = detection, 2 = plagiarism',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `ai_content_detectors`
--

INSERT INTO `ai_content_detectors` (`id`, `title`, `ai`, `human`, `content`, `output`, `response`, `is_active`, `length`, `created_by`, `updated_by`, `type`, `created_at`, `updated_at`) VALUES
(1, 'fsfsfsf', '100', '0', 'OpenAI operates on a prepaid, pay-as-you-go billing model for its API services. This means you purchase credits in advance, and your usage is deducted from this balance. Here\'s how it works:​\r\nhelp.promptitude.io\r\n\r\n', NULL, '{\"status\":200,\"results\":[],\"results_count\":0,\"errors\":[],\"errors_count\":0,\"score\":0,\"credits_used\":348,\"credits_remaining\":2152}', 1, 1323, 1, 1, 2, '2025-04-21 17:58:37', '2025-04-21 17:58:37'),
(2, 'Easy Fruit Cocktail Cake Recipe With Astonishing Taste', '10', '90', 'Ever craved something sweet and comforting that doesn’t require a pile of ingredients or hours in the kitchen? Let me tell you a little story. One chilly afternoon, I was rummaging through my pantry and spotted a dusty can of fruit cocktail. That moment turned into the beginning of my obsession with this easy fruit cocktail cake recipe—a dessert so simple, even your little cousin could make it.\r\n\r\nSeriously, this cake is a throwback to potluck dinners and grandma’s handwritten recipe cards. It’s the kind of treat that fills your kitchen with sweet, warm memories and a scent that hugs you like your favorite blanket. And the best part? You can whip it up in less than an hour using things you likely already have at home.\r\n\r\n\r\nLet’s dive into this no-fuss, no-mixer-needed, gloriously moist cake that’s been passed around for generations—and is now ready to find a spot in your recipe box too.\r\n\r\nTable of Contents\r\n\r\nWhy Fruit Cocktail Cake Is the Ultimate Comfort Dessert\r\nSimple Ingredients That Make Big Magic\r\nStep-By-Step Instructions for the Perfect Fruit Cocktail Cake\r\nHow to Customize Your Fruit Cocktail Cake Like a Pro\r\nFruit Cocktail Cake Using Cake Mix vs. From Scratch\r\nFAQ’s\r\nFinal Thoughts: This Cake is a Hug in Dessert Form\r\nWhy Fruit Cocktail Cake Is the Ultimate Comfort Dessert\r\nThere’s something beautifully nostalgic about a good old-fashioned fruit cocktail cake recipe. Maybe it’s the syrupy sweetness of canned fruits or the dense, almost pudding-like texture that makes every bite so satisfying. Whatever it is, this cake delivers comfort with every forkful.\r\n\r\nAnd let’s talk about convenience. Most easy fruit cocktail cake recipes call for pantry staples—flour, sugar, baking soda, eggs, and a can of fruit cocktail. That’s it. You don’t need to be a pastry chef, and there’s no need for fancy equipment. It’s honestly the ideal dessert when unexpected guests show up or when your sweet tooth just won’t wait.\r\n\r\n\r\nAnother reason this cake stands out? It’s ridiculously versatile. Want to use gluten-free flour? Go for it. Only have a cake mix on hand? There’s an easy fruit cocktail cake using cake mix version for that (which I’ll share later). Want to add nuts or coconut? Absolutely. It’s a blank canvas for creativity—or a last-minute lifesaver when you’re low on ingredients.\r\n\r\nIt’s like the sweatpants of cakes—low effort, high reward, and guaranteed to make you feel good.\r\n\r\nEasy Fruit Cocktail Cake Recipe With Astonishing Taste\r\n\r\nSimple Ingredients That Make Big Magic\r\nLet’s break down the magic formula for this cake. You won’t believe how such humble ingredients turn into something so heavenly.\r\n\r\nIngredient	Purpose\r\nAll-purpose flour	The backbone of the cake\r\nGranulated sugar	Sweetness + golden edges\r\nBaking soda	Helps the cake rise\r\nEggs	Binds everything together\r\nCanned fruit cocktail	The star—adds moisture, sweetness, and charm\r\nVanilla extract (optional)	Adds depth of flavor\r\nChopped nuts (optional)	For texture and a little crunch\r\nBrown sugar and milk (for glaze)	Creates a gooey, sticky topping\r\n \r\n\r\nNow, here’s the fun twist. If you’re short on time or just feeling extra lazy (no judgment), you can totally go the easy fruit cocktail cake using cake mix route. Just grab a vanilla or yellow cake mix, mix in your fruit cocktail (undrained!), and bake. Boom—instant grandma vibes with zero stress.\r\n\r\nYou can even check out our classic vanilla sponge cake recipe at Homexan.com for more sweet inspiration.\r\n\r\nEasy Fruit Cocktail Cake Recipe With Astonishing Taste\r\n\r\nStep-By-Step Instructions for the Perfect Fruit Cocktail Cake\r\nAlright, friend, roll up those sleeves. This cake is so easy, I promise you’ll have it memorized by the third time you make it—which, trust me, will happen.\r\n\r\nStep 1: Preheat and Prep\r\nSet your oven to 350°F (175°C). Grease a 9×13 inch baking dish or line it with parchment if you’re feeling fancy.\r\n\r\n\r\nStep 2: Mix the Dry Ingredients\r\nIn a big bowl, whisk together 2 cups of flour, 1½ cups of sugar, and 1 teaspoon of baking soda. No need for sifting—just blend well.\r\n\r\nStep 3: Add the Wet Ingredients\r\nCrack in two eggs and pour in the canned fruit cocktail, juice and all. Mix it up with a spoon or spatula until it’s combined. The batter will be thick and lumpy. That’s totally okay.\r\n\r\nStep 4: Optional Goodies\r\nAdd ½ cup of chopped nuts or shredded coconut if you want a bit more texture.\r\n\r\nStep 5: Bake That Beauty\r\nPour the batter into your dish and bake for 35–40 minutes, or until the top is golden brown and a toothpick comes out clean.\r\n\r\nStep 6: Make It Gooey (Optional but Recommended)\r\nWhile it bakes, heat ½ cup of brown sugar and ½ cup of milk in a small saucepan until it bubbles. Pour this glaze over the hot cake when it comes out of the oven.\r\n\r\nLet it sit for at least 15 minutes. Or don’t. I won’t judge you if you dive in immediately.\r\n\r\nHow to Customize Your Fruit Cocktail Cake Like a Pro\r\nWhat’s great about this recipe for fruit cocktail cake is how forgiving and adaptable it is. Once you’ve nailed the basics, it’s time to get creative.\r\n\r\nCraving a tropical twist? Swap regular fruit cocktail for one with pineapple and mango.\r\nFeeling indulgent? Add chocolate chips to the batter. Trust me, it works.\r\nWant a spice kick? A dash of cinnamon or nutmeg warms it up beautifully.\r\nPrefer less sweetness? Reduce the sugar by ¼ cup. The fruit still gives it plenty of natural sugar.\r\nYou can even bake the batter in muffin tins for portable fruit cocktail cupcakes. Just reduce the baking time to around 18–20 minutes.\r\n\r\nAnd yes, it tastes even better the next day. Wrap it up and store it in the fridge for up to 5 days—if it lasts that long.\r\n\r\nFruit Cocktail Cake Using Cake Mix vs. From Scratch\r\nLet’s be honest. Some days, we want to bake from scratch. Other days, we want cake right now with minimal effort. Here’s a quick breakdown:\r\n\r\nAspect	From Scratch	Using Cake Mix\r\nTime Needed	About 10 min prep, 40 min bake	5 min prep, 35 min bake\r\nFlavor Control	Total control of sugar and ingredients	Slightly more processed flavor\r\nTexture	Dense, moist, rich	Fluffier, lighter\r\nSkill Level	Beginner friendly	Even easier\r\nBest For	Classic lovers, home bakers	Busy days, kids’ baking, potlucks\r\nWhichever method you choose, you’re still getting a recipe fruit cocktail cake that delivers on flavor, fun, and pure satisfaction.\r\n\r\nEasy Fruit Cocktail Cake Recipe With Astonishing Taste\r\n\r\nFAQ’s\r\n1. Can I use fresh fruit instead of canned fruit cocktail?\r\nYes, but you’ll need to add extra liquid (juice or syrup) to replace the moisture from the can. It may also change the texture a bit.\r\n\r\n2. Is this cake freezer friendly?\r\nAbsolutely! Slice it and wrap in plastic wrap. It stays good for up to 2 months. Thaw at room temp or warm slightly before serving.\r\n\r\n\r\n3. What’s the best topping for fruit cocktail cake?\r\nBesides the brown sugar glaze, whipped cream or vanilla ice cream are great choices. Some folks even sprinkle powdered sugar on top.\r\n\r\n4. Can I make this cake vegan?\r\nTotally! Swap the eggs with flax eggs (1 tbsp flaxseed + 3 tbsp water per egg). Use plant-based milk and dairy-free glaze options.\r\n\r\n5. Do I have to drain the canned fruit?\r\nNope! Keep the juice—it’s what makes the cake so moist and flavorful.\r\n\r\nFinal Thoughts: This Cake is a Hug in Dessert Form\r\nIf you’ve made it this far, you’re probably already preheating your oven, right? I don’t blame you. This easy fruit cocktail cake is more than just a dessert—it’s a memory, a mood-lifter, and an excuse to use that can of fruit cocktail sitting in your pantry.\r\n\r\nWhether you stick to the classic canned fruit cocktail cake, tweak it with your favorite mix-ins, or go the shortcut route with cake mix, this recipe is here to make your life sweeter and simpler.\r\n\r\nAnd hey—if you do try it, tag me or comment on Homexan. I’d love to hear how it turned out for you.', NULL, '{\"status\":200,\"length\":7876,\"score\":89.6700000000000017053025658242404460906982421875,\"sentences\":[{\"length\":397,\"score\":0.84999999999999997779553950749686919152736663818359375,\"text\":\"Ever craved something sweet and comforting that doesn\\u2019t require a pile of ingredients or hours in the kitchen? Let me tell you a little story. One chilly afternoon, I was rummaging through my pantry and spotted a dusty can of fruit cocktail. That moment turned into the beginning of my obsession with this easy fruit cocktail cake recipe-a dessert so simple, even your little cousin could make it.\"},{\"length\":395,\"score\":75.56000000000000227373675443232059478759765625,\"text\":\"Seriously, this cake is a throwback to potluck dinners and grandma\\u2019s handwritten recipe cards. It\\u2019s the kind of treat that fills your kitchen with sweet, warm memories and a scent that hugs you like your favorite blanket. And the best part? You can whip it up in less than an hour using things you likely already have at home. Let\\u2019s dive into this no-fuss, no-mixer-needed, gloriously moist cake\"},{\"length\":399,\"score\":99.9899999999999948840923025272786617279052734375,\"text\":\"that\\u2019s been passed around for generations-and is now ready to find a spot in your recipe box too. Table of Contents Why Fruit Cocktail Cake Is the Ultimate Comfort Dessert Simple Ingredients That Make Big Magic Step-By-Step Instructions for the Perfect Fruit Cocktail Cake How to Customize Your Fruit Cocktail Cake Like a Pro Fruit Cocktail Cake Using Cake Mix vs. From Scratch FAQ\\u2019s Final Thoughts:\"},{\"length\":397,\"score\":98.409999999999996589394868351519107818603515625,\"text\":\"This Cake is a Hug in Dessert Form Why Fruit Cocktail Cake Is the Ultimate Comfort Dessert There\\u2019s something beautifully nostalgic about a good old-fashioned fruit cocktail cake recipe. Maybe it\\u2019s the syrupy sweetness of canned fruits or the dense, almost pudding-like texture that makes every bite so satisfying. Whatever it is, this cake delivers comfort with every forkful. And let\\u2019s talk about\"},{\"length\":400,\"score\":99.8700000000000045474735088646411895751953125,\"text\":\"convenience. Most easy fruit cocktail cake recipes call for pantry staples-flour, sugar, baking soda, eggs, and a can of fruit cocktail. That\\u2019s it. You don\\u2019t need to be a pastry chef, and there\\u2019s no need for fancy equipment. It\\u2019s honestly the ideal dessert when unexpected guests show up or when your sweet tooth just won\\u2019t wait. Another reason this cake stands out? It\\u2019s ridiculously versatile. Want\"},{\"length\":397,\"score\":99.9500000000000028421709430404007434844970703125,\"text\":\"to use gluten-free flour? Go for it. Only have a cake mix on hand? There\\u2019s an easy fruit cocktail cake using cake mix version for that (which I\\u2019ll share later). Want to add nuts or coconut? Absolutely. It\\u2019s a blank canvas for creativity-or a last-minute lifesaver when you\\u2019re low on ingredients. It\\u2019s like the sweatpants of cakes-low effort, high reward, and guaranteed to make you feel good. Easy\"},{\"length\":397,\"score\":28.3299999999999982946974341757595539093017578125,\"text\":\"Fruit Cocktail Cake Recipe With Astonishing Taste Simple Ingredients That Make Big Magic Let\\u2019s break down the magic formula for this cake. You won\\u2019t believe how such humble ingredients turn into something so heavenly. Ingredient Purpose All-purpose flour The backbone of the cake Granulated sugar Sweetness + golden edges Baking soda Helps the cake rise Eggs Binds everything together Canned fruit\"},{\"length\":397,\"score\":99.31000000000000227373675443232059478759765625,\"text\":\"cocktail The star-adds moisture, sweetness, and charm Vanilla extract (optional) Adds depth of flavor Chopped nuts (optional) For texture and a little crunch Brown sugar and milk (for glaze) Creates a gooey, sticky topping Now, here\\u2019s the fun twist. If you\\u2019re short on time or just feeling extra lazy (no judgment), you can totally go the easy fruit cocktail cake using cake mix route. Just grab a\"},{\"length\":398,\"score\":99.7699999999999960209606797434389591217041015625,\"text\":\"vanilla or yellow cake mix, mix in your fruit cocktail (undrained!), and bake. Boom-instant grandma vibes with zero stress. You can even check out our classic vanilla sponge cake recipe at Homexan.com for more sweet inspiration. Easy Fruit Cocktail Cake Recipe With Astonishing Taste Step-By-Step Instructions for the Perfect Fruit Cocktail Cake Alright, friend, roll up those sleeves. This cake is\"},{\"length\":395,\"score\":99.9599999999999937472239253111183643341064453125,\"text\":\"so easy, I promise you\\u2019ll have it memorized by the third time you make it-which, trust me, will happen. Step 1: Preheat and Prep Set your oven to 350\\u00b0F (175\\u00b0C). Grease a 9\\u00d713 inch baking dish or line it with parchment if you\\u2019re feeling fancy. Step 2: Mix the Dry Ingredients In a big bowl, whisk together 2 cups of flour, 1\\u00bd cups of sugar, and 1 teaspoon of baking soda. No need for sifting-just\"},{\"length\":399,\"score\":97.9899999999999948840923025272786617279052734375,\"text\":\"blend well. Step 3: Add the Wet Ingredients Crack in two eggs and pour in the canned fruit cocktail, juice and all. Mix it up with a spoon or spatula until it\\u2019s combined. The batter will be thick and lumpy. That\\u2019s totally okay. Step 4: Optional Goodies Add \\u00bd cup of chopped nuts or shredded coconut if you want a bit more texture. Step 5: Bake That Beauty Pour the batter into your dish and bake for\"},{\"length\":391,\"score\":99.7300000000000039790393202565610408782958984375,\"text\":\"35-40 minutes, or until the top is golden brown and a toothpick comes out clean. Step 6: Make It Gooey (Optional but Recommended) While it bakes, heat \\u00bd cup of brown sugar and \\u00bd cup of milk in a small saucepan until it bubbles. Pour this glaze over the hot cake when it comes out of the oven. Let it sit for at least 15 minutes. Or don\\u2019t. I won\\u2019t judge you if you dive in immediately. How to\"},{\"length\":399,\"score\":2.75,\"text\":\"Customize Your Fruit Cocktail Cake Like a Pro What\\u2019s great about this recipe for fruit cocktail cake is how forgiving and adaptable it is. Once you\\u2019ve nailed the basics, it\\u2019s time to get creative. Craving a tropical twist? Swap regular fruit cocktail for one with pineapple and mango. Feeling indulgent? Add chocolate chips to the batter. Trust me, it works. Want a spice kick? A dash of cinnamon or\"},{\"length\":395,\"score\":99.8599999999999994315658113919198513031005859375,\"text\":\"nutmeg warms it up beautifully. Prefer less sweetness? Reduce the sugar by \\u00bc cup. The fruit still gives it plenty of natural sugar. You can even bake the batter in muffin tins for portable fruit cocktail cupcakes. Just reduce the baking time to around 18-20 minutes. And yes, it tastes even better the next day. Wrap it up and store it in the fridge for up to 5 days-if it lasts that long. Fruit\"},{\"length\":399,\"score\":85.5799999999999982946974341757595539093017578125,\"text\":\"Cocktail Cake Using Cake Mix vs. From Scratch Let\\u2019s be honest. Some days, we want to bake from scratch. Other days, we want cake right now with minimal effort. Here\\u2019s a quick breakdown: Aspect From Scratch Using Cake Mix Time Needed About 10 min prep, 40 min bake 5 min prep, 35 min bake Flavor Control Total control of sugar and ingredients Slightly more processed flavor Texture Dense, moist, rich\"},{\"length\":398,\"score\":99.9800000000000039790393202565610408782958984375,\"text\":\"Fluffier, lighter Skill Level Beginner friendly Even easier Best For Classic lovers, home bakers Busy days, kids\\u2019 baking, potlucks Whichever method you choose, you\\u2019re still getting a recipe fruit cocktail cake that delivers on flavor, fun, and pure satisfaction. Easy Fruit Cocktail Cake Recipe With Astonishing Taste FAQ\\u2019s 1. Can I use fresh fruit instead of canned fruit cocktail? Yes, but you\\u2019ll\"},{\"length\":395,\"score\":39.56000000000000227373675443232059478759765625,\"text\":\"need to add extra liquid (juice or syrup) to replace the moisture from the can. It may also change the texture a bit. 2. Is this cake freezer friendly? Absolutely! Slice it and wrap in plastic wrap. It stays good for up to 2 months. Thaw at room temp or warm slightly before serving. 3. What\\u2019s the best topping for fruit cocktail cake? Besides the brown sugar glaze, whipped cream or vanilla ice\"},{\"length\":398,\"score\":75.7699999999999960209606797434389591217041015625,\"text\":\"cream are great choices. Some folks even sprinkle powdered sugar on top. 4. Can I make this cake vegan? Totally! Swap the eggs with flax eggs (1 tbsp flaxseed + 3 tbsp water per egg). Use plant-based milk and dairy-free glaze options. 5. Do I have to drain the canned fruit? Nope! Keep the juice-it\\u2019s what makes the cake so moist and flavorful. Final Thoughts: This Cake is a Hug in Dessert Form If\"},{\"length\":553,\"score\":99.43000000000000682121026329696178436279296875,\"text\":\"you\\u2019ve made it this far, you\\u2019re probably already preheating your oven, right? I don\\u2019t blame you. This easy fruit cocktail cake is more than just a dessert-it\\u2019s a memory, a mood-lifter, and an excuse to use that can of fruit cocktail sitting in your pantry. Whether you stick to the classic canned fruit cocktail cake, tweak it with your favorite mix-ins, or go the shortcut route with cake mix, this recipe is here to make your life sweeter and simpler. And hey-if you do try it, tag me or comment on Homexan. I\\u2019d love to hear how it turned out for you.\"}],\"input\":\"text\",\"attack_detected\":{\"zero_width_space\":false,\"homoglyph_attack\":false},\"readability_score\":65.6700000000000017053025658242404460906982421875,\"credits_used\":1245,\"credits_remaining\":907,\"version\":\"3.0\",\"language\":\"en\"}', 1, 8006, 1, 1, 1, '2025-04-21 18:02:27', '2025-04-21 18:02:27'),
(3, 'Subject: Following Up on Your Quest for Email Lists', '100', '0', 'Dear [Recipient],\r\n\r\nI hope this email finds you in good health and spirits.\r\n\r\nI am following up on our recent communication regarding your interest in purchasing an email list. It’s always thrilling to see businesses eager to grow their customer engagement and boost their marketing strategies.\r\n\r\nBefore proceeding further, I wanted to walk you through certain important aspects of buying an email list and what it means for your business growth, ensuring we’re on the same wavelength.\r\n\r\nSo, why should a company consider buying an email list? The prime reason is to increase its consumer base with minimum effort. In lieu of traditional methods, buying an email list gives your business immediate access to an extensive pool of prospective consumers. This can swiftly escalate your outreach, facilitate targeted marketing campaigns and drastically improve lead generation.\r\n\r\nHowever, while an email list can reap ample benefits, it’s crucial to pay attention to the quality and relevance of these lists. An optimal email list includes verified contacts that are likely to be interested in your offerings. Moreover, being respectful of individual privacy regulations is integral to this procedure. Hence, we take utmost care in compiling these lists, strictly adhering to all guidelines and ethical considerations.\r\n\r\nOur email list packages come in several shapes and sizes, customized to best suit your enterprise needs. Whether you\'re a start-up aiming for quick growth or an established corporation striving to enhance its consumer reach, we can create a package tailored specifically for you. Our email lists are compiled from reliable sources, double-checked, and updated regularly to maintain their relevancy and effectiveness.\r\n\r\nFurther, upon purchasing an email list, we also provide comprehensive guides, filled with best practices for email marketing. These can help ease your initiation into this new phase of your business and ensure maximum return on your investment.\r\n\r\nRespecting the privacy laws is one of our top concerns. While fulfilling the needs of businesses like yours, we explicitly follow guidelines such as the CAN-SPAM Act, GDPR, and other similar legislation. We believe in clean marketing, hence, all our lists are generated through legal means, from individuals who have expressed a direct interest in receiving marketing emails.\r\n\r\nThe power of effective email marketing tactics should not be underestimated. With these in place, creating engaging content, and personalizing your approach to target specific leads, there’s no limit to where your business can reach.\r\n\r\nHowever, the key to effective email marketing using purchased lists is to initially focus on building strong relationships with your new contacts rather than immediately pushing for sales. Breaking the ice, building trust and credibility among your audience is a surefire way to turn these new leads into loyal customers!\r\n\r\nLet\'s take your business to new heights together. I invite you to share more details about specific interests or criteria you might have related to your prospective customers. Doing so will enable us to create an email list that perfectly aligns with your goals.\r\n\r\nShould you have any queries or need further information, please respond to this email. We look forward to walking this invigorating path of your business journey with you.\r\n\r\nJust as every business is unique, so too are the strategies required for its growth. Allow us to provide the fuel your business needs to surge forward in this competitive world.\r\n\r\nThank you for considering our services. we await your response to proceed with this exciting opportunity.\r\n\r\nBest Regards,\r\n\r\n[Your Name]\r\n[Your Position]\r\n[Your Contact Information]', NULL, '{\"status\":200,\"length\":3736,\"score\":0.01000000000000000020816681711721685132943093776702880859375,\"sentences\":[{\"text\":\"Dear [Recipient], I hope this email finds you in good health and spirits. I am following up on our recent communication regarding your interest in purchasing an email list. It\\u2019s always thrilling to see businesses eager to grow their customer engagement and boost their marketing strategies. Before proceeding further, I wanted to walk you through certain important aspects of buying an email list and\",\"length\":400,\"score\":0.01000000000000000020816681711721685132943093776702880859375},{\"text\":\"what it means for your business growth, ensuring we\\u2019re on the same wavelength. So, why should a company consider buying an email list? The prime reason is to increase its consumer base with minimum effort. In lieu of traditional methods, buying an email list gives your business immediate access to an extensive pool of prospective consumers. This can swiftly escalate your outreach, facilitate\",\"length\":394,\"score\":99.0199999999999960209606797434389591217041015625},{\"text\":\"targeted marketing campaigns and drastically improve lead generation. However, while an email list can reap ample benefits, it\\u2019s crucial to pay attention to the quality and relevance of these lists. An optimal email list includes verified contacts that are likely to be interested in your offerings. Moreover, being respectful of individual privacy regulations is integral to this procedure. Hence,\",\"length\":398,\"score\":0.01000000000000000020816681711721685132943093776702880859375},{\"text\":\"we take utmost care in compiling these lists, strictly adhering to all guidelines and ethical considerations. Our email list packages come in several shapes and sizes, customized to best suit your enterprise needs. Whether you\'re a start-up aiming for quick growth or an established corporation striving to enhance its consumer reach, we can create a package tailored specifically for you. Our email\",\"length\":399,\"score\":49.14999999999999857891452847979962825775146484375},{\"text\":\"lists are compiled from reliable sources, double-checked, and updated regularly to maintain their relevancy and effectiveness. Further, upon purchasing an email list, we also provide comprehensive guides, filled with best practices for email marketing. These can help ease your initiation into this new phase of your business and ensure maximum return on your investment. Respecting the privacy laws\",\"length\":399,\"score\":0.01000000000000000020816681711721685132943093776702880859375},{\"text\":\"is one of our top concerns. While fulfilling the needs of businesses like yours, we explicitly follow guidelines such as the CAN-SPAM Act, GDPR, and other similar legislation. We believe in clean marketing, hence, all our lists are generated through legal means, from individuals who have expressed a direct interest in receiving marketing emails. The power of effective email marketing tactics\",\"length\":394,\"score\":89.280000000000001136868377216160297393798828125},{\"text\":\"should not be underestimated. With these in place, creating engaging content, and personalizing your approach to target specific leads, there\\u2019s no limit to where your business can reach. However, the key to effective email marketing using purchased lists is to initially focus on building strong relationships with your new contacts rather than immediately pushing for sales. Breaking the ice,\",\"length\":393,\"score\":26.800000000000000710542735760100185871124267578125},{\"text\":\"building trust and credibility among your audience is a surefire way to turn these new leads into loyal customers! Let\'s take your business to new heights together. I invite you to share more details about specific interests or criteria you might have related to your prospective customers. Doing so will enable us to create an email list that perfectly aligns with your goals. Should you have any\",\"length\":397,\"score\":0.1499999999999999944488848768742172978818416595458984375},{\"text\":\"queries or need further information, please respond to this email. We look forward to walking this invigorating path of your business journey with you. Just as every business is unique, so too are the strategies required for its growth. Allow us to provide the fuel your business needs to surge forward in this competitive world. Thank you for considering our services. we await your response to proceed with this exciting opportunity. Best Regards, [Your Name] [Your Position] [Your Contact Information]\",\"length\":504,\"score\":0.01000000000000000020816681711721685132943093776702880859375}],\"input\":\"text\",\"attack_detected\":{\"zero_width_space\":false,\"homoglyph_attack\":false},\"readability_score\":32.780000000000001136868377216160297393798828125,\"credits_used\":555,\"credits_remaining\":352,\"version\":\"3.0\",\"language\":\"en\"}', 1, 3744, 1, 1, 1, '2025-05-03 18:33:25', '2025-05-03 18:33:25');

-- --------------------------------------------------------

--
-- Table structure for table `ai_response_logs`
--

CREATE TABLE `ai_response_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ai_chat_message_id` bigint UNSIGNED DEFAULT NULL,
  `ai_blog_wizard_id` bigint UNSIGNED DEFAULT NULL,
  `project_id` bigint UNSIGNED DEFAULT NULL,
  `row_response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `generate_response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `application_versions`
--

CREATE TABLE `application_versions` (
  `id` bigint UNSIGNED NOT NULL,
  `version` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `release_date` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `application_versions`
--

INSERT INTO `application_versions` (`id`, `version`, `release_date`, `status`, `created_at`, `updated_at`) VALUES
(1, '1.0.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(2, '1.1.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(3, '1.5.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(4, '1.6.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(5, '1.7.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(6, '1.8.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(7, '1.9.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(8, '1.9.5', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(9, '2.0.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(10, '2.1.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(11, '2.2.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(12, '2.3.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(13, '2.3.1', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(14, '2.4.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(15, '2.4.1', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(16, '2.5.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(17, '2.6.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(18, '2.6.1', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(19, '2.7.0', NULL, 1, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(20, '2.7.1', NULL, 1, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(21, '2.8.0', NULL, 1, '2025-04-21 16:31:45', '2025-04-21 16:31:45');

-- --------------------------------------------------------

--
-- Table structure for table `assign_tickets`
--

CREATE TABLE `assign_tickets` (
  `id` bigint UNSIGNED NOT NULL,
  `ticket_id` int NOT NULL,
  `assign_user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` bigint UNSIGNED NOT NULL,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `blog_category_id` int NOT NULL,
  `short_description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `thumbnail_image` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `banner` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `video_provider` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'youtube' COMMENT 'youtube / vimeo / ...',
  `video_link` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `is_popular` tinyint NOT NULL DEFAULT '0',
  `meta_title` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `meta_img` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `meta_description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_wizard_blog` tinyint NOT NULL DEFAULT '0' COMMENT '1=Wizard Blog, 0=Normal Blog'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_localizations`
--

CREATE TABLE `blog_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `blog_id` int NOT NULL,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `short_description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_tags`
--

CREATE TABLE `blog_tags` (
  `id` bigint UNSIGNED NOT NULL,
  `blog_id` int NOT NULL,
  `tag_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `user_id` int DEFAULT NULL,
  `assign_staff` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us_messages`
--

CREATE TABLE `contact_us_messages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `phone` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `message` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_seen` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `contact_us_messages`
--

INSERT INTO `contact_us_messages` (`id`, `name`, `email`, `phone`, `message`, `is_seen`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Tedmit', 'aferinohis056@gmail.com', '88451196942', 'Zdravo, htio sam znati vašu cijenu.', 0, '2025-05-05 21:45:03', '2025-05-05 21:45:03', NULL),
(2, 'Georgemit', 'xiceruxuk02@gmail.com', '89699887867', 'Ողջույն, ես ուզում էի իմանալ ձեր գինը.', 0, '2025-05-07 21:00:47', '2025-05-07 21:00:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` bigint UNSIGNED NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `symbol` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `alignment` tinyint NOT NULL DEFAULT '0' COMMENT '0 for left, 1 for right',
  `rate` double NOT NULL DEFAULT '1',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `code`, `name`, `symbol`, `alignment`, `rate`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'usd', 'US Dollar', '$', 0, 1, 1, '2022-11-27 18:21:37', '2022-11-27 18:21:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_settings`
--

CREATE TABLE `customer_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `customer_id` int NOT NULL,
  `key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_templates`
--

CREATE TABLE `custom_templates` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `custom_template_category_id` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `fields` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `icon` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `total_words_generated` bigint NOT NULL DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_by` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'admin',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `custom_templates`
--

INSERT INTO `custom_templates` (`id`, `user_id`, `custom_template_category_id`, `name`, `slug`, `code`, `description`, `fields`, `prompt`, `icon`, `total_words_generated`, `is_active`, `created_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, 'Blogs writing by forid', 'Blogs-writing-by-forid', 'Blogs-writing-by-forid', 'test description', '[{\"label\":\"english\",\"is_required\":true,\"field\":{\"name\":\"lang\",\"type\":\"text\"}},{\"label\":\"input your keysowrds using comma,\",\"is_required\":true,\"field\":{\"name\":\"keywords\",\"type\":\"textarea\"}}]', 'write seo friendly blog,', NULL, 0, 1, 'admin', '2025-04-22 13:40:41', '2025-04-22 13:40:41', NULL),
(2, 1, 1, 'rana', 'rana', 'rana', 'jssh', '[{\"label\":\"inpute your keywords using comma,\",\"is_required\":true,\"field\":{\"name\":\"focus-keyword\",\"type\":\"textarea\"}}]', 'Imagine you are a seasoned content writer crafting an article for beginners in a friendly and conversational tone. Your writing should demonstrate a high level of expertise while adhering to Google\'s E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness) guidelines.\r\n\r\nWrite in a conversational tone as if you\'re talking to a friend, sharing personal experiences authentically. Use genuine emotions, relatable anecdotes, and cultural nuances to create an engaging and spontaneous feel. Balance research with intuition to analyze nuances and offer deeper insights while keeping the content factually accurate.\r\n\r\n\r\nTry to add keywords from this list naturally, ensuring they fulfill the search intent. Always follow best SEO practices when incorporating keywords. I want the article to rank well for these keywords.\r\n\r\nFocus on high readability with a Flesch-Kincaid Reading Ease score of 95+ by using simple words, short sentences, and the formula: 206.835 - 1.015 x (words/sentences) - 84.6 x (syllables/words). Keep paragraphs concise, with 3-4 sentences each, for maximum clarity. Avoid unnecessary words and ensure content is unique, plagiarism-free, and demonstrates a high level of expertise.\r\n\r\nIncorporate metaphors, empathy, and relevant insights that resonate with the audience. Make the content feel relatable and engaging by using a tone that mirrors friendly advice or storytelling. Aim for a natural flow, combining research with personal intuition to create a balanced and impactful narrative.\r\n\r\n\r\nWrite Content and must  follow all commands, don\'t avoid a single command which I have listed.\r\n1. Write content within 1500 to 1700 words.\r\n2. Every subheading must be in H2 and title case, and Every paragraph must be at least 150 to 200 words.\r\n3. Each h2 will be written in a very elaborate and detailed way. Use examples if needed. \r\n4. Important if possible, add tables or comparison charts in relevant sections.\r\n5. Before consultation generate 4 or 5 frequently asked questions with their answers related to the keyword under the heading: ‘FAQ\'s\'\r\n6. Add italic effect, bold effect in case of quotation or username.\r\n7. Use the best keyword from the Website (simplyrecipez.com) Inbound link for another page. \r\n8. Must Follow this rules Don\'t Use keyword density above 0.80%. Standard is 0.50% to 0.80%', NULL, 368, 1, 'admin', '2025-04-22 15:38:54', '2025-04-22 15:41:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `custom_template_categories`
--

CREATE TABLE `custom_template_categories` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `icon` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_by` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'admin',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `custom_template_categories`
--

INSERT INTO `custom_template_categories` (`id`, `user_id`, `name`, `slug`, `icon`, `created_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Blogs', 'Blogs', NULL, 'admin', '2025-04-22 13:39:00', '2025-04-22 13:39:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `custom_template_category_localizations`
--

CREATE TABLE `custom_template_category_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `custom_template_category_id` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_template_localizations`
--

CREATE TABLE `custom_template_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `custom_template_id` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eleven_labs_models`
--

CREATE TABLE `eleven_labs_models` (
  `id` bigint UNSIGNED NOT NULL,
  `model_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `can_do_text_to_speech` int DEFAULT NULL,
  `can_do_voice_conversion` int DEFAULT NULL,
  `can_be_finetuned` int DEFAULT NULL,
  `can_use_style` int DEFAULT NULL,
  `response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `eleven_labs_models`
--

INSERT INTO `eleven_labs_models` (`id`, `model_id`, `name`, `can_do_text_to_speech`, `can_do_voice_conversion`, `can_be_finetuned`, `can_use_style`, `response`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'eleven_multilingual_v2', 'Eleven Multilingual v2', 1, 0, 1, 1, '{\"model_id\":\"eleven_multilingual_v2\",\"name\":\"Eleven Multilingual v2\",\"can_be_finetuned\":true,\"can_do_text_to_speech\":true,\"can_do_voice_conversion\":false,\"can_use_style\":true,\"can_use_speaker_boost\":true,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our most life-like, emotionally rich mode in 29 languages. Best for voice overs, audiobooks, post-production, or any other content creation needs.\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":10000,\"max_characters_request_subscribed_user\":10000,\"maximum_text_length_per_request\":10000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"},{\"language_id\":\"ja\",\"name\":\"Japanese\"},{\"language_id\":\"zh\",\"name\":\"Chinese\"},{\"language_id\":\"de\",\"name\":\"German\"},{\"language_id\":\"hi\",\"name\":\"Hindi\"},{\"language_id\":\"fr\",\"name\":\"French\"},{\"language_id\":\"ko\",\"name\":\"Korean\"},{\"language_id\":\"pt\",\"name\":\"Portuguese\"},{\"language_id\":\"it\",\"name\":\"Italian\"},{\"language_id\":\"es\",\"name\":\"Spanish\"},{\"language_id\":\"id\",\"name\":\"Indonesian\"},{\"language_id\":\"nl\",\"name\":\"Dutch\"},{\"language_id\":\"tr\",\"name\":\"Turkish\"},{\"language_id\":\"fil\",\"name\":\"Filipino\"},{\"language_id\":\"pl\",\"name\":\"Polish\"},{\"language_id\":\"sv\",\"name\":\"Swedish\"},{\"language_id\":\"bg\",\"name\":\"Bulgarian\"},{\"language_id\":\"ro\",\"name\":\"Romanian\"},{\"language_id\":\"ar\",\"name\":\"Arabic\"},{\"language_id\":\"cs\",\"name\":\"Czech\"},{\"language_id\":\"el\",\"name\":\"Greek\"},{\"language_id\":\"fi\",\"name\":\"Finnish\"},{\"language_id\":\"hr\",\"name\":\"Croatian\"},{\"language_id\":\"ms\",\"name\":\"Malay\"},{\"language_id\":\"sk\",\"name\":\"Slovak\"},{\"language_id\":\"da\",\"name\":\"Danish\"},{\"language_id\":\"ta\",\"name\":\"Tamil\"},{\"language_id\":\"uk\",\"name\":\"Ukrainian\"},{\"language_id\":\"ru\",\"name\":\"Russian\"}],\"model_rates\":{\"character_cost_multiplier\":1},\"concurrency_group\":\"standard\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(2, 'eleven_flash_v2_5', 'Eleven Flash v2.5', 1, 0, 1, 0, '{\"model_id\":\"eleven_flash_v2_5\",\"name\":\"Eleven Flash v2.5\",\"can_be_finetuned\":true,\"can_do_text_to_speech\":true,\"can_do_voice_conversion\":false,\"can_use_style\":false,\"can_use_speaker_boost\":false,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our ultra low latency model in 32 languages. Ideal for conversational use cases.\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":40000,\"max_characters_request_subscribed_user\":40000,\"maximum_text_length_per_request\":40000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"},{\"language_id\":\"ja\",\"name\":\"Japanese\"},{\"language_id\":\"zh\",\"name\":\"Chinese\"},{\"language_id\":\"de\",\"name\":\"German\"},{\"language_id\":\"hi\",\"name\":\"Hindi\"},{\"language_id\":\"fr\",\"name\":\"French\"},{\"language_id\":\"ko\",\"name\":\"Korean\"},{\"language_id\":\"pt\",\"name\":\"Portuguese\"},{\"language_id\":\"it\",\"name\":\"Italian\"},{\"language_id\":\"es\",\"name\":\"Spanish\"},{\"language_id\":\"ru\",\"name\":\"Russian\"},{\"language_id\":\"id\",\"name\":\"Indonesian\"},{\"language_id\":\"nl\",\"name\":\"Dutch\"},{\"language_id\":\"tr\",\"name\":\"Turkish\"},{\"language_id\":\"fil\",\"name\":\"Filipino\"},{\"language_id\":\"pl\",\"name\":\"Polish\"},{\"language_id\":\"sv\",\"name\":\"Swedish\"},{\"language_id\":\"bg\",\"name\":\"Bulgarian\"},{\"language_id\":\"ro\",\"name\":\"Romanian\"},{\"language_id\":\"ar\",\"name\":\"Arabic\"},{\"language_id\":\"cs\",\"name\":\"Czech\"},{\"language_id\":\"el\",\"name\":\"Greek\"},{\"language_id\":\"fi\",\"name\":\"Finnish\"},{\"language_id\":\"hr\",\"name\":\"Croatian\"},{\"language_id\":\"ms\",\"name\":\"Malay\"},{\"language_id\":\"sk\",\"name\":\"Slovak\"},{\"language_id\":\"da\",\"name\":\"Danish\"},{\"language_id\":\"ta\",\"name\":\"Tamil\"},{\"language_id\":\"uk\",\"name\":\"Ukrainian\"},{\"language_id\":\"hu\",\"name\":\"Hungarian\"},{\"language_id\":\"no\",\"name\":\"Norwegian\"},{\"language_id\":\"vi\",\"name\":\"Vietnamese\"}],\"model_rates\":{\"character_cost_multiplier\":0.5},\"concurrency_group\":\"turbo\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(3, 'eleven_turbo_v2_5', 'Eleven Turbo v2.5', 1, 0, 1, 0, '{\"model_id\":\"eleven_turbo_v2_5\",\"name\":\"Eleven Turbo v2.5\",\"can_be_finetuned\":true,\"can_do_text_to_speech\":true,\"can_do_voice_conversion\":false,\"can_use_style\":false,\"can_use_speaker_boost\":false,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our high quality, low latency model in 32 languages. Best for developer use cases where speed matters and you need non-English languages.\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":40000,\"max_characters_request_subscribed_user\":40000,\"maximum_text_length_per_request\":40000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"},{\"language_id\":\"ja\",\"name\":\"Japanese\"},{\"language_id\":\"zh\",\"name\":\"Chinese\"},{\"language_id\":\"de\",\"name\":\"German\"},{\"language_id\":\"hi\",\"name\":\"Hindi\"},{\"language_id\":\"fr\",\"name\":\"French\"},{\"language_id\":\"ko\",\"name\":\"Korean\"},{\"language_id\":\"pt\",\"name\":\"Portuguese\"},{\"language_id\":\"it\",\"name\":\"Italian\"},{\"language_id\":\"es\",\"name\":\"Spanish\"},{\"language_id\":\"ru\",\"name\":\"Russian\"},{\"language_id\":\"id\",\"name\":\"Indonesian\"},{\"language_id\":\"nl\",\"name\":\"Dutch\"},{\"language_id\":\"tr\",\"name\":\"Turkish\"},{\"language_id\":\"fil\",\"name\":\"Filipino\"},{\"language_id\":\"pl\",\"name\":\"Polish\"},{\"language_id\":\"sv\",\"name\":\"Swedish\"},{\"language_id\":\"bg\",\"name\":\"Bulgarian\"},{\"language_id\":\"ro\",\"name\":\"Romanian\"},{\"language_id\":\"ar\",\"name\":\"Arabic\"},{\"language_id\":\"cs\",\"name\":\"Czech\"},{\"language_id\":\"el\",\"name\":\"Greek\"},{\"language_id\":\"fi\",\"name\":\"Finnish\"},{\"language_id\":\"hr\",\"name\":\"Croatian\"},{\"language_id\":\"ms\",\"name\":\"Malay\"},{\"language_id\":\"sk\",\"name\":\"Slovak\"},{\"language_id\":\"da\",\"name\":\"Danish\"},{\"language_id\":\"ta\",\"name\":\"Tamil\"},{\"language_id\":\"uk\",\"name\":\"Ukrainian\"},{\"language_id\":\"vi\",\"name\":\"Vietnamese\"},{\"language_id\":\"no\",\"name\":\"Norwegian\"},{\"language_id\":\"hu\",\"name\":\"Hungarian\"}],\"model_rates\":{\"character_cost_multiplier\":0.5},\"concurrency_group\":\"turbo\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(4, 'eleven_turbo_v2', 'Eleven Turbo v2', 1, 0, 1, 0, '{\"model_id\":\"eleven_turbo_v2\",\"name\":\"Eleven Turbo v2\",\"can_be_finetuned\":true,\"can_do_text_to_speech\":true,\"can_do_voice_conversion\":false,\"can_use_style\":false,\"can_use_speaker_boost\":false,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our English-only, low latency model. Best for developer use cases where speed matters and you only need English. Performance is on par with Turbo v2.5.\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":30000,\"max_characters_request_subscribed_user\":30000,\"maximum_text_length_per_request\":30000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"}],\"model_rates\":{\"character_cost_multiplier\":0.5},\"concurrency_group\":\"turbo\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(5, 'eleven_flash_v2', 'Eleven Flash v2', 1, 0, 1, 0, '{\"model_id\":\"eleven_flash_v2\",\"name\":\"Eleven Flash v2\",\"can_be_finetuned\":true,\"can_do_text_to_speech\":true,\"can_do_voice_conversion\":false,\"can_use_style\":false,\"can_use_speaker_boost\":false,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our ultra low latency model in english. Ideal for conversational use cases.\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":30000,\"max_characters_request_subscribed_user\":30000,\"maximum_text_length_per_request\":30000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"}],\"model_rates\":{\"character_cost_multiplier\":0.5},\"concurrency_group\":\"turbo\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(6, 'eleven_multilingual_v1', 'Eleven Multilingual v1', 1, 0, 0, 0, '{\"model_id\":\"eleven_multilingual_v1\",\"name\":\"Eleven Multilingual v1\",\"can_be_finetuned\":false,\"can_do_text_to_speech\":true,\"can_do_voice_conversion\":false,\"can_use_style\":false,\"can_use_speaker_boost\":false,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our first Multilingual model, capability of generating speech in 10 languages. Now outclassed by Multilingual v2 (for content creation) and Turbo v2.5 (for low latency use cases).\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":10000,\"max_characters_request_subscribed_user\":10000,\"maximum_text_length_per_request\":10000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"},{\"language_id\":\"de\",\"name\":\"German\"},{\"language_id\":\"pl\",\"name\":\"Polish\"},{\"language_id\":\"es\",\"name\":\"Spanish\"},{\"language_id\":\"it\",\"name\":\"Italian\"},{\"language_id\":\"fr\",\"name\":\"French\"},{\"language_id\":\"pt\",\"name\":\"Portuguese\"},{\"language_id\":\"hi\",\"name\":\"Hindi\"},{\"language_id\":\"ar\",\"name\":\"Arabic\"}],\"model_rates\":{\"character_cost_multiplier\":1},\"concurrency_group\":\"standard\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(7, 'eleven_monolingual_v1', 'Eleven English v1', 1, 0, 0, 0, '{\"model_id\":\"eleven_monolingual_v1\",\"name\":\"Eleven English v1\",\"can_be_finetuned\":false,\"can_do_text_to_speech\":true,\"can_do_voice_conversion\":false,\"can_use_style\":false,\"can_use_speaker_boost\":false,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our first ever text to speech model. Now outclassed by Multilingual v2 (for content creation) and Turbo v2.5 (for low latency use cases).\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":10000,\"max_characters_request_subscribed_user\":10000,\"maximum_text_length_per_request\":10000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"}],\"model_rates\":{\"character_cost_multiplier\":1},\"concurrency_group\":\"standard\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(8, 'eleven_english_sts_v2', 'Eleven English v2', 0, 1, 0, 1, '{\"model_id\":\"eleven_english_sts_v2\",\"name\":\"Eleven English v2\",\"can_be_finetuned\":false,\"can_do_text_to_speech\":false,\"can_do_voice_conversion\":true,\"can_use_style\":true,\"can_use_speaker_boost\":true,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our state-of-the-art speech to speech model suitable for scenarios where you need maximum control over the content and prosody of your generations.\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":5000,\"max_characters_request_subscribed_user\":5000,\"maximum_text_length_per_request\":5000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"}],\"model_rates\":{\"character_cost_multiplier\":1},\"concurrency_group\":\"standard\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(9, 'eleven_multilingual_sts_v2', 'Eleven Multilingual v2', 0, 1, 1, 1, '{\"model_id\":\"eleven_multilingual_sts_v2\",\"name\":\"Eleven Multilingual v2\",\"can_be_finetuned\":true,\"can_do_text_to_speech\":false,\"can_do_voice_conversion\":true,\"can_use_style\":true,\"can_use_speaker_boost\":true,\"serves_pro_voices\":false,\"token_cost_factor\":1,\"description\":\"Our cutting-edge, multilingual speech-to-speech model is designed for situations that demand unparalleled control over both the content and the prosody of the generated speech across various languages.\",\"requires_alpha_access\":false,\"max_characters_request_free_user\":10000,\"max_characters_request_subscribed_user\":10000,\"maximum_text_length_per_request\":10000,\"languages\":[{\"language_id\":\"en\",\"name\":\"English\"},{\"language_id\":\"ja\",\"name\":\"Japanese\"},{\"language_id\":\"zh\",\"name\":\"Chinese\"},{\"language_id\":\"de\",\"name\":\"German\"},{\"language_id\":\"hi\",\"name\":\"Hindi\"},{\"language_id\":\"fr\",\"name\":\"French\"},{\"language_id\":\"ko\",\"name\":\"Korean\"},{\"language_id\":\"pt\",\"name\":\"Portuguese\"},{\"language_id\":\"it\",\"name\":\"Italian\"},{\"language_id\":\"es\",\"name\":\"Spanish\"},{\"language_id\":\"ru\",\"name\":\"Russian\"},{\"language_id\":\"id\",\"name\":\"Indonesian\"},{\"language_id\":\"nl\",\"name\":\"Dutch\"},{\"language_id\":\"tr\",\"name\":\"Turkish\"},{\"language_id\":\"fil\",\"name\":\"Filipino\"},{\"language_id\":\"pl\",\"name\":\"Polish\"},{\"language_id\":\"sv\",\"name\":\"Swedish\"},{\"language_id\":\"bg\",\"name\":\"Bulgarian\"},{\"language_id\":\"ro\",\"name\":\"Romanian\"},{\"language_id\":\"ar\",\"name\":\"Arabic\"},{\"language_id\":\"cs\",\"name\":\"Czech\"},{\"language_id\":\"el\",\"name\":\"Greek\"},{\"language_id\":\"fi\",\"name\":\"Finnish\"},{\"language_id\":\"hr\",\"name\":\"Croatian\"},{\"language_id\":\"ms\",\"name\":\"Malay\"},{\"language_id\":\"sk\",\"name\":\"Slovak\"},{\"language_id\":\"da\",\"name\":\"Danish\"},{\"language_id\":\"ta\",\"name\":\"Tamil\"},{\"language_id\":\"uk\",\"name\":\"Ukrainian\"}],\"model_rates\":{\"character_cost_multiplier\":1},\"concurrency_group\":\"standard\"}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `eleven_labs_model_voices`
--

CREATE TABLE `eleven_labs_model_voices` (
  `id` bigint UNSIGNED NOT NULL,
  `voice_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `accent` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `description` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `use_case` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `eleven_labs_model_voices`
--

INSERT INTO `eleven_labs_model_voices` (`id`, `voice_id`, `name`, `accent`, `description`, `use_case`, `response`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '9BWtsMINqrJLrRacOk9x', 'Aria', 'american', 'expressive', '', '{\"voice_id\":\"9BWtsMINqrJLrRacOk9x\",\"name\":\"Aria\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_multilingual_v2\":\"fine_tuned\",\"eleven_turbo_v2_5\":\"fine_tuned\",\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"expressive\",\"age\":\"middle_aged\",\"gender\":\"female\",\"use_case\":\"social media\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/9BWtsMINqrJLrRacOk9x\\/405766b8-1f4e-4d3c-aba1-6f25333823ec.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(2, 'CwhRBWXzGAHq8TQ4Fs17', 'Roger', 'american', 'confident', '', '{\"voice_id\":\"CwhRBWXzGAHq8TQ4Fs17\",\"name\":\"Roger\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_multilingual_v2\":\"fine_tuned\",\"eleven_turbo_v2_5\":\"failed\",\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"confident\",\"age\":\"middle_aged\",\"gender\":\"male\",\"use_case\":\"social media\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/CwhRBWXzGAHq8TQ4Fs17\\/58ee3ff5-f6f2-4628-93b8-e38eb31806b0.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(3, 'EXAVITQu4vr4xnSDxMaL', 'Sarah', 'american', 'soft', '', '{\"voice_id\":\"EXAVITQu4vr4xnSDxMaL\",\"name\":\"Sarah\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{},\"message\":{},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"soft\",\"age\":\"young\",\"gender\":\"female\",\"use_case\":\"news\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/EXAVITQu4vr4xnSDxMaL\\/01a3e33c-6e99-4ee7-8543-ff2216a32186.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_turbo_v2\",\"eleven_multilingual_v2\",\"eleven_turbo_v2_5\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(4, 'FGY2WhTYpPnrIDTdsKH5', 'Laura', 'american', 'upbeat', '', '{\"voice_id\":\"FGY2WhTYpPnrIDTdsKH5\",\"name\":\"Laura\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_multilingual_v2\":\"fine_tuned\",\"eleven_turbo_v2_5\":\"fine_tuned\",\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"upbeat\",\"age\":\"young\",\"gender\":\"female\",\"use_case\":\"social media\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/FGY2WhTYpPnrIDTdsKH5\\/67341759-ad08-41a5-be6e-de12fe448618.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(5, 'IKne3meq5aSn9XLyUdCD', 'Charlie', 'australian', 'natural', '', '{\"voice_id\":\"IKne3meq5aSn9XLyUdCD\",\"name\":\"Charlie\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"australian\",\"description\":\"natural\",\"age\":\"middle_aged\",\"gender\":\"male\",\"use_case\":\"conversational\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/IKne3meq5aSn9XLyUdCD\\/102de6f2-22ed-43e0-a1f1-111fa75c5481.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_multilingual_v1\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(6, 'JBFqnCBsd6RMkjVDRZzb', 'George', 'british', 'warm', '', '{\"voice_id\":\"JBFqnCBsd6RMkjVDRZzb\",\"name\":\"George\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_v2_flash\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_turbo_v2\":\"\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"british\",\"description\":\"warm\",\"age\":\"middle_aged\",\"gender\":\"male\",\"use_case\":\"narration\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/JBFqnCBsd6RMkjVDRZzb\\/e6206d1a-0721-4787-aafb-06a6e705cac5.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(7, 'N2lVS1w4EtoT3dr4eOWO', 'Callum', 'american', 'intense', '', '{\"voice_id\":\"N2lVS1w4EtoT3dr4eOWO\",\"name\":\"Callum\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"intense\",\"age\":\"middle_aged\",\"gender\":\"male\",\"use_case\":\"characters\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/N2lVS1w4EtoT3dr4eOWO\\/ac833bd8-ffda-4938-9ebc-b0f99ca25481.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_multilingual_v1\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(8, 'SAz9YHcvj6GT2YYXdXww', 'River', 'american', 'confident', '', '{\"voice_id\":\"SAz9YHcvj6GT2YYXdXww\",\"name\":\"River\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_multilingual_v2\":\"fine_tuned\",\"eleven_turbo_v2_5\":\"fine_tuned\",\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\",\"eleven_multilingual_sts_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"confident\",\"age\":\"middle_aged\",\"gender\":\"non-binary\",\"use_case\":\"social media\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/SAz9YHcvj6GT2YYXdXww\\/e6c95f0b-2227-491a-b3d7-2249240decb7.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_sts_v2\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(9, 'TX3LPaxmHKxFdv7VOQHJ', 'Liam', 'american', 'articulate', '', '{\"voice_id\":\"TX3LPaxmHKxFdv7VOQHJ\",\"name\":\"Liam\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_v2_flash\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_turbo_v2\":\"\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"articulate\",\"age\":\"young\",\"gender\":\"male\",\"use_case\":\"narration\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/TX3LPaxmHKxFdv7VOQHJ\\/63148076-6363-42db-aea8-31424308b92c.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_multilingual_v1\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(10, 'XB0fDUnXU5powFXDhCwa', 'Charlotte', 'swedish', 'seductive', '', '{\"voice_id\":\"XB0fDUnXU5powFXDhCwa\",\"name\":\"Charlotte\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_multilingual_v2\":\"\",\"eleven_turbo_v2_5\":\"\",\"eleven_flash_v2_5\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"swedish\",\"description\":\"seductive\",\"age\":\"young\",\"gender\":\"female\",\"use_case\":\"characters\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/XB0fDUnXU5powFXDhCwa\\/942356dc-f10d-4d89-bda5-4f8505ee038b.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_multilingual_v1\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(11, 'Xb7hH8MSUJpSbSDYk0k2', 'Alice', 'british', 'confident', '', '{\"voice_id\":\"Xb7hH8MSUJpSbSDYk0k2\",\"name\":\"Alice\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"british\",\"description\":\"confident\",\"age\":\"middle_aged\",\"gender\":\"female\",\"use_case\":\"news\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/Xb7hH8MSUJpSbSDYk0k2\\/d10f7534-11f6-41fe-a012-2de1e482d336.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(12, 'XrExE9yKIg1WjnnlVkGX', 'Matilda', 'american', 'friendly', '', '{\"voice_id\":\"XrExE9yKIg1WjnnlVkGX\",\"name\":\"Matilda\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_v2_flash\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_turbo_v2\":\"\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"friendly\",\"age\":\"middle_aged\",\"gender\":\"female\",\"use_case\":\"narration\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/XrExE9yKIg1WjnnlVkGX\\/b930e18d-6b4d-466e-bab2-0ae97c6d8535.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_multilingual_v1\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(13, 'bIHbv24MWmeRgasZH58o', 'Will', 'american', 'friendly', '', '{\"voice_id\":\"bIHbv24MWmeRgasZH58o\",\"name\":\"Will\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_multilingual_v2\":\"fine_tuned\",\"eleven_turbo_v2_5\":\"fine_tuned\",\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"friendly\",\"age\":\"young\",\"gender\":\"male\",\"use_case\":\"social media\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/bIHbv24MWmeRgasZH58o\\/8caf8f3d-ad29-4980-af41-53f20c72d7a4.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(14, 'cgSgspJ2msm6clMCkdW9', 'Jessica', 'american', 'expressive', '', '{\"voice_id\":\"cgSgspJ2msm6clMCkdW9\",\"name\":\"Jessica\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_multilingual_v2\":\"fine_tuned\",\"eleven_turbo_v2_5\":\"fine_tuned\",\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"expressive\",\"age\":\"young\",\"gender\":\"female\",\"use_case\":\"conversational\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/cgSgspJ2msm6clMCkdW9\\/56a97bf8-b69b-448f-846c-c3a11683d45a.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(15, 'cjVigY5qzO86Huf0OWal', 'Eric', 'american', 'friendly', '', '{\"voice_id\":\"cjVigY5qzO86Huf0OWal\",\"name\":\"Eric\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_multilingual_v2\":\"fine_tuned\",\"eleven_turbo_v2_5\":\"fine_tuned\",\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"friendly\",\"age\":\"middle_aged\",\"gender\":\"male\",\"use_case\":\"conversational\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/cjVigY5qzO86Huf0OWal\\/d098fda0-6456-4030-b3d8-63aa048c9070.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(16, 'iP95p4xoKVk53GoZ742B', 'Chris', 'american', 'casual', '', '{\"voice_id\":\"iP95p4xoKVk53GoZ742B\",\"name\":\"Chris\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"casual\",\"age\":\"middle_aged\",\"gender\":\"male\",\"use_case\":\"conversational\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/iP95p4xoKVk53GoZ742B\\/3f4bde72-cc48-40dd-829f-57fbf906f4d7.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(17, 'nPczCjzI2devNBz1zQrb', 'Brian', 'american', 'deep', '', '{\"voice_id\":\"nPczCjzI2devNBz1zQrb\",\"name\":\"Brian\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"deep\",\"age\":\"middle_aged\",\"gender\":\"male\",\"use_case\":\"narration\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/nPczCjzI2devNBz1zQrb\\/2dd3e72c-4fd3-42f1-93ea-abc5d4e5aa1d.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(18, 'onwK4e9ZLuTAKqWW03F9', 'Daniel', 'british', 'authoritative', '', '{\"voice_id\":\"onwK4e9ZLuTAKqWW03F9\",\"name\":\"Daniel\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"british\",\"description\":\"authoritative\",\"age\":\"middle_aged\",\"gender\":\"male\",\"use_case\":\"news\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/onwK4e9ZLuTAKqWW03F9\\/7eee0236-1a72-4b86-b303-5dcadc007ba9.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_multilingual_v1\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(19, 'pFZP5JQG7iQjIQuC4Bku', 'Lily', 'british', 'warm', '', '{\"voice_id\":\"pFZP5JQG7iQjIQuC4Bku\",\"name\":\"Lily\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"british\",\"description\":\"warm\",\"age\":\"middle_aged\",\"gender\":\"female\",\"use_case\":\"narration\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/pFZP5JQG7iQjIQuC4Bku\\/89b68b35-b3dd-4348-a84a-a3c13a3c2b30.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33'),
(20, 'pqHfZKP75CvOlQylNhV4', 'Bill', 'american', 'trustworthy', '', '{\"voice_id\":\"pqHfZKP75CvOlQylNhV4\",\"name\":\"Bill\",\"samples\":null,\"category\":\"premade\",\"fine_tuning\":{\"is_allowed_to_fine_tune\":true,\"state\":{\"eleven_flash_v2_5\":\"fine_tuned\",\"eleven_turbo_v2\":\"fine_tuned\",\"eleven_flash_v2\":\"fine_tuned\",\"eleven_v2_flash\":\"fine_tuned\",\"eleven_v2_5_flash\":\"fine_tuned\"},\"verification_failures\":[],\"verification_attempts_count\":0,\"manual_verification_requested\":false,\"language\":\"en\",\"progress\":{\"eleven_flash_v2_5\":1,\"eleven_v2_flash\":1,\"eleven_flash_v2\":1,\"eleven_v2_5_flash\":1},\"message\":{\"eleven_flash_v2_5\":\"Done!\",\"eleven_turbo_v2\":\"\",\"eleven_flash_v2\":\"Done!\",\"eleven_v2_flash\":\"Done!\",\"eleven_v2_5_flash\":\"Done!\"},\"dataset_duration_seconds\":null,\"verification_attempts\":null,\"slice_ids\":null,\"manual_verification\":null,\"max_verification_attempts\":5,\"next_max_verification_attempts_reset_unix_ms\":1700000000000},\"labels\":{\"accent\":\"american\",\"description\":\"trustworthy\",\"age\":\"old\",\"gender\":\"male\",\"use_case\":\"narration\"},\"description\":null,\"preview_url\":\"https:\\/\\/storage.googleapis.com\\/eleven-public-prod\\/premade\\/voices\\/pqHfZKP75CvOlQylNhV4\\/d782b3ff-84ba-4029-848c-acf01285524d.mp3\",\"available_for_tiers\":[],\"settings\":null,\"sharing\":null,\"high_quality_base_model_ids\":[\"eleven_v2_flash\",\"eleven_flash_v2\",\"eleven_turbo_v2_5\",\"eleven_multilingual_v2\",\"eleven_v2_5_flash\",\"eleven_flash_v2_5\",\"eleven_turbo_v2\"],\"verified_languages\":[],\"safety_control\":null,\"voice_verification\":{\"requires_verification\":false,\"is_verified\":false,\"verification_failures\":[],\"verification_attempts_count\":0,\"language\":null,\"verification_attempts\":null},\"permission_on_resource\":null,\"is_owner\":false,\"is_legacy\":false,\"is_mixed\":false,\"created_at_unix\":null}', 1, '2025-05-11 17:07:33', '2025-05-11 17:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE `email_templates` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `subject` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `code` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `variables` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` tinyint DEFAULT '1',
  `created_by` int DEFAULT '1',
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `name`, `subject`, `slug`, `code`, `type`, `variables`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Welcome Email', 'Welcome Email', 'welcome-email', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hey\n                                    [name],\n                                    thanks for\n                                    signing up!</p>\n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercer.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright writercert.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'welcome-email', '[name], [email], [phone]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:22:32'),
(2, 'Registration Verification', 'Registration Verification', 'registration-verification', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hey\n                                    [name],\n                                    thanks for\n                                    signing up!</p>\n                                  <h4 style=\"margin-bottom:2px; color:#7E8299\">Email Verification\n                                  </h4>\n                                  <p style=\"margin-bottom:2px; color:#7E8299\">paragraphs. Please click the button below to verify your email address\n                                  </p>\n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                                <!--begin:Action-->\n                                <a href=\"[active_url]\" target=\"_blank\" style=\"background-color:#29a762; border-radius:6px;display:inline-block; padding:11px 19px; color: #FFFFFF; font-size: 14px; font-weight:500;\">\n                                  Activate Account\n                                </a>\n                                <!--begin:Action-->\n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright writercert.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'registration-verification', '[name], [email], [phone]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:23:35'),
(3, 'Add New Customer Welcome Email', 'Add New Customer Welcome Email', 'add-new-customer-welcome-email', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                  <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                    <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                      <tbody>\n                        <tr>\n                          <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n    \n                            <!--begin:Email content-->\n                            <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                              <!--begin:Logo-->\n                              <div style=\"margin-bottom: 10px\">\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                </a>\n                              </div>\n                              <!--end:Logo-->\n    \n                              <!--begin:Media-->\n                              <div style=\"margin-bottom: 15px\">\n                                <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                              </div>\n                              <!--end:Media-->\n    \n                              <!--begin:Text-->\n                              <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hi [name],\n                                We have created account for you . your login credentails here :\n                                  Email : [email]\n                                  Phone : [phone]\n                                  password : [password]\n                                  <strong> and your package info</strong>:\n                                  Package name : [package]\n                                  Price : [price]\n                                  Payment Method : [method]\n                                  Start Date : [startDate]\n                                  End Date : [endDate]\n                                  </p>\n                               \n                              </div>\n                              <!--end:Text-->\n                              <!--begin:Action-->\n                              <a href=\"[login_url]\" target=\"_blank\" style=\"background-color:#29a762; border-radius:6px;display:inline-block; padding:11px 19px; color: #FFFFFF; font-size: 14px; font-weight:500;\">\n                                Login\n                              </a>\n                              <!--begin:Action-->\n                            </div>\n                            <!--end:Email content-->\n                          </td>\n                        </tr> \n    \n                        <tr>\n                          <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                            <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                              It’s all about customers!</p>\n                            <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                            <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                            </p>\n                            <p>We serve Mon-Fri, 9AM-18AM</p>\n                          </td>\n                        </tr>  \n                        <tr>\n                          <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                            <p> © Copyright Writercert AI.\n                              <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                              from newsletter.\n                            </p>\n                          </td>\n                        </tr>\n                      </tbody>\n                    </table>\n                  </div>\n                </div>', 'add-new-customer-welcome-email', '[name], [email], [phone], [password], [package], [startDate], [endDate], [price], [method]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:24:29'),
(4, 'Purchase Package', 'Purchase Package', 'purchase-package', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hi\n                                    [name],\n                                    thanks for\n                                    purchase [package].</p>\n                                    <p>Your [Package] price [price] and start from [startDate]</p>\n                                    <p>Your [Package] Will be expire [endDate]</p>                                 \n                                </div>\n                                \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright Writercert AI.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'purchase-package', '[name], [email], [phone], [package],[startDate], [endDate],[price]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:25:10'),
(5, 'Admin Assign Package', 'Admin Assign Package', 'admin-assign-package', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hi\n                                    [name],\n                                   Admin Assigned this <strong>[package]</strong> for you.\n                                    purchase <strong>[package]</strong>.</p>\n                                    <p>Your  <strong>[package]</strong> price  <strong>[price]</strong> and start from [startDate]</p>\n                                    <p>Your [Package] Will be expire <strong>[endDate]</strong></p>\n                        \n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright Writercert AI.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'admin-assign-package', '[name], [email], [phone], [package],[startDate], [endDate],[price]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:25:30'),
(6, 'Offline Payment Request', 'Offline Payment Request', 'offline-payment-request', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hi, <br>\n                                   [name] request a offline payment for purchase <strong>[package]</strong> using this payment method <strong>[method]</strong> .</p>\n                                    <p>And  <strong>[package]</strong> price  <strong>[price]</strong></p>                         \n      \n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright Writercert AI.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'offline-payment-request', '[name], [email], [phone], [package],[price], [method],[note]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:26:01'),
(7, 'Offline Payment Request Approve', 'Offline Payment Request Approve', 'offline-payment-request-approve', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hi [name], <br>\n                                   Your request a offline payment has been approved [package] using this payment method <strong>[method]</strong> .</p>\n                                                          \n                                    <p>Your  <strong>[package]</strong> price  <strong>[price]</strong> and start from [startDate]</p>\n                                    <p>Your [Package] Will be expire <strong>[endDate]</strong></p>\n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright Writercert AI.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'offline-payment-request-approve', '[name], [email], [phone], [package],[startDate], [endDate],[price], [method],[note]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:26:24'),
(8, 'Offline Payment Request Reject', 'Offline Payment Request Reject', 'offline-payment-request-rejected', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hi [name], <br>\n                                   Your requested a offline payment for purchase <strong>[package]</strong> using this payment method <strong>[method]</strong> has been <strong>Rejected</strong> .</p>\n                                                \n      \n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright Writercert Ai.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'offline-payment-request-rejected', '[name], [email], [phone], [package],[price], [method],[note]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:27:04'),
(9, 'Offline Payment Request Add Note', 'Offline Payment Request Add Note', 'offline-payment-request-add-note', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hi [name], <br>\n                                   Your request a offline payment for purchase <strong>[package]</strong> using this payment method <strong>[method]</strong> .</p>\n                                    <p>But Admin Want more information from you</p>\n                                    <p>[note]</p>                         \n      \n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright Writercert.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'offline-payment-request-add-note', '[name], [email], [phone], [package],[price], [method],[note]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:27:24');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `slug`, `code`, `type`, `variables`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(10, 'Assign Ticket', 'Assign Ticket', 'ticket-assign', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hey, <br>\n                                    New Ticket from <strong>[name]</strong> and [ticketId] .</p>\n                                  \n      \n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright Writercert AI.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'ticket-assign', '[name], [email], [phone], [title], [ticketId]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:27:56'),
(11, 'Ticket Reply', 'Ticket Reply', 'ticket-reply', '<div style=\"background-color:#D5D9E2; font-family:Arial,Helvetica,sans-serif; line-height: 1.5; min-height: 100%; font-weight: normal; font-size: 15px; color: #2F3044; margin:0; padding:0; width:100%;\">\n                    <div style=\"background-color:#ffffff; padding: 45px 0 34px 0; border-radius: 24px; margin:0 auto; max-width: 600px;\">\n                      <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"auto\" style=\"border-collapse:collapse\">\n                        <tbody>\n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"text-align:center; padding-bottom: 10px\">\n      \n                              <!--begin:Email content-->\n                              <div style=\"text-align:center; margin:0 15px 34px 15px\">\n                                <!--begin:Logo-->\n                                <div style=\"margin-bottom: 10px\">\n                                  <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\">\n                                    <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png\" style=\"height: 35px\">\n                                  </a>\n                                </div>\n                                <!--end:Logo-->\n      \n                                <!--begin:Media-->\n                                <div style=\"margin-bottom: 15px\">\n                                  <img alt=\"Logo\" src=\"https://writebot.themetags.com/public/images/like.svg\" style=\"width: 120px; margin:40px auto;\">\n                                </div>\n                                <!--end:Media-->\n      \n                                <!--begin:Text-->\n                                <div style=\"font-size: 14px; font-weight: 500; margin-bottom: 27px; font-family:Arial,Helvetica,sans-serif;\">\n                                  <p style=\"margin-bottom:9px; color:#181C32; font-size: 22px; font-weight:700\">Hey, <br>\n                                    Ticket reply from  <strong>[name]</strong> and [ticketId] .</p>\n                                  \n      \n                                 \n                                </div>\n                                <!--end:Text-->\n      \n                              </div>\n                              <!--end:Email content-->\n                            </td>\n                          </tr> \n      \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; text-align:center; padding: 0 10px 10px 10px; font-weight: 500; color: #A1A5B7; font-family:Arial,Helvetica,sans-serif\">\n                              <p style=\"color:#181C32; font-size: 16px; font-weight: 600; margin-bottom:9px                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               \">\n                                It’s all about customers!</p>\n                              <p style=\"margin-bottom:2px\">Call our customer care number: 540-907-0453</p>\n                              <p style=\"margin-bottom:4px\">You may reach us at <a href=\"https://writercert.com\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600\">admin@writercert.com</a>.\n                              </p>\n                              <p>We serve Mon-Fri, 9AM-18AM</p>\n                            </td>\n                          </tr>  \n                          <tr>\n                            <td align=\"center\" valign=\"center\" style=\"font-size: 13px; padding:0 15px; text-align:center; font-weight: 500; color: #A1A5B7;font-family:Arial,Helvetica,sans-serif\">\n                              <p> © Copyright Writercert AI.\n                                <a href=\"https://writebot.themetags.com/\" rel=\"noopener\" target=\"_blank\" style=\"font-weight: 600;font-family:Arial,Helvetica,sans-serif\">Unsubscribe</a>&nbsp;\n                                from newsletter.\n                              </p>\n                            </td>\n                          </tr>\n                        </tbody>\n                      </table>\n                    </div>\n                  </div>', 'ticket-reply', '[name], [email], [phone], [title],[titleId]', 1, 1, 1, '2025-04-21 16:31:46', '2025-05-13 15:28:25');

-- --------------------------------------------------------

--
-- Table structure for table `e_mail_settings`
--

CREATE TABLE `e_mail_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `email_engine` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mail_driver` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mail_host` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mail_port` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mail_username` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mail_password` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mail_encryption` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `from_email` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `from_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `e_mail_settings`
--

INSERT INTO `e_mail_settings` (`id`, `email_engine`, `mail_driver`, `mail_host`, `mail_port`, `mail_username`, `mail_password`, `mail_encryption`, `from_email`, `from_name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'smtp', 'smtp', 'premium7.hostnate.com', '465', 'admin@writercert.com', 'Forid@@2025$$', 'tls', 'no-reply@writercert.com', 'WriterCert', 1, '2025-04-21 16:31:47', '2025-05-04 09:43:06');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` bigint UNSIGNED NOT NULL,
  `question` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `answer` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faq_localizations`
--

CREATE TABLE `faq_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `faq_id` int NOT NULL,
  `question` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `answer` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `favorite_templates`
--

CREATE TABLE `favorite_templates` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `template_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feature_categories`
--

CREATE TABLE `feature_categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `icon` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '1',
  `created_by` bigint DEFAULT '1',
  `updated_by` bigint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `feature_categories`
--

INSERT INTO `feature_categories` (`id`, `name`, `icon`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, '72+ Pre Build Template', '	bi bi-layers', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(2, 'Full Blog Generator', 'bi bi-textarea-t', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(3, 'AI Image Generator', 'bi bi-images', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(4, 'Text To Voice', '	bi bi-volume-up-fill', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(5, 'Chat with Expert', 'bi bi-chat-square-dots-fill', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(6, 'Integrated Tools', 'bi bi-bounding-box', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51');

-- --------------------------------------------------------

--
-- Table structure for table `feature_category_details`
--

CREATE TABLE `feature_category_details` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `image` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `feature_category_id` bigint NOT NULL,
  `short_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '1',
  `created_by` bigint DEFAULT '1',
  `updated_by` bigint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `feature_category_details`
--

INSERT INTO `feature_category_details` (`id`, `title`, `image`, `feature_category_id`, `short_description`, `icon`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Social Media Template', '35', 1, 'AI-powered robots can perform rule based tasks in business', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(2, 'Fun and Quote', '101', 1, 'AI-powered robots can perform rule based tasks in business', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(3, 'Website Content & Summery', '59', 1, 'AI-powered robots can perform rule based tasks in business', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(4, 'Email Marketing Template', '58', 1, 'Generate social media content easily using our application', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(5, 'Generate Full Blog', '60', 2, 'Generate full blog article using our writebot application', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(6, 'Generate Blog Keyword', '59', 2, 'Generated blog keyword based on your topics', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(7, 'Create Blog Outline', '58', 2, 'Generate blog outline based on your keyword and title', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(8, 'Generated Blog Publish', '57', 2, 'After generated blog article then publish to your blog', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(9, 'Generate Dall-E 2 Image', '56', 3, 'Generate dall-e 2 Images for using OpenAi', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(10, 'Stable Diffusion Images', '54', 3, 'Stable Diffusion is a deep learning, text-to-image model', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(11, 'Generate Dall-E 3 Image', '55', 3, 'Generate dall-e 3 Images for using OpenAi', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(12, 'Google text to Speech', '53', 4, 'Generate text to speech using Google TTS', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(13, 'OpenAI Text to Speech', '51', 4, 'Generate text to speech using OpenAi TTS', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(14, 'ElevenLabs Text to Speech', '52', 4, 'For real human voice using ElevenLabs Text to Speech', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(15, 'Azure Text to Speech', '50', 4, 'AI voice generators to speak naturally using Azure', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(16, 'AI Chat with Expert', '49', 5, 'Chat with different expertise more then 25', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(17, 'AI Chat Images', '48', 5, 'Ai chat for generating quality images', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(18, 'Chat From Images', '47', 5, 'Upload images for get content base on your images', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(19, 'AI PDF Chat', '46', 5, 'Collect data from your pdf file, chat with pdf', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(20, 'Twilio Authentication', '45', 6, 'Delight customers with frictionless authentication touch-point.', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:52', '2025-04-21 16:31:52'),
(21, 'Google & Microsoft Azure TTS', '40', 6, 'AI voice generators to speak naturally using Azure and google', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:52', '2025-04-21 16:31:52'),
(22, 'Storage Management', '42', 6, 'AWS storage services Object, file, and block storage', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:52', '2025-04-21 16:31:52'),
(23, 'Social Login Integrated', '44', 6, 'Integrated Google and Facebook for signup and sign in', 'bi bi-stars', '1', 1, 1, '2025-04-21 16:31:52', '2025-04-21 16:31:52');

-- --------------------------------------------------------

--
-- Table structure for table `feature_category_detail_localizations`
--

CREATE TABLE `feature_category_detail_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `feature_category_detail_id` bigint NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `short_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `feature_category_detail_localizations`
--

INSERT INTO `feature_category_detail_localizations` (`id`, `feature_category_detail_id`, `title`, `short_description`, `lang_key`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'Social Media Template', 'AI-powered robots can perform rule based tasks in business', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(2, 2, 'Fun and Quote', 'AI-powered robots can perform rule based tasks in business', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(3, 3, 'Website Content & Summery', 'AI-powered robots can perform rule based tasks in business', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(4, 4, 'Email Marketing Template', 'Generate social media content easily using our application', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(5, 5, 'Generate Full Blog', 'Generate full blog article using our writebot application', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(6, 6, 'Generate Blog Keyword', 'Generated blog keyword based on your topics', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(7, 7, 'Create Blog Outline', 'Generate blog outline based on your keyword and title', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(8, 8, 'Generated Blog Publish', 'After generated blog article then publish to your blog', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(9, 9, 'Generate Dall-E 2 Image', 'Generate dall-e 2 Images for using OpenAi', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(10, 10, 'Stable Diffusion Images', 'Stable Diffusion is a deep learning, text-to-image model', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(11, 11, 'Generate Dall-E 3 Image', 'Generate dall-e 3 Images for using OpenAi', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(12, 12, 'Google text to Speech', 'Generate text to speech using Google TTS', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(13, 13, 'OpenAI Text to Speech', 'Generate text to speech using OpenAi TTS', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(14, 14, 'ElevenLabs Text to Speech', 'For real human voice using ElevenLabs Text to Speech', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(15, 15, 'Azure Text to Speech', 'AI voice generators to speak naturally using Azure', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(16, 16, 'AI Chat with Expert', 'Chat with different expertise more then 25', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(17, 17, 'AI Chat Images', 'Ai chat for generating quality images', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(18, 18, 'Chat From Images', 'Upload images for get content base on your images', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(19, 19, 'AI PDF Chat', 'Collect data from your pdf file, chat with pdf', 'en', NULL, '2025-04-21 16:31:51', '2025-04-21 16:31:51'),
(20, 20, 'Twilio Authentication', 'Delight customers with frictionless authentication touch-point.', 'en', NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52'),
(21, 21, 'Google & Microsoft Azure TTS', 'AI voice generators to speak naturally using Azure and google', 'en', NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52'),
(22, 22, 'Storage Management', 'AWS storage services Object, file, and block storage', 'en', NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52'),
(23, 23, 'Social Login Integrated', 'Integrated Google and Facebook for signup and sign in', 'en', NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52');

-- --------------------------------------------------------

--
-- Table structure for table `feature_category_localizations`
--

CREATE TABLE `feature_category_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `feature_category_id` bigint NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `feature_category_localizations`
--

INSERT INTO `feature_category_localizations` (`id`, `feature_category_id`, `name`, `lang_key`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, '72+ Pre Build Template', 'en', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(2, 2, 'Full Blog Generator', 'en', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(3, 3, 'AI Image Generator', 'en', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(4, 4, 'Text To Voice', 'en', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(5, 5, 'Chat with Expert', 'en', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(6, 6, 'Integrated Tools', 'en', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `fine_tunes`
--

CREATE TABLE `fine_tunes` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL COMMENT 'owner of the model - user_id',
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL COMMENT 'NB: aim of the fine-tuning. Ex. Office Assistant',
  `model_engine` enum('text-davinci-002','gpt-3.5-turbo') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL COMMENT 'Ex. gpt-3.5-turbo/ davinci',
  `ft_model_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'Ex. ft-123456789xyz',
  `file_model_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'Ex. file-123456789xyz',
  `active_status` tinyint NOT NULL DEFAULT '1' COMMENT '1 = active, 0 = inactive',
  `status` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status_details` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `file_upload_response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `fine_tune_job_response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fine_tune_histories`
--

CREATE TABLE `fine_tune_histories` (
  `id` bigint UNSIGNED NOT NULL,
  `fine_tune_id` bigint UNSIGNED NOT NULL,
  `ft_model_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'Ex. ft-123456789xyz',
  `file_model_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'Ex. file-123456789xyz',
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL COMMENT 'NB: aim of the fine-tuning. Ex. Office Assistant',
  `description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL COMMENT 'NB: Description of the fine-tuning. Ex. Office Assistant Prompt & Answering',
  `trained_file_path` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL COMMENT 'Trained JSONL file path',
  `training_data` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci COMMENT 'JSON L fine contents',
  `status` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status_details` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `file_upload_response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `fine_tune_job_response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

CREATE TABLE `folders` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `general_setup_localizations`
--

CREATE TABLE `general_setup_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `system_setting_id` int DEFAULT NULL,
  `entity` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `general_setup_localizations`
--

INSERT INTO `general_setup_localizations` (`id`, `system_setting_id`, `entity`, `value`, `lang_key`, `created_at`, `updated_at`) VALUES
(1, 242, 'aboutUsContents', '<h3 data-start=\"173\" data-end=\"246\" class=\"\">Welcome to WriterCert — Where Smart Content Meets Seamless Publishing</h3><p data-start=\"248\" data-end=\"557\" class=\"\">At <strong data-start=\"251\" data-end=\"269\">WriterCert.com</strong>, we believe that great content should be easy to create and effortless to share. That’s why we’ve built an AI-powered writing and publishing platform that helps individuals, marketers, bloggers, and businesses save time, increase productivity, and stay ahead in the digital content game.</p><p data-start=\"559\" data-end=\"903\" class=\"\">Whether you\'re crafting SEO-optimized blog posts, marketing copy, emails, or custom content — <strong data-start=\"653\" data-end=\"667\">WriterCert</strong> provides certified-quality writing tools driven by the latest in artificial intelligence. With just a few clicks, your content is not only generated — it’s also <strong data-start=\"829\" data-end=\"853\">automatically posted</strong> to platforms like WordPress, Medium, and Blogger.</p><hr data-start=\"905\" data-end=\"908\" class=\"\"><h3 data-start=\"910\" data-end=\"925\" class=\"\">Our Mission</h3><p data-start=\"927\" data-end=\"1096\" class=\"\">To empower content creators and businesses with intelligent tools that simplify the writing process and streamline publishing — so you can focus on ideas, not logistics.</p><hr data-start=\"1098\" data-end=\"1101\" class=\"\"><h3 data-start=\"1103\" data-end=\"1120\" class=\"\">What We Offer</h3><ul data-start=\"1122\" data-end=\"1561\">\r\n<li data-start=\"1122\" data-end=\"1188\" class=\"\">\r\n<p data-start=\"1124\" data-end=\"1188\" class=\"\"><strong data-start=\"1124\" data-end=\"1144\">AI Writing Tools</strong> – Generate high-quality content instantly</p>\r\n</li>\r\n<li data-start=\"1189\" data-end=\"1258\" class=\"\">\r\n<p data-start=\"1191\" data-end=\"1258\" class=\"\"><strong data-start=\"1191\" data-end=\"1207\">Auto Posting</strong> – Schedule or auto-publish to multiple platforms</p>\r\n</li>\r\n<li data-start=\"1259\" data-end=\"1337\" class=\"\">\r\n<p data-start=\"1261\" data-end=\"1337\" class=\"\"><strong data-start=\"1261\" data-end=\"1274\">Templates</strong> – Ready-to-use content formats for blogs, ads, emails &amp; more</p>\r\n</li>\r\n<li data-start=\"1338\" data-end=\"1415\" class=\"\">\r\n<p data-start=\"1340\" data-end=\"1415\" class=\"\"><strong data-start=\"1340\" data-end=\"1377\">Plagiarism Checker &amp; AI Detection</strong> – Ensure originality and compliance</p>\r\n</li>\r\n<li data-start=\"1416\" data-end=\"1481\" class=\"\">\r\n<p data-start=\"1418\" data-end=\"1481\" class=\"\"><strong data-start=\"1418\" data-end=\"1453\">Text-to-Speech &amp; Speech-to-Text</strong> – Create content your way</p>\r\n</li>\r\n<li data-start=\"1482\" data-end=\"1561\" class=\"\">\r\n<p data-start=\"1484\" data-end=\"1561\" class=\"\"><strong data-start=\"1484\" data-end=\"1508\">Multi-format Support</strong> – PDF chat, AI images, rewriters, and coding tools</p>\r\n</li>\r\n</ul><hr data-start=\"1563\" data-end=\"1566\" class=\"\"><h3 data-start=\"1568\" data-end=\"1584\" class=\"\">Who We Serve</h3><ul data-start=\"1586\" data-end=\"1828\">\r\n<li data-start=\"1586\" data-end=\"1635\" class=\"\">\r\n<p data-start=\"1588\" data-end=\"1635\" class=\"\">Bloggers and writers looking to scale content</p>\r\n</li>\r\n<li data-start=\"1636\" data-end=\"1683\" class=\"\">\r\n<p data-start=\"1638\" data-end=\"1683\" class=\"\">Agencies managing multiple clients or blogs</p>\r\n</li>\r\n<li data-start=\"1684\" data-end=\"1718\" class=\"\">\r\n<p data-start=\"1686\" data-end=\"1718\" class=\"\">Entrepreneurs building a brand</p>\r\n</li>\r\n<li data-start=\"1719\" data-end=\"1764\" class=\"\">\r\n<p data-start=\"1721\" data-end=\"1764\" class=\"\">Affiliate marketers and SEO professionals</p>\r\n</li>\r\n<li data-start=\"1765\" data-end=\"1828\" class=\"\">\r\n<p data-start=\"1767\" data-end=\"1828\" class=\"\">Anyone who wants to save time while producing smarter content</p>\r\n</li>\r\n</ul><hr data-start=\"1830\" data-end=\"1833\" class=\"\"><h3 data-start=\"1835\" data-end=\"1854\" class=\"\">Why WriterCert?</h3><p data-start=\"1856\" data-end=\"2067\" class=\"\">Because we don’t just help you write — we help you <strong data-start=\"1907\" data-end=\"1957\">write with purpose and publish with confidence</strong>. From AI-powered creativity to smart distribution, WriterCert is your certified assistant for the modern web.</p><hr data-start=\"2069\" data-end=\"2072\" class=\"\"><p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p><p data-start=\"2074\" data-end=\"2196\" class=\"\"><strong data-start=\"2074\" data-end=\"2196\">Join thousands of creators embracing the future of content.<br data-start=\"2135\" data-end=\"2138\">\r\nStart writing. Get certified. Go live — with WriterCert.</strong></p>', 'en', '2025-05-04 13:21:51', '2025-05-04 13:21:51');

-- --------------------------------------------------------

--
-- Table structure for table `grass_period_payments`
--

CREATE TABLE `grass_period_payments` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `order_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `transaction_status` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `subscription_package_id` int NOT NULL,
  `response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `flag` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_rtl` tinyint NOT NULL DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `is_active_for_templates` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `flag`, `code`, `is_rtl`, `is_active`, `is_active_for_templates`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'English', 'en', 'en', 0, 1, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `licenses`
--

CREATE TABLE `licenses` (
  `id` bigint UNSIGNED NOT NULL,
  `purchase_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `client_token` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `app_env` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `licenses`
--

INSERT INTO `licenses` (`id`, `purchase_code`, `client_token`, `app_env`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '************', '************', 'production', 1, '2025-04-21 16:31:52', '2025-04-21 16:31:52');

-- --------------------------------------------------------

--
-- Table structure for table `localizations`
--

CREATE TABLE `localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `t_key` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `t_value` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `localizations`
--

INSERT INTO `localizations` (`id`, `lang_key`, `t_key`, `t_value`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'en', 'please_wait', 'Please Wait', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(2, 'en', 'package_templates', 'Package Templates', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(3, 'en', 'close', 'Close', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(4, 'en', 'something_went_wrong', 'Something went wrong', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(5, 'en', 'please_generate_ai_contents_first', 'Please generate AI contents first', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(6, 'en', 'project_moved_successfully', 'Project moved successfully', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(7, 'en', 'code_has_been_copied_successfully', 'Code has been copied successfully', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(8, 'en', 'content_has_been_copied_successfully', 'Content has been copied successfully', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(9, 'en', 'contents_generation_has_been_stopped', 'Contents generation has been stopped.', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(10, 'en', 'contents_generated_successfully', 'Contents generated successfully', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(11, 'en', 'something_wrong_happened_please_try_again', 'Something wrong happened. Please try again.', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(12, 'en', 'contents_updated_successfully', 'Contents updated successfully', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(13, 'en', 'image_generated_successfully', 'Image generated successfully', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(14, 'en', 'code_generated_successfully', 'Code generated successfully', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(15, 'en', 'delete_confirmation', 'Delete Confirmation', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(16, 'en', 'are_you_sure_to_delete_this', 'Are you sure to delete this?', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(17, 'en', 'all_data_related_to_this_may_get_deleted', 'All data related to this may get deleted.', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(18, 'en', 'proceed', 'Proceed', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(19, 'en', 'cancel', 'Cancel', '2025-04-21 16:37:26', '2025-04-21 16:37:26', NULL),
(20, 'en', 'home', 'Home', '2025-04-21 16:37:33', '2025-04-21 16:37:33', NULL),
(21, 'en', 'start_writing__its_free', 'Start Writing - It\\\'s Free', '2025-04-21 16:37:33', '2025-04-21 16:37:33', NULL),
(22, 'en', 'our_best_features', 'Our Best Features', '2025-04-21 16:37:33', '2025-04-21 16:37:33', NULL),
(23, 'en', 'we_are_more_powerful_than_others', 'We are more powerful than others', '2025-04-21 16:37:33', '2025-04-21 16:37:33', NULL),
(24, 'en', 'blog_content', 'Blog Content', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(25, 'en', 'email_template', 'Email Template', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(26, 'en', 'social_media', 'Social Media', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(27, 'en', 'video_content', 'Video Content', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(28, 'en', 'website_content', 'Website Content', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(29, 'en', 'fun__quote', 'Fun & Quote', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(30, 'en', 'medium_content', 'Medium Content', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(31, 'en', 'tik_tok', 'Tik Tok', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(32, 'en', 'instagram', 'Instagram', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(33, 'en', 'success_story', 'Success Story', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(34, 'en', 'we_help_you', 'We Help You', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(35, 'en', 'to_write_better_contents_faster', 'To Write Better Contents Faster', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(36, 'en', 'words_generated', 'Words Generated', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(37, 'en', 'view_all_templates', 'View All Templates', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(38, 'en', 'what_customers_saying', 'What Customers Saying', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(39, 'en', 'about_us', 'About Us', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(40, 'en', 'our_subscription_packages', 'Our Subscription Packages', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(41, 'en', 'ready_to_get_started', 'Ready to get started?', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(42, 'en', 'monthly', 'Monthly', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(43, 'en', 'select_payment_method', 'Select Payment Method', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(44, 'en', 'payment_method', 'Payment Method', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(45, 'en', 'select_offline_payment_method', 'Select Offline Payment Method', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(46, 'en', 'description', 'Description', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(47, 'en', 'payment_details', 'Payment Details', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(48, 'en', 'type_your_payment_details', 'Type your Payment Details', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(49, 'en', 'file', 'File', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(50, 'en', 'drop_your_files_here_or', 'Drop your files here or', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(51, 'en', 'browse', 'Browse', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(52, 'en', 'allowed_file_types_jpgpngjpeg', 'Allowed file types: jpg,png,jpeg', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(53, 'en', 'note', 'Note', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(54, 'en', 'type_your_note', 'Type your Note', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(55, 'en', 'you_current_package_subscribed_package_type_will_be_expired_if_you_want_to_subscribe_to_package_type_do_you_want_to_continue', 'You current package ${subscribed_package_type} will be expired if you want to subscribe to ${package_type}. Do you want to continue?', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(56, 'en', 'you_are_changing_your_subscription_package_type_to_package_type_your_balance_will_be_reset_with_new_package_balance_want_to_continue', 'You are changing your subscription package type to ${package_type}, your balance will be reset with new package balance. Want to continue?', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(57, 'en', 'faq', 'F.A.Q', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(58, 'en', 'templates', 'Templates', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(59, 'en', 'everything_that_you_need', 'Everything That You Need', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(60, 'en', 'blog_contents', 'Blog Contents', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(61, 'en', 'email_templates', 'Email Templates', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(62, 'en', 'videos', 'Videos', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(63, 'en', 'website_contents', 'Website Contents', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(64, 'en', 'fun_or_quote', 'Fun or Quote', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(65, 'en', 'pricing', 'Pricing', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(66, 'en', 'company', 'Company', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(67, 'en', 'useful_links', 'Useful Links', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(68, 'en', 'contact_us', 'Contact Us', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(69, 'en', 'our_latest_news', 'Our Latest News', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(70, 'en', 'customer_review', 'Customer Review', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(71, 'en', 'sign_in', 'Sign In', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(72, 'en', 'get_started', 'Get Started', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(73, 'en', 'enter_email_address', 'Enter Email Address', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(74, 'en', 'subscribe', 'Subscribe', '2025-04-21 16:37:34', '2025-04-21 16:37:34', NULL),
(75, 'en', 'login', 'Login', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(76, 'en', 'connect_with_google', 'Connect With Google', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(77, 'en', 'connect_with_facebook', 'Connect With Facebook', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(78, 'en', 'or_continue_with', 'or Continue With', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(79, 'en', 'email', 'Email', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(80, 'en', 'enter_your_email', 'Enter your email', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(81, 'en', 'login_with_phone', 'Login with phone?', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(82, 'en', 'phone', 'Phone', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(83, 'en', 'login_with_email', 'Login with email?', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(84, 'en', 'password', 'Password', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(85, 'en', 'enter_your_password', 'Enter your password', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(86, 'en', 'dont_have_an_account', 'Don\'t have an Account?', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(87, 'en', 'sign_up', 'Sign Up', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(88, 'en', 'forgot_password', 'Forgot Password', '2025-04-21 16:38:07', '2025-04-21 16:38:07', NULL),
(89, 'en', 'google_recaptcha_validation_error_seems_like_you_are_not_a_human', 'Google recaptcha validation error, seems like you are not a human.', '2025-04-21 16:38:21', '2025-04-21 16:38:21', NULL),
(90, 'en', 'invalid_login_credentials', 'Invalid login credentials.', '2025-04-21 16:38:21', '2025-04-21 16:38:21', NULL),
(91, 'en', 'reset_with_phone', 'Reset with phone?', '2025-04-21 16:43:28', '2025-04-21 16:43:28', NULL),
(92, 'en', 'reset_with_email', 'Reset with email?', '2025-04-21 16:43:28', '2025-04-21 16:43:28', NULL),
(93, 'en', 'reset_password', 'Reset Password', '2025-04-21 16:43:28', '2025-04-21 16:43:28', NULL),
(94, 'en', 'last_7_days', 'Last 7 days', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(95, 'en', 'dashboard', 'Dashboard', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(96, 'en', 'overview', 'Overview', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(97, 'en', 'create_content', 'Create Content', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(98, 'en', 'subscription_packages', 'Subscription Packages', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(99, 'en', 'total_words_generated', 'Total words generated', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(100, 'en', 'total_image_generated', 'Total Image generated', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(101, 'en', 'total_code_generated', 'Total code generated', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(102, 'en', 'total_speech_to_text', 'Total speech to text', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(103, 'en', 'total_words_generated_with_templates', 'Total Words Generated with templates', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(104, 'en', 'last_30_days', 'Last 30 days', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(105, 'en', 'last_3_months', 'Last 3 months', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(106, 'en', 'words', 'Words', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(107, 'en', 'top_5_templates', 'Top 5 Templates', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(108, 'en', 'recent_projects', 'Recent Projects', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(109, 'en', 'sl', 'S/L', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(110, 'en', 'project_name', 'Project Name', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(111, 'en', 'created_date', 'Created Date', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(112, 'en', 'type', 'Type', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(113, 'en', 'wordssize', 'Words/Size', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(114, 'en', 'action', 'Action', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(115, 'en', 'image', 'Image', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(116, 'en', 'unpublish_to_homepage', 'UnPublish to Homepage', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(117, 'en', 'view_contents', 'View Contents', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(118, 'en', 'delete', 'Delete', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(119, 'en', 'confirmation', 'Confirmation', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(120, 'en', 'are_you_sure_to_published_this_image', 'Are you sure to published this Image?', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(121, 'en', 'unpublished', 'UnPublished', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(122, 'en', 'published', 'Published', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(123, 'en', 'showing', 'Showing', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(124, 'en', 'of', 'of', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(125, 'en', 'results', 'results', '2025-04-21 16:44:47', '2025-04-21 16:44:47', NULL),
(126, 'en', 'subscriptions', 'Subscriptions', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(127, 'en', 'subscription_histories', 'Subscription Histories', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(128, 'en', 'payment_request', 'Payment Request', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(129, 'en', 'subscription_settings', 'Subscription Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(130, 'en', 'affiliate_system', 'Affiliate System', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(131, 'en', 'configurations', 'Configurations', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(132, 'en', 'manage_documents', 'Manage Documents', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(133, 'en', 'folders', 'Folders', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(134, 'en', 'all_projects', 'All Projects', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(135, 'en', 'ai_tools', 'AI Tools', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(136, 'en', 'ai_chat', 'AI Chat', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(137, 'en', 'ai_vision', 'AI Vision', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(138, 'en', 'ai_chat_image', 'AI Chat Image', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(139, 'en', 'ai_pdf_chat', 'AI PDF Chat', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(140, 'en', 'ai_rewriter', 'AI ReWriter', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(141, 'en', 'ai_blog_wizard', 'AI Blog Wizard', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(142, 'en', 'all_articles', 'All Articles', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(143, 'en', 'generate_full_article', 'Generate Full Article', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(144, 'en', 'custom_templates', 'Custom Templates', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(145, 'en', 'categories', 'Categories', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(146, 'en', 'all_templates', 'All Templates', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(147, 'en', 'ai_images', 'AI Images', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(148, 'en', 'dalle_2', 'Dall-E 2', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(149, 'en', 'dalle_3', 'Dall-E 3', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(150, 'en', 'stable_diffusion', 'Stable Diffusion', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(151, 'en', 'text_to_speech', 'Text To Speech', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(152, 'en', 'speech_to_text', 'Speech to Text', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(153, 'en', 'eleven_labs', 'Eleven Labs', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(154, 'en', 'ai_plagiarism', 'AI Plagiarism', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(155, 'en', 'ai_detector', 'AI Detector', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(156, 'en', 'ai_code', 'AI Code', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(157, 'en', 'popular_templates', 'Popular Templates', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(158, 'en', 'favorite_templates', 'Favorite Templates', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(159, 'en', 'reports', 'Reports', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(160, 'en', 'words_report', 'Words Report', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(161, 'en', 'codes_report', 'Codes Report', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(162, 'en', 'images_report', 'Images Report', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(163, 'en', 'speech_to_texts', 'Speech to Texts', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(164, 'en', 'most_used_templates', 'Most Used Templates', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(165, 'en', 'subscriptions_reports', 'Subscriptions Reports', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(166, 'en', 'manage_users', 'Manage Users', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(167, 'en', 'customers', 'Customers', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(168, 'en', 'employee_staffs', 'Employee Staffs', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(169, 'en', 'support', 'Support', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(170, 'en', 'queries', 'Queries', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(171, 'en', 'support_ticket', 'Support Ticket', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(172, 'en', 'category', 'Category', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(173, 'en', 'priority', 'Priority', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(174, 'en', 'tickets', 'Tickets', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(175, 'en', 'manage_contents', 'Manage Contents', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(176, 'en', 'tags', 'Tags', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(177, 'en', 'blogs', 'Blogs', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(178, 'en', 'all_blogs', 'All Blogs', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(179, 'en', 'pages', 'Pages', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(180, 'en', 'all_faqs', 'All FAQs', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(181, 'en', 'media_manager', 'Media Manager', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(182, 'en', 'manage_promotions', 'Manage Promotions', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(183, 'en', 'newsletters', 'Newsletters', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(184, 'en', 'bulk_emails', 'Bulk Emails', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(185, 'en', 'subscribers', 'Subscribers', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(186, 'en', 'manage_settings', 'Manage Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(187, 'en', 'ai_settings', 'AI Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(188, 'en', 'fine_tuning', 'Fine Tuning', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(189, 'en', 'plagiarism_api', 'Plagiarism API', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(190, 'en', 'update', 'Update', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(191, 'en', 'voice_settings', 'Voice Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(192, 'en', 'appearance', 'Appearance', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(193, 'en', 'homepage', 'Homepage', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(194, 'en', 'header', 'Header', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(195, 'en', 'footer', 'Footer', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(196, 'en', 'theme_settings', 'Theme Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(197, 'en', 'roles__permissions', 'Roles & Permissions', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(198, 'en', 'system_settings', 'System Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(199, 'en', 'general_settings', 'General Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(200, 'en', 'invoice_settings', 'Invoice Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(201, 'en', 'cron_job', 'Cron Job', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(202, 'en', 'google_ads', 'Google Ads', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(203, 'en', 'storage_manager', 'Storage Manager', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(204, 'en', 'auth_settings', 'Auth Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(205, 'en', 'otp_settings', 'OTP Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(206, 'en', 'smtp_settings', 'SMTP Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(207, 'en', 'pwa_settings', 'PWA Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(208, 'en', 'offline_payment', 'Offline Payment', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(209, 'en', 'payment_methods', 'Payment Methods', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(210, 'en', 'social_media_login', 'Social Media Login', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(211, 'en', 'multilingual_settings', 'Multilingual Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(212, 'en', 'multi_currency_settings', 'Multi Currency Settings', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(213, 'en', 'utilities', 'Utilities', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(214, 'en', 'file_permission', 'File Permission', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(215, 'en', 'logout', 'Logout', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(216, 'en', 'search', 'Search', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(217, 'en', 'no_notification_found', 'No Notification found', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(218, 'en', 'read_all', 'Read All', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(219, 'en', 'go_history', 'Go History', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(220, 'en', 'my_account', 'My Account', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(221, 'en', 'sign_out', 'Sign out', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(222, 'en', 'media_files', 'Media Files', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(223, 'en', 'recently_uploaded_files', 'Recently uploaded files', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(224, 'en', 'add_files_here', 'Add files here', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(225, 'en', 'previously_uploaded_files', 'Previously uploaded files', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(226, 'en', 'search_by_name', 'Search by name', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(227, 'en', 'load_more', 'Load More', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(228, 'en', 'select', 'Select', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(229, 'en', 'are_you_sure_to_delete_all_data', 'Are you sure to delete all data?', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(230, 'en', 'hidden_confirmation', 'Hidden Confirmation', '2025-04-21 16:44:48', '2025-04-21 16:44:48', NULL),
(231, 'en', 'are_you_sure_to_hide_this', 'Are you sure to hide this?', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(232, 'en', 'approve_confirmation', 'Approve Confirmation', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(233, 'en', 'are_you_sure_to_approve_this', 'Are you sure to Approve this?', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(234, 'en', 'reject_confirmation', 'Reject Confirmation', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(235, 'en', 'are_you_sure_to_reject_this', 'Are you sure to Reject this?', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(236, 'en', 'resubmit_confirmation', 'Re-Submit Confirmation', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(237, 'en', 'are_you_sure_to_resubmit_this', 'Are you sure to Re-Submit this?', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(238, 'en', 'no_data_found', 'No data found', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(239, 'en', 'selected_file', 'Selected File', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(240, 'en', 'selected_files', 'Selected Files', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(241, 'en', 'file_added', 'File added', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(242, 'en', 'files_added', 'Files added', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(243, 'en', 'no_file_chosen', 'No file chosen', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(244, 'en', 'generate_code', 'Generate Code', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(245, 'en', 'generate_image', 'Generate Image', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(246, 'en', 'move_to_folder', 'Move To Folder', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(247, 'en', 'move_project', 'Move Project', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(248, 'en', 'save_changes', 'Save Changes', '2025-04-21 16:44:49', '2025-04-21 16:44:49', NULL),
(249, 'en', 'favorite', 'Favorite', '2025-04-21 16:44:58', '2025-04-21 16:44:58', NULL),
(250, 'en', 'edit', 'Edit', '2025-04-21 16:44:58', '2025-04-21 16:44:58', NULL),
(251, 'en', 'chat_with_us', 'Chat with Us', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(252, 'en', 'get_connected_to_us_we_are_happy_to_hear_from_you', 'Get connected to us, we are happy to hear from you.', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(253, 'en', 'email_us', 'Email Us', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(254, 'en', 'drop_us_an_email_and_youll_receive_a_reply_within_a_short_time', 'Drop us an email and you\'ll receive a reply within a short time.', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(255, 'en', 'give_us_a_call', 'Give us a call', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(256, 'en', 'give_us_a_call_our_experts_are_ready_to_talk_to_you', 'Give us a call. Our Experts are ready to talk to you.', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(257, 'en', 'talk_to_our_team', 'Talk to Our Team', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(258, 'en', 'write_to_us_we_are_happy_to_assist_you_about_your_queries', 'Write to us, we are happy to assist you about your queries.', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(259, 'en', 'name', 'Name', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(260, 'en', 'your_name', 'Your name', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(261, 'en', 'your_email', 'Your email', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(262, 'en', 'your_phone', 'Your phone', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(263, 'en', 'messages', 'Messages', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(264, 'en', 'write_your_message', 'Write your message', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(265, 'en', 'get_in_touch', 'Get in Touch', '2025-04-21 16:45:16', '2025-04-21 16:45:16', NULL),
(266, 'en', 'ai_chat_experts', 'AI Chat Experts', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(267, 'en', 'add_chat_prompts', 'Add Chat Prompts', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(268, 'en', 'add_chat_expert', 'Add Chat Expert', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(269, 'en', 'search_expertise_you_are_looking_for', 'Search expertise you are looking for', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(270, 'en', 'search_experts', 'Search Experts', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(271, 'en', 'articale_generation_has_been_stopped', 'Articale generation has been stopped.', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(272, 'en', 'message_has_been_copied_successfully', 'Message has been copied successfully', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(273, 'en', 'chat_has_been_copied_successfully', 'Chat has been copied successfully', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(274, 'en', 'status_updated_successfully', 'Status updated successfully', '2025-04-21 16:47:35', '2025-04-21 16:47:35', NULL),
(275, 'en', 'ai_writer', 'AI Writer', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(276, 'en', 'open_ai_key_not_foundplease_setup_open_ai_key_from_ai_setting', 'Open Ai key not found.Please setup open ai key from Ai setting', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(277, 'en', 'select_input__output_language', 'Select input & output language', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(278, 'en', 'input_your_content_', 'Input your content ', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(279, 'en', 'type_here', 'Type here', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(280, 'en', 'advance_options', 'Advance Options', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(281, 'en', 'browse_more_fields', 'Browse more fields', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(282, 'en', 'max_results_length', 'Max Results Length', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(283, 'en', 'maximum_words_for_each_result', 'Maximum words for each result', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(284, 'en', 'enter_maximum_word_limit', 'Enter maximum word limit', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(285, 'en', 'creative_label', 'Creative Label', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(286, 'en', 'creativity_level_of_the_output_will_be_as_selected', 'Creativity level of the output will be as selected', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(287, 'en', 'high', 'High', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(288, 'en', 'medium', 'Medium', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(289, 'en', 'low', 'Low', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(290, 'en', 'choose_a_tone', 'Choose a Tone', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(291, 'en', 'choose_the_tone_of_the_result_text_as_you_need', 'Choose the tone of the result text as you need', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(292, 'en', 'friendly', 'Friendly', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(293, 'en', 'luxury', 'Luxury', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(294, 'en', 'relaxed', 'Relaxed', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(295, 'en', 'professional', 'Professional', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(296, 'en', 'casual', 'Casual', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(297, 'en', 'excited', 'Excited', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(298, 'en', 'bold', 'Bold', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(299, 'en', 'masculine', 'Masculine', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(300, 'en', 'dramatic', 'Dramatic', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(301, 'en', 'stop_generation', 'Stop Generation', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(302, 'en', 'your_project_title', 'Your project title', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(303, 'en', 'generate_successfully_dont_forget_to_save', 'Generate Successfully, dont forget to save', '2025-04-21 16:47:49', '2025-04-21 16:47:49', NULL),
(304, 'en', 'default_creativity_level', 'Default Creativity Level', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(305, 'en', 'default_tone_of_output_result', 'Default Tone Of Output Result', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(306, 'en', 'default_number_of_results', 'Default Number Of Results', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(307, 'en', 'default_max_result_length', 'Default Max Result Length', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(308, 'en', 'insert_1_to_make_it_unlimited', 'Insert -1 to make it unlimited', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(309, 'en', 'default_max_result_length_blog_wizard', 'Default Max Result Length Blog Wizard', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(310, 'en', 'insert_0_to_make_it_unlimited', 'Insert 0 to make it unlimited', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(311, 'en', 'bad_words', 'Bad Words', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(312, 'en', 'these_words_will_be_filtered_from_user_inputs_while_generating_contents', 'These words will be filtered from user inputs while generating contents', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(313, 'en', 'comma_separated_one_two', 'Comma Separated: One, Two', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(314, 'en', 'feature_activation', 'Feature Activation', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(315, 'en', 'built_in_templates', 'Built In Templates', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(316, 'en', 'elevenlabs', 'ElevenLabs', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(317, 'en', 'generate_images', 'Generate Images', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(318, 'en', 'generate_images_step_ai_blog_wizard', 'Generate Images Step AI Blog Wizard', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(319, 'en', 'ai_image_chat_model', 'AI Image Chat Model', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(320, 'en', 'set_speech_to_text_status', 'Set speech to text status', '2025-04-21 16:48:43', '2025-04-21 16:48:43', NULL),
(321, 'en', 'generate_images_ai_blog_wizard', 'Generate Images AI Blog Wizard', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(322, 'en', 'open_ai_model', 'Open AI Model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(323, 'en', 'default_ai_model', 'Default AI Model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(324, 'en', 'ai_blog_wizard_model', 'AI Blog Wizard Model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(325, 'en', 'ai_chat_model', 'AI Chat Model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(326, 'en', 'max_token_for_model', 'Max token for Model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(327, 'en', 'check_supported_max_token_with_openai', 'Check Supported Max Token With OpenAI', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(328, 'en', 'open_ai_secret_key', 'Open AI Secret Key', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(329, 'en', 'create_multipe_api_key', 'Create Multipe API Key', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(330, 'en', 'if_you_are_not_getting_any_response_please_recheck_your_api_balance_and_model', 'If you are not getting any response please re-check your api balance and model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(331, 'en', 'openai_api_key_usage_model', 'Openai API Key Usage Model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(332, 'en', 'main_api_key', 'Main Api key', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(333, 'en', 'random_api_key', 'Random Api Key', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(334, 'en', 'when_you_choose_random_api_sometimes_not_get_any_response_if_api_balance_empty_or_mismatch_model', 'when you choose random api sometimes not get any response if api balance empty or mis-match model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(335, 'en', 'stable_diffusion_api_key', 'Stable Diffusion Api Key', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(336, 'en', 'stable_diffusion_key_usage_model', 'Stable Diffusion Key Usage Model', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(337, 'en', 'stable_diffusion_engine_id', 'Stable Diffusion Engine ID', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(338, 'en', 'stable_diffusion_v16', 'Stable Diffusion v1.6', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(339, 'en', 'stable_diffusion_v21', 'Stable Diffusion v2.1', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(340, 'en', 'stable_diffusion_v21768', 'Stable Diffusion v2.1-768', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(341, 'en', 'stable_diffusion_v222xl_beta', 'Stable Diffusion v2.2.2-XL Beta', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(342, 'en', 'sdxl_v10', 'SDXL v1.0', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(343, 'en', 'sdxl_v09', 'SDXL v0.9', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(344, 'en', 'image_upscaler_engine', 'Image Upscaler Engine', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(345, 'en', 'serper_api_key_for_real_time_data', 'Serper Api key for real time data', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(346, 'en', 'save_configuration', 'Save Configuration', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(347, 'en', 'configure_settings', 'Configure Settings', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(348, 'en', 'general_information', 'General Information', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(349, 'en', 'serper_api_key', 'Serper API Key', '2025-04-21 16:48:44', '2025-04-21 16:48:44', NULL),
(350, 'en', 'general_informations', 'General Informations', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(351, 'en', 'system_title', 'System Title', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(352, 'en', 'browser_tab_title_separator', 'Browser Tab Title Separator', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(353, 'en', 'contact_email', 'Contact Email', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(354, 'en', 'contact_phone', 'Contact Phone', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(355, 'en', 'enable_preloader', 'Enable Preloader', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(356, 'en', 'set_preloader_status', 'Set preloader status', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(357, 'en', 'enable', 'Enable', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(358, 'en', 'disable', 'Disable', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(359, 'en', 'dashboard_logo__favicon', 'Dashboard Logo & Favicon', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(360, 'en', 'dashboard_logo_for_light_version', 'Dashboard logo for light version', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(361, 'en', 'choose_dark_logo', 'Choose Dark Logo', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(362, 'en', 'dashboard_logo_for_dark_version', 'Dashboard logo for dark version', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(363, 'en', 'choose_light_logo', 'Choose Light Logo', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(364, 'en', 'favicon', 'Favicon', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(365, 'en', 'choose_favicon', 'Choose Favicon', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(366, 'en', 'maintenance_mode', 'Maintenance Mode', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(367, 'en', 'enable_maintenance_mode', 'Enable Maintenance Mode', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(368, 'en', 'set_maintenance_mode', 'Set maintenance mode', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(369, 'en', 'frontendlanding_page', 'Frontend/Landing Page', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(370, 'en', 'frontend_status', 'Frontend Status', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(371, 'en', 'if_disable_only_login_registration_page_show_other_all_frontend_page_not_visiable', 'if disable only login, registration page show other all frontend page not visiable', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(372, 'en', 'seo_meta_configuration', 'SEO Meta Configuration', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(373, 'en', 'meta_title', 'Meta Title', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(374, 'en', 'type_meta_title', 'Type meta title', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(375, 'en', 'set_a_meta_tag_title_recommended_to_be_simple_and_unique', 'Set a meta tag title. Recommended to be simple and unique.', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(376, 'en', 'meta_description', 'Meta Description', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(377, 'en', 'type_your_meta_description', 'Type your meta description', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(378, 'en', 'meta_keywords', 'Meta Keywords', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(379, 'en', 'meta_image', 'Meta Image', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(380, 'en', 'choose_meta_image', 'Choose Meta Image', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(381, 'en', 'cookie_consent', 'Cookie Consent', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(382, 'en', 'show_cookie_consent', 'Show Cookie Consent', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(383, 'en', 'select_an_option', 'Select an option', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(384, 'en', 'cookie_consent_text', 'Cookie Consent Text', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(385, 'en', 'custom_scripts', 'Custom Scripts', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(386, 'en', 'header_custom_script__before_head', 'Header custom script - before </head>', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(387, 'en', 'copy_or_write_your_custom_script_here', 'Copy or write your custom script here', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(388, 'en', 'footer_custom_script__before_body', 'Footer custom script - before </body>', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(389, 'en', 'custom_css', 'Custom Css', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(390, 'en', 'custom_css__before_head', 'Custom css - before </head>', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(391, 'en', 'copy_or_write_your_custom_css_here', 'Copy or write your custom css here', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(392, 'en', 'google_analytics', 'Google Analytics', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(393, 'en', 'enable_google_analytics', 'Enable Google Analytics', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(394, 'en', 'tracking_id', 'Tracking ID', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(395, 'en', 'google_adsense', 'Google ADSENSE', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(396, 'en', 'adsense_code_snippet', 'AdSense code snippet', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(397, 'en', 'google_adsense_status', 'Google ADSENSE Status', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(398, 'en', 'enable_google_adsense', 'Enable Google ADSENSE', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(399, 'en', 'balance_carry_forward_', 'Balance Carry Forward: ', '2025-04-21 17:18:39', '2025-04-21 17:18:39', NULL),
(400, 'en', 'remaining_balance_from_active_packageonly_for_active_will_be_added_to_next_package_balance', 'Remaining balance from active package(only for active) will be added to next package balance.', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(401, 'en', 'this_service_is_applicable_for_same_package__lifetime_to_lifetime_yearly_to_yearly_monthly_to_monthly_and_prepaid_to_prepaid_pacakge', 'This service is applicable for same package - Lifetime to Lifetime, Yearly to Yearly, Monthly to Monthly and Prepaid to Prepaid pacakge.', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(402, 'en', 'scroll_bar_icon', 'Scroll Bar Icon', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(403, 'en', 'choose_scroll_bar_icon', 'Choose Scroll Bar Icon', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(404, 'en', 'configure_general_settings', 'Configure General Settings', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(405, 'en', 'dashborad_logo__favicon', 'Dashborad Logo & Favicon', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(406, 'en', 'frontend_settings', 'Frontend Settings', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(407, 'en', 'seo_configuration', 'SEO Configuration', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(408, 'en', 'saved_successfully', 'Saved Successfully', '2025-04-21 17:18:40', '2025-04-21 17:18:40', NULL),
(409, 'en', 'login__registration', 'Login & Registration', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(410, 'en', 'customer_registration', 'Customer Registration', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(411, 'en', 'email_required', 'Email Required', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(412, 'en', 'email__phone_both_required', 'Email & Phone Both Required', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(413, 'en', 'registration_verification', 'Registration Verification', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(414, 'en', 'email_verification', 'Email Verification', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(415, 'en', 'otp_verification', 'OTP Verification', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(416, 'en', 'send_welcome_email_after_registration', 'Send Welcome Email After Registration', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(417, 'en', 'leftbar_title', 'Leftbar Title', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(418, 'en', 'leftbar_colored_title', 'Leftbar Colored Title', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(419, 'en', 'rightbar_title', 'Rightbar Title', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(420, 'en', 'rightbar_subtitle', 'Rightbar Subtitle', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(421, 'en', 'google_recaptcha_v3', 'Google Recaptcha V3', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(422, 'en', 'recaptcha_site_key', 'Recaptcha Site Key', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(423, 'en', 'recaptcha_secret_key', 'Recaptcha Secret Key', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(424, 'en', 'enable_recaptcha', 'Enable Recaptcha', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(425, 'en', 'google_recaptcha', 'Google Recaptcha', '2025-04-21 17:19:26', '2025-04-21 17:19:26', NULL),
(426, 'en', 'open_ai_settings_update_successfully', 'Open Ai settings update successfully', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(427, 'en', 'supported_model', 'Supported Model', '2025-04-21 17:20:13', '2025-04-21 17:20:13', NULL),
(428, 'en', 'ai_keys', 'AI Keys', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(429, 'en', 'check_api_key_health', 'Check API Key Health', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(430, 'en', 'add_new', 'Add New', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(431, 'en', 'select_status', 'Select status', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(432, 'en', 'active', 'Active', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(433, 'en', 'deactive', 'DeActive', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(434, 'en', 'engine', 'Engine', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(435, 'en', 'api_key', 'Api Key', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(436, 'en', 'status', 'Status', '2025-04-21 17:21:24', '2025-04-21 17:21:24', NULL),
(437, 'en', 'add_api_key', 'Add API Key', '2025-04-21 17:21:31', '2025-04-21 17:21:31', NULL),
(438, 'en', 'api_keys', 'API Keys', '2025-04-21 17:21:31', '2025-04-21 17:21:31', NULL),
(439, 'en', 'api_key_list', 'Api Key List', '2025-04-21 17:21:31', '2025-04-21 17:21:31', NULL),
(440, 'en', 'ai_engine', 'AI Engine', '2025-04-21 17:21:31', '2025-04-21 17:21:31', NULL),
(441, 'en', 'save', 'Save', '2025-04-21 17:21:31', '2025-04-21 17:21:31', NULL),
(442, 'en', 'api_key_has_been_inserted_successfully', 'API Key has been inserted successfully', '2025-04-21 17:21:38', '2025-04-21 17:21:38', NULL),
(443, 'en', 'view', 'View', '2025-04-21 17:21:39', '2025-04-21 17:21:39', NULL),
(444, 'en', 'your_selected_model_not_supported_in_your_open_ai_key', 'Your Selected Model Not Supported in Your Open Ai Key', '2025-04-21 17:35:53', '2025-04-21 17:35:53', NULL),
(445, 'en', 'type_title', 'Type Title', '2025-04-21 17:37:31', '2025-04-21 17:37:31', NULL),
(446, 'en', 'type_code_title', 'Type code title', '2025-04-21 17:37:31', '2025-04-21 17:37:31', NULL),
(447, 'en', 'type_description', 'Type Description', '2025-04-21 17:37:31', '2025-04-21 17:37:31', NULL),
(448, 'en', 'generate_a_javascript_function_to_add_2_numbers_and_return_their_sum', 'Generate a javascript function to add 2 numbers and return their sum', '2025-04-21 17:37:31', '2025-04-21 17:37:31', NULL),
(449, 'en', 'copy_code', 'Copy Code', '2025-04-21 17:37:31', '2025-04-21 17:37:31', NULL),
(450, 'en', 'your_code_will_appear_here', 'Your code will appear here', '2025-04-21 17:37:31', '2025-04-21 17:37:31', NULL),
(451, 'en', 'chat_prompts', 'Chat Prompts', '2025-04-21 17:37:55', '2025-04-21 17:37:55', NULL),
(452, 'en', 'browse_experts', 'Browse Experts', '2025-04-21 17:37:55', '2025-04-21 17:37:55', NULL),
(453, 'en', 'show_history', 'Show History', '2025-04-21 17:37:55', '2025-04-21 17:37:55', NULL),
(454, 'en', 'type__hit_enter', 'Type & hit enter', '2025-04-21 17:37:55', '2025-04-21 17:37:55', NULL),
(455, 'en', 'no_conversation_found', 'No conversation found', '2025-04-21 17:37:55', '2025-04-21 17:37:55', NULL),
(456, 'en', 'new_conversation', 'New Conversation', '2025-04-21 17:37:55', '2025-04-21 17:37:55', NULL),
(457, 'en', 'open_a_new_conversation_to_chat_with_ai', 'Open a new conversation to chat with Ai', '2025-04-21 17:37:55', '2025-04-21 17:37:55', NULL),
(458, 'en', '_chat', ' Chat', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(459, 'en', 'hello_i_am_william_wood_and_im_uiux_designer_i_will_help_you_designing__creating_user_experiences_for_your_website__applications', 'Hello! I am William Wood, and I\'m UI/UX Designer. I will help you designing & creating user experiences for your website & applications.', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(460, 'en', 'realtime_data', 'Real-Time Data', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(461, 'en', 'send_chat_to_email', 'Send Chat to Email', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL);
INSERT INTO `localizations` (`id`, `lang_key`, `t_key`, `t_value`, `created_at`, `updated_at`, `deleted_at`) VALUES
(462, 'en', 'type_email', 'Type Email', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(463, 'en', 'type_an_email', 'Type an email', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(464, 'en', 'send', 'Send', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(465, 'en', 'pdf', 'PDF', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(466, 'en', 'html', 'HTML', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(467, 'en', 'ms_word', 'MS Word', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(468, 'en', 'type_your_message', 'Type your message', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(469, 'en', 'prompt_library', 'Prompt Library', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(470, 'en', 'stop', 'Stop', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(471, 'en', 'predefined_prompts_library', 'Predefined Prompts Library', '2025-04-21 17:38:02', '2025-04-21 17:38:02', NULL),
(472, 'en', 'ai_chat_prompts', 'AI Chat Prompts', '2025-04-21 17:41:08', '2025-04-21 17:41:08', NULL),
(473, 'en', 'add_prompt_group', 'Add Prompt Group', '2025-04-21 17:41:08', '2025-04-21 17:41:08', NULL),
(474, 'en', 'search_prompt_that_you_are_looking_for', 'Search prompt that you are looking for', '2025-04-21 17:41:08', '2025-04-21 17:41:08', NULL),
(475, 'en', 'search_now', 'Search Now', '2025-04-21 17:41:08', '2025-04-21 17:41:08', NULL),
(476, 'en', 'all_prompts', 'All Prompts', '2025-04-21 17:41:08', '2025-04-21 17:41:08', NULL),
(477, 'en', 'group_name', 'Group Name', '2025-04-21 17:41:08', '2025-04-21 17:41:08', NULL),
(478, 'en', 'type_group_name', 'Type group name', '2025-04-21 17:41:08', '2025-04-21 17:41:08', NULL),
(479, 'en', 'save_group', 'Save Group', '2025-04-21 17:41:08', '2025-04-21 17:41:08', NULL),
(480, 'en', 'add_new_prompt', 'Add New Prompt', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(481, 'en', 'prompts', 'Prompts', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(482, 'en', 'add_prompt', 'Add Prompt', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(483, 'en', 'basic_information', 'Basic Information', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(484, 'en', 'prompt_title', 'Prompt Title', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(485, 'en', 'type_prompt_title', 'Type prompt title', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(486, 'en', 'group', 'Group', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(487, 'en', 'select_a_group', 'Select a group', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(488, 'en', 'prompt', 'Prompt', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(489, 'en', 'generate_test_prompt', 'Generate Test Prompt', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(490, 'en', 'write_a_blog_about_blog_title', 'Write a blog about [blog title]', '2025-04-21 17:41:26', '2025-04-21 17:41:26', NULL),
(491, 'en', 'put_your_variables_inside_third_bracket_write_a_blog_about_blog_title', 'Put your variables inside third bracket: Write a blog about [blog title]', '2025-04-21 17:41:27', '2025-04-21 17:41:27', NULL),
(492, 'en', 'save_prompt', 'Save Prompt', '2025-04-21 17:41:27', '2025-04-21 17:41:27', NULL),
(493, 'en', 'prompt_information', 'Prompt Information', '2025-04-21 17:41:27', '2025-04-21 17:41:27', NULL),
(494, 'en', 'hello_i_am_mr_kevin_and_im_seo_expert_i_will_assist_you_to_generate_better_the_seo_contents', 'Hello! I am Mr Kevin, and I\'m SEO Expert. I will assist you to generate better the seo contents.', '2025-04-21 17:42:08', '2025-04-21 17:42:08', NULL),
(495, 'en', 'hello_i_am_carl_oakes_and_im_fitness_trainer_i_will_help_you_to_keep_yourself_healthy__fit', 'Hello! I am Carl Oakes, and I\'m Fitness Trainer. I will help you to keep yourself healthy & fit.', '2025-04-21 17:44:16', '2025-04-21 17:44:16', NULL),
(496, 'en', 'new_blog_article', 'New Blog Article', '2025-04-21 17:44:34', '2025-04-21 17:44:34', NULL),
(497, 'en', 'add_new_blog_article', 'Add New Blog Article', '2025-04-21 17:44:34', '2025-04-21 17:44:34', NULL),
(498, 'en', 'reset_data', 'Reset Data', '2025-04-21 17:44:34', '2025-04-21 17:44:34', NULL),
(499, 'en', 'keywords', 'Keywords', '2025-04-21 17:44:34', '2025-04-21 17:44:34', NULL),
(500, 'en', 'title', 'Title', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(501, 'en', 'outline', 'Outline', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(502, 'en', 'article', 'Article', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(503, 'en', 'topic', 'Topic', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(504, 'en', 'type_your_topic', 'Type your topic', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(505, 'en', 'number_of_keywords', 'Number of Keywords', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(506, 'en', 'type_the_number_of_keywords_you_want_to_generate', 'Type the number of keywords you want to generate', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(507, 'en', 'choose_a_language', 'Choose a language', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(508, 'en', 'generate_keywords', 'Generate Keywords', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(509, 'en', 'or', 'Or', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(510, 'en', 'already_have_keywords_enter_your_keywords_and_skip_this_step', 'Already have keywords? Enter your keywords and skip this step.', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(511, 'en', 'type_your_keywords', 'Type your keywords', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(512, 'en', 'next_step', 'Next Step', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(513, 'en', 'number_of_titles', 'Number of Titles', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(514, 'en', 'generate_titles', 'Generate Titles', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(515, 'en', 'type_your_title', 'Type your title', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(516, 'en', 'image_style', 'Image Style', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(517, 'en', 'style_of_the_image_will_be_as_selected', 'Style of the image will be as selected', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(518, 'en', 'none', 'None', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(519, 'en', 'abstract', 'Abstract', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(520, 'en', 'realstic', 'Realstic', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(521, 'en', 'cartoon', 'Cartoon', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(522, 'en', 'digital_art', 'Digital Art', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(523, 'en', 'illustration', 'Illustration', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(524, 'en', 'photography', 'Photography', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(525, 'en', '3d_render', '3D Render', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(526, 'en', 'pencil_drawing', 'Pencil Drawing', '2025-04-21 17:44:35', '2025-04-21 17:44:35', NULL),
(527, 'en', 'mood', 'Mood', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(528, 'en', 'mood_of_the_image_will_be_as_selected', 'Mood of the image will be as selected', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(529, 'en', 'angry', 'Angry', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(530, 'en', 'agressive', 'Agressive', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(531, 'en', 'calm', 'Calm', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(532, 'en', 'cheerful', 'Cheerful', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(533, 'en', 'chilling', 'Chilling', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(534, 'en', 'dark', 'Dark', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(535, 'en', 'happy', 'Happy', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(536, 'en', 'sad', 'Sad', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(537, 'en', 'resolution', 'Resolution', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(538, 'en', 'select_image_resolution_size_that_you_need', 'Select image resolution size that you need', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(539, 'en', 'medium_512x512', 'Medium [512x512]', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(540, 'en', 'large_1024x1024', 'Large [1024x1024]', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(541, 'en', 'number_of_results', 'Number of Results', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(542, 'en', 'select_how_many_variations_of_result_you_want', 'Select how many variations of result you want', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(543, 'en', 'skip_this_step', 'Skip this step', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(544, 'en', 'generate_outlines', 'Generate Outlines', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(545, 'en', 'outlines', 'Outlines', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(546, 'en', 'max_word_of_blog_article', 'Max Word of Blog Article', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(547, 'en', 'generate_article', 'Generate Article', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(548, 'en', 'generated_keywords', 'Generated Keywords', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(549, 'en', 'your_generated_keywords_will_be_listed_here', 'Your generated keywords will be listed here', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(550, 'en', 'all_keywords_are_generated_based_on_your_topic', 'All keywords are generated based on your topic', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(551, 'en', 'generated_titles', 'Generated Titles', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(552, 'en', 'your_generated_titles_will_be_listed_here', 'Your generated titles will be listed here', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(553, 'en', 'generated_images', 'Generated Images', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(554, 'en', 'your_generated_images_will_be_listed_here', 'Your generated images will be listed here', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(555, 'en', 'generated_outlines', 'Generated Outlines', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(556, 'en', 'your_generated_outlines_will_be_listed_here', 'Your generated outlines will be listed here', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(557, 'en', 'your_generated_article_will_be_shown_here', 'Your generated article will be shown here', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(558, 'en', 'next', 'Next', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(559, 'en', 'blog_updated_successfully', 'Blog updated successfully', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(560, 'en', 'blog_has_been_copied_successfully', 'Blog has been copied successfully', '2025-04-21 17:44:36', '2025-04-21 17:44:36', NULL),
(561, 'en', 'words_in_this_title', 'Words in this title', '2025-04-21 17:45:13', '2025-04-21 17:45:13', NULL),
(562, 'en', 'sections_in_this_block', 'Sections in this block', '2025-04-21 17:47:18', '2025-04-21 17:47:18', NULL),
(563, 'en', 'please_remove_these_words_from_your_inputs', 'Please remove these words from your inputs', '2025-04-21 17:48:24', '2025-04-21 17:48:24', NULL),
(564, 'en', 'generate_stable_diffusion_images', 'Generate Stable Diffusion Images', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(565, 'en', 'stable_diffusion_images', 'Stable Diffusion Images', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(566, 'en', 'text_to_image', 'Text to Image', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(567, 'en', 'image_to_image', 'Image to Image', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(568, 'en', 'upscale', 'Upscale', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(569, 'en', 'multi_prompting', 'Multi Prompting', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(570, 'en', 'choose_style_mood_resolution_number_of_results', 'Choose style, mood, resolution, number of results', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(571, 'en', '3d_model', '3D Model', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(572, 'en', 'analog_film', 'Analog Film', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(573, 'en', 'anime', 'Anime', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(574, 'en', 'cinematic', 'Cinematic', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(575, 'en', 'comic_book', 'Comic Book', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(576, 'en', 'enhance', 'Enhance', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(577, 'en', 'fantasy_art', 'Fantasy Art', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(578, 'en', 'isometric', 'Isometric', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(579, 'en', 'line_art', 'Line Art', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(580, 'en', 'low_poly', 'Low Poly', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(581, 'en', 'modeling_compound', 'Modeling Compound', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(582, 'en', 'neon_punk', 'Neon Punk', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(583, 'en', 'origami', 'Origami', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(584, 'en', 'photographic', 'Photographic', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(585, 'en', 'pixel_art', 'Pixel Art', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(586, 'en', 'tile_texture', 'Tile Texture', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(587, 'en', 'image_diffusion_samples', 'Image Diffusion Samples', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(588, 'en', 'auto', 'Auto', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(589, 'en', 'ddim', 'DDIM', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(590, 'en', 'ddpm', 'DDPM', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(591, 'en', 'k_dpmpp_2m', 'K_DPMPP_2M', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(592, 'en', 'k_dpmpp_2s_ancestral', 'K_DPMPP_2S_ANCESTRAL', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(593, 'en', 'k_dpm_2', 'K_DPM_2', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(594, 'en', 'k_dpm_2_ancestral', 'K_DPM_2_ANCESTRAL', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(595, 'en', 'k_euler', 'K_EULER', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(596, 'en', 'k_euler_ancestral', 'K_EULER_ANCESTRAL', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(597, 'en', 'k_heun', 'K_HEUN', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(598, 'en', 'k_lms', 'K_LMS', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(599, 'en', 'clip_guidance_preset', 'Clip Guidance Preset', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(600, 'en', 'fast_blue', 'FAST_BLUE', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(601, 'en', 'fast_green', 'FAST_GREEN', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(602, 'en', 'simple', 'SIMPLE', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(603, 'en', 'slow', 'SLOW', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(604, 'en', 'slower', 'SLOWER', '2025-04-21 17:55:00', '2025-04-21 17:55:00', NULL),
(605, 'en', 'slowest', 'SLOWEST', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(606, 'en', 'image_resolution', 'Image Resolution', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(607, 'en', 'width', 'Width', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(608, 'en', 'height', 'Height', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(609, 'en', 'negative_prompts', 'Negative Prompts', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(610, 'en', 'type_negative_prompts', 'Type negative prompts', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(611, 'en', 'type_your_image_title_or_description_that_you_are_looking_for', 'Type your image title or description that you are looking for', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(612, 'en', 'image_title_or_description', 'Image Title or Description', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(613, 'en', 'upload_image', 'Upload Image', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(614, 'en', 'drop_your_image_here_or_browse', 'Drop your image here or browse', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(615, 'en', 'only_jpg_png_webp_will_be_accepted', '(Only jpg, png, webp will be accepted)', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(616, 'en', 'image_title', 'Image Title', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(617, 'en', 'type_your_image_title', 'Type your image title', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(618, 'en', 'type_another_title_or_description', 'Type another title or description', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(619, 'en', 'add_more', 'Add More', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(620, 'en', 'generated_image_result', 'Generated Image Result', '2025-04-21 17:55:01', '2025-04-21 17:55:01', NULL),
(621, 'en', 'size', 'Size', '2025-04-21 17:55:20', '2025-04-21 17:55:20', NULL),
(622, 'en', 'not_found_plagiarism_active_key', 'not found plagiarism active key.', '2025-04-21 17:56:45', '2025-04-21 17:56:45', NULL),
(623, 'en', 'scan_content', 'Scan Content', '2025-04-21 17:56:45', '2025-04-21 17:56:45', NULL),
(624, 'en', 'matching_content_site', 'Matching Content site', '2025-04-21 17:56:45', '2025-04-21 17:56:45', NULL),
(625, 'en', 'ai_content_plagiarism', 'AI Content plagiarism', '2025-04-21 17:56:51', '2025-04-21 17:56:51', NULL),
(626, 'en', 'the_text_to_scan_minimum_300_characters_texts_under_600_characters_may_produce_unreliable_results_and_should_be_avoided_maximum_100_000_characters_per_request', 'The text to scan. Minimum 300 characters. Texts under 600 characters may produce unreliable results and should be avoided. Maximum 100 000 characters per request', '2025-04-21 17:56:51', '2025-04-21 17:56:51', NULL),
(627, 'en', 'total_word', 'Total word', '2025-04-21 17:56:51', '2025-04-21 17:56:51', NULL),
(628, 'en', 'scan_report', 'Scan Report', '2025-04-21 17:56:51', '2025-04-21 17:56:51', NULL),
(629, 'en', 'human_writing', 'Human Writing', '2025-04-21 17:56:51', '2025-04-21 17:56:51', NULL),
(630, 'en', 'ai_writing', 'AI Writing', '2025-04-21 17:56:51', '2025-04-21 17:56:51', NULL),
(631, 'en', 'plagiarisms', 'Plagiarisms', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(632, 'en', 'all_plagiarisms_api', 'All Plagiarisms API', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(633, 'en', 'plagiarisms_api', 'Plagiarisms API', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(634, 'en', 'key', 'Key', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(635, 'en', 'add_new_plagiarism_info', 'Add New Plagiarism Info', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(636, 'en', 'plagiarism_key', 'Plagiarism key', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(637, 'en', 'collect_api', 'Collect API', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(638, 'en', 'type_folder_key', 'Type folder key', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(639, 'en', 'save_plagiarism', 'Save Plagiarism', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(640, 'en', 'plagiarism_information', 'Plagiarism Information', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(641, 'en', 'all_plagiarisms', 'All Plagiarisms', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(642, 'en', 'add_new_plagiarism', 'Add New Plagiarism', '2025-04-21 17:57:15', '2025-04-21 17:57:15', NULL),
(643, 'en', 'operation_successfully', 'Operation Successfully', '2025-04-21 17:58:12', '2025-04-21 17:58:12', NULL),
(644, 'en', 'total_number_of_matching_websites_found_by_the_plagiarism_api', 'total number of matching websites found by the Plagiarism API', '2025-04-21 17:58:38', '2025-04-21 17:58:38', NULL),
(645, 'en', 'ai_content_detection', 'AI Content Detection', '2025-04-21 18:02:05', '2025-04-21 18:02:05', NULL),
(646, 'en', 'human_score', 'Human Score', '2025-04-21 18:02:05', '2025-04-21 18:02:05', NULL),
(647, 'en', 'ai_score', 'AI Score', '2025-04-21 18:02:05', '2025-04-21 18:02:05', NULL),
(648, 'en', 'scan_text', 'Scan Text', '2025-04-21 18:02:11', '2025-04-21 18:02:11', NULL),
(649, 'en', 'homen_writing', 'Homen Writing', '2025-04-21 18:02:28', '2025-04-21 18:02:28', NULL),
(650, 'en', 'publish_to_homepage', 'Publish to Homepage', '2025-04-21 18:06:48', '2025-04-21 18:06:48', NULL),
(651, 'en', 'full_name', 'Full Name', '2025-04-21 18:24:25', '2025-04-21 18:24:25', NULL),
(652, 'en', 'type_full_name', 'Type full name', '2025-04-21 18:24:25', '2025-04-21 18:24:25', NULL),
(653, 'en', 'type_your_email', 'Type your email', '2025-04-21 18:24:25', '2025-04-21 18:24:25', NULL),
(654, 'en', '880xxxxxxxxxx', '+880xxxxxxxxxx', '2025-04-21 18:24:25', '2025-04-21 18:24:25', NULL),
(655, 'en', 'confirm_password', 'Confirm Password', '2025-04-21 18:24:25', '2025-04-21 18:24:25', NULL),
(656, 'en', 'already_have_an_account', 'Already have an Account?', '2025-04-21 18:24:25', '2025-04-21 18:24:25', NULL),
(657, 'en', 'google_recaptcha_is_required', 'Google recaptcha is required', '2025-04-21 18:25:29', '2025-04-21 18:25:29', NULL),
(658, 'en', 'registration_successful', 'Registration successful.', '2025-04-21 18:25:29', '2025-04-21 18:25:29', NULL),
(659, 'en', 'histories', 'Histories', '2025-04-21 18:25:30', '2025-04-21 18:25:30', NULL),
(660, 'en', 'profile', 'Profile', '2025-04-21 18:25:30', '2025-04-21 18:25:30', NULL),
(661, 'en', 'create_ticket', 'Create Ticket', '2025-04-21 18:25:30', '2025-04-21 18:25:30', NULL),
(662, 'en', 'no_active_subscription', 'No active Subscription', '2025-04-21 18:25:30', '2025-04-21 18:25:30', NULL),
(663, 'en', 'free', 'Free', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(664, 'en', 'applied_on_registration', 'Applied on Registration', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(665, 'en', 'ai_templates', 'AI Templates', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(666, 'en', 'words_per_month', 'Words per month', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(667, 'en', 'images_per_month', 'Images per month', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(668, 'en', 'speech_to_text_per_month', 'Speech to Text per month', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(669, 'en', 'audio_file_size_limit', 'Audio file size limit', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(670, 'en', 'live_support', 'Live Support', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(671, 'en', 'free_support', 'Free Support', '2025-04-21 18:25:50', '2025-04-21 18:25:50', NULL),
(672, 'en', 'package', 'Package', '2025-04-21 18:26:49', '2025-04-21 18:26:49', NULL),
(673, 'en', 'package_price', 'Package Price', '2025-04-21 18:26:49', '2025-04-21 18:26:49', NULL),
(674, 'en', 'paid_amount', 'Paid Amount', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(675, 'en', 'start_date', 'Start Date', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(676, 'en', 'expire_date', 'Expire Date', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(677, 'en', 'recurring', 'Recurring', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(678, 'en', 'payment_status', 'Payment Status', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(679, 'en', 'actions', 'Actions', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(680, 'en', 'active_now_confirmation', 'Active Now Confirmation', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(681, 'en', 'expire_previous_package_and_start_new_package_from_now_enjoy_', 'Expire Previous Package and Start New package From Now, Enjoy !!', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(682, 'en', 'are_you_sure_to_active_this', 'Are you sure to Active this?', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(683, 'en', 'procced', 'Procced', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(684, 'en', 'reason', 'Reason', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(685, 'en', 'cancel_auto_subscription', 'Cancel Auto Subscription', '2025-04-21 18:26:50', '2025-04-21 18:26:50', NULL),
(686, 'en', 'its_free', 'It\'s Free', '2025-04-21 18:27:36', '2025-04-21 18:27:36', NULL),
(687, 'en', 'yearly', 'Yearly', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(688, 'en', 'lifetime', 'Lifetime', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(689, 'en', 'prepaid', 'Prepaid', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(690, 'en', 'selected_package_type', 'Selected package type', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(691, 'en', 'if_this_is_enabled_user_will_be_able_to_use_unlimited_balance', 'If this is enabled, user will be able to use unlimited balance.', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(692, 'en', 'if_this_is_checkd_it_will_be_shown_in_the_subscription_plan_list', 'If this is checkd, it will be shown in the subscription plan list', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(693, 'en', 'if_this_is_enabled_user_will_be_able_to_use_the_feature', 'If this is enabled, user will be able to use the feature.', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(694, 'en', 'chat_real_time_data', 'Chat Real Time Data', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(695, 'en', 'dall_e_2', 'Dall E 2', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(696, 'en', 'dall_e_3', 'Dall E 3', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(697, 'en', 'chat_image', 'Chat Image', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(698, 'en', 'is_featured', 'Is Featured?', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(699, 'en', 'if_this_is_enabled_a_recommend_badge_will_be_shown_in_the_subscription_plan', 'If this is enabled, a recommend badge will be shown in the subscription plan.', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(700, 'en', 'if_this_is_enabled_you_have_to_provide_live_support_to_the_users', 'If this is enabled, you have to provide live support to the users.', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(701, 'en', 'if_this_is_enabled_you_have_to_provide_free_support_to_the_users', 'If this is enabled, you have to provide free support to the users.', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(702, 'en', 'select_open_ai_model', 'Select Open AI Model', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(703, 'en', 'type_additional_features', 'Type additional features', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(704, 'en', 'comma_separated_feature_afeature_b', 'Comma separated: Feature A,Feature B', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(705, 'en', '30', '30', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(706, 'en', 'expire_in_number_in_days_for_starter_package', 'Expire in number in days for Starter Package', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(707, 'en', 'is_active', 'Is Active?', '2025-04-21 18:28:43', '2025-04-21 18:28:43', NULL),
(708, 'en', 'if_active_this_will_be_applied_to_new_users_registration', 'If active, this will be applied to new user\'s registration.', '2025-04-21 18:28:44', '2025-04-21 18:28:44', NULL),
(709, 'en', 'templates_updated_successfully', 'Templates updated successfully', '2025-04-21 18:28:44', '2025-04-21 18:28:44', NULL),
(710, 'en', 'package_created_successfully', 'Package created successfully', '2025-04-21 18:28:44', '2025-04-21 18:28:44', NULL),
(711, 'en', 'new_package', 'New Package', '2025-04-21 18:29:20', '2025-04-21 18:29:20', NULL),
(712, 'en', 'create_new_package', 'Create New Package', '2025-04-21 18:29:20', '2025-04-21 18:29:20', NULL),
(713, 'en', 'copy_from_existing', 'Copy From Existing', '2025-04-21 18:29:20', '2025-04-21 18:29:20', NULL),
(714, 'en', 'monthly_packages', 'Monthly Packages', '2025-04-21 18:29:20', '2025-04-21 18:29:20', NULL),
(715, 'en', 'yearly_packages', 'Yearly Packages', '2025-04-21 18:29:20', '2025-04-21 18:29:20', NULL),
(716, 'en', 'lifetime_packages', 'Lifetime Packages', '2025-04-21 18:29:20', '2025-04-21 18:29:20', NULL),
(717, 'en', 'prepaid_packages', 'Prepaid Packages', '2025-04-21 18:29:20', '2025-04-21 18:29:20', NULL),
(718, 'en', 'copy', 'Copy', '2025-04-21 18:29:20', '2025-04-21 18:29:20', NULL),
(719, 'en', 'set_0_to_make_it_free', 'Set $0 to make it free', '2025-04-21 18:29:39', '2025-04-21 18:29:39', NULL),
(720, 'en', 'discount', 'Discount', '2025-04-21 18:29:39', '2025-04-21 18:29:39', NULL),
(721, 'en', 'fixed', 'Fixed', '2025-04-21 18:29:39', '2025-04-21 18:29:39', NULL),
(722, 'en', 'percentage', 'Percentage', '2025-04-21 18:29:39', '2025-04-21 18:29:39', NULL),
(723, 'en', 'delete_this_package', 'Delete this package', '2025-04-21 18:29:39', '2025-04-21 18:29:39', NULL),
(724, 'en', 'featured', 'Featured', '2025-04-21 18:32:33', '2025-04-21 18:32:33', NULL),
(725, 'en', 'payment_methods_settings', 'Payment Methods Settings', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(726, 'en', 'settings', 'Settings', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(727, 'en', 'offline_payment_method', 'Offline Payment Method', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(728, 'en', 'paypal_configuration', 'Paypal Configuration', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(729, 'en', 'paypal_client_id', 'Paypal Client ID', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(730, 'en', 'paypal_client_secret', 'Paypal Client Secret', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(731, 'en', 'enable_paypal', 'Enable Paypal', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(732, 'en', 'gateway', 'Gateway', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(733, 'en', 'sandbox', 'Sandbox', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(734, 'en', 'live', 'Live', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(735, 'en', 'stripe_configuration', 'Stripe Configuration', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(736, 'en', 'publishable_key', 'Publishable Key', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(737, 'en', 'stripe_secret', 'Stripe Secret', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(738, 'en', 'enable_stripe', 'Enable Stripe', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(739, 'en', 'paytm_configuration', 'PayTm Configuration', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(740, 'en', 'paytm_environment', 'PayTm Environment', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(741, 'en', 'paytm_merchant_id', 'PayTm Merchant ID', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(742, 'en', 'paytm_merchant_key', 'PayTm Merchant Key', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(743, 'en', 'paytm_merchant_website', 'PayTm Merchant Website', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(744, 'en', 'paytm_channel', 'PayTm Channel', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(745, 'en', 'paytm_industry_type', 'PayTm Industry Type', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(746, 'en', 'enable_paytm', 'Enable PayTm', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(747, 'en', 'razorpay_configuration', 'Razorpay Configuration', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(748, 'en', 'razorpay_key', 'Razorpay Key', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(749, 'en', 'razorpay_secret', 'Razorpay Secret', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(750, 'en', 'enable_razorpay', 'Enable Razorpay', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(751, 'en', 'iyzico_configuration', 'Iyzico Configuration', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(752, 'en', 'iyzico_api_key', 'IyZico API Key', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(753, 'en', 'iyzico_secret_key', 'IyZico Secret Key', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(754, 'en', 'enable_iyzico', 'Enable IyZico', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(755, 'en', 'enable_test_sandbox_mode', 'Enable Test Sandbox Mode', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(756, 'en', 'paystack_configuration', 'Paystack Configuration', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(757, 'en', 'paystack_public_key', 'Paystack Public Key', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(758, 'en', 'secret_key', 'Secret Key', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(759, 'en', 'merchant_email', 'Merchant Email', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(760, 'en', 'paystack_callback', 'Paystack Callback', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(761, 'en', 'paystack_currency_code', 'Paystack Currency Code', '2025-04-21 18:38:22', '2025-04-21 18:38:22', NULL),
(762, 'en', 'enable_paystack', 'Enable Paystack', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(763, 'en', 'flutterwave_configuration', 'Flutterwave Configuration', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(764, 'en', 'flutterwave_public_key', 'Flutterwave Public Key', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(765, 'en', 'flutterwave_secret_key', 'Flutterwave Secret Key', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(766, 'en', 'flutterwave_secret_hash', 'Flutterwave Secret Hash', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(767, 'en', 'enable_flutterwave', 'Enable Flutterwave', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(768, 'en', 'duitku_configuration', 'Duitku Configuration', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(769, 'en', 'duitku_api_key', 'Duitku Api Key', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(770, 'en', 'duitku_merchant_code', 'Duitku Merchant Code', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(771, 'en', 'duitku_callback_url', 'Duitku Callback Url', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(772, 'en', 'duitku_return_url', 'Duitku Return Url', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(773, 'en', 'duitku_env', 'Duitku Env', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(774, 'en', 'enable_duitku', 'Enable Duitku', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(775, 'en', 'yookassa_configuration', 'Yookassa Configuration', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(776, 'en', 'yookassa_shop_id', 'Yookassa Shop ID', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(777, 'en', 'yookassa_secret_key', 'Yookassa Secret Key', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(778, 'en', 'yookassa_currency_code', 'YOOKASSA Currency Code', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(779, 'en', 'enable_yookassa', 'Enable Yookassa', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(780, 'en', 'reciept_', 'Reciept ?', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(781, 'en', 'vat_rates_yookassa', 'VAT rates Yookassa', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(782, 'en', 'vat_not_included', 'VAT not included', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(783, 'en', '0_vat_rate', '0% VAT rate', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(784, 'en', '10_vat_rate', '10% VAT rate', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(785, 'en', '20_receipts_vat_rate', '20% receipt’s VAT rate', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(786, 'en', '10110_receipts_estimate_vat_rate', '10/110 receipt’s estimate VAT rate', '2025-04-21 18:38:23', '2025-04-21 18:38:23', NULL),
(787, 'en', '20120_receipts_estimate_vat_rate', '20/120 receipt’s estimate VAT rate', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(788, 'en', 'molile_configuration', 'Molile Configuration', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(789, 'en', 'molile_api_key', 'Molile API Key', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(790, 'en', 'enable_molile', 'Enable Molile', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(791, 'en', 'mercadopago_configuration', 'Mercadopago Configuration', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(792, 'en', 'mercadopago_secret_key', 'Mercadopago Secret Key', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(793, 'en', 'enable_mercadopago', 'Enable Mercadopago', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(794, 'en', 'midtrans_configuration', 'Midtrans Configuration', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(795, 'en', 'midtrans_server_key', 'Midtrans Server Key', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(796, 'en', 'midtrans_client_key', 'Midtrans Client Key', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(797, 'en', 'finish_url', 'Finish URL', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(798, 'en', 'payment_notification_url', 'Payment Notification URL', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(799, 'en', 'payment_failed_url', 'Payment Failed URL', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(800, 'en', 'enable_midtrans', 'Enable Midtrans', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(801, 'en', 'offline_configuration', 'Offline Configuration', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(802, 'en', 'enable_offline', 'Enable Offline', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(803, 'en', 'choose_image', 'Choose Image', '2025-04-21 18:38:24', '2025-04-21 18:38:24', NULL),
(804, 'en', 'payment_settings_updated_successfully', 'Payment settings updated successfully', '2025-04-21 18:38:49', '2025-04-21 18:38:49', NULL),
(805, 'en', 'smtp', 'SMTP', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(806, 'en', 'send_mail', 'Send Mail', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(807, 'en', 'smtp_configuration', 'SMTP Configuration', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(808, 'en', 'mail_host', 'Mail Host', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(809, 'en', 'type_mail_host', 'Type mail host', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(810, 'en', 'mail_port', 'Mail Port', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(811, 'en', 'type_mail_port', 'Type mail port', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(812, 'en', 'mail_username', 'Mail Username', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(813, 'en', 'type_mail_username', 'Type mail username', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(814, 'en', 'mail_password', 'Mail Password', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(815, 'en', 'type_mail_password', 'Type mail password', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(816, 'en', 'mail_encryption', 'Mail Encryption', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(817, 'en', 'type_mail_encryption', 'Type mail encryption', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(818, 'en', 'mail_from_address', 'Mail From Address', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(819, 'en', 'type_mail_from_address', 'Type mail from address', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(820, 'en', 'mail_from_name', 'Mail From Name', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(821, 'en', 'type_mail_from_name', 'Type mail from name', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(822, 'en', 'configure_smtp', 'Configure SMTP', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(823, 'en', 'smtp_information', 'SMTP Information', '2025-04-21 18:40:06', '2025-04-21 18:40:06', NULL),
(824, 'en', 'search_template_that_you_are_looking_for', 'Search template that you are looking for', '2025-04-21 22:30:24', '2025-04-21 22:30:24', NULL),
(825, 'en', 'show_category', 'Show Category', '2025-04-21 22:30:24', '2025-04-21 22:30:24', NULL),
(826, 'en', 'general_contents', 'General Contents', '2025-04-21 22:30:24', '2025-04-21 22:30:24', NULL),
(827, 'en', 'tiktok', 'TikTok', '2025-04-21 22:30:24', '2025-04-21 22:30:24', NULL),
(828, 'en', 'seo_tools', 'SEO Tools', '2025-04-21 22:30:24', '2025-04-21 22:30:24', NULL),
(829, 'en', 'images', 'Images', '2025-04-21 22:43:45', '2025-04-21 22:43:45', NULL),
(830, 'en', 'subscriptions_settings', 'Subscriptions Settings', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(831, 'en', 'balance_carry_forward', 'Balance Carry Forward', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(832, 'en', 'new_package_purchase_settigns', 'New package Purchase Settigns', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(833, 'en', 'auto_activated_new_package_exire_old_package_', 'Auto Activated New package Exire Old Package: ', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(834, 'en', 'if_enable_running_package_expire_when_purchase_to_new_package', 'if enable, running package expire when purchase to new package', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(835, 'en', 'auto_subscription', 'Auto Subscription', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(836, 'en', 'allow_user_to_cancel_auto_subscription_', 'Allow user to cancel Auto Subscription: ', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(837, 'en', 'if_enable_user_can_cancel_auto_recurring_payment_if_purchase_from_paypal', 'if enable, user can cancel auto recurring payment if purchase from paypal', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(838, 'en', 'allow_user_to_active_auto_subscription_', 'Allow user to Active Auto Subscription: ', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(839, 'en', 'if_enable_user_can_active_auto_recurring_payment_if_purchase_from_paypal', 'if enable, user can Active auto recurring payment if purchase from paypal', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(840, 'en', 'configure_subscriptions_settings', 'Configure Subscriptions Settings', '2025-04-21 22:44:22', '2025-04-21 22:44:22', NULL),
(841, 'en', 'affiliate_configurations', 'Affiliate Configurations', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(842, 'en', 'affiliate_commission_', 'Affiliate Commission %', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(843, 'en', 'type_affiliate_commission_', 'Type affiliate commission %', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(844, 'en', 'minimum_withdrawal_amount', 'Minimum Withdrawal Amount', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(845, 'en', 'type_minimum_withdrawal_amount', 'Type minimum withdrawal amount', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(846, 'en', 'allow_commission_continuously', 'Allow Commission Continuously', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(847, 'en', 'if_enabled_user_will_get_commission_for_each_subscriptions_of_referred_user_otherwise_only_for_the_first_subscription', 'If enabled, user will get commission for each subscriptions of referred user. Otherwise only for the first subscription.', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(848, 'en', 'payout_payment_methods', 'Payout Payment Methods', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(849, 'en', 'select_payout_payment_methods', 'Select payout payment methods', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(850, 'en', 'bank_payment', 'Bank Payment', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(851, 'en', 'paypal', 'Paypal', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(852, 'en', 'stripe', 'Stripe', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(853, 'en', 'paytm', 'PayTm', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(854, 'en', 'razorpay', 'Razorpay', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(855, 'en', 'iyzico', 'IyZico', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(856, 'en', 'enable_affiliate_system', 'Enable Affiliate System', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(857, 'en', 'configure_affiliate_settings', 'Configure Affiliate Settings', '2025-04-21 22:44:45', '2025-04-21 22:44:45', NULL),
(858, 'en', 'settings_updated_successfully', 'Settings updated successfully', '2025-04-21 22:45:03', '2025-04-21 22:45:03', NULL),
(859, 'en', 'withdraw_requests', 'Withdraw Requests', '2025-04-21 22:45:04', '2025-04-21 22:45:04', NULL),
(860, 'en', 'earning_histories', 'Earning Histories', '2025-04-21 22:45:04', '2025-04-21 22:45:04', NULL),
(861, 'en', 'payment_histories', 'Payment Histories', '2025-04-21 22:45:04', '2025-04-21 22:45:04', NULL),
(862, 'en', 'payout_configuration', 'Payout Configuration', '2025-04-21 22:46:27', '2025-04-21 22:46:27', NULL),
(863, 'en', 'invite_your_friends_and_earn_money_from_their_subscriptions', 'Invite your friends and earn money from their subscriptions', '2025-04-21 22:46:27', '2025-04-21 22:46:27', NULL),
(864, 'en', 'invite_friends', 'Invite Friends', '2025-04-21 22:46:27', '2025-04-21 22:46:27', NULL),
(865, 'en', 'subscription_product_and_plan_not_created_for_this_payment_gateway', 'Subscription Product and Plan not created for this Payment Gateway', '2025-04-21 22:46:39', '2025-04-21 22:46:39', NULL),
(866, 'en', 'export_customers', 'Export Customers', '2025-04-21 22:47:05', '2025-04-21 22:47:05', NULL),
(867, 'en', 'add_customer', 'Add Customer', '2025-04-21 22:47:05', '2025-04-21 22:47:05', NULL),
(868, 'en', 'select_package', 'Select Package', '2025-04-21 22:47:05', '2025-04-21 22:47:05', NULL),
(869, 'en', 'banned', 'Banned', '2025-04-21 22:47:05', '2025-04-21 22:47:05', NULL),
(870, 'en', 'active_package', 'Active Package', '2025-04-21 22:47:05', '2025-04-21 22:47:05', NULL),
(871, 'en', 'assign_package', 'Assign Package', '2025-04-21 22:47:05', '2025-04-21 22:47:05', NULL),
(872, 'en', 'customer_name', 'Customer Name', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(873, 'en', 'type_customer_name', 'Type Customer name', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(874, 'en', 'offline', 'Offline', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(875, 'en', 'select_offline_method', 'Select Offline Method', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(876, 'en', 'type_amount', 'Type Amount', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(877, 'en', 'type_payment_detail', 'Type payment detail', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(878, 'en', 'your_global_setting_for_balance_carry_forward_is', 'Your global setting for Balance Carry Forward is:', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(879, 'en', 'disabled', 'Disabled', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(880, 'en', 'customer_information', 'Customer Information', '2025-04-21 22:47:13', '2025-04-21 22:47:13', NULL),
(881, 'en', 'add_new_offline_payment_method', 'Add New Offline Payment Method', '2025-04-21 22:47:57', '2025-04-21 22:47:57', NULL),
(882, 'en', 'type_name', 'Type name', '2025-04-21 22:47:57', '2025-04-21 22:47:57', NULL),
(883, 'en', 'save_offline_payment_method', 'Save Offline Payment Method', '2025-04-21 22:47:57', '2025-04-21 22:47:57', NULL),
(884, 'en', 'offline_payment_method_information', 'Offline Payment Method Information', '2025-04-21 22:47:57', '2025-04-21 22:47:57', NULL),
(885, 'en', 'all_offline_payment_method', 'All Offline Payment Method', '2025-04-21 22:47:57', '2025-04-21 22:47:57', NULL),
(886, 'en', 'add_offline_payment_method', 'Add Offline Payment Method', '2025-04-21 22:47:57', '2025-04-21 22:47:57', NULL),
(887, 'en', 'offline_payment_method_inserted_successfully', 'Offline Payment Method inserted successfully', '2025-04-21 22:48:28', '2025-04-21 22:48:28', NULL),
(888, 'en', 'operation_successfully_please_wait_for_approval', 'Operation successfully. Please Wait For Approval', '2025-04-21 22:50:06', '2025-04-21 22:50:06', NULL),
(889, 'en', 'offline_payment_request', 'Offline Payment Request', '2025-04-21 22:50:06', '2025-04-21 22:50:06', NULL),
(890, 'en', 'already_subscribed', 'Already Subscribed', '2025-04-21 22:50:07', '2025-04-21 22:50:07', NULL),
(891, 'en', 'new', 'New', '2025-04-21 22:50:22', '2025-04-21 22:50:22', NULL),
(892, 'en', 'no', 'No', '2025-04-21 22:50:36', '2025-04-21 22:50:36', NULL),
(893, 'en', 'pending', 'Pending', '2025-04-21 22:50:36', '2025-04-21 22:50:36', NULL),
(894, 'en', 'reject', 'Reject', '2025-04-21 22:50:58', '2025-04-21 22:50:58', NULL),
(895, 'en', 'incomplete', 'Incomplete', '2025-04-21 22:50:58', '2025-04-21 22:50:58', NULL),
(896, 'en', 'user', 'User', '2025-04-21 22:50:58', '2025-04-21 22:50:58', NULL),
(897, 'en', 'approve', 'Approve', '2025-04-21 22:50:58', '2025-04-21 22:50:58', NULL),
(898, 'en', 'add_note', 'Add Note', '2025-04-21 22:50:58', '2025-04-21 22:50:58', NULL),
(899, 'en', 'write_note', 'Write Note', '2025-04-21 22:50:58', '2025-04-21 22:50:58', NULL),
(900, 'en', 'status_change_successfully', 'Status Change successfully', '2025-04-21 22:51:16', '2025-04-21 22:51:16', NULL),
(901, 'en', 'paid', 'Paid', '2025-04-21 22:52:39', '2025-04-21 22:52:39', NULL),
(902, 'en', 'ai_image_chat', 'AI Image Chat', '2025-04-21 22:52:39', '2025-04-21 22:52:39', NULL),
(903, 'en', 'renew_package', 'Renew Package', '2025-04-21 22:52:56', '2025-04-21 22:52:56', NULL),
(904, 'en', 'do_you_want_to_active_this_package_', 'Do you want to active this package ?', '2025-04-21 22:52:57', '2025-04-21 22:52:57', NULL),
(905, 'en', 'your_current_active_package_will_be_expired_and_this_will_be_active', 'Your current active package will be expired and This Will be active.', '2025-04-21 22:52:57', '2025-04-21 22:52:57', NULL),
(906, 'en', 'generate_contents', 'Generate Contents', '2025-04-21 23:10:42', '2025-04-21 23:10:42', NULL),
(907, 'en', 'about_what_is_the_website', 'About what is the website?', '2025-04-21 23:10:43', '2025-04-21 23:10:43', NULL),
(908, 'en', 'type_description_of_the_website', 'Type description of the website', '2025-04-21 23:10:43', '2025-04-21 23:10:43', NULL),
(909, 'en', 'edit_blog_article', 'Edit Blog Article', '2025-04-21 23:13:47', '2025-04-21 23:13:47', NULL),
(910, 'en', 'update_blog_details', 'Update Blog Details', '2025-04-21 23:14:08', '2025-04-21 23:14:08', NULL),
(911, 'en', 'ai_blog_articles', 'Ai Blog Articles', '2025-04-21 23:14:08', '2025-04-21 23:14:08', NULL),
(912, 'en', 'your_blog_title', 'Your blog title', '2025-04-21 23:14:08', '2025-04-21 23:14:08', NULL),
(913, 'en', 'copy_contents', 'Copy Contents', '2025-04-21 23:14:08', '2025-04-21 23:14:08', NULL),
(914, 'en', 'staffs', 'Staffs', '2025-04-21 23:16:57', '2025-04-21 23:16:57', NULL),
(915, 'en', 'new_employee', 'New Employee', '2025-04-21 23:16:57', '2025-04-21 23:16:57', NULL),
(916, 'en', 'add_employee', 'Add Employee', '2025-04-21 23:16:57', '2025-04-21 23:16:57', NULL),
(917, 'en', 'role', 'Role', '2025-04-21 23:16:57', '2025-04-21 23:16:57', NULL),
(918, 'en', 'created_by', 'Created By', '2025-04-21 23:16:57', '2025-04-21 23:16:57', NULL),
(919, 'en', 'add_page', 'Add Page', '2025-04-21 23:17:05', '2025-04-21 23:17:05', NULL);
INSERT INTO `localizations` (`id`, `lang_key`, `t_key`, `t_value`, `created_at`, `updated_at`, `deleted_at`) VALUES
(920, 'en', 'page_link', 'Page Link', '2025-04-21 23:17:05', '2025-04-21 23:17:05', NULL),
(921, 'en', 'update_page', 'Update Page', '2025-04-21 23:17:14', '2025-04-21 23:17:14', NULL),
(922, 'en', 'page_title', 'Page Title', '2025-04-21 23:17:14', '2025-04-21 23:17:14', NULL),
(923, 'en', 'type_page_title', 'Type page title', '2025-04-21 23:17:14', '2025-04-21 23:17:14', NULL),
(924, 'en', 'page_description', 'Page Description', '2025-04-21 23:17:14', '2025-04-21 23:17:14', NULL),
(925, 'en', 'page_information', 'Page Information', '2025-04-21 23:17:14', '2025-04-21 23:17:14', NULL),
(926, 'en', 'seo_meta_options', 'SEO Meta Options', '2025-04-21 23:17:14', '2025-04-21 23:17:14', NULL),
(927, 'en', 'title_of_the_blog', 'Title of the blog', '2025-04-22 13:35:37', '2025-04-22 13:35:37', NULL),
(928, 'en', 'eg_best_restaurants_in_la_to_eat_indian_foods', 'e.g. best restaurants in LA to eat indian foods', '2025-04-22 13:35:38', '2025-04-22 13:35:38', NULL),
(929, 'en', 'what_are_the_main_points_you_want_to_cover', 'What are the main points you want to cover?', '2025-04-22 13:35:42', '2025-04-22 13:35:42', NULL),
(930, 'en', 'eg_dosa_biriyani_tandoori_chicken', 'e.g. dosa, biriyani, tandoori chicken', '2025-04-22 13:35:45', '2025-04-22 13:35:45', NULL),
(931, 'en', 'add_custom_template', 'Add Custom Template', '2025-04-22 13:36:51', '2025-04-22 13:36:51', NULL),
(932, 'en', 'custom', 'Custom', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(933, 'en', 'add_template', 'Add Template', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(934, 'en', 'template_name', 'Template Name', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(935, 'en', 'type_template_name', 'Type template name', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(936, 'en', 'icon', 'Icon', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(937, 'en', 'select_a_category', 'Select a category', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(938, 'en', 'type_short_description', 'Type short description', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(939, 'en', 'input_information', 'Input Information', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(940, 'en', 'input_type', 'Input Type', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(941, 'en', 'input_field', 'Input Field', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(942, 'en', 'textarea_field', 'Textarea Field', '2025-04-22 13:36:59', '2025-04-22 13:36:59', NULL),
(943, 'en', 'input_name', 'Input Name', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(944, 'en', 'type_input_name', 'Type input name', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(945, 'en', 'input_label', 'Input Label', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(946, 'en', 'type_input_label', 'Type input label', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(947, 'en', 'input_variables', 'Input Variables', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(948, 'en', 'click_on_variable_to_set_the_user_input_of_it_in_your_prompts', 'Click on variable to set the user input of it in your prompts', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(949, 'en', 'custom_prompt', 'Custom Prompt', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(950, 'en', 'type_your_prompt', 'Type your prompt', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(951, 'en', 'save_template', 'Save Template', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(952, 'en', 'template_information', 'Template Information', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(953, 'en', 'basic', 'Basic', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(954, 'en', 'inputs', 'Inputs', '2025-04-22 13:37:00', '2025-04-22 13:37:00', NULL),
(955, 'en', 'custom_template_categories', 'Custom Template Categories', '2025-04-22 13:38:43', '2025-04-22 13:38:43', NULL),
(956, 'en', 'add_new_category', 'Add New Category', '2025-04-22 13:38:43', '2025-04-22 13:38:43', NULL),
(957, 'en', 'category_name', 'Category Name', '2025-04-22 13:38:43', '2025-04-22 13:38:43', NULL),
(958, 'en', 'type_category_name', 'Type category name', '2025-04-22 13:38:43', '2025-04-22 13:38:43', NULL),
(959, 'en', 'save_category', 'Save Category', '2025-04-22 13:38:43', '2025-04-22 13:38:43', NULL),
(960, 'en', 'category_information', 'Category Information', '2025-04-22 13:38:43', '2025-04-22 13:38:43', NULL),
(961, 'en', 'all_categories', 'All Categories', '2025-04-22 13:38:43', '2025-04-22 13:38:43', NULL),
(962, 'en', 'category_has_been_inserted_successfully', 'Category has been inserted successfully', '2025-04-22 13:39:00', '2025-04-22 13:39:00', NULL),
(963, 'en', 'template_has_been_added_successfully', 'Template has been added successfully', '2025-04-22 13:40:43', '2025-04-22 13:40:43', NULL),
(964, 'en', 'english', 'english', '2025-04-22 13:41:04', '2025-04-22 13:41:04', NULL),
(965, 'en', 'input_your_keysowrds_using_comma', 'input your keysowrds using comma,', '2025-04-22 13:41:05', '2025-04-22 13:41:05', NULL),
(966, 'en', 'please_login_to_continue', 'Please login to continue', '2025-04-22 13:43:01', '2025-04-22 13:43:01', NULL),
(967, 'en', 'content', 'Content', '2025-04-22 13:43:21', '2025-04-22 13:43:21', NULL),
(968, 'en', 'email_template_settings', 'Email Template Settings', '2025-04-22 13:43:53', '2025-04-22 13:43:53', NULL),
(969, 'en', 'variables', 'Variables', '2025-04-22 13:43:53', '2025-04-22 13:43:53', NULL),
(970, 'en', 'subject', 'Subject', '2025-04-22 13:43:53', '2025-04-22 13:43:53', NULL),
(971, 'en', 'type_subject', 'Type Subject', '2025-04-22 13:43:53', '2025-04-22 13:43:53', NULL),
(972, 'en', 'is_active_', 'Is Active ?', '2025-04-22 13:43:53', '2025-04-22 13:43:53', NULL),
(973, 'en', 'update_successfully', 'Update Successfully', '2025-04-22 13:43:53', '2025-04-22 13:43:53', NULL),
(974, 'en', 'update_failed', 'Update Failed', '2025-04-22 13:43:53', '2025-04-22 13:43:53', NULL),
(975, 'en', 'roles', 'Roles', '2025-04-22 13:44:10', '2025-04-22 13:44:10', NULL),
(976, 'en', 'reset_permission', 'Reset Permission', '2025-04-22 13:44:10', '2025-04-22 13:44:10', NULL),
(977, 'en', 'add_role', 'Add Role', '2025-04-22 13:44:10', '2025-04-22 13:44:10', NULL),
(978, 'en', 'used_out_of', 'Used out of', '2025-04-22 13:50:46', '2025-04-22 13:50:46', NULL),
(979, 'en', 'used', 'Used', '2025-04-22 13:51:30', '2025-04-22 13:51:30', NULL),
(980, 'en', 'remaining_words', 'Remaining Words', '2025-04-22 13:51:31', '2025-04-22 13:51:31', NULL),
(981, 'en', 'projects', 'Projects', '2025-04-22 13:53:37', '2025-04-22 13:53:37', NULL),
(982, 'en', 'all', 'All', '2025-04-22 13:53:37', '2025-04-22 13:53:37', NULL),
(983, 'en', 'code', 'Code', '2025-04-22 13:53:37', '2025-04-22 13:53:37', NULL),
(984, 'en', 'project_details', 'Project Details', '2025-04-22 13:53:46', '2025-04-22 13:53:46', NULL),
(985, 'en', 'blog_title', 'Blog Title', '2025-04-22 15:32:36', '2025-04-22 15:32:36', NULL),
(986, 'en', 'generated', 'Generated', '2025-04-22 15:32:36', '2025-04-22 15:32:36', NULL),
(987, 'en', 'times', 'Times', '2025-04-22 15:32:36', '2025-04-22 15:32:36', NULL),
(988, 'en', 'not_published', 'Not Published', '2025-04-22 15:32:36', '2025-04-22 15:32:36', NULL),
(989, 'en', 'continue_writing', 'Continue Writing', '2025-04-22 15:32:36', '2025-04-22 15:32:36', NULL),
(990, 'en', 'are_you_going_to_publish_the_blog', 'Are you going to publish the blog?', '2025-04-22 15:32:36', '2025-04-22 15:32:36', NULL),
(991, 'en', 'blog_title_', 'Blog Title ', '2025-04-22 15:32:36', '2025-04-22 15:32:36', NULL),
(992, 'en', 'select_blog_category', 'Select Blog Category', '2025-04-22 15:32:36', '2025-04-22 15:32:36', NULL),
(993, 'en', 'select_blog_tags', 'Select Blog Tags', '2025-04-22 15:32:37', '2025-04-22 15:32:37', NULL),
(994, 'en', 'completed', 'Completed', '2025-04-22 15:32:37', '2025-04-22 15:32:37', NULL),
(995, 'en', '_publish_to_blog', ' Publish to Blog', '2025-04-22 15:32:37', '2025-04-22 15:32:37', NULL),
(996, 'en', 'view_details', 'View Details', '2025-04-22 15:32:37', '2025-04-22 15:32:37', NULL),
(997, 'en', 'edit_blog', 'Edit Blog', '2025-04-22 15:32:37', '2025-04-22 15:32:37', NULL),
(998, 'en', 'inpute_your_keywords_using_comma', 'inpute your keywords using comma,', '2025-04-22 15:39:03', '2025-04-22 15:39:03', NULL),
(999, 'en', 'generate_dalle_2_image', 'Generate DALL-E 2 Image', '2025-04-25 04:34:50', '2025-04-25 04:34:50', NULL),
(1000, 'en', 'generate_dalle_3_image', 'Generate DALL-E 3 Image', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1001, 'en', 'remaining_images', 'Remaining Images', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1002, 'en', 'vivid', 'Vivid', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1003, 'en', 'natural', 'Natural', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1004, 'en', 'quality', 'Quality', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1005, 'en', 'quality_of_the_image_will_be_as_selected', 'Quality of the image will be as selected', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1006, 'en', 'standard_', 'Standard ', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1007, 'en', 'hd', 'HD', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1008, 'en', '_1024x1024', ' [1024x1024]', '2025-04-25 04:34:52', '2025-04-25 04:34:52', NULL),
(1009, 'en', '_1024x1792', ' [1024x1792]', '2025-04-25 04:34:53', '2025-04-25 04:34:53', NULL),
(1010, 'en', '_1792x1024', ' [1792x1024]', '2025-04-25 04:34:53', '2025-04-25 04:34:53', NULL),
(1011, 'en', 'only_one_image_generate_at_a_time_for_dall_e_3', 'Only One image generate at a time for DALL E 3', '2025-04-25 04:34:53', '2025-04-25 04:34:53', NULL),
(1012, 'en', 'about_what_is_the_story', 'About what is the story?', '2025-04-25 05:06:30', '2025-04-25 05:06:30', NULL),
(1013, 'en', 'type_description_of_the_story', 'Type description of the story', '2025-04-25 05:06:30', '2025-04-25 05:06:30', NULL),
(1014, 'en', 'invoice', 'Invoice', '2025-04-25 05:08:00', '2025-04-25 05:08:00', NULL),
(1015, 'en', 'testimonials', 'Testimonials', '2025-04-26 12:51:12', '2025-04-26 12:51:12', NULL),
(1016, 'en', 'frequently_asked_questions', 'Frequently Asked Questions', '2025-04-26 15:11:53', '2025-04-26 15:11:53', NULL),
(1017, 'en', 'everything_you_need_to_know_about_the_product_and_billing', 'Everything you need to know about the product and billing.', '2025-04-26 15:11:53', '2025-04-26 15:11:53', NULL),
(1018, 'en', 'our_pricing', 'Our Pricing', '2025-04-26 15:11:58', '2025-04-26 15:11:58', NULL),
(1019, 'en', 'our_blogs', 'Our Blogs', '2025-04-26 21:15:28', '2025-04-26 21:15:28', NULL),
(1020, 'en', 'quick_links', 'Quick Links', '2025-04-27 01:38:36', '2025-04-27 01:38:36', NULL),
(1021, 'en', 'your_system_optimization_successfully_complete', 'Your System Optimization Successfully Complete', '2025-05-03 13:48:58', '2025-05-03 13:48:58', NULL),
(1022, 'en', 'debug_mode_enable_successfully', 'Debug Mode Enable Successfully', '2025-05-03 13:51:59', '2025-05-03 13:51:59', NULL),
(1023, 'en', 'file_permission_to_edit', 'File Permission To Edit', '2025-05-03 13:52:55', '2025-05-03 13:52:55', NULL),
(1024, 'en', 'recheck', 'Re-Check', '2025-05-03 13:52:55', '2025-05-03 13:52:55', NULL),
(1025, 'en', 'you_have_no_file_permission_issues_and_you_are_using_latest_version', 'You have no file permission issues and you are using latest version', '2025-05-03 13:52:55', '2025-05-03 13:52:55', NULL),
(1026, 'en', 'code_copied_successfully', 'Code copied successfully', '2025-05-03 13:52:55', '2025-05-03 13:52:55', NULL),
(1027, 'en', 'languages', 'Languages', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1028, 'en', 'iso_6391_code', 'ISO 639-1 Code', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1029, 'en', 'multilangual_support', 'MultiLangual Support', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1030, 'en', 'show_in_templates', 'Show In Templates', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1031, 'en', 'localizations', 'Localizations', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1032, 'en', 'add_new_language', 'Add New Language', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1033, 'en', 'language_name', 'Language Name', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1034, 'en', 'type_language_name', 'Type language name', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1035, 'en', 'enbn', 'en/bn', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1036, 'en', 'flag', 'Flag', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1037, 'en', 'is_rtl_', 'Is RTL ?', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1038, 'en', 'yes', 'Yes', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1039, 'en', 'save_language', 'Save Language', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1040, 'en', 'set_default_language', 'Set Default Language', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1041, 'en', 'default_language', 'Default Language', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1042, 'en', 'language_information', 'Language Information', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1043, 'en', 'all_languages', 'All Languages', '2025-05-03 13:53:09', '2025-05-03 13:53:09', NULL),
(1044, 'en', 'get_started_now', 'Get Started Now', '2025-05-03 14:03:07', '2025-05-03 14:03:07', NULL),
(1045, 'en', 'writbot_ai_tools', 'WritBot AI Tools.', '2025-05-03 14:03:08', '2025-05-03 14:03:08', NULL),
(1046, 'en', 'templated', 'Templated', '2025-05-03 14:03:08', '2025-05-03 14:03:08', NULL),
(1047, 'en', 'see_more', 'See More', '2025-05-03 14:03:08', '2025-05-03 14:03:08', NULL),
(1048, 'en', 'ai_images_generate', 'AI Images Generate', '2025-05-03 14:03:08', '2025-05-03 14:03:08', NULL),
(1049, 'en', 'writebot_subscription_plans', 'WriteBot Subscription Plans', '2025-05-03 14:03:08', '2025-05-03 14:03:08', NULL),
(1050, 'en', 'one_platform_multiple_ai_applications', 'One Platform Multiple AI Applications', '2025-05-03 14:03:09', '2025-05-03 14:03:09', NULL),
(1051, 'en', 'writbot_ai_loved_by_thinkers', 'WritBot AI Loved by thinkers', '2025-05-03 14:03:09', '2025-05-03 14:03:09', NULL),
(1052, 'en', 'blog', 'Blog', '2025-05-03 14:03:09', '2025-05-03 14:03:09', NULL),
(1053, 'en', 'facebook', 'Facebook', '2025-05-03 14:03:09', '2025-05-03 14:03:09', NULL),
(1054, 'en', 'twitter', 'Twitter', '2025-05-03 14:03:09', '2025-05-03 14:03:09', NULL),
(1055, 'en', 'privacy_policy', 'Privacy Policy', '2025-05-03 14:03:09', '2025-05-03 14:03:09', NULL),
(1056, 'en', 'terms_of_service', 'Terms of Service', '2025-05-03 14:03:09', '2025-05-03 14:03:09', NULL),
(1057, 'en', 'google', 'Google', '2025-05-03 14:03:49', '2025-05-03 14:03:49', NULL),
(1058, 'en', 'remember_me', 'Remember me', '2025-05-03 14:03:52', '2025-05-03 14:03:52', NULL),
(1059, 'en', 'login_now', 'Login Now', '2025-05-03 14:03:56', '2025-05-03 14:03:56', NULL),
(1060, 'en', 'back_to_home', 'Back to Home', '2025-05-03 14:04:01', '2025-05-03 14:04:01', NULL),
(1061, 'en', 'hello_i_am_megan_hyde_and_im_accountant_i_will_answer_your_accounting_related_questions', 'Hello! I am Megan Hyde, and I\'m Accountant. I will answer your accounting related questions.', '2025-05-03 14:05:42', '2025-05-03 14:05:42', NULL),
(1062, 'en', 'email_us_', 'Email us ', '2025-05-03 14:41:00', '2025-05-03 14:41:00', NULL),
(1063, 'en', 'give_us_call', 'Give us call', '2025-05-03 14:41:01', '2025-05-03 14:41:01', NULL),
(1064, 'en', 'your_gateway_to_cutting_edge_ai_innovations', 'Your Gateway to Cutting Edge AI Innovations', '2025-05-03 15:09:58', '2025-05-03 15:09:58', NULL),
(1065, 'en', 'have_a_question_that_is________________________________________________________________________not_answered_you_can_contact_us_at', 'Have a question that is                                                                        not answered? You can contact us at', '2025-05-03 16:01:58', '2025-05-03 16:01:58', NULL),
(1066, 'en', 'have_a_question_submit_a_ticket', 'Have a question? Submit a Ticket', '2025-05-03 16:01:58', '2025-05-03 16:01:58', NULL),
(1067, 'en', 'terms_of_condition', 'Terms of Condition', '2025-05-03 16:32:55', '2025-05-03 16:32:55', NULL),
(1068, 'en', 'support_categories', 'Support Categories', '2025-05-03 16:54:30', '2025-05-03 16:54:30', NULL),
(1069, 'en', 'assign_staff', 'Assign Staff', '2025-05-03 16:54:30', '2025-05-03 16:54:30', NULL),
(1070, 'en', 'select_staff', 'Select Staff', '2025-05-03 16:54:30', '2025-05-03 16:54:30', NULL),
(1071, 'en', 'by_continuing_you_are_stating_that_you_accept_the', 'By continuing, you are stating that you accept the', '2025-05-03 17:52:51', '2025-05-03 17:52:51', NULL),
(1072, 'en', 'terms__conditions', 'Terms & Conditions', '2025-05-03 17:52:51', '2025-05-03 17:52:51', NULL),
(1073, 'en', 'have_read_the', 'have read the', '2025-05-03 17:52:51', '2025-05-03 17:52:51', NULL),
(1074, 'en', 'register', 'Register', '2025-05-03 17:52:51', '2025-05-03 17:52:51', NULL),
(1075, 'en', 'do_you_have_an_account', 'Do you have an Account?', '2025-05-03 17:52:51', '2025-05-03 17:52:51', NULL),
(1076, 'en', 'hello_i_am_jason_ferrara_and_im_web_developer_i_will_help_you_developing_your_website__applications', 'Hello! I am Jason Ferrara, and I\'m Web Developer. I will help you developing your website & applications.', '2025-05-03 18:09:09', '2025-05-03 18:09:09', NULL),
(1077, 'en', 'about_what_is_your_email', 'About what is your email?', '2025-05-03 18:30:54', '2025-05-03 18:30:54', NULL),
(1078, 'en', 'eg_following_up_after_an_interview', 'e.g. Following up after an interview', '2025-05-03 18:30:54', '2025-05-03 18:30:54', NULL),
(1079, 'en', 'hello_i_am_chat_image_creator_and_im_image_expert_hi_i_am_image_creator_expert_i_can_assist_to_generate_image_by_user_inputi_will_help_you_to_create_your_image', 'Hello! I am Chat Image Creator, and I\'m Image Expert. Hi! I am Image Creator Expert. I can assist to generate image by user inputI will help you to create your Image.', '2025-05-03 18:34:14', '2025-05-03 18:34:14', NULL),
(1080, 'en', 'website_header_configuration', 'Website Header Configuration', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1081, 'en', 'navbar_information', 'Navbar Information', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1082, 'en', 'navbar_logo_white', 'Navbar Logo White', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1083, 'en', 'choose_navbar_white_logo', 'Choose Navbar White Logo', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1084, 'en', 'navbar_logo_dark', 'Navbar Logo Dark', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1085, 'en', 'choose_navbar_dark_logo', 'Choose Navbar Dark Logo', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1086, 'en', 'templates_group', 'Templates Group', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1087, 'en', 'select_groups', 'Select groups', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1088, 'en', 'select_pages', 'Select pages', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1089, 'en', 'header_configuration', 'Header Configuration', '2025-05-03 18:45:45', '2025-05-03 18:45:45', NULL),
(1090, 'en', 'all_folders', 'All Folders', '2025-05-03 18:50:24', '2025-05-03 18:50:24', NULL),
(1091, 'en', 'add_new_folder', 'Add New Folder', '2025-05-03 18:50:24', '2025-05-03 18:50:24', NULL),
(1092, 'en', 'folder_name', 'Folder Name', '2025-05-03 18:50:24', '2025-05-03 18:50:24', NULL),
(1093, 'en', 'type_folder_name', 'Type folder name', '2025-05-03 18:50:24', '2025-05-03 18:50:24', NULL),
(1094, 'en', 'save_folder', 'Save Folder', '2025-05-03 18:50:24', '2025-05-03 18:50:24', NULL),
(1095, 'en', 'folder_information', 'Folder Information', '2025-05-03 18:50:24', '2025-05-03 18:50:24', NULL),
(1096, 'en', 'questions_we_have_answers', 'Questions? We Have Answers.', '2025-05-03 20:34:53', '2025-05-03 20:34:53', NULL),
(1097, 'en', 'about_us_contents', 'About Us Contents', '2025-05-03 22:32:45', '2025-05-03 22:32:45', NULL),
(1098, 'en', 'contents', 'Contents', '2025-05-03 22:32:45', '2025-05-03 22:32:45', NULL),
(1099, 'en', 'hello_i_am_ai_vision_and_im_image_expert_hi_i_am_image_experti_will_help_you_to_understand_your_images', 'Hello! I am AI Vision, and I\'m Image Expert. Hi, I am Image Expert.I will help you to understand your images.', '2025-05-03 22:54:03', '2025-05-03 22:54:03', NULL),
(1100, 'en', 'please_select_image', 'Please select Image', '2025-05-03 22:54:25', '2025-05-03 22:54:25', NULL),
(1101, 'en', 'website_footer_configuration', 'Website Footer Configuration', '2025-05-03 23:18:03', '2025-05-03 23:18:03', NULL),
(1102, 'en', 'select_quick_link_pages', 'Select quick link pages', '2025-05-03 23:18:03', '2025-05-03 23:18:03', NULL),
(1103, 'en', 'copyright_text', 'Copyright Text', '2025-05-03 23:18:03', '2025-05-03 23:18:03', NULL),
(1104, 'en', 'footer_configuration', 'Footer Configuration', '2025-05-03 23:18:03', '2025-05-03 23:18:03', NULL),
(1105, 'en', 'what_is_the_name_of_the_product', 'What is the name of the product?', '2025-05-03 23:19:57', '2025-05-03 23:19:57', NULL),
(1106, 'en', 'eg_iphone_14_pro', 'e.g. iPhone 14 Pro', '2025-05-03 23:19:57', '2025-05-03 23:19:57', NULL),
(1107, 'en', 'ai_keys_support_model', 'AI Keys Support Model', '2025-05-04 02:41:03', '2025-05-04 02:41:03', NULL),
(1108, 'en', 'ai_fine_tune_jobs', 'AI Fine Tune Jobs', '2025-05-04 02:41:03', '2025-05-04 02:41:03', NULL),
(1109, 'en', 'update_system', 'Update System', '2025-05-04 02:41:03', '2025-05-04 02:41:03', NULL),
(1110, 'en', 'update_your_application', 'Update Your Application', '2025-05-04 02:41:10', '2025-05-04 02:41:10', NULL),
(1111, 'en', 'your_ai_model_fine_tune', 'Your Ai Model (Fine Tune)', '2025-05-04 02:41:10', '2025-05-04 02:41:10', NULL),
(1112, 'en', 'model', 'Model', '2025-05-04 02:41:11', '2025-05-04 02:41:11', NULL),
(1113, 'en', 'one_click_update', 'One Click Update', '2025-05-04 02:41:11', '2025-05-04 02:41:11', NULL),
(1114, 'en', 'finetune', 'Fine-Tune', '2025-05-04 02:41:11', '2025-05-04 02:41:11', NULL),
(1115, 'en', 'manual_update', 'Manual Update', '2025-05-04 02:41:11', '2025-05-04 02:41:11', NULL),
(1116, 'en', 'new_fine_tune', 'New Fine Tune', '2025-05-04 02:41:12', '2025-05-04 02:41:12', NULL),
(1117, 'en', 'update_file_zip', 'Update File (Zip)', '2025-05-04 02:41:13', '2025-05-04 02:41:13', NULL),
(1118, 'en', 'ft_job', 'FT. Job', '2025-05-04 02:41:13', '2025-05-04 02:41:13', NULL),
(1119, 'en', 'your_version', 'Your Version', '2025-05-04 02:41:13', '2025-05-04 02:41:13', NULL),
(1120, 'en', 'organization_id', 'Organization ID', '2025-05-04 02:41:13', '2025-05-04 02:41:13', NULL),
(1121, 'en', 'latest_version', 'Latest Version', '2025-05-04 02:41:14', '2025-05-04 02:41:14', NULL),
(1122, 'en', 'training_file', 'Training File', '2025-05-04 02:41:14', '2025-05-04 02:41:14', NULL),
(1123, 'en', 'view_changelog', 'View Changelog', '2025-05-04 02:41:14', '2025-05-04 02:41:14', NULL),
(1124, 'en', 'errors', 'Errors', '2025-05-04 02:41:15', '2025-05-04 02:41:15', NULL),
(1125, 'en', 'update_now', 'Update Now', '2025-05-04 02:41:15', '2025-05-04 02:41:15', NULL),
(1126, 'en', 'check_compatibility', 'Check Compatibility', '2025-05-04 02:41:16', '2025-05-04 02:41:16', NULL),
(1127, 'en', 'allowed_file_types_', 'Allowed file types: ', '2025-05-04 02:41:16', '2025-05-04 02:41:16', NULL),
(1128, 'en', 'blog_categories', 'Blog Categories', '2025-05-04 02:41:19', '2025-05-04 02:41:19', NULL),
(1129, 'en', 'add_new_blog_category', 'Add New Blog Category', '2025-05-04 02:41:19', '2025-05-04 02:41:19', NULL),
(1130, 'en', 'twilio_credentials', 'Twilio Credentials', '2025-05-04 09:37:10', '2025-05-04 09:37:10', NULL),
(1131, 'en', 'twilio_sid', 'Twilio SID', '2025-05-04 09:37:10', '2025-05-04 09:37:10', NULL),
(1132, 'en', 'twilio_auth_token', 'Twilio Auth Token', '2025-05-04 09:37:10', '2025-05-04 09:37:10', NULL),
(1133, 'en', 'valid_twilo_number', 'Valid Twilo Number', '2025-05-04 09:37:10', '2025-05-04 09:37:10', NULL),
(1134, 'en', 'active_sms_gateway', 'Active SMS Gateway', '2025-05-04 09:37:10', '2025-05-04 09:37:10', NULL),
(1135, 'en', 'select_sms_gateway', 'Select SMS gateway', '2025-05-04 09:37:10', '2025-05-04 09:37:10', NULL),
(1136, 'en', 'twilio', 'Twilio', '2025-05-04 09:37:10', '2025-05-04 09:37:10', NULL),
(1137, 'en', 'short_name', 'Short Name', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1138, 'en', 'pwa', 'PWA', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1139, 'en', 'background_color', 'Background Color', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1140, 'en', 'theme_color', 'Theme Color', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1141, 'en', 'status_bar', 'Status Bar', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1142, 'en', '72x72', '72x72', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1143, 'en', '96x96', '96x96', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1144, 'en', '128x128', '128x128', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1145, 'en', '144x144', '144x144', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1146, 'en', '152x152', '152x152', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1147, 'en', '192x192', '192x192', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1148, 'en', '384x384', '384x384', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1149, 'en', '512x512', '512x512', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1150, 'en', 'setup', 'Setup', '2025-05-04 09:49:55', '2025-05-04 09:49:55', NULL),
(1151, 'en', 'page_has_been_updated_successfully', 'Page has been updated successfully', '2025-05-04 13:22:25', '2025-05-04 13:22:25', NULL),
(1152, 'en', 'website_homepage_configuration', 'Website Homepage Configuration', '2025-05-04 13:23:36', '2025-05-04 13:23:36', NULL),
(1153, 'en', 'hero_section_configuration', 'Hero Section Configuration', '2025-05-04 13:23:39', '2025-05-04 13:23:39', NULL),
(1154, 'en', 'hero', 'Hero', '2025-05-04 13:23:42', '2025-05-04 13:23:42', NULL),
(1155, 'en', 'hero_information', 'Hero Information', '2025-05-04 13:23:45', '2025-05-04 13:23:45', NULL),
(1156, 'en', 'sub_title', 'Sub Title', '2025-05-04 13:23:47', '2025-05-04 13:23:47', NULL),
(1157, 'en', 'sub_title_button_text', 'Sub Title Button Text', '2025-05-04 13:23:49', '2025-05-04 13:23:49', NULL),
(1158, 'en', 'sub_title_button_link', 'Sub Title Button Link', '2025-05-04 13:23:52', '2025-05-04 13:23:52', NULL),
(1159, 'en', 'sroll_to_top_image', 'Sroll to Top Image', '2025-05-04 13:23:54', '2025-05-04 13:23:54', NULL),
(1160, 'en', 'choose_scroll_to_top_image', 'Choose Scroll to Top Image', '2025-05-04 13:23:57', '2025-05-04 13:23:57', NULL),
(1161, 'en', 'video_information', 'Video Information', '2025-05-04 13:24:01', '2025-05-04 13:24:01', NULL),
(1162, 'en', 'video', 'Video', '2025-05-04 13:24:03', '2025-05-04 13:24:03', NULL),
(1163, 'en', 'homepage_configuration', 'Homepage Configuration', '2025-05-04 13:24:06', '2025-05-04 13:24:06', NULL),
(1164, 'en', 'hero_section', 'Hero Section', '2025-05-04 13:24:08', '2025-05-04 13:24:08', NULL),
(1165, 'en', 'feature_category', 'Feature Category', '2025-05-04 13:24:10', '2025-05-04 13:24:10', NULL),
(1166, 'en', 'feature__category_detail', 'Feature  Category Detail', '2025-05-04 13:24:13', '2025-05-04 13:24:13', NULL),
(1167, 'en', 'feature_tools', 'Feature Tools', '2025-05-04 13:24:15', '2025-05-04 13:24:15', NULL),
(1168, 'en', 'ai_image_generator', 'AI Image Generator', '2025-05-04 13:24:18', '2025-05-04 13:24:18', NULL),
(1169, 'en', 'image_section', 'Image Section', '2025-05-04 13:24:20', '2025-05-04 13:24:20', NULL),
(1170, 'en', 'feature__integration', 'Feature  Integration', '2025-05-04 13:24:22', '2025-05-04 13:24:22', NULL),
(1171, 'en', 'client_feedback', 'Client Feedback', '2025-05-04 13:24:24', '2025-05-04 13:24:24', NULL),
(1172, 'en', 'cta_section', 'CTA Section', '2025-05-04 13:24:27', '2025-05-04 13:24:27', NULL),
(1173, 'en', 'social_media_link', 'Social Media Link', '2025-05-04 13:24:29', '2025-05-04 13:24:29', NULL),
(1174, 'en', 'actived', 'Actived', '2025-05-04 13:37:22', '2025-05-04 13:37:22', NULL),
(1175, 'en', 'active_now', 'Active Now', '2025-05-04 13:37:24', '2025-05-04 13:37:24', NULL),
(1176, 'en', 'active_storage', 'Active Storage', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1177, 'en', 'storage', 'Storage', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1178, 'en', 'amazon_web_services', 'Amazon Web Services', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1179, 'en', 'aws_access_key', 'AWS Access Key', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1180, 'en', 'aws_secret_access_key', 'AWS Secret Access Key', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1181, 'en', 'aws_s3_bucket_name', 'AWS S3 Bucket Name', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1182, 'en', 'aws_region', 'AWS Region', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1183, 'en', 'save_aws_configuration', 'Save AWS Configuration', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1184, 'en', 'configure_storage_manager', 'Configure Storage Manager', '2025-05-04 13:38:54', '2025-05-04 13:38:54', NULL),
(1185, 'en', 'active_this_package_now_', 'Active This Package Now ', '2025-05-04 13:48:18', '2025-05-04 13:48:18', NULL),
(1186, 'en', 'admin_assign_package_for_you', 'Admin Assign Package For You', '2025-05-04 13:48:43', '2025-05-04 13:48:43', NULL),
(1187, 'en', 'package_has_been_assigned_successfully', 'Package has been assigned successfully', '2025-05-04 13:48:43', '2025-05-04 13:48:43', NULL),
(1188, 'en', 'start_date__end_date', 'Start date - End date', '2025-05-04 13:49:01', '2025-05-04 13:49:01', NULL),
(1189, 'en', 'select_user', 'Select User', '2025-05-04 13:49:01', '2025-05-04 13:49:01', NULL),
(1190, 'en', 'select_template', 'Select Template', '2025-05-04 13:49:01', '2025-05-04 13:49:01', NULL),
(1191, 'en', 'total_words', 'Total Words', '2025-05-04 13:49:01', '2025-05-04 13:49:01', NULL),
(1192, 'en', 'generated_on', 'Generated On', '2025-05-04 13:49:01', '2025-05-04 13:49:01', NULL),
(1193, 'en', 'template', 'Template', '2025-05-04 13:49:01', '2025-05-04 13:49:01', NULL),
(1194, 'en', 'product_description', 'Product Description', '2025-05-04 13:49:01', '2025-05-04 13:49:01', NULL),
(1195, 'en', 'follow_up_email', 'Follow Up Email', '2025-05-04 13:49:01', '2025-05-04 13:49:01', NULL),
(1196, 'en', 'chat_id__', 'Chat ID : ', '2025-05-04 14:02:40', '2025-05-04 14:02:40', NULL),
(1197, 'en', 'write_a_content_based_on_pdf_', 'Write a content based on pdf ', '2025-05-04 14:02:40', '2025-05-04 14:02:40', NULL),
(1198, 'en', 'select_pdf_file', 'Select PDF File', '2025-05-04 14:02:40', '2025-05-04 14:02:40', NULL),
(1199, 'en', 'ai_pdf_chat_has_been_stopped', 'Ai Pdf Chat has been stopped.', '2025-05-04 14:02:40', '2025-05-04 14:02:40', NULL),
(1200, 'en', 'your_eleven_lab_api_not_connected__please_connect_api_from_voice_settings', 'Your Eleven Lab API not connected ! Please connect API From Voice Settings', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1201, 'en', 'generate_text_to_speech', 'Generate Text To Speech', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1202, 'en', 'voice', 'Voice', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1203, 'en', 'stability', 'Stability', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1204, 'en', 'increasing_variability_can_make_speech_more_expressive_with_output_varying_between_regenerationsit_can_also_lead_to_instabilities', 'Increasing variability can make speech more expressive with output varying between re-generations.It can also lead to instabilities.', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1205, 'en', 'more_variable', 'More variable', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1206, 'en', 'increasing_stability_will_make_the_voice_more_consistent_between_regenerations_but_it_can_also_make_it_sounds_a_bit_monotoneon_longer_text_fragments_we_recommend_lowering_this_value', 'Increasing stability will make the voice more consistent between re-generations, but it can also make it sounds a bit monotone.On longer text fragments we recommend lowering this value.', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1207, 'en', 'more_stable', 'More stable', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1208, 'en', 'clarity__similarity_enhancement', 'Clarity + Similarity Enhancement', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1209, 'en', 'low__values_are_recommended_if_background_artifacts_are_present_in_generated_speech', 'Low  Values are recommended if background artifacts are present in generated speech.', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1210, 'en', 'high_enhancement_boosts_overall_voice_clarity_and_target_speaker_similarityvery_high_values_can_cause_artifacts_so_adjusting_this_setting_to_find_the_optimal_value_is_encouraged', 'High enhancement boosts overall voice clarity and target speaker similarity.Very high values can cause artifacts, so adjusting this setting to find the optimal value is encouraged.', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1211, 'en', 'style_exaggeration', 'Style Exaggeration', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1212, 'en', 'hight_values_are_recommended_if_the_style_of_the_speech_should_be_exaggerated_compared_to_the_uploaded_audiohigher_values_can_lead_to_more_instability_in_the_generated_speechsetting_this_to_00_will_greatly_increase_generation_speed_and_is_the_deafult_setting', 'Hight Values are recommended if the style of the speech should be exaggerated compared to the uploaded audio.Higher values can lead to more instability in the generated speech.Setting this to 0.0 will greatly increase generation speed and is the deafult setting.', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1213, 'en', 'exaggerated', 'Exaggerated', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1214, 'en', 'speaker_boost', 'Speaker Boost', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1215, 'en', 'boost_the_similarity_of_the_synthesized_speech_and_the_voice_at_the_cost_of_some_generation_speed', 'Boost the similarity of the synthesized speech and the voice at the cost of some generation speed', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1216, 'en', 'type_your_text', 'Type your Text', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1217, 'en', 'total_quota_remaining', 'Total quota remaining', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1218, 'en', 'generate', 'Generate', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1219, 'en', 'generated_speeches', 'Generated Speeches', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1220, 'en', 'date', 'Date', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1221, 'en', 'play', 'Play', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1222, 'en', 'content_exceeds_limit', 'Content exceeds limit', '2025-05-04 14:03:30', '2025-05-04 14:03:30', NULL),
(1223, 'en', 'about_what_is_your_post', 'About what is your post?', '2025-05-04 14:33:51', '2025-05-04 14:33:51', NULL),
(1224, 'en', 'eg_going_to_watch_the_champions_league_final', 'e.g. Going to watch the champions league final', '2025-05-04 14:33:52', '2025-05-04 14:33:52', NULL),
(1225, 'en', 'welcome_email', 'Welcome Email', '2025-05-04 14:34:25', '2025-05-04 14:34:25', NULL),
(1226, 'en', 'operation_failed_you_cant_purchase_more_than_2_package', 'Operation Failed. You Can\'t Purchase More Than 2 package', '2025-05-04 14:39:04', '2025-05-04 14:39:04', NULL),
(1227, 'en', 'add_new_expert', 'Add New Expert', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1228, 'en', 'experts', 'Experts', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1229, 'en', 'add_expert', 'Add Expert', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1230, 'en', 'expert_name', 'Expert Name', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1231, 'en', 'type_expert_name', 'Type expert name', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1232, 'en', 'character_name', 'Character Name', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1233, 'en', 'type_character_name', 'Type character name', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1234, 'en', 'short_description', 'Short Description', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1235, 'en', 'type_role', 'Type role', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1236, 'en', 'expertise', 'Expertise', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1237, 'en', 'i_will_assist_you_to_generate_better_content', 'I will assist you to generate better content', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1238, 'en', 'train_expert', 'Train Expert', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1239, 'en', 'generate_test_data', 'Generate Test Data', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1240, 'en', 'avatar_image', 'Avatar Image', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1241, 'en', 'choose_avatar', 'Choose Avatar', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1242, 'en', 'save_expert', 'Save Expert', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1243, 'en', 'expert_information', 'Expert Information', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1244, 'en', 'avatar', 'Avatar', '2025-05-05 12:11:24', '2025-05-05 12:11:24', NULL),
(1245, 'en', 'your_message_has_been_sent', 'Your message has been sent', '2025-05-05 21:45:03', '2025-05-05 21:45:03', NULL),
(1246, 'en', 'prompt_group_has_been_added_successfully', 'Prompt group has been added successfully', '2025-05-11 15:10:23', '2025-05-11 15:10:23', NULL),
(1247, 'en', 'quora_answer', 'quora answer', '2025-05-11 15:10:24', '2025-05-11 15:10:24', NULL),
(1248, 'en', 'prompt_has_been_added_successfully', 'Prompt has been added successfully', '2025-05-11 15:19:12', '2025-05-11 15:19:12', NULL),
(1249, 'en', 'expert_has_been_added_successfully', 'Expert has been added successfully', '2025-05-11 15:25:00', '2025-05-11 15:25:00', NULL),
(1250, 'en', 'hello_i_am_quora_answer_and_im_owner_i_will_assist_you_to_generate_better_content_for_quora_with_high_readability_a_natural_tone_and_smart_promotional_strategy', 'Hello! I am quora answer, and I\'m owner. I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy..', '2025-05-11 15:28:20', '2025-05-11 15:28:20', NULL),
(1251, 'en', 'update_expert', 'Update Expert', '2025-05-11 15:36:51', '2025-05-11 15:36:51', NULL),
(1252, 'en', 'blog_information', 'Blog Information', '2025-05-11 15:36:51', '2025-05-11 15:36:51', NULL),
(1253, 'en', 'expert_has_been_updated_successfully', 'Expert has been updated successfully', '2025-05-11 15:38:42', '2025-05-11 15:38:42', NULL),
(1254, 'en', 'update_profile', 'Update Profile', '2025-05-11 15:59:46', '2025-05-11 15:59:46', NULL),
(1255, 'en', 'type_your_name', 'Type your name', '2025-05-11 15:59:46', '2025-05-11 15:59:46', NULL),
(1256, 'en', 'type_your_phone', 'Type your phone', '2025-05-11 15:59:46', '2025-05-11 15:59:46', NULL),
(1257, 'en', 'type_password', 'Type password', '2025-05-11 15:59:46', '2025-05-11 15:59:46', NULL),
(1258, 'en', 'retype_password', 'Re-type password', '2025-05-11 15:59:46', '2025-05-11 15:59:46', NULL),
(1259, 'en', 'user_information', 'User Information', '2025-05-11 15:59:46', '2025-05-11 15:59:46', NULL),
(1260, 'en', 'create_auto_renew_subscription_product_for_paypal', 'Create Auto Renew Subscription Product For Paypal', '2025-05-11 16:01:30', '2025-05-11 16:01:30', NULL),
(1261, 'en', 'packages', 'Packages', '2025-05-11 16:01:30', '2025-05-11 16:01:30', NULL),
(1262, 'en', 'submit', 'Submit', '2025-05-11 16:01:30', '2025-05-11 16:01:30', NULL),
(1263, 'en', 'auto_renew_subscription_plans_for_paypal', 'Auto Renew Subscription Plans For Paypal', '2025-05-11 16:01:30', '2025-05-11 16:01:30', NULL),
(1264, 'en', 'plan_id', 'Plan ID', '2025-05-11 16:01:30', '2025-05-11 16:01:30', NULL),
(1265, 'en', 'product_id', 'Product ID', '2025-05-11 16:01:30', '2025-05-11 16:01:30', NULL),
(1266, 'en', 'auto_renew_subscriptions_product', 'Auto Renew Subscriptions Product', '2025-05-11 16:01:30', '2025-05-11 16:01:30', NULL),
(1267, 'en', 'auto_renew_subscriptions_plans', 'Auto Renew Subscriptions Plans', '2025-05-11 16:01:30', '2025-05-11 16:01:30', NULL),
(1268, 'en', 'remaining_speech_to_text', 'Remaining Speech to Text', '2025-05-11 16:02:50', '2025-05-11 16:02:50', NULL),
(1269, 'en', 'type_text_title', 'Type Text Title', '2025-05-11 16:02:51', '2025-05-11 16:02:51', NULL),
(1270, 'en', 'upload_audio_file', 'Upload Audio File', '2025-05-11 16:02:53', '2025-05-11 16:02:53', NULL),
(1271, 'en', 'max_size_', 'Max Size: ', '2025-05-11 16:02:54', '2025-05-11 16:02:54', NULL),
(1272, 'en', 'hello_i_am_quora_answer_and_im_friendly_writer_i_will_assist_you_to_generate_better_content_for_quora_with_high_readability_a_natural_tone_and_smart_promotional_strategy', 'Hello! I am quora answer, and I\'m Friendly writer. I will assist you to generate better content for Quora with high readability, a natural tone, and smart promotional strategy..', '2025-05-11 16:04:11', '2025-05-11 16:04:11', NULL),
(1273, 'en', 'enable_voice_over', 'Enable Voice Over', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1274, 'en', 'select_voice_over', 'Select Voice Over', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1275, 'en', 'google_tts_settings', 'Google TTS Settings', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1276, 'en', 'documentation', 'Documentation', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1277, 'en', 'gcs_file_json', 'GCS File (JSON)', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1278, 'en', 'gcs_project_name', 'GCS Project Name', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1279, 'en', 'type_gcs_project_name', 'Type GCS Project Name', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1280, 'en', 'maximum_characters', 'Maximum characters', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1281, 'en', 'if_not_give_any_input_maximum_unlimited', 'if not give any input maximum unlimited', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1282, 'en', 'save_configurations', 'Save Configurations', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1283, 'en', 'azure_voiceover_settings', 'Azure Voiceover Settings', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1284, 'en', 'azure_key', 'Azure Key', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1285, 'en', 'type_azure_key', 'Type Azure Key', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1286, 'en', 'azure_region', 'Azure Region', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1287, 'en', 'type_azure_region', 'Type Azure Region', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1288, 'en', 'eleven_labs_voiceover_settings', 'ELEVEN LABS Voiceover Settings', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1289, 'en', 'eleven_labs_api_key', 'ELEVEN LABS API KEY', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1290, 'en', 'type_eleven_labs_api_key', 'Type Eleven Labs Api Key', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1291, 'en', 'open_ai_text_to_speech_settings', 'Open Ai Text To Speech Settings', '2025-05-11 17:01:12', '2025-05-11 17:01:12', NULL),
(1292, 'en', 'if_not_give_any_input_maximum_4096_characters', 'if not give any input maximum 4096 characters', '2025-05-11 17:01:13', '2025-05-11 17:01:13', NULL),
(1293, 'en', 'voice_setting', 'Voice Setting', '2025-05-11 17:01:13', '2025-05-11 17:01:13', NULL),
(1294, 'en', 'google_tts', 'Google TTS', '2025-05-11 17:01:13', '2025-05-11 17:01:13', NULL),
(1295, 'en', 'azure_voiceover', 'Azure Voiceover', '2025-05-11 17:01:13', '2025-05-11 17:01:13', NULL),
(1296, 'en', 'open_ai', 'Open AI', '2025-05-11 17:01:13', '2025-05-11 17:01:13', NULL),
(1297, 'en', 'generate_successfully', 'Generate Successfully', '2025-05-11 17:14:11', '2025-05-11 17:14:11', NULL),
(1298, 'en', 'download', 'Download', '2025-05-11 17:14:12', '2025-05-11 17:14:12', NULL),
(1299, 'en', 'select_the_model', 'Select the Model', '2025-05-11 17:33:06', '2025-05-11 17:33:06', NULL),
(1300, 'en', 'select_the_voice', 'Select the voice', '2025-05-11 17:33:06', '2025-05-11 17:33:06', NULL),
(1301, 'en', 'speed', 'Speed', '2025-05-11 17:33:06', '2025-05-11 17:33:06', NULL),
(1302, 'en', 'speech_speed', 'Speech Speed', '2025-05-11 17:33:06', '2025-05-11 17:33:06', NULL),
(1303, 'en', 'response_format', 'Response Format', '2025-05-11 17:33:06', '2025-05-11 17:33:06', NULL),
(1304, 'en', 'select_the_break_time', 'Select the break time', '2025-05-11 17:33:06', '2025-05-11 17:33:06', NULL),
(1305, 'en', 'generate_speech', 'Generate Speech', '2025-05-11 17:33:06', '2025-05-11 17:33:06', NULL),
(1306, 'en', 'language', 'Language', '2025-05-11 17:33:06', '2025-05-11 17:33:06', NULL),
(1307, 'en', 'speech_generate_successfully', 'Speech generate Successfully', '2025-05-11 17:33:33', '2025-05-11 17:33:33', NULL),
(1308, 'en', 'remove_all_data', 'Remove all data', '2025-05-11 17:37:49', '2025-05-11 17:37:49', NULL),
(1309, 'en', 'delete_all', 'Delete All', '2025-05-11 17:37:49', '2025-05-11 17:37:49', NULL),
(1310, 'en', 'issue', 'Issue', '2025-05-11 17:37:49', '2025-05-11 17:37:49', NULL),
(1311, 'en', 'message', 'Message', '2025-05-11 17:37:49', '2025-05-11 17:37:49', NULL),
(1312, 'en', 'mark_as_read', 'Mark As Read', '2025-05-11 17:37:49', '2025-05-11 17:37:49', NULL),
(1313, 'en', 'reply_in_email', 'Reply in Email', '2025-05-11 17:37:49', '2025-05-11 17:37:49', NULL),
(1314, 'en', 'operation_failed_user_can_not_have_more_than_2_packages', 'Operation Failed. User Can Not Have More Than 2 packages', '2025-05-12 01:33:54', '2025-05-12 01:33:54', NULL),
(1315, 'en', 'all_notification_read_successfully', 'All Notification Read Successfully', '2025-05-12 01:45:56', '2025-05-12 01:45:56', NULL),
(1316, 'en', 'notification', 'Notification', '2025-05-12 01:45:57', '2025-05-12 01:45:57', NULL),
(1317, 'en', 'url', 'URL', '2025-05-12 01:45:57', '2025-05-12 01:45:57', NULL),
(1318, 'en', 'is_read', 'Is read', '2025-05-12 01:45:57', '2025-05-12 01:45:57', NULL),
(1319, 'en', 'click', 'Click', '2025-05-12 01:45:57', '2025-05-12 01:45:57', NULL),
(1320, 'en', 'mark_as_unread', 'Mark As Unread', '2025-05-12 01:45:57', '2025-05-12 01:45:57', NULL),
(1321, 'en', 'hello_i_am_flossie_cardoza_and_im_mbbs_doctor_i_will_help_you_to_have_a_healthy_life', 'Hello! I am Flossie Cardoza, and I\'m MBBS Doctor. I will help you to have a healthy life.', '2025-05-12 01:47:58', '2025-05-12 01:47:58', NULL),
(1322, 'en', 'package_active_successfully', 'Package Active successfully', '2025-05-12 09:16:45', '2025-05-12 09:16:45', NULL),
(1323, 'en', 'na', 'n/a', '2025-05-13 10:37:59', '2025-05-13 10:37:59', NULL),
(1324, 'en', 'social_login_configurations', 'Social Login Configurations', '2025-05-13 14:12:08', '2025-05-13 14:12:08', NULL),
(1325, 'en', 'google_login', 'Google Login', '2025-05-13 14:12:10', '2025-05-13 14:12:10', NULL),
(1326, 'en', 'google_client_id', 'Google Client ID', '2025-05-13 14:12:12', '2025-05-13 14:12:12', NULL),
(1327, 'en', 'google_client_id', 'Google Client ID', '2025-05-13 14:12:12', '2025-05-13 14:12:12', NULL),
(1328, 'en', 'google_client_secret', 'Google Client Secret', '2025-05-13 14:12:13', '2025-05-13 14:12:13', NULL),
(1329, 'en', 'google_redirect_url', 'Google Redirect Url', '2025-05-13 14:12:15', '2025-05-13 14:12:15', NULL),
(1330, 'en', 'google_redirect_url', 'Google Redirect Url', '2025-05-13 14:12:15', '2025-05-13 14:12:15', NULL),
(1331, 'en', 'google_callback_url', 'Google Callback Url', '2025-05-13 14:12:18', '2025-05-13 14:12:18', NULL),
(1332, 'en', 'google_callback_url', 'Google Callback Url', '2025-05-13 14:12:18', '2025-05-13 14:12:18', NULL),
(1333, 'en', 'facebook_login', 'Facebook Login', '2025-05-13 14:12:19', '2025-05-13 14:12:19', NULL),
(1334, 'en', 'facebook_app_id', 'Facebook App ID', '2025-05-13 14:12:20', '2025-05-13 14:12:20', NULL),
(1335, 'en', 'facebook_app_secret', 'Facebook App Secret', '2025-05-13 14:12:21', '2025-05-13 14:12:21', NULL),
(1336, 'en', 'facebook_redirect_url', 'Facebook Redirect Url', '2025-05-13 14:12:22', '2025-05-13 14:12:22', NULL),
(1337, 'en', 'facebook_callback_url', 'Facebook Callback Url', '2025-05-13 14:12:22', '2025-05-13 14:12:22', NULL),
(1338, 'en', 'faccebook_login', 'Faccebook Login', '2025-05-13 14:12:23', '2025-05-13 14:12:23', NULL),
(1339, 'en', 'update_ads', 'Update Ads', '2025-05-13 15:19:49', '2025-05-13 15:19:49', NULL),
(1340, 'en', 'adsense_information', 'AdSense Information', '2025-05-13 15:19:49', '2025-05-13 15:19:49', NULL),
(1341, 'en', 'command', 'Command', '2025-05-13 15:20:05', '2025-05-13 15:20:05', NULL),
(1342, 'en', 'example', 'Example', '2025-05-13 15:20:05', '2025-05-13 15:20:05', NULL),
(1343, 'en', 'code_prefix', 'Code Prefix', '2025-05-13 15:20:25', '2025-05-13 15:20:25', NULL),
(1344, 'en', 'code_prefix_start', 'Code Prefix Start', '2025-05-13 15:20:25', '2025-05-13 15:20:25', NULL),
(1345, 'en', 'thanks_message', 'Thanks Message', '2025-05-13 15:20:25', '2025-05-13 15:20:25', NULL),
(1346, 'en', 'add_new_role', 'Add New Role', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1347, 'en', 'new_role', 'New Role', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1348, 'en', 'role_name', 'Role Name', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1349, 'en', 'type_role_name', 'Type role name', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1350, 'en', 'permissions', 'Permissions', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1351, 'en', 'select_all', 'Select All', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1352, 'en', 'select_all_of', 'Select all of', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1353, 'en', 'subscriptions_histories', 'Subscriptions Histories', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1354, 'en', 'add_folders', 'Add Folders', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1355, 'en', 'favorites_templates', 'Favorites Templates', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1356, 'en', 'text_to_speech_eleven_labs', 'Text To Speech Eleven Labs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1357, 'en', 'fine_tune', 'Fine Tune', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1358, 'en', 'ban_customers', 'Ban Customers', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1359, 'en', 'all_staffs', 'All Staffs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL);
INSERT INTO `localizations` (`id`, `lang_key`, `t_key`, `t_value`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1360, 'en', 'add_staffs', 'Add Staffs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1361, 'en', 'edit_staffs', 'Edit Staffs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1362, 'en', 'delete_staffs', 'Delete Staffs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1363, 'en', 'own_staff', 'Own Staff', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1364, 'en', 'contact_us_messages', 'Contact Us Messages', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1365, 'en', 'add_tags', 'Add Tags', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1366, 'en', 'edit_tags', 'Edit Tags', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1367, 'en', 'delete_tags', 'Delete Tags', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1368, 'en', 'add_blogs', 'Add Blogs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1369, 'en', 'edit_blogs', 'Edit Blogs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1370, 'en', 'publish_blogs', 'Publish Blogs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1371, 'en', 'delete_blogs', 'Delete Blogs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1372, 'en', 'add_blog_categories', 'Add Blog Categories', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1373, 'en', 'edit_blog_categories', 'Edit Blog Categories', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1374, 'en', 'delete_blog_categories', 'Delete Blog Categories', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1375, 'en', 'add_pages', 'Add Pages', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1376, 'en', 'edit_pages', 'Edit Pages', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1377, 'en', 'delete_pages', 'Delete Pages', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1378, 'en', 'faqs', 'Faqs', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1379, 'en', 'add_media', 'Add Media', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1380, 'en', 'delete_media', 'Delete Media', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1381, 'en', 'delete_subscribers', 'Delete Subscribers', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1382, 'en', 'multiopenai', 'MultiOpenAi', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1383, 'en', 'add_multiopenai', 'Add MultiOpenAi', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1384, 'en', 'edit_multiopenai', 'Edit MultiOpenAi', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1385, 'en', 'status_multiopenai', 'Status MultiOpenAi', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1386, 'en', 'delete_multiopenai', 'Delete MultiOpenAi', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1387, 'en', 'about_us_page', 'About Us Page', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1388, 'en', 'roles_and_permissions', 'Roles And Permissions', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1389, 'en', 'add_roles_and_permissions', 'Add Roles And Permissions', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1390, 'en', 'edit_roles_and_permissions', 'Edit Roles And Permissions', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1391, 'en', 'delete_roles_and_permissions', 'Delete Roles And Permissions', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1392, 'en', 'currency_settings', 'Currency Settings', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1393, 'en', 'add_currency', 'Add Currency', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1394, 'en', 'edit_currency', 'Edit Currency', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1395, 'en', 'publish_currency', 'Publish Currency', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1396, 'en', 'language_settings', 'Language Settings', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1397, 'en', 'add_languages', 'Add Languages', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1398, 'en', 'edit_languages', 'Edit Languages', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1399, 'en', 'publish_languages', 'Publish Languages', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1400, 'en', 'translate_languages', 'Translate Languages', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1401, 'en', 'payment_settings', 'Payment Settings', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1402, 'en', 'default_currency', 'Default Currency', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1403, 'en', 'social_login_settings', 'Social Login Settings', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1404, 'en', 'affiliate_withdraw', 'Affiliate Withdraw', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1405, 'en', 'affiliate_earning_histories', 'Affiliate Earning Histories', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1406, 'en', 'affiliate_payment_histories', 'Affiliate Payment Histories', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1407, 'en', 'report', 'Report', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1408, 'en', 's2t_report', 'S2t Report', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1409, 'en', 'offline_payment_methods', 'Offline Payment Methods', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1410, 'en', 'add_offline_payment_methods', 'Add Offline Payment Methods', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1411, 'en', 'edit_offline_payment_methods', 'Edit Offline Payment Methods', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1412, 'en', 'delete_offline_payment_methods', 'Delete Offline Payment Methods', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1413, 'en', 'all_payment_request', 'All Payment Request', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1414, 'en', 'approve_payment_request', 'Approve Payment Request', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1415, 'en', 'reject_payment_request', 'Reject Payment Request', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1416, 'en', 'add_note_payment_request', 'Add Note Payment Request', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1417, 'en', 'blog_wizard', 'Blog Wizard', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1418, 'en', 'supports', 'Supports', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1419, 'en', 'support_category', 'Support Category', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1420, 'en', 'support_priority', 'Support Priority', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1421, 'en', 'plagiarism', 'Plagiarism', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1422, 'en', 'add_content_detectors', 'Add Content Detectors', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1423, 'en', 'add_content_plagiarism', 'Add Content Plagiarism', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1424, 'en', 'save_role', 'Save Role', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1425, 'en', 'role_information', 'Role Information', '2025-05-13 15:59:36', '2025-05-13 15:59:36', NULL),
(1426, 'en', 'new_role_has_been_added_successfully', 'New Role has been added successfully', '2025-05-13 16:02:35', '2025-05-13 16:02:35', NULL),
(1427, 'en', 'update_customer', 'Update Customer', '2025-05-13 16:04:46', '2025-05-13 16:04:46', NULL),
(1428, 'en', 'customer_email', 'Customer Email', '2025-05-13 16:04:46', '2025-05-13 16:04:46', NULL),
(1429, 'en', 'type_customer_email', 'Type Customer email', '2025-05-13 16:04:46', '2025-05-13 16:04:46', NULL),
(1430, 'en', 'customer_phone', 'Customer Phone', '2025-05-13 16:04:46', '2025-05-13 16:04:46', NULL),
(1431, 'en', 'type_customer_phone', 'Type Customer phone', '2025-05-13 16:04:46', '2025-05-13 16:04:46', NULL),
(1432, 'en', 'save_customer', 'Save Customer', '2025-05-13 16:04:46', '2025-05-13 16:04:46', NULL),
(1433, 'en', 'affiliate_earnings', 'Affiliate Earnings', '2025-05-13 16:06:07', '2025-05-13 16:06:07', NULL),
(1434, 'en', 'referred_by', 'Referred By', '2025-05-13 16:06:07', '2025-05-13 16:06:07', NULL),
(1435, 'en', 'rate', 'Rate', '2025-05-13 16:06:07', '2025-05-13 16:06:07', NULL),
(1436, 'en', 'earning', 'Earning', '2025-05-13 16:06:07', '2025-05-13 16:06:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `media_managers`
--

CREATE TABLE `media_managers` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int DEFAULT NULL,
  `media_file` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `media_size` int DEFAULT NULL,
  `media_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'video / image / pdf / ...',
  `media_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `media_extension` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `media_managers`
--

INSERT INTO `media_managers` (`id`, `user_id`, `media_file`, `media_size`, `media_type`, `media_name`, `media_extension`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'uploads/media/aJ7wAo70bSOXLSXTvI4hhtBBSYpusjHSrKuGO0L7.png', 124065, 'image', 'bg-gradient.png', 'png', '2023-05-29 23:33:17', '2023-05-29 23:33:17', NULL),
(2, 1, 'uploads/media/WLWgVML58lHjPWtis3H1MSsCAy6LWuo1ZzPbBYcE.png', 205461, 'image', 'copy-publish.png', 'png', '2023-05-29 23:33:18', '2023-05-29 23:33:18', NULL),
(3, 1, 'uploads/media/OnAXEv6O8iK2S0SOvwrcK6gIevuH2Eg2xLXgQJ3g.jpg', 221760, 'image', 'feature-3.jpg', 'jpg', '2023-05-29 23:33:18', '2023-05-29 23:33:18', NULL),
(4, 1, 'uploads/media/JlMry90Z6zwsOssK0pLIDFmVKGxlxJ4zy4sxxEw8.jpg', 313808, 'image', 'feature-2.jpg', 'jpg', '2023-05-29 23:33:18', '2023-05-29 23:33:18', NULL),
(5, 1, 'uploads/media/g9DOLLnCDzgFjP5FMbCOcLg23Wh2T5S0DSqKjhh6.jpg', 282897, 'image', 'feature-1.jpg', 'jpg', '2023-05-29 23:33:18', '2023-05-29 23:33:18', NULL),
(6, 1, 'uploads/media/sNkOGJkxjsX53ITIdFp4m5CrgcOkwVnIHx9mVHe2.jpg', 286529, 'image', 'feature-4.jpg', 'jpg', '2023-05-29 23:33:18', '2023-05-29 23:33:18', NULL),
(7, 1, 'uploads/media/lOF5TPvuGPcU0HBFb4vyvE11lvXufZemYwZBSgPq.jpg', 458111, 'image', 'feature-top-2.jpg', 'jpg', '2023-05-29 23:33:19', '2023-05-29 23:33:19', NULL),
(8, 1, 'uploads/media/Kvvt9vH6u55udSDVevRdPjvRlTXLrSTjKTfORIrs.png', 264611, 'image', 'hero-img.png', 'png', '2023-05-29 23:33:19', '2023-05-29 23:33:19', NULL),
(9, 1, 'uploads/media/gDOTo2s8VY2P01XXBxQnvu61K5MlbuOcQ2DME2Za.png', 39931, 'image', 'hero-robot.png', 'png', '2023-05-29 23:33:19', '2023-05-29 23:33:19', NULL),
(10, 1, 'uploads/media/eQuDX4Xoxaopqzak7tXBZ12vw208b4ZU1DknerAE.png', 142328, 'image', 'select-advance-option.png', 'png', '2023-05-29 23:33:19', '2023-05-29 23:33:19', NULL),
(11, 1, 'uploads/media/eCu54yrdjXTNBt9IEdjnnkGjHOGD1xiXZJcDp6MK.png', 166740, 'image', 'select-template.png', 'png', '2023-05-29 23:33:19', '2023-05-29 23:33:19', NULL),
(12, 1, 'uploads/media/VHLlVTJb3sfnMtm5yCBo3vwBqqwVaKYeIeKdA9Mk.png', 173138, 'image', 'write-prompt.png', 'png', '2023-05-29 23:33:19', '2023-05-29 23:33:19', NULL),
(13, 1, 'uploads/media/tLTQLIFlP0I9v0lA1MYX5RlZfsDXxjQSbQSZ7cU0.png', 4319, 'image', 'favicon.png', 'png', '2023-05-29 23:34:25', '2023-05-29 23:34:25', NULL),
(14, 1, 'uploads/media/bwZeX0SwgEwevLfO0yCGNAvxkFq8vdlVAt6swLQX.png', 2496, 'image', 'logo-color.png', 'png', '2023-05-29 23:34:25', '2023-05-29 23:34:25', NULL),
(15, 1, 'uploads/media/TmrQOAsKTfTmPBmyJ4p5AvxWy4Ff76PLdP5O5Cd0.png', 2399, 'image', 'logo-white.png', 'png', '2023-05-29 23:34:25', '2023-05-29 23:34:25', NULL),
(16, 1, 'uploads/media/aUtenzo6i8hhJxcHl0n69ZFTZd0j10T9wcxXCt5C.png', 794, 'image', 'logo-icon.png', 'png', '2023-05-29 23:36:10', '2023-05-29 23:36:10', NULL),
(17, 1, 'uploads/media/PeegEpyC8yJKOncHmcFHO0FzZZflFp0vuM0lbXy3.png', 1650, 'image', 'logo.png', 'png', '2023-05-29 23:36:10', '2023-05-29 23:36:10', NULL),
(18, 1, 'uploads/media/lxkdLUhhClW2gS7lnGB2o0orGb9UwSn3bdvffnmF.png', 3100, 'image', 'brand-4.png', 'png', '2023-05-30 00:01:13', '2023-05-30 00:01:13', NULL),
(19, 1, 'uploads/media/88fdY65pfvVX8ikbEHJ96uaVm0XVbXQNAQugzEem.png', 2982, 'image', 'brand-3.png', 'png', '2023-05-30 00:01:13', '2023-05-30 00:01:13', NULL),
(20, 1, 'uploads/media/fp9a6rz9m8Up4sWGYOvUhnTdQPY6jRkt396xA48F.png', 3119, 'image', 'brand-5.png', 'png', '2023-05-30 00:01:13', '2023-05-30 00:01:13', NULL),
(21, 1, 'uploads/media/mlvcdXpf4UMUUwPW2PvF0YILNVz7ign3Xex0sBTb.png', 2898, 'image', 'brand-1.png', 'png', '2023-05-30 00:01:13', '2023-05-30 00:01:13', NULL),
(22, 1, 'uploads/media/sdv4Y3czchHd6E64HH0vp3T1BiCHkY9MJwkiFuj9.png', 3023, 'image', 'brand-2.png', 'png', '2023-05-30 00:01:13', '2023-05-30 00:01:13', NULL),
(23, 1, 'uploads/media/LrcRjOJv1gVlTHeWB61Y9ONBsYqmunc6dP1GdJqp.png', 2491, 'image', 'brand-7.png', 'png', '2023-05-30 00:01:14', '2023-05-30 00:01:14', NULL),
(24, 1, 'uploads/media/hLdXSlU2o9xtOgRvbjIb1eaSlynZJeFBLMnHuwdb.png', 2592, 'image', 'brand-8.png', 'png', '2023-05-30 00:01:14', '2023-05-30 00:01:14', NULL),
(25, 1, 'uploads/media/wBLJC29tMJ8SWRpx15XtZukHCjV7GY7I6rx4X7Ep.png', 3732, 'image', 'brand-6.png', 'png', '2023-05-30 00:01:14', '2023-05-30 00:01:14', NULL),
(26, 1, 'uploads/media/xwezZUvaxRS9pjH6mI6MfNznDTToN6bqQyrVaPnH.png', 2233, 'image', 'brand-9.png', 'png', '2023-05-30 00:01:14', '2023-05-30 00:01:14', NULL),
(27, 1, 'uploads/media/KL5lx1UypJXI4mmV7FeblDIUpMyH1PzIrnNKVDuZ.jpg', 6325, 'image', '3.jpg', 'jpg', '2023-05-30 00:49:35', '2023-05-30 00:49:35', NULL),
(28, 1, 'uploads/media/TDnetBh0y5ppwaYd2hfILXwXih0XaHXecGTlKtGq.jpg', 6587, 'image', '2.jpg', 'jpg', '2023-05-30 00:49:35', '2023-05-30 00:49:35', NULL),
(29, 1, 'uploads/media/dX6Ci8opVohOjE7axAH4QcC3BSNu0qRiqQH86NBz.jpg', 8310, 'image', '5.jpg', 'jpg', '2023-05-30 00:49:35', '2023-05-30 00:49:35', NULL),
(30, 1, 'uploads/media/Gk34IvkoLgo0x4BNJLYH6qKyCWnwwBe3TyCWeyBG.jpg', 8250, 'image', '4.jpg', 'jpg', '2023-05-30 00:49:35', '2023-05-30 00:49:35', NULL),
(31, 1, 'uploads/media/O5GvAe2XxpInTfRZrEWjPITIQTMdIkCtZAJPBTNo.jpg', 6851, 'image', '6.jpg', 'jpg', '2023-05-30 00:49:35', '2023-05-30 00:49:35', NULL),
(32, 1, 'uploads/media/EAuMFug7lSa1oxXB5kT66fTsTlOysXfCt6pjrawR.jpg', 8250, 'image', '4.jpg', 'jpg', '2023-05-30 04:46:20', '2023-05-30 04:46:20', NULL),
(33, 1, 'uploads/media/LYHIqdlUyNHWB5FWoWZKKxEbV8uSkfLtL7NEnXDy.png', 697, 'image', 'ai-tools-card-img-1.png', 'png', '2024-03-20 14:27:27', '2024-03-20 14:27:27', NULL),
(34, 1, 'uploads/media/mIeqkecZ94L5dLgEwUAIz37VzsBrmEWt1OQ3FwdM.png', 37984, 'image', 'Storage Management.png', 'png', '2024-03-20 14:28:43', '2024-03-20 14:28:43', NULL),
(35, 1, 'uploads/media/zGVMh8rb7HN3cYFcjL6XfS4mPynAnUKJVuXmA1xg.png', 26104, 'image', 'Social Login.png', 'png', '2024-03-20 14:28:43', '2024-03-20 14:28:43', NULL),
(36, 1, 'uploads/media/MqhdN3swXnuwjyPTi40HK5xHP29gvbquzm9mVOI8.png', 2442, 'image', 'ai-tools-card-img-5.png', 'png', '2024-03-20 14:28:43', '2024-03-20 14:28:43', NULL),
(37, 1, 'uploads/media/0SmgQ3IcyKR6tlCcppwkpRG0viECFMI1aY9inLQU.png', 26601, 'image', 'Twilio Credentials.png', 'png', '2024-03-20 14:28:43', '2024-03-20 14:28:43', NULL),
(38, 1, 'uploads/media/6ToWNneIyFmufGCRSjsU04q77SK3Sr3SUS9GCNrg.png', 30195, 'image', 'Google (1).png', 'png', '2024-03-20 14:28:43', '2024-03-20 14:28:43', NULL),
(39, 1, 'uploads/media/U1NnEAd810RjAPzXNRLGz2BLDYTIyx5lPb8665IT.png', 11361, 'image', 'ai-tools-card-img-2 (1).png', 'png', '2024-03-20 14:28:44', '2024-03-20 14:28:44', NULL),
(40, 1, 'uploads/media/4frGeilaXbpoXxcySkZtSH4SUkC7sBuVsF0HKvwS.png', 1965, 'image', 'ai-application-icon-3.png', 'png', '2024-03-20 14:28:44', '2024-03-20 14:28:44', NULL),
(41, 1, 'uploads/media/FKqPeC4XUlq5fhN7bq7Rt1REdfROkeGyULZ3ndYv.png', 25156, 'image', 'affiliate marketing.png', 'png', '2024-03-20 14:28:44', '2024-03-20 14:28:44', NULL),
(42, 1, 'uploads/media/sUD7MniXjChCU1HMQq2w9z2XUIByO8ud9Z2ZzRYi.png', 1153, 'image', 'ai-application-icon-4.png', 'png', '2024-03-20 14:28:44', '2024-03-20 14:28:44', NULL),
(43, 1, 'uploads/media/Wtd2ivUyWUe3vQAJP8IP2We8Xr01gX5RAeLhpOMy.png', 261101, 'image', 'testimonial-4-shape-dots.png', 'png', '2024-03-20 14:28:44', '2024-03-20 14:28:44', NULL),
(44, 1, 'uploads/media/BI6U0vYE0VtATR7YUXy85qeIWDx3wHwAUkiXvgq0.png', 1873, 'image', 'ai-application-icon-2.png', 'png', '2024-03-20 14:28:44', '2024-03-20 14:28:44', NULL),
(45, 1, 'uploads/media/8xCmOJIHloGGkA1KaRNQn1D67IDp7NgyJbGu4kjd.png', 1778, 'image', 'ai-application-icon-1.png', 'png', '2024-03-20 14:28:44', '2024-03-20 14:28:44', NULL),
(46, 1, 'uploads/media/oY0p5qYKwuCghptcfDYr4SrhIw3yxKfeYhWU1qFz.png', 24201, 'image', 'AI PDF Chat.png', 'png', '2024-03-20 14:28:44', '2024-03-20 14:28:44', NULL),
(47, 1, 'uploads/media/lyV6xTRnHNzjC0zUuVw8MAEpWUYEH0LlKnWa10DA.png', 79987, 'image', 'AI VISION.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(48, 1, 'uploads/media/u7Z7gTZdCNnRKSm8tGuWTJFDUxKTeC2KRdJpDe40.png', 61002, 'image', 'AI Chat to image.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(49, 1, 'uploads/media/ppP2H29Vcnd43Q3KY46XxnuBzjLBc194dXyCalgn.png', 26503, 'image', 'AI Chat.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(50, 1, 'uploads/media/7GPtw5YJS5HSZXxMiftBTWRiaUM8EkrCswvwKSq4.png', 30979, 'image', 'azure.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(51, 1, 'uploads/media/xqTwmjLyhxKOA62zQt8IPXXM4dyuB7M8amQaiaU4.png', 10768, 'image', 'IIElevenlabs.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(52, 1, 'uploads/media/n6BdfTgN7JaRKWG3UujL7MAWG5ukwJ0WIPJXcXPY.png', 23124, 'image', 'Open AI.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(53, 1, 'uploads/media/XEHWIW7ELu12jB7fsQv1kT6l19N7bLgoeLitOWep.png', 12371, 'image', 'Google.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(54, 1, 'uploads/media/vfVTApPecKb380ZX3TZifUZtDEFFaG8J3EYv5Pxv.png', 23080, 'image', 'ai-image-card-2.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(55, 1, 'uploads/media/fK5jk3Wyo7VaqtQatWUtUxdE4LhXpiZzaBXpJs4s.png', 9609, 'image', 'ai-image-card-3.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(56, 1, 'uploads/media/VeXX49YTJvxdAToyZOHANuOa4UzoNfEDgAnY9ZdU.png', 13123, 'image', 'ai-image-card-1.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(57, 1, 'uploads/media/nZUWEvvYh0PDFbJWuwc5EBSltIbY3SmsZ2xUu7ka.png', 16977, 'image', 'Public Blog.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(58, 1, 'uploads/media/D6AO0HT3Q1QyGQHR5w4FBAEcfPMhNOb4uYX63Qa0.png', 31504, 'image', 'Create Outline.png', 'png', '2024-03-20 14:28:45', '2024-03-20 14:28:45', NULL),
(59, 1, 'uploads/media/nwIDceo3SItd6Cu7EcqQQY2r3ZdVbIEcLlKYe2Dc.png', 24715, 'image', 'AI BLOG (1).png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(60, 1, 'uploads/media/kkU5aBM1vLUFeuIpjXAUPV4qbrOfN5S6moxJ9Ydt.png', 22357, 'image', 'AI Full Blog.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(61, 1, 'uploads/media/vaH1KHg5bv0A8edjRpmcoCttVjDXj9TxDeYvqLND.png', 32665, 'image', 'Email Templated.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(62, 1, 'uploads/media/Bu9UJiU4kzKLxSvmCGdY8Wuj897zunyrcbbJg0TW.png', 25277, 'image', 'AI Blog.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(63, 1, 'uploads/media/31FYJoAr89IelzAjbgDuBjkBVzM4iiFrfejdcQ3h.png', 34508, 'image', 'Fun or Quote.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(64, 1, 'uploads/media/NqvX51lSTzataYvD0pktquxbpFwnGtzlx7kLbYt2.png', 22028, 'image', 'Social Media Templated.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(65, 1, 'uploads/media/XLXUm4rUow6zmTvTEaVJYH4CyOy6xg1vrRKIkAx3.png', 5797, 'image', 'ai-tools-card-img-4.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(66, 1, 'uploads/media/wLOBj2qS9IzJTpOofmVWAtxIgrOLAcJSes3W6NDB.png', 70105, 'image', 'map.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(67, 1, 'uploads/media/2XgEhTjyVbV4Qp8spoWsZrWRY7S9JA1xD9sICU6S.png', 22103, 'image', 'ai-tools-card-img-3-globe.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(68, 1, 'uploads/media/3Fmyl2cMxv9WKnIq9KJ0KqTfOqmUVY58htSJdimN.png', 11361, 'image', 'ai-tools-card-img-2.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(69, 1, 'uploads/media/EZRK1vXhyBSsS5rx4Y5QGAfYzClfRhxAgq4V9qpO.png', 5704, 'image', 'ai-tools-card-shape-1.png', 'png', '2024-03-20 14:28:46', '2024-03-20 14:28:46', NULL),
(70, 1, 'uploads/media/bsixvuR7PtPwTsxo4WiRRwePxqBYrVtPjLhxZxCN.png', 16967, 'image', 'affir.png', 'png', '2024-03-20 14:51:16', '2024-03-20 14:51:16', NULL),
(71, 1, 'uploads/media/HBszinquVVNnE8VRJeXyaxEwwCnEk3uLkoYofmX3.png', 17218, 'image', 'affir.png', 'png', '2024-03-20 14:52:22', '2024-03-20 14:52:22', NULL),
(72, 1, 'uploads/media/qHVNZIW4EPy13v1TePIysBXpAqPWEihOS2owtJYg.png', 36256, 'image', 'ai-image-slide-1.png', 'png', '2024-03-20 15:23:36', '2024-03-20 15:23:36', NULL),
(73, 1, 'uploads/media/w1prPacnTuPvCdnmoKsf0olIi5sF2VxfNWiFsdqb.png', 40999, 'image', 'ai-image-slide-2.png', 'png', '2024-03-20 15:23:36', '2024-03-20 15:23:36', NULL),
(74, 1, 'uploads/media/BUtcZ68o5zpNANxj38HNmI7R4mDfFEWGbhS4y4M8.png', 239877, 'image', 'ai-featured-video-img-3.png', 'png', '2024-03-20 15:23:36', '2024-03-20 15:23:36', NULL),
(75, 1, 'uploads/media/vMZ95Vilv0Qi6qO4rbx20fHPQurfzabU9HPjoE3c.png', 188633, 'image', 'ai-featured-video-img-2.png', 'png', '2024-03-20 15:23:36', '2024-03-20 15:23:36', NULL),
(76, 1, 'uploads/media/8u8g3zdRrb6EbiuZ1msdRoavDmaxsUbIgylzb7Av.png', 159298, 'image', 'ai-featured-video-img-4.png', 'png', '2024-03-20 15:23:36', '2024-03-20 15:23:36', NULL),
(77, 1, 'uploads/media/76CwWSrcqNpKwOC4xyBdIcLaqHPZkfvGZXYjO93y.png', 43791, 'image', 'ai-image-slide-5.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(78, 1, 'uploads/media/s6Cejmb02gSLbpOYiZzFQR3hlhkpwhyS4e1oIpNQ.png', 34001, 'image', 'ai-image-slide-6.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(79, 1, 'uploads/media/LpfohnS7fNJ98uBaLyBB5lf8D0xZNO8R1SZL25bQ.png', 34840, 'image', 'ai-image-slide-9.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(80, 1, 'uploads/media/7Quhoi9MaqmENZ6hQjnkyUuMkCyge70ZPbJdQ7zk.png', 38299, 'image', 'ai-image-slide-10.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(81, 1, 'uploads/media/QMHd768U8eoUxuQoK2J9h1CupxsmXyxcE9XlfMFK.png', 32728, 'image', 'ai-image-slide-11.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(82, 1, 'uploads/media/92Rikf03wOrWggAeRm8PQCZfBzRtMJLBrwjAbTTU.png', 41043, 'image', 'ai-image-slide-12.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(83, 1, 'uploads/media/FlSHC8qUW5eVMOEWZc1jtJdwqeBQ8QNJWbPyXurI.png', 48369, 'image', 'ai-image-slide-13.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(84, 1, 'uploads/media/9WSCLmtY3vWtsK3Nt7R4UsLWEyXamk4M08qs1Kev.png', 29380, 'image', 'ai-image-slide-15.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(85, 1, 'uploads/media/ffFR6R4lm6UlPiDs5kXbGUpFGrPawAIVM4N0ux3S.png', 32098, 'image', 'ai-image-slide-16.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(86, 1, 'uploads/media/CW4Mdr8igX30Q3m02ntRLAonfjig44K7SstXSQOx.png', 222564, 'image', 'insight-1.png', 'png', '2024-03-20 15:23:37', '2024-03-20 15:23:37', NULL),
(87, 1, 'uploads/media/ejOyRxBK6P3kE6Vr7e9FTduGhTwJ4RCKangRzEbK.png', 165383, 'image', 'insight-2.png', 'png', '2024-03-20 15:23:38', '2024-03-20 15:23:38', NULL),
(88, 1, 'uploads/media/lhAEEpt9G0pMdZfAH6spBcr7rYtEphF9bVThs1FR.png', 239360, 'image', 'insight-3.png', 'png', '2024-03-20 15:23:38', '2024-03-20 15:23:38', NULL),
(89, 1, 'uploads/media/NpyhziYxqZfYX1hrPCPDLLDgv5ZvqJT5GzahL6yt.png', 145029, 'image', 'popular-post-1.png', 'png', '2024-03-20 15:23:38', '2024-03-20 15:23:38', NULL),
(90, 1, 'uploads/media/rgD3lq6imYfhJEsTF5EZd69ht3VnbPb3ITxiEDPM.png', 133016, 'image', 'popular-post-2.png', 'png', '2024-03-20 15:23:38', '2024-03-20 15:23:38', NULL),
(91, 1, 'uploads/media/T4Vzc5QJ3ya77Z4IOcwHocZUxIxsaNiEeEOFGCim.png', 103769, 'image', 'popular-post-3.png', 'png', '2024-03-20 15:23:38', '2024-03-20 15:23:38', NULL),
(92, 1, 'uploads/media/MLz5akOToNx4ET1T4CojXeEvu9WH6QhgP9cOhY1O.png', 159576, 'image', 'popular-post-4.png', 'png', '2024-03-20 15:23:38', '2024-03-20 15:23:38', NULL),
(93, 1, 'uploads/media/1DLUMsmNyGy8PeF50xteMxGUSQI2AoBkVMdFKV1M.png', 132077, 'image', 'popular-post-5.png', 'png', '2024-03-20 15:23:38', '2024-03-20 15:23:38', NULL),
(94, 1, 'uploads/media/AbWfW3NOns772PGy2pL6pe8u1vXVWVFStUMqowol.png', 161328, 'image', 'popular-post-6.png', 'png', '2024-03-20 15:23:38', '2024-03-20 15:23:38', NULL),
(95, 1, 'uploads/media/7Eve5kxuIu77CjcO8453V7HDdRGzHcvkbbT1ceNG.png', 129005, 'image', 'popular-post-7.png', 'png', '2024-03-20 15:23:39', '2024-03-20 15:23:39', NULL),
(96, 1, 'uploads/media/R0PTaXlhzedIeJx4xST1Ujlv7FBRV8A2UscdsDim.png', 156284, 'image', 'popular-post-8.png', 'png', '2024-03-20 15:23:39', '2024-03-20 15:23:39', NULL),
(97, 1, 'uploads/media/eIzd6hHZOalcnwrPMqaHU7AqQuZqjY05u8pIoxHn.png', 153036, 'image', 'popular-post-9.png', 'png', '2024-03-20 15:23:39', '2024-03-20 15:23:39', NULL),
(98, 1, 'uploads/media/YmXrreIeXCCjjROng5N58MnZFB7AycRvQZgdQcPH.png', 141882, 'image', 'popular-post-10.png', 'png', '2024-03-20 15:23:39', '2024-03-20 15:23:39', NULL),
(99, 1, 'uploads/media/z6ghEhPROsxDnURSgtpNo83eBmhBMkbG5ezD5M3E.png', 136274, 'image', 'popular-post-11.png', 'png', '2024-03-20 15:23:39', '2024-03-20 15:23:39', NULL),
(100, 1, 'uploads/media/cHfOYmId3reG8spUc0PxaGG742BRXEWauTn4rSLa.png', 119588, 'image', 'popular-post-12.png', 'png', '2024-03-20 15:23:39', '2024-03-20 15:23:39', NULL),
(101, 1, 'uploads/media/ha9iyqxBIjlZbXOBBAcMNYA4wpzqbsJOTtAx3V18.png', 34508, 'image', 'Fun or Quote.png', 'png', '2024-03-20 15:23:39', '2024-03-20 15:23:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_05_03_000001_create_customer_columns', 1),
(4, '2019_05_03_000002_create_subscriptions_table', 1),
(5, '2019_05_03_000003_create_subscription_items_table', 1),
(6, '2019_08_19_000000_create_failed_jobs_table', 1),
(7, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(8, '2022_10_31_050025_create_languages_table', 1),
(9, '2022_10_31_050126_create_localizations_table', 1),
(10, '2022_11_07_061318_create_tags_table', 1),
(11, '2022_11_07_064323_create_blog_categories_table', 1),
(12, '2022_11_07_085058_create_blogs_table', 1),
(13, '2022_11_07_085227_create_blog_localizations_table', 1),
(14, '2022_11_07_105203_create_blog_tags_table', 1),
(15, '2022_11_09_050229_create_currencies_table', 1),
(16, '2022_11_12_044845_create_system_settings_table', 1),
(17, '2022_11_16_094759_create_subscribed_users_table', 1),
(18, '2022_11_20_085351_create_pages_table', 1),
(19, '2022_11_20_085638_create_page_localizations_table', 1),
(20, '2022_11_27_080124_create_permission_tables', 1),
(21, '2022_12_13_051944_create_media_managers_table', 1),
(22, '2023_04_17_042610_create_subscription_packages_table', 1),
(23, '2023_04_17_054102_create_subscription_package_templates_table', 1),
(24, '2023_04_17_054442_create_open_ai_models_table', 1),
(25, '2023_04_17_064710_create_template_groups_table', 1),
(26, '2023_04_17_064720_create_templates_table', 1),
(27, '2023_04_17_064727_create_template_usages_table', 1),
(28, '2023_04_17_085249_create_prompts_table', 1),
(29, '2023_04_17_093903_create_projects_table', 1),
(30, '2023_04_17_102312_create_folders_table', 1),
(31, '2023_04_19_055241_create_subscription_histories_table', 1),
(32, '2023_05_16_131036_create_favorite_templates_table', 1),
(33, '2023_05_26_121658_create_faqs_table', 1),
(34, '2023_05_27_093725_create_contact_us_messages_table', 1),
(35, '2023_05_31_054841_create_affiliate_earnings_table', 1),
(36, '2023_05_31_055019_create_affiliate_payments_table', 1),
(37, '2023_05_31_055103_create_affiliate_payout_accounts_table', 1),
(38, '2023_06_05_094934_create_custom_templates_table', 1),
(39, '2023_06_05_095225_create_custom_template_categories_table', 1),
(40, '2023_06_13_085132_create_ai_chat_categories_table', 1),
(41, '2023_06_13_085649_create_ai_chats_table', 1),
(42, '2023_06_13_085806_create_ai_chat_messages_table', 1),
(43, '2023_07_15_063713_create_general_setup_localizations_table', 1),
(44, '2023_07_15_114522_create_custom_template_category_localizations_table', 1),
(45, '2023_07_15_122141_create_custom_template_localizations_table', 1),
(46, '2023_07_16_055928_create_open_ai_keys_table', 1),
(47, '2023_07_17_112223_create_text_to_speeches_table', 1),
(48, '2023_07_19_095436_alter_user_table_subscription_balance_to_history_table_v_2_3_0', 1),
(49, '2023_07_22_043738_create_faq_localizations_table', 1),
(50, '2023_07_23_062901_create_voice_languages_table', 1),
(51, '2023_07_23_063124_stable_diffusion_projects_table_changes_v_2_3_0', 1),
(52, '2023_07_23_084514_create_voice_language_details_table', 1),
(53, '2023_07_23_102636_create_text_to_speech_settings_table', 1),
(54, '2023_07_24_065338_subscription_packages_show_hide_enable_disable_table_changes_v_2_3_0', 1),
(55, '2023_07_25_062442_add_column_to_roles_table', 1),
(56, '2023_07_29_122512_create_offline_payment_methods_table', 1),
(57, '2023_07_30_103230_add_column_to_subscription_histories_table', 1),
(58, '2023_08_02_070349_create_template_localizations_table', 1),
(59, '2023_08_05_105422_add_maximum_character_to_text_to_speech_settings_table', 1),
(60, '2023_08_06_044313_create_customer_settings_table', 1),
(61, '2023_08_06_044552_create_subscription_logs_table', 1),
(62, '2023_08_06_062934_create_project_logs_table', 1),
(63, '2023_08_07_063738_add_is_carried_over_in_subscription_histories_table', 1),
(64, '2023_08_07_101042_add_cteated_by_in_subscription_histories_table', 1),
(65, '2023_08_08_083411_remove_unused_column_from_subscription_histories', 1),
(66, '2023_08_09_104307_add_duration_to_subscription_packages_table', 1),
(67, '2023_08_12_114446_add_template_status_to_languages_table', 1),
(68, '2023_08_14_063459_add_chat_training_data_column_in_ai_chat_categories_table', 1),
(69, '2023_08_15_063319_create_storage_managers_table', 1),
(70, '2023_08_15_065015_create_ai_chat_prompt_groups_table', 1),
(71, '2023_08_15_065440_create_ai_chat_prompts_table', 1),
(72, '2023_08_19_091707_add_is_active_column_to_ai_chat_categories_table', 1),
(73, '2023_08_20_090553_add_column_to_for_storage_type', 1),
(74, '2023_08_20_113404_create_ai_blog_wizards_table', 1),
(75, '2023_08_20_113616_create_ai_blog_wizard_key_words_table', 1),
(76, '2023_08_20_113632_create_ai_blog_wizard_titles_table', 1),
(77, '2023_08_20_115923_create_ai_blog_wizard_outlines_table', 1),
(78, '2023_08_20_115935_create_ai_blog_wizard_articles_table', 1),
(79, '2023_08_21_054326_add_blog_wizard_columns_to_subscription_packages_table', 1),
(80, '2023_08_27_052627_create_ai_blog_wizard_images_table', 1),
(81, '2023_08_30_065001_create_ai_blog_wizard_article_logs_table', 1),
(82, '2023_09_04_103202_delete_open_ai_older_models', 1),
(83, '2023_09_04_105944_add_column_to_open_ai_models', 1),
(84, '2023_09_04_114657_add_column_to_subscription_histories', 1),
(85, '2023_09_04_114828_alter_subscription_package_model', 1),
(86, '2023_09_13_104741_add_column_to_subscription_packages_table', 1),
(87, '2023_09_23_093805_create_wr_notifications_table', 1),
(88, '2023_09_26_131104_create_application_versions_table', 1),
(89, '2023_10_10_052245_create_payment_gateways_table', 1),
(90, '2023_10_10_062746_create_payment_gateway_details_table', 1),
(91, '2023_10_10_181821_create_subscription_auto_payments_table', 1),
(92, '2023_10_11_083127_create_payment_gateway_products_table', 1),
(93, '2023_10_11_112841_create_paymentgateway_product_histories_table', 1),
(94, '2023_10_15_083016_create_subscription_recurring_payments_table', 1),
(95, '2023_10_17_060530_create_webhook_histories_table', 1),
(96, '2023_10_18_064115_create_writebot_modules_table', 1),
(97, '2023_10_18_084552_create_categories_table', 1),
(98, '2023_10_18_084602_create_priorities_table', 1),
(99, '2023_10_18_112819_create_tickets_table', 1),
(100, '2023_10_18_115858_create_ticket_files_table', 1),
(101, '2023_10_18_121029_create_reply_tickets_table', 1),
(102, '2023_10_18_121455_create_assign_tickets_table', 1),
(103, '2023_10_28_065605_add_column_currency_code_to_subscription_histories_table', 1),
(104, '2023_11_26_131631_create_ai_response_logs_table', 1),
(105, '2023_12_03_085730_create_grass_period_payments_table', 1),
(106, '2023_12_06_052431_add_column_order_id_subscription_hisotry_table', 1),
(107, '2023_12_18_084244_create_p_w_a_settings_table', 1),
(108, '2023_12_19_062144_create_ad_senses_table', 1),
(109, '2023_12_24_044622_add_column_eleven_labs_to_subscription_packages_table', 1),
(110, '2023_12_24_093353_create_eleven_labs_models_table', 1),
(111, '2023_12_24_093711_create_eleven_labs_model_voices_table', 1),
(112, '2023_12_27_133404_add_column_input_prompt_to_projects_table', 1),
(113, '2024_01_02_093010_add_column_type_to_ai_chat_messages_table', 1),
(114, '2024_01_17_124325_create_licenses_table', 1),
(115, '2024_01_30_060752_create_email_templates_table', 1),
(116, '2024_01_30_094811_create_pdf_chats', 1),
(117, '2024_01_30_095015_create_pdf_chat_conversations', 1),
(118, '2024_02_04_091051_add_ai_pdf_chat_at_table_subscription_packages', 1),
(119, '2024_02_05_054530_create_fine_tunes_table', 1),
(120, '2024_02_05_061642_create_fine_tune_histories_table', 1),
(121, '2024_02_08_103643_is_blog_published_at_table_ai_blog_wizard', 1),
(122, '2024_02_08_111752_is_wizard_blog_at_table_blogs', 1),
(123, '2024_02_13_055006_add_column_ai_rewriter_to_subscription_packages_table', 1),
(124, '2024_03_09_055803_create_themes_table', 1),
(125, '2024_03_16_061654_create_feature_categories_table', 1),
(126, '2024_03_16_061937_create_feature_category_localizations_table', 1),
(127, '2024_03_16_062014_create_feature_category_details_table', 1),
(128, '2024_03_16_062034_create_feature_category_detail_localizations_table', 1),
(129, '2024_03_24_094428_create_plagiarism_settings_table', 1),
(130, '2024_03_25_055320_create_ai_content_detectors_table', 1),
(131, '2024_04_02_043032_create_ad_sense_localizations_table', 1),
(132, '2024_04_03_091819_create_e_mail_settings_table', 1),
(133, '2024_04_07_074737_create_old_payment_gateway_products_table', 1),
(134, '2024_04_08_061719_add_column_to_payment_gatways_product_table', 1),
(135, '2024_04_08_061719_add_column_to_payment_gatways_table', 1),
(136, '2024_04_16_062202_add_column_real_time_data_to_subscription_packages_table', 1),
(137, '2024_08_17_102638_add_version_update_4_8_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `offline_payment_methods`
--

CREATE TABLE `offline_payment_methods` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `is_delete` tinyint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `offline_payment_methods`
--

INSERT INTO `offline_payment_methods` (`id`, `name`, `description`, `is_active`, `created_by`, `updated_by`, `is_delete`, `created_at`, `updated_at`) VALUES
(1, 'Bianance', 'pay via binance', 1, 1, NULL, NULL, '2025-04-21 22:48:28', '2025-04-21 22:48:28'),
(2, 'Bkash Marchent', '01896156710', 1, 1, NULL, NULL, '2025-04-21 22:48:58', '2025-04-21 22:48:58'),
(3, 'Nagad Marchent', '01896156710', 1, 1, NULL, NULL, '2025-04-21 22:49:22', '2025-04-21 22:49:22');

-- --------------------------------------------------------

--
-- Table structure for table `old_payment_gateway_products`
--

CREATE TABLE `old_payment_gateway_products` (
  `id` bigint UNSIGNED NOT NULL,
  `package_id` int NOT NULL DEFAULT '0',
  `package_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `gateway` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `product_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `old_price_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `new_price_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `open_ai_keys`
--

CREATE TABLE `open_ai_keys` (
  `id` bigint UNSIGNED NOT NULL,
  `engine` int DEFAULT '1' COMMENT '1= openAi 2= Diffusion',
  `api_key` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `open_ai_keys`
--

INSERT INTO `open_ai_keys` (`id`, `engine`, `api_key`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, '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', 1, 1, NULL, '2025-04-21 17:21:38', '2025-04-21 17:21:38');

-- --------------------------------------------------------

--
-- Table structure for table `open_ai_models`
--

CREATE TABLE `open_ai_models` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `open_ai_models`
--

INSERT INTO `open_ai_models` (`id`, `name`, `key`, `order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Gpt 3.5 turbo instruct', 'gpt-3.5-turbo-instruct', 0, NULL, NULL, '2023-09-04 22:50:22'),
(2, 'ChatGPT 3.5', 'gpt-3.5-turbo', 0, NULL, NULL, NULL),
(3, 'ChatGPT 4', 'gpt-4', 1, NULL, NULL, NULL),
(4, 'ChatGPT 3.5 Turbo-16k', 'gpt-3.5-turbo-16k', 0, NULL, NULL, NULL),
(5, 'Updated GPT 3.5 Turbo', 'gpt-3.5-turbo-1106', 1, NULL, NULL, NULL),
(6, 'ChatGPT 4 Gpt-4-32k', 'gpt-4-0613', 1, NULL, NULL, NULL),
(7, 'GPT-4 Turbo', 'gpt-4-turbo', 0, NULL, NULL, NULL),
(8, 'GPT-4o', 'gpt-4o', 1, NULL, NULL, NULL),
(9, 'Gpt 4o mini', 'gpt-4o-mini', 1, NULL, NULL, NULL),
(10, 'Gpt 4o mini 2024 07 18', 'gpt-4o-mini-2024-07-18', 1, NULL, NULL, NULL),
(11, 'Chatgpt 4o latest', 'chatgpt-4o-latest', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `meta_title` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `meta_image` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `meta_description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_system` tinyint DEFAULT '0',
  `is_active` tinyint DEFAULT '1',
  `created_by` int DEFAULT '1',
  `updated_by` int DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `content`, `meta_title`, `meta_image`, `meta_description`, `created_at`, `updated_at`, `deleted_at`, `is_system`, `is_active`, `created_by`, `updated_by`) VALUES
(1, 'Terms & Conditions', 'terms-conditions', '<div class=\"mb-5\" style=\"color: rgb(71, 85, 105); font-family: Jost, sans-serif; font-size: 15.008px;\"><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\"><p data-start=\"172\" data-end=\"205\" class=\"\"><strong data-start=\"172\" data-end=\"191\">Effective Date:</strong> 05-4-2025</p>\r\n<p data-start=\"207\" data-end=\"400\" class=\"\">Welcome to <strong data-start=\"218\" data-end=\"236\">WriterCert.com</strong>. By accessing or using our website and services, you agree to be bound by the following Terms and Conditions. Please read them carefully before using our platform.</p>\r\n<hr data-start=\"402\" data-end=\"405\" class=\"\">\r\n</h2><h3 data-start=\"407\" data-end=\"433\" class=\"\">1. Acceptance of Terms</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"435\" data-end=\"690\" class=\"\">By registering, accessing, or using any services on WriterCert.com (hereinafter “WriterCert”, “we”, “our”, or “us”), you agree to be legally bound by these Terms &amp; Conditions. If you do not agree with any part of these terms, you may not use our services.</p>\r\n<hr data-start=\"692\" data-end=\"695\" class=\"\">\r\n</h2><h3 data-start=\"697\" data-end=\"720\" class=\"\">2. Services Offered</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"722\" data-end=\"950\" class=\"\">WriterCert provides AI-powered tools for generating written content, images, voice-based content, and automated posting to external platforms such as WordPress, Medium, and Blogger. Some features may require a paid subscription.</p>\r\n<hr data-start=\"952\" data-end=\"955\" class=\"\">\r\n</h2><h3 data-start=\"957\" data-end=\"985\" class=\"\">3. User Responsibilities</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"987\" data-end=\"1223\">\r\n<li data-start=\"987\" data-end=\"1044\" class=\"\">\r\n<p data-start=\"989\" data-end=\"1044\" class=\"\">You agree to use WriterCert for lawful purposes only.</p>\r\n</li>\r\n<li data-start=\"1045\" data-end=\"1133\" class=\"\">\r\n<p data-start=\"1047\" data-end=\"1133\" class=\"\">You are responsible for maintaining the confidentiality of your account credentials.</p>\r\n</li>\r\n<li data-start=\"1134\" data-end=\"1223\" class=\"\">\r\n<p data-start=\"1136\" data-end=\"1223\" class=\"\">You are solely responsible for any content generated or published through your account.</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"1225\" data-end=\"1228\" class=\"\">\r\n</h2><h3 data-start=\"1230\" data-end=\"1258\" class=\"\">4. Intellectual Property</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"1260\" data-end=\"1507\" class=\"\">All content and technology on WriterCert, including AI models, software, design, and branding, are the property of WriterCert or its licensors. You may not copy, redistribute, or reproduce any part of the platform without prior written permission.</p>\r\n<p data-start=\"1509\" data-end=\"1700\" class=\"\">Content generated by our AI may be used by you, but <strong data-start=\"1561\" data-end=\"1642\">you remain responsible for ensuring its legality, originality, and compliance</strong> with applicable laws and third-party platform guidelines.</p>\r\n<hr data-start=\"1702\" data-end=\"1705\" class=\"\">\r\n</h2><h3 data-start=\"1707\" data-end=\"1738\" class=\"\">5. Payment and Subscription</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"1740\" data-end=\"1979\">\r\n<li data-start=\"1740\" data-end=\"1832\" class=\"\">\r\n<p data-start=\"1742\" data-end=\"1832\" class=\"\">Some features of WriterCert are free; others require a subscription or one-time payment.</p>\r\n</li>\r\n<li data-start=\"1833\" data-end=\"1881\" class=\"\">\r\n<p data-start=\"1835\" data-end=\"1881\" class=\"\">All sales are final unless otherwise stated.</p>\r\n</li>\r\n<li data-start=\"1882\" data-end=\"1979\" class=\"\">\r\n<p data-start=\"1884\" data-end=\"1979\" class=\"\">Prices and features may change; users will be notified in advance if significant changes occur.</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"1981\" data-end=\"1984\" class=\"\">\r\n</h2><h3 data-start=\"1986\" data-end=\"2021\" class=\"\">6. Cancellation and Termination</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2023\" data-end=\"2215\" class=\"\">You may cancel your account at any time from your dashboard. We reserve the right to suspend or terminate any account that violates these Terms, or if we suspect misuse or abuse of the system.</p>\r\n<hr data-start=\"2217\" data-end=\"2220\" class=\"\">\r\n</h2><h3 data-start=\"2222\" data-end=\"2252\" class=\"\">7. Limitation of Liability</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2254\" data-end=\"2432\" class=\"\">WriterCert does not guarantee the accuracy, completeness, or legality of AI-generated content. We are not liable for any damages resulting from the use or misuse of our services.</p>\r\n<p data-start=\"2434\" data-end=\"2472\" class=\"\">Use of WriterCert is at your own risk.</p>\r\n<hr data-start=\"2474\" data-end=\"2477\" class=\"\">\r\n</h2><h3 data-start=\"2479\" data-end=\"2493\" class=\"\">8. Privacy</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2495\" data-end=\"2639\" class=\"\">Your privacy is important to us. Please refer to our <a data-start=\"2548\" data-end=\"2581\" class=\"cursor-pointer\" rel=\"noopener\">Privacy Policy</a> to learn how we collect, store, and use your information.</p>\r\n<hr data-start=\"2641\" data-end=\"2644\" class=\"\">\r\n</h2><h3 data-start=\"2646\" data-end=\"2666\" class=\"\">9. Modifications</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2668\" data-end=\"2856\" class=\"\">We reserve the right to update or change these Terms at any time. Changes will be effective immediately upon posting. Continued use of the platform constitutes acceptance of those changes.</p>\r\n<hr data-start=\"2858\" data-end=\"2861\" class=\"\">\r\n</h2><h3 data-start=\"2863\" data-end=\"2881\" class=\"\">10. Contact Us</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2883\" data-end=\"2949\" class=\"\">If you have any questions about these Terms, please contact us at:</p>\r\n<p data-start=\"2951\" data-end=\"3012\" class=\"\">', 'Quis ab ut officia b', '30', 'Explicabo Consectet', '2023-02-16 12:28:22', '2025-05-04 13:22:25', NULL, 1, 1, 1, 1),
(2, 'Privacy & Policy', 'privacy-policy', '<div class=\"mb-5\" style=\"color: rgb(71, 85, 105); font-family: Jost, sans-serif; font-size: 15.008px;\"><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\"><p data-start=\"149\" data-end=\"182\" class=\"\"><strong data-start=\"149\" data-end=\"168\">Effective Date:</strong>&nbsp;05-04-2025</p>\r\n<p data-start=\"184\" data-end=\"394\" class=\"\">At <strong data-start=\"187\" data-end=\"205\">WriterCert.com</strong>, we value your privacy. This Privacy Policy explains how we collect, use, store, and protect your personal data when you visit our website, register an account, or use any of our services.</p>\r\n<p data-start=\"396\" data-end=\"477\" class=\"\">By accessing WriterCert.com, you agree to the practices described in this policy.</p>\r\n<hr data-start=\"479\" data-end=\"482\" class=\"\">\r\n</h2><h3 data-start=\"484\" data-end=\"513\" class=\"\">1. Information We Collect</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"515\" data-end=\"561\" class=\"\">We collect the following types of information:</p>\r\n</h2><h4 data-start=\"563\" data-end=\"593\" class=\"\">a. Personal Information</h4><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"594\" data-end=\"687\">\r\n<li data-start=\"594\" data-end=\"602\" class=\"\">\r\n<p data-start=\"596\" data-end=\"602\" class=\"\">Name</p>\r\n</li>\r\n<li data-start=\"603\" data-end=\"620\" class=\"\">\r\n<p data-start=\"605\" data-end=\"620\" class=\"\">Email address</p>\r\n</li>\r\n<li data-start=\"621\" data-end=\"644\" class=\"\">\r\n<p data-start=\"623\" data-end=\"644\" class=\"\">Account credentials</p>\r\n</li>\r\n<li data-start=\"645\" data-end=\"687\" class=\"\">\r\n<p data-start=\"647\" data-end=\"687\" class=\"\">Billing details (for paid subscriptions)</p>\r\n</li>\r\n</ul>\r\n</h2><h4 data-start=\"689\" data-end=\"716\" class=\"\">b. Usage Information</h4><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"717\" data-end=\"810\">\r\n<li data-start=\"717\" data-end=\"731\" class=\"\">\r\n<p data-start=\"719\" data-end=\"731\" class=\"\">IP address</p>\r\n</li>\r\n<li data-start=\"732\" data-end=\"759\" class=\"\">\r\n<p data-start=\"734\" data-end=\"759\" class=\"\">Device and browser type</p>\r\n</li>\r\n<li data-start=\"760\" data-end=\"777\" class=\"\">\r\n<p data-start=\"762\" data-end=\"777\" class=\"\">Pages visited</p>\r\n</li>\r\n<li data-start=\"778\" data-end=\"795\" class=\"\">\r\n<p data-start=\"780\" data-end=\"795\" class=\"\">Features used</p>\r\n</li>\r\n<li data-start=\"796\" data-end=\"810\" class=\"\">\r\n<p data-start=\"798\" data-end=\"810\" class=\"\">Access times</p>\r\n</li>\r\n</ul>\r\n</h2><h4 data-start=\"812\" data-end=\"834\" class=\"\">c. Content Data</h4><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"835\" data-end=\"967\">\r\n<li data-start=\"835\" data-end=\"880\" class=\"\">\r\n<p data-start=\"837\" data-end=\"880\" class=\"\">Any content you create using our AI tools</p>\r\n</li>\r\n<li data-start=\"881\" data-end=\"967\" class=\"\">\r\n<p data-start=\"883\" data-end=\"967\" class=\"\">Posts scheduled or published through integrations (e.g., WordPress, Medium, Blogger)</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"969\" data-end=\"972\" class=\"\">\r\n</h2><h3 data-start=\"974\" data-end=\"1008\" class=\"\">2. How We Use Your Information</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"1010\" data-end=\"1047\" class=\"\">We use the information we collect to:</p>\r\n<ul data-start=\"1049\" data-end=\"1335\">\r\n<li data-start=\"1049\" data-end=\"1085\" class=\"\">\r\n<p data-start=\"1051\" data-end=\"1085\" class=\"\">Provide and improve our services</p>\r\n</li>\r\n<li data-start=\"1086\" data-end=\"1117\" class=\"\">\r\n<p data-start=\"1088\" data-end=\"1117\" class=\"\">Personalize your experience</p>\r\n</li>\r\n<li data-start=\"1118\" data-end=\"1158\" class=\"\">\r\n<p data-start=\"1120\" data-end=\"1158\" class=\"\">Manage accounts and process payments</p>\r\n</li>\r\n<li data-start=\"1159\" data-end=\"1200\" class=\"\">\r\n<p data-start=\"1161\" data-end=\"1200\" class=\"\">Respond to customer support inquiries</p>\r\n</li>\r\n<li data-start=\"1201\" data-end=\"1277\" class=\"\">\r\n<p data-start=\"1203\" data-end=\"1277\" class=\"\">Send service-related updates and marketing emails (with opt-out options)</p>\r\n</li>\r\n<li data-start=\"1278\" data-end=\"1335\" class=\"\">\r\n<p data-start=\"1280\" data-end=\"1335\" class=\"\">Analyze usage trends and improve platform functionality</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"1337\" data-end=\"1340\" class=\"\">\r\n</h2><h3 data-start=\"1342\" data-end=\"1373\" class=\"\">3. Sharing Your Information</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"1375\" data-end=\"1462\" class=\"\">We <strong data-start=\"1378\" data-end=\"1401\">do not sell or rent</strong> your personal data. However, we may share it in these cases:</p>\r\n<ul data-start=\"1464\" data-end=\"1687\">\r\n<li data-start=\"1464\" data-end=\"1563\" class=\"\">\r\n<p data-start=\"1466\" data-end=\"1563\" class=\"\">With trusted third-party service providers for payment processing, analytics, or infrastructure</p>\r\n</li>\r\n<li data-start=\"1564\" data-end=\"1605\" class=\"\">\r\n<p data-start=\"1566\" data-end=\"1605\" class=\"\">When required by law or legal process</p>\r\n</li>\r\n<li data-start=\"1606\" data-end=\"1687\" class=\"\">\r\n<p data-start=\"1608\" data-end=\"1687\" class=\"\">To protect our rights, users, or the public from fraudulent or harmful activity</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"1689\" data-end=\"1692\" class=\"\">\r\n</h2><h3 data-start=\"1694\" data-end=\"1721\" class=\"\">4. Cookies and Tracking</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"1723\" data-end=\"1775\" class=\"\">We use cookies and similar tracking technologies to:</p>\r\n<ul data-start=\"1777\" data-end=\"1882\">\r\n<li data-start=\"1777\" data-end=\"1803\" class=\"\">\r\n<p data-start=\"1779\" data-end=\"1803\" class=\"\">Maintain user sessions</p>\r\n</li>\r\n<li data-start=\"1804\" data-end=\"1852\" class=\"\">\r\n<p data-start=\"1806\" data-end=\"1852\" class=\"\">Analyze user behavior for improving services</p>\r\n</li>\r\n<li data-start=\"1853\" data-end=\"1882\" class=\"\">\r\n<p data-start=\"1855\" data-end=\"1882\" class=\"\">Remember user preferences</p>\r\n</li>\r\n</ul>\r\n<p data-start=\"1884\" data-end=\"1980\" class=\"\">You can disable cookies through your browser settings, but it may impact platform functionality.</p>\r\n<hr data-start=\"1982\" data-end=\"1985\" class=\"\">\r\n</h2><h3 data-start=\"1987\" data-end=\"2007\" class=\"\">5. Data Security</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2009\" data-end=\"2219\" class=\"\">We implement industry-standard security measures (encryption, secure access controls, etc.) to protect your personal data. However, no system is 100% secure, so please use our services with appropriate caution.</p>\r\n<hr data-start=\"2221\" data-end=\"2224\" class=\"\">\r\n</h2><h3 data-start=\"2226\" data-end=\"2244\" class=\"\">6. Your Rights</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2246\" data-end=\"2268\" class=\"\">You have the right to:</p>\r\n<ul data-start=\"2270\" data-end=\"2408\">\r\n<li data-start=\"2270\" data-end=\"2309\" class=\"\">\r\n<p data-start=\"2272\" data-end=\"2309\" class=\"\">Access, update, or delete your data</p>\r\n</li>\r\n<li data-start=\"2310\" data-end=\"2362\" class=\"\">\r\n<p data-start=\"2312\" data-end=\"2362\" class=\"\">Withdraw consent (e.g., unsubscribe from emails)</p>\r\n</li>\r\n<li data-start=\"2363\" data-end=\"2408\" class=\"\">\r\n<p data-start=\"2365\" data-end=\"2408\" class=\"\">Request data portability (where applicable)</p>\r\n</li>\r\n</ul>\r\n<p data-start=\"2410\" data-end=\"2484\" class=\"\">To exercise these rights, please contact us at <strong data-start=\"2457\" data-end=\"2483\"><a data-start=\"2459\" data-end=\"2481\" class=\"cursor-pointer\" rel=\"noopener\">support@writercert.com</a></strong>.</p>\r\n<hr data-start=\"2486\" data-end=\"2489\" class=\"\">\r\n</h2><h3 data-start=\"2491\" data-end=\"2512\" class=\"\">7. Data Retention</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2514\" data-end=\"2660\" class=\"\">We retain your data for as long as your account is active or as necessary to provide services, comply with legal obligations, or resolve disputes.</p>\r\n<hr data-start=\"2662\" data-end=\"2665\" class=\"\">\r\n</h2><h3 data-start=\"2667\" data-end=\"2692\" class=\"\">8. Children\'s Privacy</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2694\" data-end=\"2889\" class=\"\">WriterCert is not intended for children under the age of 13. We do not knowingly collect data from minors. If we learn that a child has provided us with personal data, we will delete it promptly.</p>\r\n<hr data-start=\"2891\" data-end=\"2894\" class=\"\">\r\n</h2><h3 data-start=\"2896\" data-end=\"2920\" class=\"\">9. Third-Party Links</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2922\" data-end=\"3092\" class=\"\">Our platform may include links or integrations to third-party sites or tools. We are not responsible for their privacy practices. Please review their policies separately.</p>\r\n<hr data-start=\"3094\" data-end=\"3097\" class=\"\">\r\n</h2><h3 data-start=\"3099\" data-end=\"3129\" class=\"\">10. Changes to This Policy</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"3131\" data-end=\"3317\" class=\"\">We may update this Privacy Policy periodically. Any changes will be posted here with an updated effective date. Continued use of the platform constitutes acceptance of the revised terms.</p>\r\n<hr data-start=\"3319\" data-end=\"3322\" class=\"\">\r\n</h2><h3 data-start=\"3324\" data-end=\"3342\" class=\"\">11. Contact Us</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"3344\" data-end=\"3424\" class=\"\">If you have any questions or concerns about this Privacy Policy, please contact:</p>\r\n<p data-start=\"3426\" data-end=\"3487\" class=\"\">', 'Quis ab ut officia b', '30', 'Explicabo Consectet', '2023-02-16 12:28:22', '2025-05-04 13:23:11', NULL, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `page_localizations`
--

CREATE TABLE `page_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `page_id` int NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `page_localizations`
--

INSERT INTO `page_localizations` (`id`, `page_id`, `title`, `content`, `lang_key`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Terms & Conditions', '<div class=\"mb-5\" style=\"color: rgb(71, 85, 105); font-family: Jost, sans-serif; font-size: 15.008px;\"><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\"><p data-start=\"172\" data-end=\"205\" class=\"\"><strong data-start=\"172\" data-end=\"191\">Effective Date:</strong> 05-4-2025</p>\r\n<p data-start=\"207\" data-end=\"400\" class=\"\">Welcome to <strong data-start=\"218\" data-end=\"236\">WriterCert.com</strong>. By accessing or using our website and services, you agree to be bound by the following Terms and Conditions. Please read them carefully before using our platform.</p>\r\n<hr data-start=\"402\" data-end=\"405\" class=\"\">\r\n</h2><h3 data-start=\"407\" data-end=\"433\" class=\"\">1. Acceptance of Terms</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"435\" data-end=\"690\" class=\"\">By registering, accessing, or using any services on WriterCert.com (hereinafter “WriterCert”, “we”, “our”, or “us”), you agree to be legally bound by these Terms &amp; Conditions. If you do not agree with any part of these terms, you may not use our services.</p>\r\n<hr data-start=\"692\" data-end=\"695\" class=\"\">\r\n</h2><h3 data-start=\"697\" data-end=\"720\" class=\"\">2. Services Offered</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"722\" data-end=\"950\" class=\"\">WriterCert provides AI-powered tools for generating written content, images, voice-based content, and automated posting to external platforms such as WordPress, Medium, and Blogger. Some features may require a paid subscription.</p>\r\n<hr data-start=\"952\" data-end=\"955\" class=\"\">\r\n</h2><h3 data-start=\"957\" data-end=\"985\" class=\"\">3. User Responsibilities</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"987\" data-end=\"1223\">\r\n<li data-start=\"987\" data-end=\"1044\" class=\"\">\r\n<p data-start=\"989\" data-end=\"1044\" class=\"\">You agree to use WriterCert for lawful purposes only.</p>\r\n</li>\r\n<li data-start=\"1045\" data-end=\"1133\" class=\"\">\r\n<p data-start=\"1047\" data-end=\"1133\" class=\"\">You are responsible for maintaining the confidentiality of your account credentials.</p>\r\n</li>\r\n<li data-start=\"1134\" data-end=\"1223\" class=\"\">\r\n<p data-start=\"1136\" data-end=\"1223\" class=\"\">You are solely responsible for any content generated or published through your account.</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"1225\" data-end=\"1228\" class=\"\">\r\n</h2><h3 data-start=\"1230\" data-end=\"1258\" class=\"\">4. Intellectual Property</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"1260\" data-end=\"1507\" class=\"\">All content and technology on WriterCert, including AI models, software, design, and branding, are the property of WriterCert or its licensors. You may not copy, redistribute, or reproduce any part of the platform without prior written permission.</p>\r\n<p data-start=\"1509\" data-end=\"1700\" class=\"\">Content generated by our AI may be used by you, but <strong data-start=\"1561\" data-end=\"1642\">you remain responsible for ensuring its legality, originality, and compliance</strong> with applicable laws and third-party platform guidelines.</p>\r\n<hr data-start=\"1702\" data-end=\"1705\" class=\"\">\r\n</h2><h3 data-start=\"1707\" data-end=\"1738\" class=\"\">5. Payment and Subscription</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"1740\" data-end=\"1979\">\r\n<li data-start=\"1740\" data-end=\"1832\" class=\"\">\r\n<p data-start=\"1742\" data-end=\"1832\" class=\"\">Some features of WriterCert are free; others require a subscription or one-time payment.</p>\r\n</li>\r\n<li data-start=\"1833\" data-end=\"1881\" class=\"\">\r\n<p data-start=\"1835\" data-end=\"1881\" class=\"\">All sales are final unless otherwise stated.</p>\r\n</li>\r\n<li data-start=\"1882\" data-end=\"1979\" class=\"\">\r\n<p data-start=\"1884\" data-end=\"1979\" class=\"\">Prices and features may change; users will be notified in advance if significant changes occur.</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"1981\" data-end=\"1984\" class=\"\">\r\n</h2><h3 data-start=\"1986\" data-end=\"2021\" class=\"\">6. Cancellation and Termination</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2023\" data-end=\"2215\" class=\"\">You may cancel your account at any time from your dashboard. We reserve the right to suspend or terminate any account that violates these Terms, or if we suspect misuse or abuse of the system.</p>\r\n<hr data-start=\"2217\" data-end=\"2220\" class=\"\">\r\n</h2><h3 data-start=\"2222\" data-end=\"2252\" class=\"\">7. Limitation of Liability</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2254\" data-end=\"2432\" class=\"\">WriterCert does not guarantee the accuracy, completeness, or legality of AI-generated content. We are not liable for any damages resulting from the use or misuse of our services.</p>\r\n<p data-start=\"2434\" data-end=\"2472\" class=\"\">Use of WriterCert is at your own risk.</p>\r\n<hr data-start=\"2474\" data-end=\"2477\" class=\"\">\r\n</h2><h3 data-start=\"2479\" data-end=\"2493\" class=\"\">8. Privacy</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2495\" data-end=\"2639\" class=\"\">Your privacy is important to us. Please refer to our <a data-start=\"2548\" data-end=\"2581\" class=\"cursor-pointer\" rel=\"noopener\">Privacy Policy</a> to learn how we collect, store, and use your information.</p>\r\n<hr data-start=\"2641\" data-end=\"2644\" class=\"\">\r\n</h2><h3 data-start=\"2646\" data-end=\"2666\" class=\"\">9. Modifications</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2668\" data-end=\"2856\" class=\"\">We reserve the right to update or change these Terms at any time. Changes will be effective immediately upon posting. Continued use of the platform constitutes acceptance of those changes.</p>\r\n<hr data-start=\"2858\" data-end=\"2861\" class=\"\">\r\n</h2><h3 data-start=\"2863\" data-end=\"2881\" class=\"\">10. Contact Us</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2883\" data-end=\"2949\" class=\"\">If you have any questions about these Terms, please contact us at:</p>\r\n<p data-start=\"2951\" data-end=\"3012\" class=\"\">', 'en', '2023-02-16 12:28:22', '2025-05-04 13:22:25', NULL),
(2, 2, 'Privacy & Policy', '<div class=\"mb-5\" style=\"color: rgb(71, 85, 105); font-family: Jost, sans-serif; font-size: 15.008px;\"><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\"><p data-start=\"149\" data-end=\"182\" class=\"\"><strong data-start=\"149\" data-end=\"168\">Effective Date:</strong>&nbsp;05-04-2025</p>\r\n<p data-start=\"184\" data-end=\"394\" class=\"\">At <strong data-start=\"187\" data-end=\"205\">WriterCert.com</strong>, we value your privacy. This Privacy Policy explains how we collect, use, store, and protect your personal data when you visit our website, register an account, or use any of our services.</p>\r\n<p data-start=\"396\" data-end=\"477\" class=\"\">By accessing WriterCert.com, you agree to the practices described in this policy.</p>\r\n<hr data-start=\"479\" data-end=\"482\" class=\"\">\r\n</h2><h3 data-start=\"484\" data-end=\"513\" class=\"\">1. Information We Collect</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"515\" data-end=\"561\" class=\"\">We collect the following types of information:</p>\r\n</h2><h4 data-start=\"563\" data-end=\"593\" class=\"\">a. Personal Information</h4><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"594\" data-end=\"687\">\r\n<li data-start=\"594\" data-end=\"602\" class=\"\">\r\n<p data-start=\"596\" data-end=\"602\" class=\"\">Name</p>\r\n</li>\r\n<li data-start=\"603\" data-end=\"620\" class=\"\">\r\n<p data-start=\"605\" data-end=\"620\" class=\"\">Email address</p>\r\n</li>\r\n<li data-start=\"621\" data-end=\"644\" class=\"\">\r\n<p data-start=\"623\" data-end=\"644\" class=\"\">Account credentials</p>\r\n</li>\r\n<li data-start=\"645\" data-end=\"687\" class=\"\">\r\n<p data-start=\"647\" data-end=\"687\" class=\"\">Billing details (for paid subscriptions)</p>\r\n</li>\r\n</ul>\r\n</h2><h4 data-start=\"689\" data-end=\"716\" class=\"\">b. Usage Information</h4><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"717\" data-end=\"810\">\r\n<li data-start=\"717\" data-end=\"731\" class=\"\">\r\n<p data-start=\"719\" data-end=\"731\" class=\"\">IP address</p>\r\n</li>\r\n<li data-start=\"732\" data-end=\"759\" class=\"\">\r\n<p data-start=\"734\" data-end=\"759\" class=\"\">Device and browser type</p>\r\n</li>\r\n<li data-start=\"760\" data-end=\"777\" class=\"\">\r\n<p data-start=\"762\" data-end=\"777\" class=\"\">Pages visited</p>\r\n</li>\r\n<li data-start=\"778\" data-end=\"795\" class=\"\">\r\n<p data-start=\"780\" data-end=\"795\" class=\"\">Features used</p>\r\n</li>\r\n<li data-start=\"796\" data-end=\"810\" class=\"\">\r\n<p data-start=\"798\" data-end=\"810\" class=\"\">Access times</p>\r\n</li>\r\n</ul>\r\n</h2><h4 data-start=\"812\" data-end=\"834\" class=\"\">c. Content Data</h4><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<ul data-start=\"835\" data-end=\"967\">\r\n<li data-start=\"835\" data-end=\"880\" class=\"\">\r\n<p data-start=\"837\" data-end=\"880\" class=\"\">Any content you create using our AI tools</p>\r\n</li>\r\n<li data-start=\"881\" data-end=\"967\" class=\"\">\r\n<p data-start=\"883\" data-end=\"967\" class=\"\">Posts scheduled or published through integrations (e.g., WordPress, Medium, Blogger)</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"969\" data-end=\"972\" class=\"\">\r\n</h2><h3 data-start=\"974\" data-end=\"1008\" class=\"\">2. How We Use Your Information</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"1010\" data-end=\"1047\" class=\"\">We use the information we collect to:</p>\r\n<ul data-start=\"1049\" data-end=\"1335\">\r\n<li data-start=\"1049\" data-end=\"1085\" class=\"\">\r\n<p data-start=\"1051\" data-end=\"1085\" class=\"\">Provide and improve our services</p>\r\n</li>\r\n<li data-start=\"1086\" data-end=\"1117\" class=\"\">\r\n<p data-start=\"1088\" data-end=\"1117\" class=\"\">Personalize your experience</p>\r\n</li>\r\n<li data-start=\"1118\" data-end=\"1158\" class=\"\">\r\n<p data-start=\"1120\" data-end=\"1158\" class=\"\">Manage accounts and process payments</p>\r\n</li>\r\n<li data-start=\"1159\" data-end=\"1200\" class=\"\">\r\n<p data-start=\"1161\" data-end=\"1200\" class=\"\">Respond to customer support inquiries</p>\r\n</li>\r\n<li data-start=\"1201\" data-end=\"1277\" class=\"\">\r\n<p data-start=\"1203\" data-end=\"1277\" class=\"\">Send service-related updates and marketing emails (with opt-out options)</p>\r\n</li>\r\n<li data-start=\"1278\" data-end=\"1335\" class=\"\">\r\n<p data-start=\"1280\" data-end=\"1335\" class=\"\">Analyze usage trends and improve platform functionality</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"1337\" data-end=\"1340\" class=\"\">\r\n</h2><h3 data-start=\"1342\" data-end=\"1373\" class=\"\">3. Sharing Your Information</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"1375\" data-end=\"1462\" class=\"\">We <strong data-start=\"1378\" data-end=\"1401\">do not sell or rent</strong> your personal data. However, we may share it in these cases:</p>\r\n<ul data-start=\"1464\" data-end=\"1687\">\r\n<li data-start=\"1464\" data-end=\"1563\" class=\"\">\r\n<p data-start=\"1466\" data-end=\"1563\" class=\"\">With trusted third-party service providers for payment processing, analytics, or infrastructure</p>\r\n</li>\r\n<li data-start=\"1564\" data-end=\"1605\" class=\"\">\r\n<p data-start=\"1566\" data-end=\"1605\" class=\"\">When required by law or legal process</p>\r\n</li>\r\n<li data-start=\"1606\" data-end=\"1687\" class=\"\">\r\n<p data-start=\"1608\" data-end=\"1687\" class=\"\">To protect our rights, users, or the public from fraudulent or harmful activity</p>\r\n</li>\r\n</ul>\r\n<hr data-start=\"1689\" data-end=\"1692\" class=\"\">\r\n</h2><h3 data-start=\"1694\" data-end=\"1721\" class=\"\">4. Cookies and Tracking</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"1723\" data-end=\"1775\" class=\"\">We use cookies and similar tracking technologies to:</p>\r\n<ul data-start=\"1777\" data-end=\"1882\">\r\n<li data-start=\"1777\" data-end=\"1803\" class=\"\">\r\n<p data-start=\"1779\" data-end=\"1803\" class=\"\">Maintain user sessions</p>\r\n</li>\r\n<li data-start=\"1804\" data-end=\"1852\" class=\"\">\r\n<p data-start=\"1806\" data-end=\"1852\" class=\"\">Analyze user behavior for improving services</p>\r\n</li>\r\n<li data-start=\"1853\" data-end=\"1882\" class=\"\">\r\n<p data-start=\"1855\" data-end=\"1882\" class=\"\">Remember user preferences</p>\r\n</li>\r\n</ul>\r\n<p data-start=\"1884\" data-end=\"1980\" class=\"\">You can disable cookies through your browser settings, but it may impact platform functionality.</p>\r\n<hr data-start=\"1982\" data-end=\"1985\" class=\"\">\r\n</h2><h3 data-start=\"1987\" data-end=\"2007\" class=\"\">5. Data Security</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2009\" data-end=\"2219\" class=\"\">We implement industry-standard security measures (encryption, secure access controls, etc.) to protect your personal data. However, no system is 100% secure, so please use our services with appropriate caution.</p>\r\n<hr data-start=\"2221\" data-end=\"2224\" class=\"\">\r\n</h2><h3 data-start=\"2226\" data-end=\"2244\" class=\"\">6. Your Rights</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2246\" data-end=\"2268\" class=\"\">You have the right to:</p>\r\n<ul data-start=\"2270\" data-end=\"2408\">\r\n<li data-start=\"2270\" data-end=\"2309\" class=\"\">\r\n<p data-start=\"2272\" data-end=\"2309\" class=\"\">Access, update, or delete your data</p>\r\n</li>\r\n<li data-start=\"2310\" data-end=\"2362\" class=\"\">\r\n<p data-start=\"2312\" data-end=\"2362\" class=\"\">Withdraw consent (e.g., unsubscribe from emails)</p>\r\n</li>\r\n<li data-start=\"2363\" data-end=\"2408\" class=\"\">\r\n<p data-start=\"2365\" data-end=\"2408\" class=\"\">Request data portability (where applicable)</p>\r\n</li>\r\n</ul>\r\n<p data-start=\"2410\" data-end=\"2484\" class=\"\">To exercise these rights, please contact us at <strong data-start=\"2457\" data-end=\"2483\"><a data-start=\"2459\" data-end=\"2481\" class=\"cursor-pointer\" rel=\"noopener\">support@writercert.com</a></strong>.</p>\r\n<hr data-start=\"2486\" data-end=\"2489\" class=\"\">\r\n</h2><h3 data-start=\"2491\" data-end=\"2512\" class=\"\">7. Data Retention</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2514\" data-end=\"2660\" class=\"\">We retain your data for as long as your account is active or as necessary to provide services, comply with legal obligations, or resolve disputes.</p>\r\n<hr data-start=\"2662\" data-end=\"2665\" class=\"\">\r\n</h2><h3 data-start=\"2667\" data-end=\"2692\" class=\"\">8. Children\'s Privacy</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2694\" data-end=\"2889\" class=\"\">WriterCert is not intended for children under the age of 13. We do not knowingly collect data from minors. If we learn that a child has provided us with personal data, we will delete it promptly.</p>\r\n<hr data-start=\"2891\" data-end=\"2894\" class=\"\">\r\n</h2><h3 data-start=\"2896\" data-end=\"2920\" class=\"\">9. Third-Party Links</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"2922\" data-end=\"3092\" class=\"\">Our platform may include links or integrations to third-party sites or tools. We are not responsible for their privacy practices. Please review their policies separately.</p>\r\n<hr data-start=\"3094\" data-end=\"3097\" class=\"\">\r\n</h2><h3 data-start=\"3099\" data-end=\"3129\" class=\"\">10. Changes to This Policy</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"3131\" data-end=\"3317\" class=\"\">We may update this Privacy Policy periodically. Any changes will be posted here with an updated effective date. Continued use of the platform constitutes acceptance of the revised terms.</p>\r\n<hr data-start=\"3319\" data-end=\"3322\" class=\"\">\r\n</h2><h3 data-start=\"3324\" data-end=\"3342\" class=\"\">11. Contact Us</h3><h2 class=\"h5\" style=\"font-family: Rubik, sans-serif; font-weight: 500; color: rgb(51, 65, 85); font-size: 1.1725rem;\">\r\n<p data-start=\"3344\" data-end=\"3424\" class=\"\">If you have any questions or concerns about this Privacy Policy, please contact:</p>\r\n<p data-start=\"3426\" data-end=\"3487\" class=\"\">', 'en', '2023-02-16 12:28:22', '2025-05-04 13:23:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `paymentgateway_product_histories`
--

CREATE TABLE `paymentgateway_product_histories` (
  `id` bigint UNSIGNED NOT NULL,
  `package_id` int NOT NULL DEFAULT '0',
  `package_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `gateway` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `old_product_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `product_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `old_billing_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `new_billing_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateways`
--

CREATE TABLE `payment_gateways` (
  `id` bigint UNSIGNED NOT NULL,
  `gateway` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `image` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_recurring` tinyint(1) DEFAULT '0',
  `webhook_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `sandbox` tinyint(1) DEFAULT '0',
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'sandbox, live',
  `is_active` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '0',
  `service_charge` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '0',
  `charge_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT '1= flat, 2=percentage',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `webhook_secret` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `payment_gateways`
--

INSERT INTO `payment_gateways` (`id`, `gateway`, `image`, `is_recurring`, `webhook_id`, `sandbox`, `type`, `is_active`, `service_charge`, `charge_type`, `created_at`, `updated_at`, `webhook_secret`) VALUES
(1, 'paypal', 'backend/assets/img/payments/paypal.svg', NULL, NULL, 0, 'live', '1', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 22:45:51', NULL),
(2, 'stripe', 'backend/assets/img/payments/stripe.svg', NULL, NULL, 0, 'live', '1', '0', NULL, '2025-04-21 16:31:45', '2025-05-13 15:15:22', NULL),
(3, 'paytm', 'backend/assets/img/payments/paytm.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(4, 'razorpay', 'backend/assets/img/payments/razorpay.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(5, 'iyzico', 'backend/assets/img/payments/iyzico.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(6, 'paystack', 'backend/assets/img/payments/paystack.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(7, 'flutterwave', 'backend/assets/img/payments/flutterwave.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(8, 'duitku', 'backend/assets/img/payments/duitku.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(9, 'yookassa', 'backend/assets/img/payments/yookassa.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(10, 'molile', 'backend/assets/img/payments/molile.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(11, 'mercadopago', 'backend/assets/img/payments/mercadopago.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL),
(12, 'midtrans', 'backend/assets/img/payments/midtrans.svg', 0, NULL, 0, 'live', '0', '0', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateway_details`
--

CREATE TABLE `payment_gateway_details` (
  `id` bigint UNSIGNED NOT NULL,
  `payment_gateway_id` int NOT NULL,
  `key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `value` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `payment_gateway_details`
--

INSERT INTO `payment_gateway_details` (`id`, `payment_gateway_id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 1, 'PAYPAL_CLIENT_ID', 'sfsfsf', '2025-04-21 16:31:45', '2025-04-21 22:45:51'),
(2, 1, 'PAYPAL_CLIENT_SECRET', 'sfsfsfsfsf', '2025-04-21 16:31:45', '2025-04-21 22:45:51'),
(3, 2, 'STRIPE_KEY', 'pk_test_51Mo4ikITCz0zIkvbORQ7fbpYL22oR3P2MvoR0MaInOfxSFgqiYkv9B1HtG0qSamcoPfvwD0hsq6HWbb4UwAnDSfD00fe4Y27Kw', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(4, 2, 'STRIPE_SECRET', 'sk_test_51Mo4ikITCz0zIkvbO7G5QkJWPhpvKYaBQGCLrgtYp2JvRwOqAQpo7Ir0xQSHMbY0F420ICIPGUefeX3DUgk7IaJ800L5Vunbsk', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(5, 3, 'PAYTM_ENVIRONMENT', 'local', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(6, 3, 'PAYTM_MERCHANT_ID', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(7, 3, 'PAYTM_MERCHANT_KEY', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(8, 3, 'PAYTM_MERCHANT_WEBSITE', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(9, 3, 'PAYTM_CHANNEL', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(10, 3, 'PAYTM_INDUSTRY_TYPE', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(11, 4, 'RAZORPAY_KEY', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(12, 4, 'RAZORPAY_SECRET', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(13, 5, 'IYZICO_API_KEY', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(14, 5, 'IYZICO_SECRET_KEY', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(15, 6, 'PAYSTACK_PUBLIC_KEY', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(16, 6, 'PAYSTACK_SECRET_KEY', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(17, 6, 'MERCHANT_EMAIL', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(18, 6, 'PAYSTACK_CURRENCY_CODE', '3453', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(19, 7, 'FLW_PUBLIC_KEY', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(20, 7, 'FLW_SECRET_KEY', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(21, 7, 'FLW_SECRET_HASH', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(22, 8, 'DUITKU_API_KEY', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(23, 8, 'DUITKU_MERCHANT_CODE', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(24, 8, 'DUITKU_CALLBACK_URL', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(25, 8, 'DUITKU_RETURN_URL', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(26, 8, 'DUITKU_ENV', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(27, 9, 'YOOKASSA_SHOP_ID', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(28, 9, 'YOOKASSA_SECRET_KEY', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(29, 9, 'YOOKASSA_CURRENCY_CODE', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(30, 9, 'YOOKASSA_RECIEPT', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(31, 9, 'YOOKASSA_VAT', '', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(32, 10, 'MOLILE_API_KEY', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(33, 11, 'MERCADOPAGO_SECRET_KEY', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(34, 12, 'MIDTRANS_SERVER_KEY', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(35, 12, 'MIDTRANS_CLIENT_KEY', NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45');

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateway_products`
--

CREATE TABLE `payment_gateway_products` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `package_id` int NOT NULL DEFAULT '0',
  `package_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `gateway` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `product_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `billing_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `price_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pdf_chats`
--

CREATE TABLE `pdf_chats` (
  `id` bigint UNSIGNED NOT NULL,
  `chat_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `prompt_tokens` int NOT NULL DEFAULT '0',
  `total_words` int NOT NULL DEFAULT '0',
  `total_tokens` int NOT NULL DEFAULT '0',
  `user_id` bigint UNSIGNED NOT NULL,
  `total_conversations` int NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `pdf_chats`
--

INSERT INTO `pdf_chats` (`id`, `chat_code`, `prompt_tokens`, `total_words`, `total_tokens`, `user_id`, `total_conversations`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'R1i8E2H4U3', 0, 0, 0, 1, 0, NULL, '2025-05-04 14:02:40', '2025-05-04 14:02:40');

-- --------------------------------------------------------

--
-- Table structure for table `pdf_chat_conversations`
--

CREATE TABLE `pdf_chat_conversations` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `pdf_chat_id` bigint UNSIGNED NOT NULL,
  `pdf_file` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `pdf_content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL COMMENT 'PDF Inside Text',
  `pdf_embedding_content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `prompt_embedding_content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `ai_response` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `words` int NOT NULL DEFAULT '0',
  `prompt_tokens` int NOT NULL DEFAULT '0',
  `total_used_tokens` int NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `group_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `guard_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `group_name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'dashboard', 'dashboard', 'web', NULL, NULL),
(2, 'subscriptions', 'subscriptions', 'web', NULL, NULL),
(3, 'subscriptions_histories', 'subscriptions', 'web', NULL, NULL),
(4, 'folders', 'folders', 'web', NULL, NULL),
(5, 'projects', 'projects', 'web', NULL, NULL),
(6, 'templates', 'templates', 'web', NULL, NULL),
(7, 'speech_to_text', 'ai_tools', 'web', NULL, NULL),
(8, 'generate_images', 'ai_tools', 'web', NULL, NULL),
(9, 'generate_code', 'ai_tools', 'web', NULL, NULL),
(10, 'customers', 'customers', 'web', NULL, NULL),
(11, 'ban_customers', 'customers', 'web', NULL, NULL),
(12, 'all_staffs', 'staffs', 'web', NULL, NULL),
(13, 'add_staffs', 'staffs', 'web', NULL, NULL),
(14, 'edit_staffs', 'staffs', 'web', NULL, NULL),
(15, 'delete_staffs', 'staffs', 'web', NULL, NULL),
(16, 'contact_us_messages', 'contact_us_messages', 'web', NULL, NULL),
(17, 'tags', 'tags', 'web', NULL, NULL),
(18, 'add_tags', 'tags', 'web', NULL, NULL),
(19, 'edit_tags', 'tags', 'web', NULL, NULL),
(20, 'delete_tags', 'tags', 'web', NULL, NULL),
(21, 'blogs', 'blogs', 'web', NULL, NULL),
(22, 'add_blogs', 'blogs', 'web', NULL, NULL),
(23, 'edit_blogs', 'blogs', 'web', NULL, NULL),
(24, 'publish_blogs', 'blogs', 'web', NULL, NULL),
(25, 'delete_blogs', 'blogs', 'web', NULL, NULL),
(26, 'blog_categories', 'blogs', 'web', NULL, NULL),
(27, 'add_blog_categories', 'blogs', 'web', NULL, NULL),
(28, 'edit_blog_categories', 'blogs', 'web', NULL, NULL),
(29, 'delete_blog_categories', 'blogs', 'web', NULL, NULL),
(30, 'pages', 'pages', 'web', NULL, NULL),
(31, 'add_pages', 'pages', 'web', NULL, NULL),
(32, 'edit_pages', 'pages', 'web', NULL, NULL),
(33, 'delete_pages', 'pages', 'web', NULL, NULL),
(34, 'faqs', 'faqs', 'web', NULL, NULL),
(35, 'media_manager', 'media_manager', 'web', NULL, NULL),
(36, 'add_media', 'media_manager', 'web', NULL, NULL),
(37, 'delete_media', 'media_manager', 'web', NULL, NULL),
(38, 'newsletters', 'newsletters', 'web', NULL, NULL),
(39, 'subscribers', 'newsletters', 'web', NULL, NULL),
(40, 'delete_subscribers', 'newsletters', 'web', NULL, NULL),
(41, 'open_ai', 'open_ai', 'web', NULL, NULL),
(42, 'homepage', 'appearance', 'web', NULL, NULL),
(43, 'header', 'appearance', 'web', NULL, NULL),
(44, 'footer', 'appearance', 'web', NULL, NULL),
(45, 'roles_and_permissions', 'roles_and_permissions', 'web', NULL, NULL),
(46, 'add_roles_and_permissions', 'roles_and_permissions', 'web', NULL, NULL),
(47, 'edit_roles_and_permissions', 'roles_and_permissions', 'web', NULL, NULL),
(48, 'delete_roles_and_permissions', 'roles_and_permissions', 'web', NULL, NULL),
(49, 'smtp_settings', 'system_settings', 'web', NULL, NULL),
(50, 'general_settings', 'system_settings', 'web', NULL, NULL),
(51, 'currency_settings', 'system_settings', 'web', NULL, NULL),
(52, 'add_currency', 'system_settings', 'web', NULL, NULL),
(53, 'edit_currency', 'system_settings', 'web', NULL, NULL),
(54, 'publish_currency', 'system_settings', 'web', NULL, NULL),
(55, 'language_settings', 'system_settings', 'web', NULL, NULL),
(56, 'add_languages', 'system_settings', 'web', NULL, NULL),
(57, 'edit_languages', 'system_settings', 'web', NULL, NULL),
(58, 'publish_languages', 'system_settings', 'web', NULL, NULL),
(59, 'translate_languages', 'system_settings', 'web', NULL, NULL),
(60, 'payment_settings', 'system_settings', 'web', NULL, NULL),
(61, 'default_language', 'system_settings', 'web', NULL, NULL),
(62, 'default_currency', 'system_settings', 'web', NULL, NULL),
(63, 'social_login_settings', 'system_settings', 'web', NULL, NULL),
(64, 'auth_settings', 'system_settings', 'web', NULL, NULL),
(65, 'otp_settings', 'system_settings', 'web', NULL, NULL),
(66, 'affiliate_configurations', 'affiliate_system', 'web', NULL, NULL),
(67, 'affiliate_withdraw', 'affiliate_system', 'web', NULL, NULL),
(68, 'affiliate_earning_histories', 'affiliate_system', 'web', NULL, NULL),
(69, 'affiliate_payment_histories', 'affiliate_system', 'web', NULL, NULL),
(70, 'custom_template_categories', 'templates', 'web', NULL, NULL),
(71, 'custom_templates', 'templates', 'web', NULL, NULL),
(72, 'words_report', 'report', 'web', NULL, NULL),
(73, 'codes_report', 'report', 'web', NULL, NULL),
(74, 'images_report', 'report', 'web', NULL, NULL),
(75, 's2t_report', 'report', 'web', NULL, NULL),
(76, 'most_used_templates', 'report', 'web', NULL, NULL),
(77, 'subscriptions_reports', 'report', 'web', NULL, NULL),
(78, 'ai_chat', 'ai_tools', 'web', NULL, NULL),
(79, 'about_us_page', 'appearance', 'web', NULL, NULL),
(80, 'text_to_speech', 'ai_tools', 'web', NULL, NULL),
(81, 'multiOpenAi', 'open_ai', 'web', NULL, NULL),
(82, 'add_multiOpenAi', 'open_ai', 'web', NULL, NULL),
(83, 'edit_multiOpenAi', 'open_ai', 'web', NULL, NULL),
(84, 'status_multiOpenAi', 'open_ai', 'web', NULL, NULL),
(85, 'delete_multiOpenAi', 'open_ai', 'web', NULL, NULL),
(86, 'voice_settings', 'voice_settings', 'web', NULL, NULL),
(87, 'own_staff', 'staffs', 'web', NULL, NULL),
(88, 'offline_payment_methods', 'offline_payment_methods', 'web', NULL, NULL),
(89, 'add_offline_payment_methods', 'offline_payment_methods', 'web', NULL, NULL),
(90, 'edit_offline_payment_methods', 'offline_payment_methods', 'web', NULL, NULL),
(91, 'delete_offline_payment_methods', 'offline_payment_methods', 'web', NULL, NULL),
(92, 'all_payment_request', 'payment_request', 'web', NULL, NULL),
(93, 'approve_payment_request', 'payment_request', 'web', NULL, NULL),
(94, 'reject_payment_request', 'payment_request', 'web', NULL, NULL),
(95, 'add_note_payment_request', 'payment_request', 'web', NULL, NULL),
(96, 'add_customer', 'customers', 'web', NULL, NULL),
(97, 'cron_job', 'system_settings', 'web', NULL, NULL),
(98, 'storage_manager', 'system_settings', 'web', NULL, NULL),
(99, 'blog_wizard', 'blog_wizard', 'web', NULL, NULL),
(100, 'subscriptions_settings', 'subscriptions', 'web', NULL, NULL),
(101, 'add_folders', 'folders', 'web', NULL, NULL),
(102, 'text_to_speech_eleven_labs', 'ai_tools', 'web', NULL, NULL),
(103, 'pwa_settings', 'system_settings', 'web', NULL, NULL),
(104, 'ai_vision', 'ai_tools', 'web', NULL, NULL),
(105, 'ai_image_chat', 'ai_tools', 'web', NULL, NULL),
(106, 'email_template', 'system_settings', 'web', NULL, NULL),
(107, 'ai_pdf_chat', 'ai_tools', 'web', NULL, NULL),
(108, 'fine_tune', 'ai_tools', 'web', NULL, NULL),
(109, 'ai_rewriter', 'ai_tools', 'web', NULL, NULL),
(110, 'dall_e_2', 'ai_images', 'web', NULL, NULL),
(111, 'dall_e_3', 'ai_images', 'web', NULL, NULL),
(112, 'stable_diffusion', 'ai_images', 'web', NULL, NULL),
(113, 'popular_templates', 'templates', 'web', NULL, NULL),
(114, 'favorites_templates', 'templates', 'web', NULL, NULL),
(115, 'support_category', 'supports', 'web', NULL, NULL),
(116, 'support_ticket', 'supports', 'web', NULL, NULL),
(117, 'support_priority', 'supports', 'web', NULL, NULL),
(118, 'theme_settings', 'appearance', 'web', NULL, NULL),
(119, 'invoice_settings', 'system_settings', 'web', NULL, NULL),
(120, 'plagiarism_api', 'plagiarism', 'web', NULL, NULL),
(121, 'ai_plagiarism', 'plagiarism', 'web', NULL, NULL),
(122, 'ai_detector', 'plagiarism', 'web', NULL, NULL),
(123, 'add_content_detectors', 'plagiarism', 'web', NULL, NULL),
(124, 'add_content_plagiarism', 'plagiarism', 'web', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plagiarism_settings`
--

CREATE TABLE `plagiarism_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `access_token` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint DEFAULT '0',
  `created_by` int DEFAULT '1',
  `updated_by` int DEFAULT '1',
  `issued` datetime DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `plagiarism_settings`
--

INSERT INTO `plagiarism_settings` (`id`, `email`, `key`, `access_token`, `is_active`, `created_by`, `updated_by`, `issued`, `expires`, `created_at`, `updated_at`) VALUES
(1, NULL, 'eN2fs2x1E9Z8tLDD1YrdtALeQ0k9mNI1bq3HR4Zt9b75d9ab', NULL, 1, 1, 1, NULL, NULL, '2025-04-21 17:58:12', '2025-04-21 17:58:12');

-- --------------------------------------------------------

--
-- Table structure for table `priorities`
--

CREATE TABLE `priorities` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `user_id` int DEFAULT NULL,
  `color` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `priorities`
--

INSERT INTO `priorities` (`id`, `name`, `is_active`, `user_id`, `color`, `created_at`, `updated_at`) VALUES
(1, 'High', 1, 1, '#e11414', '2025-04-21 16:31:45', '2025-04-21 16:31:45'),
(2, 'Low', 1, 1, '#528118', '2025-04-21 16:31:45', '2025-04-21 16:31:45');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int DEFAULT NULL,
  `folder_id` int DEFAULT NULL,
  `template_id` int DEFAULT NULL,
  `custom_template_id` int DEFAULT NULL,
  `model_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `slug` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `prompts` bigint DEFAULT NULL,
  `completion` bigint DEFAULT NULL,
  `words` bigint DEFAULT NULL,
  `content_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'content/image/code/speech_to_text...',
  `resolution` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `audio_file` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `text_to_speech_content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `engine` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'OpenAI',
  `storage_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'local',
  `input_prompt` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `completion_tokens` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_published` tinyint DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `user_id`, `folder_id`, `template_id`, `custom_template_id`, `model_name`, `title`, `slug`, `content`, `prompts`, `completion`, `words`, `content_type`, `resolution`, `audio_file`, `text_to_speech_content`, `created_at`, `updated_at`, `deleted_at`, `engine`, `storage_type`, `input_prompt`, `completion_tokens`, `is_published`) VALUES
(1, 1, NULL, NULL, NULL, NULL, 'popular-post-10.png', 'popular-post-10.png-fgqyl', 'uploads/media/YmXrreIeXCCjjROng5N58MnZFB7AycRvQZgdQcPH.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(2, 1, NULL, NULL, NULL, NULL, 'popular-post-9.png', 'popular-post-9.png-ounev', 'uploads/media/eIzd6hHZOalcnwrPMqaHU7AqQuZqjY05u8pIoxHn.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(3, 1, NULL, NULL, NULL, NULL, 'popular-post-11.png', 'popular-post-11.png-2khjt', 'uploads/media/z6ghEhPROsxDnURSgtpNo83eBmhBMkbG5ezD5M3E.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(4, 1, NULL, NULL, NULL, NULL, 'popular-post-5.png', 'popular-post-5.png-wnwzx', 'uploads/media/1DLUMsmNyGy8PeF50xteMxGUSQI2AoBkVMdFKV1M.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(5, 1, NULL, NULL, NULL, NULL, 'popular-post-4.png', 'popular-post-4.png-do5ay', 'uploads/media/MLz5akOToNx4ET1T4CojXeEvu9WH6QhgP9cOhY1O.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(6, 1, NULL, NULL, NULL, NULL, 'popular-post-3.png', 'popular-post-3.png-a1yd2', 'uploads/media/T4Vzc5QJ3ya77Z4IOcwHocZUxIxsaNiEeEOFGCim.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(7, 1, NULL, NULL, NULL, NULL, 'popular-post-2.png', 'popular-post-2.png-5mopa', 'uploads/media/rgD3lq6imYfhJEsTF5EZd69ht3VnbPb3ITxiEDPM.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(8, 1, NULL, NULL, NULL, NULL, 'popular-post-6.png', 'popular-post-6.png-8yzal', 'uploads/media/AbWfW3NOns772PGy2pL6pe8u1vXVWVFStUMqowol.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(9, 1, NULL, NULL, NULL, NULL, 'insight-3.png', 'insight-3.png-dl9ku', 'uploads/media/lhAEEpt9G0pMdZfAH6spBcr7rYtEphF9bVThs1FR.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(10, 1, NULL, NULL, NULL, NULL, 'insight-2.png', 'insight-2.png-kow38', 'uploads/media/ejOyRxBK6P3kE6Vr7e9FTduGhTwJ4RCKangRzEbK.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(11, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-5.png', 'ai-image-slide-5.png-hmlmy', 'uploads/media/76CwWSrcqNpKwOC4xyBdIcLaqHPZkfvGZXYjO93y.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(12, 1, NULL, NULL, NULL, NULL, 'popular-post-1.png', 'popular-post-1.png-rvaeq', 'uploads/media/NpyhziYxqZfYX1hrPCPDLLDgv5ZvqJT5GzahL6yt.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(13, 1, NULL, NULL, NULL, NULL, 'ai-featured-video-img-3.png', 'ai-featured-video-img-3.png-00uke', 'uploads/media/BUtcZ68o5zpNANxj38HNmI7R4mDfFEWGbhS4y4M8.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(14, 1, NULL, NULL, NULL, NULL, 'ai-featured-video-img-2.png', 'ai-featured-video-img-2.png-ksrj3', 'uploads/media/vMZ95Vilv0Qi6qO4rbx20fHPQurfzabU9HPjoE3c.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(15, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-2.png', 'ai-image-slide-2.png-nhei6', 'uploads/media/w1prPacnTuPvCdnmoKsf0olIi5sF2VxfNWiFsdqb.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(16, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-6.png', 'ai-image-slide-6.png-h9xeq', 'uploads/media/s6Cejmb02gSLbpOYiZzFQR3hlhkpwhyS4e1oIpNQ.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(17, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-12.png', 'ai-image-slide-12.png-y5nt0', 'uploads/media/92Rikf03wOrWggAeRm8PQCZfBzRtMJLBrwjAbTTU.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(18, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-11.png', 'ai-image-slide-11.png-dlkax', 'uploads/media/QMHd768U8eoUxuQoK2J9h1CupxsmXyxcE9XlfMFK.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(19, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-10.png', 'ai-image-slide-10.png-zul6k', 'uploads/media/7Quhoi9MaqmENZ6hQjnkyUuMkCyge70ZPbJdQ7zk.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(20, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-9.png', 'ai-image-slide-9.png-ts9fi', 'uploads/media/LpfohnS7fNJ98uBaLyBB5lf8D0xZNO8R1SZL25bQ.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(21, 1, NULL, NULL, NULL, NULL, 'insight-1.png', 'insight-1.png-u9f6z', 'uploads/media/CW4Mdr8igX30Q3m02ntRLAonfjig44K7SstXSQOx.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(22, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-16.png', 'ai-image-slide-16.png-xm71e', 'uploads/media/ffFR6R4lm6UlPiDs5kXbGUpFGrPawAIVM4N0ux3S.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(23, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-15.png', 'ai-image-slide-15.png-zvmu1', 'uploads/media/9WSCLmtY3vWtsK3Nt7R4UsLWEyXamk4M08qs1Kev.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(24, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-13.png', 'ai-image-slide-13.png-hmqnz', 'uploads/media/FlSHC8qUW5eVMOEWZc1jtJdwqeBQ8QNJWbPyXurI.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(25, 1, NULL, NULL, NULL, NULL, 'ai-featured-video-img-4.png', 'ai-featured-video-img-4.png-ha6vj', 'uploads/media/8u8g3zdRrb6EbiuZ1msdRoavDmaxsUbIgylzb7Av.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(26, 1, NULL, NULL, NULL, NULL, 'ai-image-slide-1.png', 'ai-image-slide-1.png-pjoig', 'uploads/media/qHVNZIW4EPy13v1TePIysBXpAqPWEihOS2owtJYg.png', NULL, NULL, NULL, 'image', NULL, NULL, NULL, '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL, 'local', 'local', NULL, NULL, 1),
(27, 1, NULL, NULL, NULL, 'gpt-3.5-turbo', 'Untitled Project - 2025-04-21', 'Untitled-Project---2025-04-21-v9hnz', '', 33, 1, 34, 'Ai ReWriter', NULL, NULL, NULL, '2025-04-21 16:48:09', '2025-04-21 16:48:10', NULL, 'OpenAI', 'local', 'how do make a coffee in English language how do make a coffee .The tone of voice should be Friendly and the output must be completed in  words. Do not generate translation.', NULL, 0),
(28, 1, NULL, NULL, NULL, 'gpt-3.5-turbo', 'Untitled Project - 2025-04-21', 'Untitled-Project---2025-04-21-bhuqy', '', 33, 1, 34, 'Ai ReWriter', NULL, NULL, NULL, '2025-04-21 17:20:45', '2025-04-21 17:20:46', NULL, 'OpenAI', 'local', 'how do make a coffe in English language how do make a coffe .The tone of voice should be Friendly and the output must be completed in  words. Do not generate translation.', NULL, 0),
(29, 1, NULL, NULL, NULL, 'gpt-3.5-turbo', 'Untitled Project - 2025-04-21', 'Untitled-Project---2025-04-21-txysr', '', 33, 1, 34, 'Ai ReWriter', NULL, NULL, NULL, '2025-04-21 17:22:11', '2025-04-21 17:22:12', NULL, 'OpenAI', 'local', 'how to make a cooffe in English language how to make a cooffe .The tone of voice should be Friendly and the output must be completed in  words. Do not generate translation.', NULL, 0),
(30, 1, NULL, NULL, NULL, 'gpt-3.5-turbo', 'Untitled Project - 2025-04-21', 'Untitled-Project---2025-04-21-5irfq', '', 25, 1, 26, 'Ai ReWriter', NULL, NULL, NULL, '2025-04-21 17:34:19', '2025-04-21 17:34:20', NULL, 'OpenAI', 'local', 'xvddvd in English language xvddvd .The tone of voice should be Friendly and the output must be completed in 1 words. Do not generate translation.', NULL, 0),
(31, 1, NULL, NULL, NULL, 'gpt-4', 'Untitled Project - 2025-04-21', 'Untitled-Project---2025-04-21-mzbvj', '', 25, 1, 26, 'Ai ReWriter', NULL, NULL, NULL, '2025-04-21 17:37:25', '2025-04-21 17:37:26', NULL, 'OpenAI', 'local', 'hello in English language hello .The tone of voice should be Friendly and the output must be completed in 1 words. Do not generate translation.', NULL, 0),
(32, 1, NULL, NULL, NULL, 'gpt-4', 'Untitled Project - 2025-04-21', 'Untitled-Project---2025-04-21-nl4zi', 'Pre', 371, 1, 372, 'Ai ReWriter', NULL, NULL, NULL, '2025-04-21 17:53:42', '2025-04-21 17:54:31', NULL, 'OpenAI', 'local', 'OpenAI operates on a prepaid, pay-as-you-go billing model for its API services. This means you purchase credits in advance, and your usage is deducted from this balance. Here\'s how it works:​\r\nhelp.promptitude.io\r\n\r\n', NULL, 0),
(33, 1, NULL, NULL, NULL, NULL, 'make money online', 'make-money-online-6znik', 'images/mEqqX9AAzV.png', NULL, NULL, NULL, 'image', '512x512', NULL, NULL, '2025-04-21 17:55:20', '2025-04-21 17:55:20', NULL, 'SD', 'local', NULL, NULL, 0),
(34, 1, NULL, NULL, NULL, NULL, 'make money online', 'make-money-online-1whgi', 'images/qtyFrgKuLh.png', NULL, NULL, NULL, 'image', '512x512', NULL, NULL, '2025-04-21 17:56:28', '2025-04-21 17:56:28', NULL, 'SD', 'local', NULL, NULL, 0),
(35, 1, NULL, 31, NULL, 'gpt-4', 'Untitled Project - 2025-04-21', 'Untitled-Project---2025-04-21-vwevd', 'As', 34, 1, 35, 'content', NULL, NULL, NULL, '2025-04-21 23:11:00', '2025-04-21 23:11:45', NULL, 'OpenAI', 'local', 'Generate about us content in English language for a website based on this text:\ntechitcenter.com\n\n .The tone of voice should be Friendly and the output must be completed in 1 words. Do not generate translation.', NULL, 0),
(36, 1, NULL, NULL, NULL, 'gpt-4', 'Untitled Project - 2025-04-22', 'Untitled-Project---2025-04-22-qb2mm', 'Profit', 29, 1, 30, 'Ai ReWriter', NULL, NULL, NULL, '2025-04-22 13:22:57', '2025-04-22 13:23:02', NULL, 'OpenAI', 'local', 'make money online in English language make money online .The tone of voice should be Friendly and the output must be completed in 1 words. Do not generate translation.', NULL, 0),
(37, 1, NULL, 1, NULL, 'gpt-4', 'Untitled Project - 2025-04-22', 'Untitled-Project---2025-04-22-s5q7x', 'As', 41, 1, 42, 'content', NULL, NULL, NULL, '2025-04-22 13:36:12', '2025-04-22 13:36:24', NULL, 'OpenAI', 'local', 'Write a complete article in English language on this topic:\n\nhow to make money online\n\nUse following keywords in the article:\nmake money, forid\n\n .The tone of voice should be Friendly and the output must be completed in 1 words. Do not generate translation.', NULL, 0),
(38, 3, NULL, 1, NULL, 'gpt-4', 'Untitled Project - 2025-04-22', 'Untitled-Project---2025-04-22-mqeoh', 'If', 45, 1, 46, 'content', NULL, NULL, NULL, '2025-04-22 13:53:19', '2025-04-22 13:53:21', NULL, 'OpenAI', 'local', 'Write a complete article in English language on this topic:\n\ngerman potato salad recipe\n\nUse following keywords in the article:\nWrite blog post about german potato salad recipe\n\n .The tone of voice should be Friendly and the output must be completed in 1 words. Do not generate translation.', NULL, 0),
(39, 1, NULL, NULL, 2, 'gpt-4', 'Untitled Project - 2025-04-22', 'Untitled-Project---2025-04-22-w9kjt', 'Title', 367, 1, 368, 'content', NULL, NULL, NULL, '2025-04-22 15:41:07', '2025-04-22 15:41:09', NULL, 'OpenAI', 'local', 'Imagine you are a seasoned content writer crafting an article for beginners in a friendly and conversational tone. Your writing should demonstrate a high level of expertise while adhering to Google\'s E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness) guidelines.\r\n\r\nWrite in a conversational tone as if you\'re talking to a friend, sharing personal experiences authentically. Use genuine emotions, relatable anecdotes, and cultural nuances to create an engaging and spontaneous feel. Balance research with intuition to analyze nuances and offer deeper insights while keeping the content factually accurate.\r\n\r\n\r\nTry to add keywords from this list naturally, ensuring they fulfill the search intent. Always follow best SEO practices when incorporating keywords. I want the article to rank well for these keywords.\r\n\r\nFocus on high readability with a Flesch-Kincaid Reading Ease score of 95+ by using simple words, short sentences, and the formula: 206.835 - 1.015 x (words/sentences) - 84.6 x (syllables/words). Keep paragraphs concise, with 3-4 sentences each, for maximum clarity. Avoid unnecessary words and ensure content is unique, plagiarism-free, and demonstrates a high level of expertise.\r\n\r\nIncorporate metaphors, empathy, and relevant insights that resonate with the audience. Make the content feel relatable and engaging by using a tone that mirrors friendly advice or storytelling. Aim for a natural flow, combining research with personal intuition to create a balanced and impactful narrative.\r\n\r\n\r\nWrite Content and must  follow all commands, don\'t avoid a single command which I have listed.\r\n1. Write content within 1500 to 1700 words.\r\n2. Every subheading must be in H2 and title case, and Every paragraph must be at least 150 to 200 words.\r\n3. Each h2 will be written in a very elaborate and detailed way. Use examples if needed. \r\n4. Important if possible, add tables or comparison charts in relevant sections.\r\n5. Before consultation generate 4 or 5 frequently asked questions with their answers related to the keyword under the heading: ‘FAQ\'s\'\r\n6. Add italic effect, bold effect in case of quotation or username.\r\n7. Use the best keyword from the Website (simplyrecipez.com) Inbound link for another page. \r\n8. Must Follow this rules Don\'t Use keyword density above 0.80%. Standard is 0.50% to 0.80%Write in English language. The tone of voice should be Friendly and the output must be completed in 1 words. Do not write translations.', NULL, 0),
(40, 3, NULL, 57, NULL, 'gpt-4', 'Untitled Project - 2025-04-25', 'Untitled-Project---2025-04-25-eqpyr', 'Title', 39, 1, 40, 'content', NULL, NULL, NULL, '2025-04-25 05:07:04', '2025-04-25 05:07:05', NULL, 'OpenAI', 'local', 'Write the title & subtitle of the story in English language for medium.com based on this description:\n\nDigital Marketing Experts\n\n .The tone of voice should be Friendly and the output must be completed in 1 words. Do not generate translation.', NULL, 0),
(41, 1, NULL, 12, NULL, 'gpt-4', 'Untitled Project - 2025-05-03', 'Untitled-Project---2025-05-03-5ucfy', 'Subject: Following Up on Your Quest for Email Lists<br><br>Dear [Recipient],<br><br>I hope this email finds you in good health and spirits.<br><br>I am following up on our recent communication regarding your interest in purchasing an email list. It’s always thrilling to see businesses eager to grow their customer engagement and boost their marketing strategies.<br><br>Before proceeding further, I wanted to walk you through certain important aspects of buying an email list and what it means for your business growth, ensuring we’re on the same wavelength.<br><br>So, why should a company consider buying an email list? The prime reason is to increase its consumer base with minimum effort. In lieu of traditional methods, buying an email list gives your business immediate access to an extensive pool of prospective consumers. This can swiftly escalate your outreach, facilitate targeted marketing campaigns and drastically improve lead generation.<br><br>However, while an email list can reap ample benefits, it’s crucial to pay attention to the quality and relevance of these lists. An optimal email list includes verified contacts that are likely to be interested in your offerings. Moreover, being respectful of individual privacy regulations is integral to this procedure. Hence, we take utmost care in compiling these lists, strictly adhering to all guidelines and ethical considerations.<br><br>Our email list packages come in several shapes and sizes, customized to best suit your enterprise needs. Whether you\'re a start-up aiming for quick growth or an established corporation striving to enhance its consumer reach, we can create a package tailored specifically for you. Our email lists are compiled from reliable sources, double-checked, and updated regularly to maintain their relevancy and effectiveness.<br><br>Further, upon purchasing an email list, we also provide comprehensive guides, filled with best practices for email marketing. These can help ease your initiation into this new phase of your business and ensure maximum return on your investment.<br><br>Respecting the privacy laws is one of our top concerns. While fulfilling the needs of businesses like yours, we explicitly follow guidelines such as the CAN-SPAM Act, GDPR, and other similar legislation. We believe in clean marketing, hence, all our lists are generated through legal means, from individuals who have expressed a direct interest in receiving marketing emails.<br><br>The power of effective email marketing tactics should not be underestimated. With these in place, creating engaging content, and personalizing your approach to target specific leads, there’s no limit to where your business can reach.<br><br>However, the key to effective email marketing using purchased lists is to initially focus on building strong relationships with your new contacts rather than immediately pushing for sales. Breaking the ice, building trust and credibility among your audience is a surefire way to turn these new leads into loyal customers!<br><br>Let\'s take your business to new heights together. I invite you to share more details about specific interests or criteria you might have related to your prospective customers. Doing so will enable us to create an email list that perfectly aligns with your goals.<br><br>Should you have any queries or need further information, please respond to this email. We look forward to walking this invigorating path of your business journey with you.<br><br>Just as every business is unique, so too are the strategies required for its growth. Allow us to provide the fuel your business needs to surge forward in this competitive world.<br><br>Thank you for considering our services. we await your response to proceed with this exciting opportunity.<br><br>Best Regards,<br><br>[Your Name]<br>[Your Position]<br>[Your Contact Information]', 34, 563, 597, 'content', NULL, NULL, NULL, '2025-05-03 18:31:08', '2025-05-03 18:31:44', NULL, 'OpenAI', 'local', 'Write a follow up email in English language based on this text:\n\nBuying email list\n\n .The tone of voice should be Friendly and the output must be completed in 1000 words. Do not generate translation.', NULL, 0),
(42, 1, NULL, NULL, NULL, NULL, 'Windows 11 banner', 'Windows-11-banner-3iyro', 'images/EaTWuTXATv.png', NULL, NULL, NULL, 'image', '512x512', NULL, NULL, '2025-05-03 18:42:29', '2025-05-03 18:42:29', NULL, 'SD', 'local', NULL, NULL, 0),
(43, 1, NULL, 40, NULL, 'gpt-4', 'Untitled Project - 2025-05-03', 'Untitled-Project---2025-05-03-7svmo', 'Introducing the Microsoft Office 2024 Professional Plus LTSE - your ultimate productivity powerhouse. This state-of-the-art office suite is carefully engineered and superbly crafted to cater for advanced business requirements and professional needs. This isn\'t just software; it\'s an intricate work of technological artistry - an indispensable tool designed to elevate your workflow efficiency, communication, collaboration, and overall, performance.<br><br>Boasting an impressive suite of applications such as Word, Excel, PowerPoint, Access, Publisher, Outlook, OneNote, SharePoint, and much more, the Microsoft Office 2024 Professional Plus LTSE provides you with everything you\'d need seamlessly integrated into a singular, exceptionally versatile package. It encapsulates Microsoft\'s decades of expertise in creating business software and presents it to you in a refined, user-friendly interface that encourages you to do more.<br><br>Dive into the expansive world of Word 2024, where document creation is not only effortless but also enjoyable. With its advanced features and innovative, intuitive tools, Word 2024 ensures that you can bring your vision to life on the page. Whether you\'re drafting an intricate report, crafting a compelling article, or jotting down quick notes, it\'s never been easier or more efficient.<br><br>Experience data management like never before with Excel 2024. With smarter functions, stronger connections, and unlimited potential, Excel paves the way for seamless navigation through massive data. Be it complex mathematical equations, detailed statistical analysis, insightful data visualization, or straightforward budgeting, Excel 2024 now handles it all with stunning ease and efficiency.<br><br>Unleash your creativity with PowerPoint 2024. Design mesmerizing presentations with new design tools and creative assets that captivate your audience. Interactive elements, rich media integration, and enhanced editing features empower you to create, narrate, and share stories with impact.<br><br>Experience impeccable email management and scheduling too, with the all-new Outlook 2024. Optimized to simplify communication tasks, it comes equipped with smart filters, focused inbox, integrated calendar, and intuitive search to help you prioritize and manage your overwhelming email traffic.<br><br>But email isn\'t the only way to collaborate in Microsoft Office 2024 Professional Plus LTSE. SharePoint enables robust document sharing and team collaboration, conjoined by Teams, that\'s built to offer a unified communication platform for modern workplaces. <br><br>Moreover, this sleek office suite incorporates database management with Access 2024 to manage complex queries, create detailed reports and automate processes. It\'s easier than ever to ensure your data is safe, organized, and ready whenever you need it. For businesses that require desktop publishing, Publisher 2024 provides an array of intuitive tools to help you create stunning marketing materials with ease.<br><br>Next is OneNote 2024: A digital notebook where you can scribble down your thoughts, doodle to your heart\'s content, or meticulously plan your next big project. Organize the clutter of your mind into neat sections and pages with tags to find what\'s important without wasting time.<br><br>Additionally, the LTSE—Long Term Servicing Edition—offers long-term support necessary for organizations wishing to avoid frequent updates. This option emphasizes stability, decreasing the risk of downtime during crucial business operations. Updates in LTSE versions primarily offer security patches and bug fixes, reassuring solid, uninterrupted performance.<br><br>The licensing model of Microsoft Office 2024 Professional Plus LTSE offers enormous flexibility, suitable for both small businesses and large enterprises. Moreover, this version is also an excellent choice for educational institutions due to its vast range of tools that boost productivity and facilitate effective, smooth-running operations.<br><br>In essence, when you choose Microsoft Office 2024 Professional Plus LTSE, you\'re investing in more than just an office suite. You\'re investing in seamless performance, enhanced productivity, and flawless communication. Equip your team with highly advanced tools tailored to streamline operations, promote collaboration, and drive efficient outcomes. With Microsoft\'s unrivaled support and constant innovation, prepare to unlock newfound potential and push the boundaries of what\'s possible. Discover what it means to truly excel at professional tasks today with the Microsoft Office 2024 Professional Plus LTSE.', 35, 627, 662, 'content', NULL, NULL, NULL, '2025-05-03 23:20:38', '2025-05-03 23:21:14', NULL, 'OpenAI', 'local', 'Write a long creative product description in English language for:\n\nMicrosoft Office 2024 Professional Plus LTSE\n\n .The tone of voice should be Professional and the output must be completed in 1500 words. Do not generate translation.', NULL, 0),
(44, 1, NULL, NULL, NULL, 'gpt-4', 'ecommerce landing page', 'ecommerce-landing-page-htgtw', 'Sure, I can help you with that. I\'ll give you a simple example of how a static HTML landing page looks. Please make sure to replace all \'your-content\' blocks with the actual content you want to use. Also, this is a very basic template, you\'ll need to add further CSS or use some frontend library for a better appearance. \n\n```html\n<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <title>Your Landing Page</title>\n    <link rel=\"stylesheet\" href=\"styles.css\">\n</head>\n<body>\n    <header>\n        <nav>\n            <ul>\n                <li><a href=\"#feature-section\">Features</a></li>\n                <li><a href=\"#about-section\">About Us</a></li>\n                <li><a href=\"#contact-section\">Contact Us</a></li>\n            </ul>\n        </nav>\n    </header>\n\n    <section id=\"hero-section\">\n        <h1>Your Landing Page</h1>\n        <p>Welcome to our site!</p>\n        <button>Sign Up</button>\n    </section>\n\n    <section id=\"feature-section\">\n        <h2>Features</h2>\n        <p>your-content</p>\n    </section>\n\n    <section id=\"about-section\">\n        <h2>About Us</h2>\n        <p>your-content</p>\n    </section>\n\n    <section id=\"contact-section\">\n        <h2>Contact Us</h2>\n        <p>your-content</p>\n    </section>\n\n    <footer>\n        <p>Copyright 20xx. All rights reserved.</p>\n    </footer>\n</body>\n</html>\n```\n\nYou can add a simple CSS file to style your elements. The filename has to match with the filename in the \'link\' tag in the \'head\' section of the HTML file. In this case, \'styles.css\':\n```css\nbody {\n    font-family: Arial, sans-serif;\n}\n\nnav ul {\n    list-style-type: none;\n}\n\nsection {\n    padding: 20px;\n}\n\nfooter {\n    text-align: center;\n    margin-top: 50px;\n}\n``` \n\nRemember, landing pages often need to be effectively designed and written to convert visitors into customers. Depending on the complexity of your design and whether you require any interactivity, you might need to use further HTML/CSS, JavaScript, or even a front-end framework like React or Vue.', 31, 538, 569, 'code', NULL, NULL, NULL, '2025-05-05 12:10:42', '2025-05-05 12:10:42', NULL, 'OpenAI', 'local', NULL, NULL, 0),
(45, 9, NULL, NULL, NULL, 'gpt-4', 'Untitled Project - 2025-05-11', 'Untitled-Project---2025-05-11-3zfhh', 'Repair', 27, 1, 28, 'Ai ReWriter', NULL, NULL, NULL, '2025-05-12 01:36:41', '2025-05-12 01:36:42', NULL, 'OpenAI', 'local', 'Samsung reparatur in English language Samsung reparatur .The tone of voice should be Friendly and the output must be completed in 1 words. Do not generate translation.', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `project_logs`
--

CREATE TABLE `project_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `subscription_history_id` int DEFAULT NULL,
  `subscription_package_id` int DEFAULT NULL,
  `template_id` int DEFAULT NULL,
  `custom_template_id` int DEFAULT NULL,
  `model_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `words` bigint DEFAULT NULL,
  `prompt_words` bigint DEFAULT NULL,
  `completion_words` bigint DEFAULT NULL,
  `previous_balance` bigint DEFAULT NULL,
  `after_balance` bigint DEFAULT NULL,
  `resolution` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `content_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'content/image/code/speech_to_text...',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `project_logs`
--

INSERT INTO `project_logs` (`id`, `user_id`, `project_id`, `subscription_history_id`, `subscription_package_id`, `template_id`, `custom_template_id`, `model_name`, `content`, `words`, `prompt_words`, `completion_words`, `previous_balance`, `after_balance`, `resolution`, `content_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 27, NULL, NULL, NULL, NULL, 'gpt-3.5-turbo', '', 34, 33, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 16:48:10', '2025-04-21 16:48:10', NULL),
(2, 1, 27, NULL, NULL, NULL, NULL, 'gpt-3.5-turbo', '', 34, 33, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 16:48:14', '2025-04-21 16:48:14', NULL),
(3, 1, 28, NULL, NULL, NULL, NULL, 'gpt-3.5-turbo', '', 34, 33, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:20:46', '2025-04-21 17:20:46', NULL),
(4, 1, 28, NULL, NULL, NULL, NULL, 'gpt-3.5-turbo', '', 34, 33, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:20:52', '2025-04-21 17:20:52', NULL),
(5, 1, 29, NULL, NULL, NULL, NULL, 'gpt-3.5-turbo', '', 34, 33, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:22:12', '2025-04-21 17:22:12', NULL),
(6, 1, 29, NULL, NULL, NULL, NULL, 'gpt-3.5-turbo', '', 34, 33, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:27:28', '2025-04-21 17:27:28', NULL),
(7, 1, 29, NULL, NULL, NULL, NULL, 'gpt-3.5-turbo', '', 34, 33, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:34:09', '2025-04-21 17:34:09', NULL),
(8, 1, 30, NULL, NULL, NULL, NULL, 'gpt-3.5-turbo', '', 26, 25, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:34:20', '2025-04-21 17:34:20', NULL),
(9, 1, 31, NULL, NULL, NULL, NULL, 'gpt-4', '', 26, 25, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:37:26', '2025-04-21 17:37:26', NULL),
(10, 1, 32, NULL, NULL, NULL, NULL, 'gpt-4', '', 220, 219, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:53:43', '2025-04-21 17:53:43', NULL),
(11, 1, 32, NULL, NULL, NULL, NULL, 'gpt-4', '', 220, 219, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:53:53', '2025-04-21 17:53:53', NULL),
(12, 1, 32, NULL, NULL, NULL, NULL, 'gpt-4', '', 372, 371, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:54:10', '2025-04-21 17:54:10', NULL),
(13, 1, 32, NULL, NULL, NULL, NULL, 'gpt-4', '', 372, 371, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-21 17:54:31', '2025-04-21 17:54:31', NULL),
(14, 1, 33, NULL, NULL, NULL, NULL, NULL, 'images/mEqqX9AAzV.png', NULL, NULL, NULL, NULL, NULL, '512x512', 'image', '2025-04-21 17:55:20', '2025-04-21 17:55:20', NULL),
(15, 1, 34, NULL, NULL, NULL, NULL, NULL, 'images/qtyFrgKuLh.png', NULL, NULL, NULL, NULL, NULL, '512x512', 'image', '2025-04-21 17:56:28', '2025-04-21 17:56:28', NULL),
(16, 1, 35, NULL, NULL, 31, NULL, 'gpt-4', '', 35, 34, 1, NULL, NULL, NULL, 'content', '2025-04-21 23:11:03', '2025-04-21 23:11:03', NULL),
(17, 1, 35, NULL, NULL, 31, NULL, 'gpt-4', '', 35, 34, 1, NULL, NULL, NULL, 'content', '2025-04-21 23:11:41', '2025-04-21 23:11:41', NULL),
(18, 1, 35, NULL, NULL, 31, NULL, 'gpt-4', '', 35, 34, 1, NULL, NULL, NULL, 'content', '2025-04-21 23:11:45', '2025-04-21 23:11:45', NULL),
(19, 1, 36, NULL, NULL, NULL, NULL, 'gpt-4', '', 30, 29, 1, NULL, NULL, NULL, 'Ai ReWriter', '2025-04-22 13:23:04', '2025-04-22 13:23:04', NULL),
(20, 1, 37, NULL, NULL, 1, NULL, 'gpt-4', '', 42, 41, 1, NULL, NULL, NULL, 'content', '2025-04-22 13:36:28', '2025-04-22 13:36:28', NULL),
(21, 3, 38, 2, 1, 1, NULL, 'gpt-4', '', 46, 45, 1, 954, 908, NULL, 'content', '2025-04-22 13:53:22', '2025-04-22 13:53:22', NULL),
(22, 1, 39, NULL, NULL, NULL, 2, 'gpt-4', '', 368, 367, 1, NULL, NULL, NULL, 'content', '2025-04-22 15:41:09', '2025-04-22 15:41:09', NULL),
(23, 3, 40, 2, 1, 57, NULL, 'gpt-4', '', 40, 39, 1, 914, 874, NULL, 'content', '2025-04-25 05:07:05', '2025-04-25 05:07:05', NULL),
(24, 1, 41, NULL, NULL, 12, NULL, 'gpt-4', '', 35, 34, 1, NULL, NULL, NULL, 'content', '2025-05-03 18:31:10', '2025-05-03 18:31:10', NULL),
(25, 1, 41, NULL, NULL, 12, NULL, 'gpt-4', '', 597, 34, 563, NULL, NULL, NULL, 'content', '2025-05-03 18:31:44', '2025-05-03 18:31:44', NULL),
(26, 1, 42, NULL, NULL, NULL, NULL, NULL, 'images/EaTWuTXATv.png', NULL, NULL, NULL, NULL, NULL, '512x512', 'image', '2025-05-03 18:42:29', '2025-05-03 18:42:29', NULL),
(27, 1, 43, NULL, NULL, 40, NULL, 'gpt-4', '', 662, 35, 627, NULL, NULL, NULL, 'content', '2025-05-03 23:21:14', '2025-05-03 23:21:14', NULL),
(28, 1, 44, NULL, NULL, NULL, NULL, 'gpt-4', 'Sure, I can help you with that. I\'ll give you a simple example of how a static HTML landing page looks. Please make sure to replace all \'your-content\' blocks with the actual content you want to use. Also, this is a very basic template, you\'ll need to add further CSS or use some frontend library for a better appearance. \n\n```html\n<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <title>Your Landing Page</title>\n    <link rel=\"stylesheet\" href=\"styles.css\">\n</head>\n<body>\n    <header>\n        <nav>\n            <ul>\n                <li><a href=\"#feature-section\">Features</a></li>\n                <li><a href=\"#about-section\">About Us</a></li>\n                <li><a href=\"#contact-section\">Contact Us</a></li>\n            </ul>\n        </nav>\n    </header>\n\n    <section id=\"hero-section\">\n        <h1>Your Landing Page</h1>\n        <p>Welcome to our site!</p>\n        <button>Sign Up</button>\n    </section>\n\n    <section id=\"feature-section\">\n        <h2>Features</h2>\n        <p>your-content</p>\n    </section>\n\n    <section id=\"about-section\">\n        <h2>About Us</h2>\n        <p>your-content</p>\n    </section>\n\n    <section id=\"contact-section\">\n        <h2>Contact Us</h2>\n        <p>your-content</p>\n    </section>\n\n    <footer>\n        <p>Copyright 20xx. All rights reserved.</p>\n    </footer>\n</body>\n</html>\n```\n\nYou can add a simple CSS file to style your elements. The filename has to match with the filename in the \'link\' tag in the \'head\' section of the HTML file. In this case, \'styles.css\':\n```css\nbody {\n    font-family: Arial, sans-serif;\n}\n\nnav ul {\n    list-style-type: none;\n}\n\nsection {\n    padding: 20px;\n}\n\nfooter {\n    text-align: center;\n    margin-top: 50px;\n}\n``` \n\nRemember, landing pages often need to be effectively designed and written to convert visitors into customers. Depending on the complexity of your design and whether you require any interactivity, you might need to use further HTML/CSS, JavaScript, or even a front-end framework like React or Vue.', 569, 31, 538, NULL, NULL, NULL, 'code', '2025-05-05 12:10:42', '2025-05-05 12:10:42', NULL),
(29, 9, 45, 12, 3, NULL, NULL, 'gpt-4', '', 28, 27, 1, 499972, 499944, NULL, 'Ai ReWriter', '2025-05-12 01:36:42', '2025-05-12 01:36:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `prompts`
--

CREATE TABLE `prompts` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `template_group_id` int DEFAULT NULL COMMENT 'if null -> custom template',
  `template_id` int DEFAULT NULL,
  `prompts` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `p_w_a_settings`
--

CREATE TABLE `p_w_a_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `short_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `background_color` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `theme_color` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `status_bar` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon_72` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon_96` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon_128` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon_144` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon_152` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon_192` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon_384` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon_512` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `p_w_a_settings`
--

INSERT INTO `p_w_a_settings` (`id`, `name`, `short_name`, `background_color`, `theme_color`, `status_bar`, `icon_72`, `icon_96`, `icon_128`, `icon_144`, `icon_152`, `icon_192`, `icon_384`, `icon_512`, `created_at`, `updated_at`) VALUES
(1, 'WriteBot AI', 'PWA', '#ffffff', '#7a16d4', '#000000', 'images/icons/icon-72x72.png', 'images/icons/icon-96x96.png', 'images/icons/icon-128x128.png', 'images/icons/icon-144x144.png', 'images/icons/icon-152x152.png', 'images/icons/icon-192x192.png', 'images/icons/icon-384x384.png', 'images/icons/icon-512x512.png', '2025-04-21 16:31:45', '2025-04-21 16:31:45');

-- --------------------------------------------------------

--
-- Table structure for table `reply_tickets`
--

CREATE TABLE `reply_tickets` (
  `id` bigint UNSIGNED NOT NULL,
  `ticket_id` int NOT NULL,
  `replied` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `replied_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `file_path` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `guard_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `is_delete` tinyint DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `is_system`, `is_active`, `created_by`, `updated_by`, `is_delete`) VALUES
(1, 'Super Admin', 'web', NULL, NULL, 1, 1, NULL, NULL, 1),
(2, 'Staff', 'web', '2025-05-13 16:02:35', '2025-05-13 16:02:35', 0, 1, 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 2),
(2, 2),
(3, 2),
(4, 2),
(5, 2),
(6, 2),
(7, 2),
(8, 2),
(9, 2),
(10, 2),
(11, 2),
(12, 2),
(13, 2),
(14, 2),
(15, 2),
(16, 2),
(17, 2),
(18, 2),
(19, 2),
(20, 2),
(21, 2),
(22, 2),
(23, 2),
(24, 2),
(25, 2),
(26, 2),
(27, 2),
(28, 2),
(29, 2),
(30, 2),
(31, 2),
(32, 2),
(33, 2),
(34, 2),
(35, 2),
(36, 2),
(37, 2),
(38, 2),
(39, 2),
(40, 2),
(41, 2),
(42, 2),
(43, 2),
(44, 2),
(45, 2),
(46, 2),
(47, 2),
(48, 2),
(66, 2),
(67, 2),
(68, 2),
(69, 2),
(70, 2),
(71, 2),
(72, 2),
(73, 2),
(74, 2),
(75, 2),
(76, 2),
(77, 2),
(78, 2),
(79, 2),
(80, 2),
(81, 2),
(82, 2),
(83, 2),
(84, 2),
(85, 2),
(86, 2),
(87, 2),
(92, 2),
(93, 2),
(94, 2),
(95, 2),
(96, 2),
(99, 2),
(100, 2),
(101, 2),
(102, 2),
(104, 2),
(105, 2),
(107, 2),
(108, 2),
(109, 2),
(110, 2),
(111, 2),
(112, 2),
(113, 2),
(114, 2),
(115, 2),
(116, 2),
(117, 2),
(118, 2),
(120, 2),
(121, 2),
(122, 2),
(123, 2),
(124, 2);

-- --------------------------------------------------------

--
-- Table structure for table `storage_managers`
--

CREATE TABLE `storage_managers` (
  `id` bigint UNSIGNED NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `access_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `secret_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `bucket` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `region` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `container` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `storage_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `storage_url` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `file_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `path` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `is_deActive` tinyint(1) DEFAULT '1',
  `created_by` int DEFAULT '1',
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `storage_managers`
--

INSERT INTO `storage_managers` (`id`, `type`, `access_key`, `secret_key`, `bucket`, `region`, `container`, `storage_name`, `storage_url`, `file_name`, `path`, `is_active`, `is_deActive`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'local', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, NULL, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(2, 'aws', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, NULL, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(3, 'gcs', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, '2025-04-21 16:31:44', '2025-04-21 16:31:44'),
(4, 'azure', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, '2025-04-21 16:31:44', '2025-04-21 16:31:44');

-- --------------------------------------------------------

--
-- Table structure for table `subscribed_users`
--

CREATE TABLE `subscribed_users` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `subscribed_users`
--

INSERT INTO `subscribed_users` (`id`, `email`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'forid@tic.com.bd', '2025-04-21 18:25:29', '2025-04-21 18:25:29', NULL),
(2, 'q3rana@gmail.com', '2025-04-22 13:50:43', '2025-04-22 13:50:43', NULL),
(3, 'ticfatema@gmail.com', '2025-05-04 13:19:45', '2025-05-04 13:19:45', NULL),
(4, 'asibsrabon.ticltd@gmail.com', '2025-05-04 14:34:25', '2025-05-04 14:34:25', NULL),
(5, 'revers711@1ti.ru', '2025-05-08 21:47:04', '2025-05-08 21:47:04', NULL),
(6, 'mimparvin602@gmail.com', '2025-05-11 15:58:23', '2025-05-11 15:58:23', NULL),
(7, 'azharulislamokokok@gmail.com', '2025-05-11 16:23:46', '2025-05-11 16:23:46', NULL),
(8, 'php673500@gmail.com', '2025-05-12 01:33:52', '2025-05-12 01:33:52', NULL),
(9, 'tamannarezvi73@gmail.com', '2025-05-12 14:39:32', '2025-05-12 14:39:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `stripe_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `stripe_status` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `stripe_price` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `package_id` int DEFAULT NULL,
  `payment_method` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_auto_payments`
--

CREATE TABLE `subscription_auto_payments` (
  `id` bigint UNSIGNED NOT NULL,
  `gateway` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `price` double DEFAULT '0',
  `currency` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'USD',
  `recurring` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'monthly',
  `product_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_histories`
--

CREATE TABLE `subscription_histories` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `expire_by_admin_date` date DEFAULT NULL,
  `subscription_status` int DEFAULT NULL COMMENT '1=active, 2=expired, 3=subscribed',
  `payment_status` int DEFAULT NULL COMMENT '1=paid, 2=Pending, 3=Rejected 4=Re-Submit',
  `subscription_package_id` int NOT NULL,
  `old_subscription_package_id` int DEFAULT NULL,
  `new_word_balance` bigint NOT NULL DEFAULT '0',
  `new_image_balance` bigint NOT NULL DEFAULT '0',
  `new_s2t_balance` bigint NOT NULL DEFAULT '0',
  `price` double NOT NULL DEFAULT '0',
  `payment_method` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `offline_payment_id` int DEFAULT NULL,
  `payment_details` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `note` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `this_month_used_words` bigint NOT NULL DEFAULT '0',
  `this_month_available_words` bigint NOT NULL DEFAULT '0',
  `total_used_words` bigint NOT NULL DEFAULT '0',
  `this_month_used_images` bigint NOT NULL DEFAULT '0',
  `this_month_available_images` bigint NOT NULL DEFAULT '0',
  `total_used_images` bigint NOT NULL DEFAULT '0',
  `this_month_used_s2t` bigint NOT NULL DEFAULT '0',
  `this_month_available_s2t` bigint NOT NULL DEFAULT '0',
  `total_used_s2t` bigint NOT NULL DEFAULT '0',
  `this_month_used_t2s` bigint NOT NULL DEFAULT '0',
  `this_month_available_t2s` bigint NOT NULL DEFAULT '0',
  `total_used_t2s` bigint NOT NULL DEFAULT '0',
  `file` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `feedback_note` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `is_carried_over` tinyint NOT NULL DEFAULT '0',
  `carried_over_words` bigint NOT NULL DEFAULT '0',
  `carried_over_images` bigint NOT NULL DEFAULT '0',
  `carried_over_speech_to_text` bigint NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `active_by` int NOT NULL,
  `discount_type` int DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `package_price` double DEFAULT '0',
  `forcefully_active` tinyint(1) DEFAULT '0',
  `allow_unlimited_speech_to_text` int DEFAULT '0',
  `allow_unlimited_image` int DEFAULT '0',
  `allow_unlimited_word` int DEFAULT '0',
  `is_recurring` tinyint(1) DEFAULT '0',
  `currency_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `order_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `subscription_histories`
--

INSERT INTO `subscription_histories` (`id`, `user_id`, `start_date`, `end_date`, `expire_by_admin_date`, `subscription_status`, `payment_status`, `subscription_package_id`, `old_subscription_package_id`, `new_word_balance`, `new_image_balance`, `new_s2t_balance`, `price`, `payment_method`, `offline_payment_id`, `payment_details`, `note`, `created_at`, `updated_at`, `deleted_at`, `this_month_used_words`, `this_month_available_words`, `total_used_words`, `this_month_used_images`, `this_month_available_images`, `total_used_images`, `this_month_used_s2t`, `this_month_available_s2t`, `total_used_s2t`, `this_month_used_t2s`, `this_month_available_t2s`, `total_used_t2s`, `file`, `feedback_note`, `is_carried_over`, `carried_over_words`, `carried_over_images`, `carried_over_speech_to_text`, `created_by`, `active_by`, `discount_type`, `discount`, `package_price`, `forcefully_active`, `allow_unlimited_speech_to_text`, `allow_unlimited_image`, `allow_unlimited_word`, `is_recurring`, `currency_code`, `order_id`) VALUES
(1, 2, '2025-04-21', '2025-05-21', NULL, 1, 1, 3, NULL, 500000, 10, 2, 50, 'offline', 2, '\"Oofndndj\"', 'Ndndn', '2025-04-21 22:50:00', '2025-04-21 22:51:18', NULL, 0, 500000, 0, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 1, 500000, 10, 2, 0, 0, NULL, NULL, 50, 0, 0, 0, 0, 0, 'usd', NULL),
(2, 3, '2025-04-22', '2025-05-22', NULL, 1, 1, 1, NULL, 1000, 10, 2, 0, NULL, NULL, NULL, NULL, '2025-04-22 13:50:43', '2025-04-25 05:07:05', NULL, 86, 914, 86, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL),
(3, 4, '2025-05-04', '2025-06-03', NULL, 1, 1, 1, NULL, 1000, 10, 2, 0, NULL, NULL, NULL, NULL, '2025-05-04 13:19:46', '2025-05-04 13:19:46', NULL, 0, 1000, 0, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL),
(4, 4, '2025-06-04', '2026-06-04', NULL, 3, 1, 4, 1, 250000, 10, 2, 250, 'paypal', NULL, NULL, NULL, '2025-05-04 13:48:43', '2025-05-04 13:48:43', NULL, 0, 250000, 0, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 1, 0, NULL, NULL, 250, 0, 0, 0, 0, 0, 'usd', NULL),
(5, 5, '2025-05-04', '2025-05-12', NULL, 2, 1, 1, NULL, 1000, 10, 2, 0, NULL, NULL, NULL, NULL, '2025-05-04 14:34:25', '2025-05-12 09:16:45', NULL, 670, 330, 670, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL),
(6, 5, '2025-05-12', '2025-06-12', NULL, 1, 1, 3, 1, 500000, 100, 2, 50, 'offline', 2, '\"Asib Srabon\"', NULL, '2025-05-04 14:38:58', '2025-05-12 09:16:45', NULL, 0, 500000, 0, 0, 100, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 5, NULL, NULL, 50, 0, 0, 0, 0, 0, 'usd', NULL),
(7, 6, '2025-05-08', '2025-06-07', NULL, 1, 1, 1, NULL, 1000, 10, 2, 0, NULL, NULL, NULL, NULL, '2025-05-08 21:47:04', '2025-05-08 21:47:04', NULL, 0, 1000, 0, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL),
(8, 7, '2025-05-11', '2025-06-10', NULL, 1, 1, 1, NULL, 1000, 10, 2, 0, NULL, NULL, NULL, NULL, '2025-05-11 15:58:23', '2025-05-11 16:51:05', NULL, 697, 303, 697, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL),
(9, 7, NULL, NULL, NULL, 3, 1, 3, 1, 500000, 100, 2, 50, 'offline', 1, '\"gdfgdfg\"', 'gfdgdfg', '2025-05-11 15:59:23', '2025-05-11 16:02:18', NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 50, 0, 0, 0, 0, 0, 'usd', NULL),
(10, 8, '2025-05-11', '2025-05-11', NULL, 2, 1, 1, NULL, 1000, 10, 2, 0, NULL, NULL, NULL, NULL, '2025-05-11 16:23:47', '2025-05-12 01:35:39', NULL, 0, 1000, 0, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL),
(11, 9, '2025-05-11', '2025-05-11', NULL, 2, 1, 1, NULL, 1000, 10, 2, 0, NULL, NULL, NULL, NULL, '2025-05-12 01:33:52', '2025-05-12 01:34:47', NULL, 0, 1000, 0, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL),
(12, 9, '2025-05-11', '2025-06-11', NULL, 1, 1, 3, 1, 500000, 100, 2, 50, 'paypal', NULL, NULL, NULL, '2025-05-12 01:34:47', '2025-05-13 04:03:14', NULL, 1882, 498118, 1882, 1, 99, 1, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 1, 0, NULL, NULL, 50, 1, 0, 0, 0, 0, 'usd', NULL),
(13, 8, '2025-05-11', '2025-05-13', NULL, 2, 1, 2, 1, 100000, 50, 2, 20, 'paypal', NULL, NULL, NULL, '2025-05-12 01:35:39', '2025-05-13 16:03:50', NULL, 0, 100000, 0, 0, 50, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 1, 0, NULL, NULL, 20, 1, 0, 0, 0, 0, 'usd', NULL),
(14, 10, '2025-05-12', '2025-05-13', NULL, 2, 1, 1, NULL, 1000, 10, 2, 0, NULL, NULL, NULL, NULL, '2025-05-12 14:39:32', '2025-05-13 16:03:17', NULL, 0, 1000, 0, 0, 10, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL),
(15, 10, '2025-05-13', '2025-06-13', NULL, 1, 1, 3, 1, 500000, 100, 2, 50, 'paypal', NULL, NULL, NULL, '2025-05-13 16:03:17', '2025-05-13 16:03:17', NULL, 0, 500000, 0, 0, 100, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 1, 0, NULL, NULL, 50, 1, 0, 0, 0, 0, 'usd', NULL),
(16, 8, '2025-05-13', '2025-06-13', NULL, 1, 1, 3, 2, 500000, 100, 2, 50, 'paypal', NULL, NULL, NULL, '2025-05-13 16:03:50', '2025-05-13 16:03:50', NULL, 0, 500000, 0, 0, 100, 0, 0, 2, 0, 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 1, 0, NULL, NULL, 50, 1, 0, 0, 0, 0, 'usd', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscription_items`
--

CREATE TABLE `subscription_items` (
  `id` bigint UNSIGNED NOT NULL,
  `subscription_id` bigint UNSIGNED NOT NULL,
  `stripe_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `stripe_product` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `stripe_price` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `quantity` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_logs`
--

CREATE TABLE `subscription_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `subscription_history_id` int NOT NULL,
  `subscription_package_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `total_text` bigint NOT NULL,
  `before_balance` bigint DEFAULT NULL,
  `after_balance` bigint DEFAULT NULL,
  `promptsToken` bigint DEFAULT NULL,
  `completionToken` bigint DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_packages`
--

CREATE TABLE `subscription_packages` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `openai_model_id` int NOT NULL,
  `package_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'monthly' COMMENT 'starter/monthly/yearly/lifetime',
  `price` double NOT NULL DEFAULT '0',
  `discount` double DEFAULT NULL,
  `discount_price` double DEFAULT NULL,
  `discount_status` int DEFAULT NULL,
  `total_words_per_month` bigint NOT NULL DEFAULT '0',
  `total_images_per_month` bigint NOT NULL DEFAULT '0',
  `total_speech_to_text_per_month` bigint NOT NULL DEFAULT '0',
  `total_text_to_speech_per_month` bigint NOT NULL DEFAULT '0',
  `speech_to_text_filesize_limit` bigint NOT NULL DEFAULT '-1',
  `allow_images` tinyint NOT NULL DEFAULT '0',
  `allow_ai_code` tinyint NOT NULL DEFAULT '0',
  `allow_speech_to_text` tinyint NOT NULL DEFAULT '0',
  `allow_ai_chat` tinyint NOT NULL DEFAULT '0',
  `allow_text_to_speech` tinyint NOT NULL DEFAULT '0',
  `allow_custom_templates` tinyint NOT NULL DEFAULT '0',
  `allow_blog_wizard` tinyint NOT NULL DEFAULT '1',
  `show_open_ai_model` tinyint NOT NULL DEFAULT '1',
  `has_live_support` tinyint NOT NULL DEFAULT '0',
  `has_free_support` tinyint NOT NULL DEFAULT '0',
  `is_featured` tinyint NOT NULL DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `other_features` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `show_word_tools` tinyint NOT NULL DEFAULT '1',
  `allow_word_tools` tinyint NOT NULL DEFAULT '1',
  `allow_built_in_templates` tinyint NOT NULL DEFAULT '1',
  `show_built_in_templates` tinyint NOT NULL DEFAULT '1',
  `show_custom_templates` tinyint NOT NULL DEFAULT '1',
  `show_blog_wizard` tinyint NOT NULL DEFAULT '1',
  `show_ai_chat` tinyint NOT NULL DEFAULT '1',
  `show_ai_code` tinyint NOT NULL DEFAULT '1',
  `show_text_to_speech` tinyint NOT NULL DEFAULT '1',
  `show_image_tools` tinyint NOT NULL DEFAULT '1',
  `allow_image_tools` tinyint NOT NULL DEFAULT '1',
  `show_images` tinyint NOT NULL DEFAULT '1',
  `show_sd_images` tinyint NOT NULL DEFAULT '1',
  `allow_sd_images` tinyint NOT NULL DEFAULT '1',
  `show_speech_to_text_tools` tinyint NOT NULL DEFAULT '1',
  `show_live_support` tinyint NOT NULL DEFAULT '1',
  `show_free_support` tinyint NOT NULL DEFAULT '1',
  `duration` int DEFAULT '30',
  `discount_type` int DEFAULT NULL COMMENT '1=fixed, 2=percentage',
  `discount_start_date` date DEFAULT NULL,
  `discount_end_date` date DEFAULT NULL,
  `allow_unlimited_speech_to_text` int DEFAULT '0',
  `allow_unlimited_image` int DEFAULT '0',
  `allow_unlimited_word` int DEFAULT '0',
  `show_eleven_labs` int DEFAULT '0',
  `allow_eleven_labs` int DEFAULT '0',
  `allow_ai_vision` tinyint NOT NULL DEFAULT '0',
  `show_ai_vision` tinyint NOT NULL DEFAULT '0',
  `allow_ai_image_chat` tinyint NOT NULL DEFAULT '0',
  `show_ai_image_chat` tinyint NOT NULL DEFAULT '0',
  `allow_ai_pdf_chat` tinyint NOT NULL DEFAULT '0',
  `show_ai_pdf_chat` tinyint NOT NULL DEFAULT '0',
  `allow_ai_rewriter` tinyint NOT NULL DEFAULT '0',
  `show_ai_rewriter` tinyint NOT NULL DEFAULT '0',
  `show_dall_e_2_image` tinyint DEFAULT '0',
  `show_dall_e_3_image` tinyint DEFAULT '1',
  `allow_dall_e_2_image` int DEFAULT '1',
  `allow_dall_e_3_image` int DEFAULT '1',
  `show_ai_detector` tinyint DEFAULT '0',
  `show_ai_plagiarism` tinyint DEFAULT '1',
  `allow_ai_detector` int DEFAULT '1',
  `allow_ai_plagiarism` int DEFAULT '1',
  `allow_real_time_data` int DEFAULT '0',
  `show_real_time_data` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `subscription_packages`
--

INSERT INTO `subscription_packages` (`id`, `title`, `description`, `slug`, `openai_model_id`, `package_type`, `price`, `discount`, `discount_price`, `discount_status`, `total_words_per_month`, `total_images_per_month`, `total_speech_to_text_per_month`, `total_text_to_speech_per_month`, `speech_to_text_filesize_limit`, `allow_images`, `allow_ai_code`, `allow_speech_to_text`, `allow_ai_chat`, `allow_text_to_speech`, `allow_custom_templates`, `allow_blog_wizard`, `show_open_ai_model`, `has_live_support`, `has_free_support`, `is_featured`, `is_active`, `other_features`, `created_at`, `updated_at`, `deleted_at`, `show_word_tools`, `allow_word_tools`, `allow_built_in_templates`, `show_built_in_templates`, `show_custom_templates`, `show_blog_wizard`, `show_ai_chat`, `show_ai_code`, `show_text_to_speech`, `show_image_tools`, `allow_image_tools`, `show_images`, `show_sd_images`, `allow_sd_images`, `show_speech_to_text_tools`, `show_live_support`, `show_free_support`, `duration`, `discount_type`, `discount_start_date`, `discount_end_date`, `allow_unlimited_speech_to_text`, `allow_unlimited_image`, `allow_unlimited_word`, `show_eleven_labs`, `allow_eleven_labs`, `allow_ai_vision`, `show_ai_vision`, `allow_ai_image_chat`, `show_ai_image_chat`, `allow_ai_pdf_chat`, `show_ai_pdf_chat`, `allow_ai_rewriter`, `show_ai_rewriter`, `show_dall_e_2_image`, `show_dall_e_3_image`, `allow_dall_e_2_image`, `allow_dall_e_3_image`, `show_ai_detector`, `show_ai_plagiarism`, `allow_ai_detector`, `allow_ai_plagiarism`, `allow_real_time_data`, `show_real_time_data`) VALUES
(1, 'Starter', 'Get started with our starter package', 'starter', 3, 'starter', 0, NULL, NULL, NULL, 1000, 10, 2, 0, 2, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, NULL, '2025-04-21 18:25:50', '2025-05-11 16:02:57', NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0),
(2, 'Basic', 'Get started with our Basic package', 'starter-1745242178', 3, 'monthly', 20, NULL, NULL, NULL, 100000, 50, 2, 0, 2, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, NULL, '2025-04-21 18:29:38', '2025-05-03 23:03:36', NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1),
(3, 'Premium&nbsp;', 'Get started with our Premium package', 'starter-1745242178-1745242257', 3, 'monthly', 50, NULL, NULL, NULL, 500000, 100, 2, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, NULL, '2025-04-21 18:30:57', '2025-05-03 23:03:46', NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, NULL, NULL, NULL, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1),
(4, 'Yearly Pakage', 'Get started with our Premium package', 'starter-1745242178-1745242257-1745257202', 3, 'yearly', 250, NULL, NULL, NULL, 250000, 10, 2, 0, 2, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, NULL, '2025-04-21 22:40:02', '2025-04-21 22:42:18', NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, NULL, NULL, NULL, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1),
(5, 'Premium&nbsp;', 'Get started with our Premium package', 'starter-1745242178-1745242257-1745257352', 3, 'lifetime', 699, NULL, NULL, 0, 50000, 10, 2, 0, 2, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, NULL, '2025-04-21 22:42:32', '2025-04-21 22:43:16', NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, NULL, NULL, NULL, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1),
(6, 'Basic', 'Get started with our Basic package', 'starter-1745242178-1745257423', 3, 'prepaid', 20, NULL, NULL, NULL, 100000, 10, 2, 0, 2, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, NULL, '2025-04-21 22:43:43', '2025-04-21 22:43:43', NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1),
(7, 'Platinum', 'Get started with our Premium package', 'starter-1745242178-1745242257-1746294940', 3, 'monthly', 150, NULL, NULL, NULL, 1500000, 500, 2, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, NULL, '2025-05-03 22:55:40', '2025-05-03 23:03:52', NULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, NULL, NULL, NULL, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `subscription_package_templates`
--

CREATE TABLE `subscription_package_templates` (
  `id` bigint UNSIGNED NOT NULL,
  `subscription_package_id` int NOT NULL,
  `template_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `subscription_package_templates`
--

INSERT INTO `subscription_package_templates` (`id`, `subscription_package_id`, `template_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 1, 2, NULL, NULL),
(3, 1, 3, NULL, NULL),
(4, 1, 4, NULL, NULL),
(5, 1, 5, NULL, NULL),
(6, 1, 6, NULL, NULL),
(7, 1, 7, NULL, NULL),
(8, 1, 8, NULL, NULL),
(9, 1, 9, NULL, NULL),
(10, 1, 10, NULL, NULL),
(11, 1, 11, NULL, NULL),
(12, 1, 12, NULL, NULL),
(13, 1, 13, NULL, NULL),
(14, 1, 14, NULL, NULL),
(15, 1, 15, NULL, NULL),
(16, 1, 16, NULL, NULL),
(17, 1, 17, NULL, NULL),
(18, 1, 18, NULL, NULL),
(19, 1, 19, NULL, NULL),
(20, 1, 20, NULL, NULL),
(21, 1, 21, NULL, NULL),
(22, 1, 22, NULL, NULL),
(23, 1, 23, NULL, NULL),
(24, 1, 24, NULL, NULL),
(25, 1, 25, NULL, NULL),
(26, 1, 26, NULL, NULL),
(27, 1, 27, NULL, NULL),
(28, 1, 28, NULL, NULL),
(29, 1, 29, NULL, NULL),
(30, 1, 30, NULL, NULL),
(31, 1, 31, NULL, NULL),
(32, 1, 32, NULL, NULL),
(33, 1, 33, NULL, NULL),
(34, 1, 34, NULL, NULL),
(35, 1, 35, NULL, NULL),
(36, 1, 36, NULL, NULL),
(37, 1, 37, NULL, NULL),
(38, 1, 38, NULL, NULL),
(39, 1, 39, NULL, NULL),
(40, 1, 40, NULL, NULL),
(41, 1, 41, NULL, NULL),
(42, 1, 42, NULL, NULL),
(43, 1, 43, NULL, NULL),
(44, 1, 44, NULL, NULL),
(45, 1, 45, NULL, NULL),
(46, 1, 46, NULL, NULL),
(47, 1, 47, NULL, NULL),
(48, 1, 48, NULL, NULL),
(49, 1, 49, NULL, NULL),
(50, 1, 50, NULL, NULL),
(51, 1, 51, NULL, NULL),
(52, 1, 52, NULL, NULL),
(53, 1, 53, NULL, NULL),
(54, 1, 54, NULL, NULL),
(55, 1, 55, NULL, NULL),
(56, 1, 56, NULL, NULL),
(57, 1, 57, NULL, NULL),
(58, 1, 58, NULL, NULL),
(59, 1, 59, NULL, NULL),
(60, 1, 60, NULL, NULL),
(61, 1, 61, NULL, NULL),
(62, 1, 62, NULL, NULL),
(63, 1, 63, NULL, NULL),
(64, 1, 64, NULL, NULL),
(65, 1, 65, NULL, NULL),
(66, 1, 66, NULL, NULL),
(67, 1, 67, NULL, NULL),
(68, 1, 68, NULL, NULL),
(69, 1, 69, NULL, NULL),
(70, 1, 70, NULL, NULL),
(71, 1, 71, NULL, NULL),
(72, 2, 1, NULL, NULL),
(73, 2, 2, NULL, NULL),
(74, 2, 3, NULL, NULL),
(75, 2, 4, NULL, NULL),
(76, 2, 5, NULL, NULL),
(77, 2, 6, NULL, NULL),
(78, 2, 7, NULL, NULL),
(79, 2, 8, NULL, NULL),
(80, 2, 9, NULL, NULL),
(81, 2, 10, NULL, NULL),
(82, 2, 11, NULL, NULL),
(83, 2, 12, NULL, NULL),
(84, 2, 13, NULL, NULL),
(85, 2, 14, NULL, NULL),
(86, 2, 15, NULL, NULL),
(87, 2, 16, NULL, NULL),
(88, 2, 17, NULL, NULL),
(89, 2, 18, NULL, NULL),
(90, 2, 19, NULL, NULL),
(91, 2, 20, NULL, NULL),
(92, 2, 21, NULL, NULL),
(93, 2, 22, NULL, NULL),
(94, 2, 23, NULL, NULL),
(95, 2, 24, NULL, NULL),
(96, 2, 25, NULL, NULL),
(97, 2, 26, NULL, NULL),
(98, 2, 27, NULL, NULL),
(99, 2, 28, NULL, NULL),
(100, 2, 29, NULL, NULL),
(101, 2, 30, NULL, NULL),
(102, 2, 31, NULL, NULL),
(103, 2, 32, NULL, NULL),
(104, 2, 33, NULL, NULL),
(105, 2, 34, NULL, NULL),
(106, 2, 35, NULL, NULL),
(107, 2, 36, NULL, NULL),
(108, 2, 37, NULL, NULL),
(109, 2, 38, NULL, NULL),
(110, 2, 39, NULL, NULL),
(111, 2, 40, NULL, NULL),
(112, 2, 41, NULL, NULL),
(113, 2, 42, NULL, NULL),
(114, 2, 43, NULL, NULL),
(115, 2, 44, NULL, NULL),
(116, 2, 45, NULL, NULL),
(117, 2, 46, NULL, NULL),
(118, 2, 47, NULL, NULL),
(119, 2, 48, NULL, NULL),
(120, 2, 49, NULL, NULL),
(121, 2, 50, NULL, NULL),
(122, 2, 51, NULL, NULL),
(123, 2, 52, NULL, NULL),
(124, 2, 53, NULL, NULL),
(125, 2, 54, NULL, NULL),
(126, 2, 55, NULL, NULL),
(127, 2, 56, NULL, NULL),
(128, 2, 57, NULL, NULL),
(129, 2, 58, NULL, NULL),
(130, 2, 59, NULL, NULL),
(131, 2, 60, NULL, NULL),
(132, 2, 61, NULL, NULL),
(133, 2, 62, NULL, NULL),
(134, 2, 63, NULL, NULL),
(135, 2, 64, NULL, NULL),
(136, 2, 65, NULL, NULL),
(137, 2, 66, NULL, NULL),
(138, 2, 67, NULL, NULL),
(139, 2, 68, NULL, NULL),
(140, 2, 69, NULL, NULL),
(141, 2, 70, NULL, NULL),
(142, 2, 71, NULL, NULL),
(143, 3, 1, NULL, NULL),
(144, 3, 2, NULL, NULL),
(145, 3, 3, NULL, NULL),
(146, 3, 4, NULL, NULL),
(147, 3, 5, NULL, NULL),
(148, 3, 6, NULL, NULL),
(149, 3, 7, NULL, NULL),
(150, 3, 8, NULL, NULL),
(151, 3, 9, NULL, NULL),
(152, 3, 10, NULL, NULL),
(153, 3, 11, NULL, NULL),
(154, 3, 12, NULL, NULL),
(155, 3, 13, NULL, NULL),
(156, 3, 14, NULL, NULL),
(157, 3, 15, NULL, NULL),
(158, 3, 16, NULL, NULL),
(159, 3, 17, NULL, NULL),
(160, 3, 18, NULL, NULL),
(161, 3, 19, NULL, NULL),
(162, 3, 20, NULL, NULL),
(163, 3, 21, NULL, NULL),
(164, 3, 22, NULL, NULL),
(165, 3, 23, NULL, NULL),
(166, 3, 24, NULL, NULL),
(167, 3, 25, NULL, NULL),
(168, 3, 26, NULL, NULL),
(169, 3, 27, NULL, NULL),
(170, 3, 28, NULL, NULL),
(171, 3, 29, NULL, NULL),
(172, 3, 30, NULL, NULL),
(173, 3, 31, NULL, NULL),
(174, 3, 32, NULL, NULL),
(175, 3, 33, NULL, NULL),
(176, 3, 34, NULL, NULL),
(177, 3, 35, NULL, NULL),
(178, 3, 36, NULL, NULL),
(179, 3, 37, NULL, NULL),
(180, 3, 38, NULL, NULL),
(181, 3, 39, NULL, NULL),
(182, 3, 40, NULL, NULL),
(183, 3, 41, NULL, NULL),
(184, 3, 42, NULL, NULL),
(185, 3, 43, NULL, NULL),
(186, 3, 44, NULL, NULL),
(187, 3, 45, NULL, NULL),
(188, 3, 46, NULL, NULL),
(189, 3, 47, NULL, NULL),
(190, 3, 48, NULL, NULL),
(191, 3, 49, NULL, NULL),
(192, 3, 50, NULL, NULL),
(193, 3, 51, NULL, NULL),
(194, 3, 52, NULL, NULL),
(195, 3, 53, NULL, NULL),
(196, 3, 54, NULL, NULL),
(197, 3, 55, NULL, NULL),
(198, 3, 56, NULL, NULL),
(199, 3, 57, NULL, NULL),
(200, 3, 58, NULL, NULL),
(201, 3, 59, NULL, NULL),
(202, 3, 60, NULL, NULL),
(203, 3, 61, NULL, NULL),
(204, 3, 62, NULL, NULL),
(205, 3, 63, NULL, NULL),
(206, 3, 64, NULL, NULL),
(207, 3, 65, NULL, NULL),
(208, 3, 66, NULL, NULL),
(209, 3, 67, NULL, NULL),
(210, 3, 68, NULL, NULL),
(211, 3, 69, NULL, NULL),
(212, 3, 70, NULL, NULL),
(213, 3, 71, NULL, NULL),
(214, 4, 1, NULL, NULL),
(215, 4, 2, NULL, NULL),
(216, 4, 3, NULL, NULL),
(217, 4, 4, NULL, NULL),
(218, 4, 5, NULL, NULL),
(219, 4, 6, NULL, NULL),
(220, 4, 7, NULL, NULL),
(221, 4, 8, NULL, NULL),
(222, 4, 9, NULL, NULL),
(223, 4, 10, NULL, NULL),
(224, 4, 11, NULL, NULL),
(225, 4, 12, NULL, NULL),
(226, 4, 13, NULL, NULL),
(227, 4, 14, NULL, NULL),
(228, 4, 15, NULL, NULL),
(229, 4, 16, NULL, NULL),
(230, 4, 17, NULL, NULL),
(231, 4, 18, NULL, NULL),
(232, 4, 19, NULL, NULL),
(233, 4, 20, NULL, NULL),
(234, 4, 21, NULL, NULL),
(235, 4, 22, NULL, NULL),
(236, 4, 23, NULL, NULL),
(237, 4, 24, NULL, NULL),
(238, 4, 25, NULL, NULL),
(239, 4, 26, NULL, NULL),
(240, 4, 27, NULL, NULL),
(241, 4, 28, NULL, NULL),
(242, 4, 29, NULL, NULL),
(243, 4, 30, NULL, NULL),
(244, 4, 31, NULL, NULL),
(245, 4, 32, NULL, NULL),
(246, 4, 33, NULL, NULL),
(247, 4, 34, NULL, NULL),
(248, 4, 35, NULL, NULL),
(249, 4, 36, NULL, NULL),
(250, 4, 37, NULL, NULL),
(251, 4, 38, NULL, NULL),
(252, 4, 39, NULL, NULL),
(253, 4, 40, NULL, NULL),
(254, 4, 41, NULL, NULL),
(255, 4, 42, NULL, NULL),
(256, 4, 43, NULL, NULL),
(257, 4, 44, NULL, NULL),
(258, 4, 45, NULL, NULL),
(259, 4, 46, NULL, NULL),
(260, 4, 47, NULL, NULL),
(261, 4, 48, NULL, NULL),
(262, 4, 49, NULL, NULL),
(263, 4, 50, NULL, NULL),
(264, 4, 51, NULL, NULL),
(265, 4, 52, NULL, NULL),
(266, 4, 53, NULL, NULL),
(267, 4, 54, NULL, NULL),
(268, 4, 55, NULL, NULL),
(269, 4, 56, NULL, NULL),
(270, 4, 57, NULL, NULL),
(271, 4, 58, NULL, NULL),
(272, 4, 59, NULL, NULL),
(273, 4, 60, NULL, NULL),
(274, 4, 61, NULL, NULL),
(275, 4, 62, NULL, NULL),
(276, 4, 63, NULL, NULL),
(277, 4, 64, NULL, NULL),
(278, 4, 65, NULL, NULL),
(279, 4, 66, NULL, NULL),
(280, 4, 67, NULL, NULL),
(281, 4, 68, NULL, NULL),
(282, 4, 69, NULL, NULL),
(283, 4, 70, NULL, NULL),
(284, 4, 71, NULL, NULL),
(285, 5, 1, NULL, NULL),
(286, 5, 2, NULL, NULL),
(287, 5, 3, NULL, NULL),
(288, 5, 4, NULL, NULL),
(289, 5, 5, NULL, NULL),
(290, 5, 6, NULL, NULL),
(291, 5, 7, NULL, NULL),
(292, 5, 8, NULL, NULL),
(293, 5, 9, NULL, NULL),
(294, 5, 10, NULL, NULL),
(295, 5, 11, NULL, NULL),
(296, 5, 12, NULL, NULL),
(297, 5, 13, NULL, NULL),
(298, 5, 14, NULL, NULL),
(299, 5, 15, NULL, NULL),
(300, 5, 16, NULL, NULL),
(301, 5, 17, NULL, NULL),
(302, 5, 18, NULL, NULL),
(303, 5, 19, NULL, NULL),
(304, 5, 20, NULL, NULL),
(305, 5, 21, NULL, NULL),
(306, 5, 22, NULL, NULL),
(307, 5, 23, NULL, NULL),
(308, 5, 24, NULL, NULL),
(309, 5, 25, NULL, NULL),
(310, 5, 26, NULL, NULL),
(311, 5, 27, NULL, NULL),
(312, 5, 28, NULL, NULL),
(313, 5, 29, NULL, NULL),
(314, 5, 30, NULL, NULL),
(315, 5, 31, NULL, NULL),
(316, 5, 32, NULL, NULL),
(317, 5, 33, NULL, NULL),
(318, 5, 34, NULL, NULL),
(319, 5, 35, NULL, NULL),
(320, 5, 36, NULL, NULL),
(321, 5, 37, NULL, NULL),
(322, 5, 38, NULL, NULL),
(323, 5, 39, NULL, NULL),
(324, 5, 40, NULL, NULL),
(325, 5, 41, NULL, NULL),
(326, 5, 42, NULL, NULL),
(327, 5, 43, NULL, NULL),
(328, 5, 44, NULL, NULL),
(329, 5, 45, NULL, NULL),
(330, 5, 46, NULL, NULL),
(331, 5, 47, NULL, NULL),
(332, 5, 48, NULL, NULL),
(333, 5, 49, NULL, NULL),
(334, 5, 50, NULL, NULL),
(335, 5, 51, NULL, NULL),
(336, 5, 52, NULL, NULL),
(337, 5, 53, NULL, NULL),
(338, 5, 54, NULL, NULL),
(339, 5, 55, NULL, NULL),
(340, 5, 56, NULL, NULL),
(341, 5, 57, NULL, NULL),
(342, 5, 58, NULL, NULL),
(343, 5, 59, NULL, NULL),
(344, 5, 60, NULL, NULL),
(345, 5, 61, NULL, NULL),
(346, 5, 62, NULL, NULL),
(347, 5, 63, NULL, NULL),
(348, 5, 64, NULL, NULL),
(349, 5, 65, NULL, NULL),
(350, 5, 66, NULL, NULL),
(351, 5, 67, NULL, NULL),
(352, 5, 68, NULL, NULL),
(353, 5, 69, NULL, NULL),
(354, 5, 70, NULL, NULL),
(355, 5, 71, NULL, NULL),
(356, 6, 1, NULL, NULL),
(357, 6, 2, NULL, NULL),
(358, 6, 3, NULL, NULL),
(359, 6, 4, NULL, NULL),
(360, 6, 5, NULL, NULL),
(361, 6, 6, NULL, NULL),
(362, 6, 7, NULL, NULL),
(363, 6, 8, NULL, NULL),
(364, 6, 9, NULL, NULL),
(365, 6, 10, NULL, NULL),
(366, 6, 11, NULL, NULL),
(367, 6, 12, NULL, NULL),
(368, 6, 13, NULL, NULL),
(369, 6, 14, NULL, NULL),
(370, 6, 15, NULL, NULL),
(371, 6, 16, NULL, NULL),
(372, 6, 17, NULL, NULL),
(373, 6, 18, NULL, NULL),
(374, 6, 19, NULL, NULL),
(375, 6, 20, NULL, NULL),
(376, 6, 21, NULL, NULL),
(377, 6, 22, NULL, NULL),
(378, 6, 23, NULL, NULL),
(379, 6, 24, NULL, NULL),
(380, 6, 25, NULL, NULL),
(381, 6, 26, NULL, NULL),
(382, 6, 27, NULL, NULL),
(383, 6, 28, NULL, NULL),
(384, 6, 29, NULL, NULL),
(385, 6, 30, NULL, NULL),
(386, 6, 31, NULL, NULL),
(387, 6, 32, NULL, NULL),
(388, 6, 33, NULL, NULL),
(389, 6, 34, NULL, NULL),
(390, 6, 35, NULL, NULL),
(391, 6, 36, NULL, NULL),
(392, 6, 37, NULL, NULL),
(393, 6, 38, NULL, NULL),
(394, 6, 39, NULL, NULL),
(395, 6, 40, NULL, NULL),
(396, 6, 41, NULL, NULL),
(397, 6, 42, NULL, NULL),
(398, 6, 43, NULL, NULL),
(399, 6, 44, NULL, NULL),
(400, 6, 45, NULL, NULL),
(401, 6, 46, NULL, NULL),
(402, 6, 47, NULL, NULL),
(403, 6, 48, NULL, NULL),
(404, 6, 49, NULL, NULL),
(405, 6, 50, NULL, NULL),
(406, 6, 51, NULL, NULL),
(407, 6, 52, NULL, NULL),
(408, 6, 53, NULL, NULL),
(409, 6, 54, NULL, NULL),
(410, 6, 55, NULL, NULL),
(411, 6, 56, NULL, NULL),
(412, 6, 57, NULL, NULL),
(413, 6, 58, NULL, NULL),
(414, 6, 59, NULL, NULL),
(415, 6, 60, NULL, NULL),
(416, 6, 61, NULL, NULL),
(417, 6, 62, NULL, NULL),
(418, 6, 63, NULL, NULL),
(419, 6, 64, NULL, NULL),
(420, 6, 65, NULL, NULL),
(421, 6, 66, NULL, NULL),
(422, 6, 67, NULL, NULL),
(423, 6, 68, NULL, NULL),
(424, 6, 69, NULL, NULL),
(425, 6, 70, NULL, NULL),
(426, 6, 71, NULL, NULL),
(427, 7, 1, NULL, NULL),
(428, 7, 2, NULL, NULL),
(429, 7, 3, NULL, NULL),
(430, 7, 4, NULL, NULL),
(431, 7, 5, NULL, NULL),
(432, 7, 6, NULL, NULL),
(433, 7, 7, NULL, NULL),
(434, 7, 8, NULL, NULL),
(435, 7, 9, NULL, NULL),
(436, 7, 10, NULL, NULL),
(437, 7, 11, NULL, NULL),
(438, 7, 12, NULL, NULL),
(439, 7, 13, NULL, NULL),
(440, 7, 14, NULL, NULL),
(441, 7, 15, NULL, NULL),
(442, 7, 16, NULL, NULL),
(443, 7, 17, NULL, NULL),
(444, 7, 18, NULL, NULL),
(445, 7, 19, NULL, NULL),
(446, 7, 20, NULL, NULL),
(447, 7, 21, NULL, NULL),
(448, 7, 22, NULL, NULL),
(449, 7, 23, NULL, NULL),
(450, 7, 24, NULL, NULL),
(451, 7, 25, NULL, NULL),
(452, 7, 26, NULL, NULL),
(453, 7, 27, NULL, NULL),
(454, 7, 28, NULL, NULL),
(455, 7, 29, NULL, NULL),
(456, 7, 30, NULL, NULL),
(457, 7, 31, NULL, NULL),
(458, 7, 32, NULL, NULL),
(459, 7, 33, NULL, NULL),
(460, 7, 34, NULL, NULL),
(461, 7, 35, NULL, NULL),
(462, 7, 36, NULL, NULL),
(463, 7, 37, NULL, NULL),
(464, 7, 38, NULL, NULL),
(465, 7, 39, NULL, NULL),
(466, 7, 40, NULL, NULL),
(467, 7, 41, NULL, NULL),
(468, 7, 42, NULL, NULL),
(469, 7, 43, NULL, NULL),
(470, 7, 44, NULL, NULL),
(471, 7, 45, NULL, NULL),
(472, 7, 46, NULL, NULL),
(473, 7, 47, NULL, NULL),
(474, 7, 48, NULL, NULL),
(475, 7, 49, NULL, NULL),
(476, 7, 50, NULL, NULL),
(477, 7, 51, NULL, NULL),
(478, 7, 52, NULL, NULL),
(479, 7, 53, NULL, NULL),
(480, 7, 54, NULL, NULL),
(481, 7, 55, NULL, NULL),
(482, 7, 56, NULL, NULL),
(483, 7, 57, NULL, NULL),
(484, 7, 58, NULL, NULL),
(485, 7, 59, NULL, NULL),
(486, 7, 60, NULL, NULL),
(487, 7, 61, NULL, NULL),
(488, 7, 62, NULL, NULL),
(489, 7, 63, NULL, NULL),
(490, 7, 64, NULL, NULL),
(491, 7, 65, NULL, NULL),
(492, 7, 66, NULL, NULL),
(493, 7, 67, NULL, NULL),
(494, 7, 68, NULL, NULL),
(495, 7, 69, NULL, NULL),
(496, 7, 70, NULL, NULL),
(497, 7, 71, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscription_recurring_payments`
--

CREATE TABLE `subscription_recurring_payments` (
  `id` bigint UNSIGNED NOT NULL,
  `subscription_history_id` int DEFAULT NULL,
  `billing_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `product_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `price_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `gateway_subscription_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `gateway` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `reason` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `status` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `cancel_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `entity` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `entity`, `value`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'google_login', '1', '2022-12-07 23:33:40', '2023-05-30 05:11:19', NULL),
(2, 'default_currency', 'usd', '2022-12-07 23:55:08', '2022-12-07 23:55:08', NULL),
(3, 'no_of_decimals', '2', '2022-12-07 23:55:08', '2022-12-07 23:55:08', NULL),
(4, 'truncate_price', '0', '2022-12-07 23:55:08', '2022-12-07 23:55:08', NULL),
(5, 'enable_multi_vendor', '0', '2022-12-25 23:00:08', '2023-02-19 01:56:54', NULL),
(6, 'default_admin_commission', '5', '2022-12-25 23:00:08', '2022-12-25 23:00:08', NULL),
(7, 'vendor_minimum_payout', '500', '2022-12-28 23:34:48', '2022-12-28 23:34:48', NULL),
(8, 'order_code_prefix', '#writebot-:', '2023-02-04 23:48:17', '2023-02-20 01:42:24', NULL),
(9, 'order_code_start', '1', '2023-02-04 23:48:17', '2023-02-04 23:51:38', NULL),
(10, 'system_title', 'WriterCert', '2023-02-05 23:48:44', '2025-05-03 14:33:08', NULL),
(11, 'title_separator', ': AI Writing. Auto-Posted. Certified Quality.', '2023-02-05 23:48:44', '2025-05-03 14:33:08', NULL),
(12, 'site_address', 'Cecilia Chapman, 711-2880 Nulla St, Mankato Mississippi 96522', '2023-02-05 23:49:15', '2023-02-05 23:49:15', NULL),
(13, 'registration_with', 'email', '2023-02-19 02:10:22', '2023-02-19 02:10:22', NULL),
(14, 'registration_verification_with', 'disable', '2023-02-19 02:10:22', '2023-02-19 02:10:22', NULL),
(15, 'topbar_welcome_text', 'Welcome to our Organic store', '2023-02-20 23:41:46', '2023-02-20 23:41:46', NULL),
(16, 'topbar_email', 'groshop@support.com', '2023-02-20 23:41:46', '2023-02-20 23:41:46', NULL),
(17, 'topbar_location', 'Washington, New York, USA - 254230', '2023-02-20 23:41:46', '2023-02-20 23:41:46', NULL),
(18, 'navbar_logo', '1', '2023-02-20 23:41:46', '2023-03-12 20:04:45', NULL),
(19, 'navbar_categories', NULL, '2023-02-20 23:41:46', '2023-03-12 20:04:45', NULL),
(20, 'navbar_pages', '[\"1\"]', '2023-02-20 23:41:47', '2023-03-02 02:32:34', NULL),
(21, 'navbar_contact_number', '+80 157 058 4567', '2023-02-20 23:41:47', '2023-02-20 23:41:47', NULL),
(22, 'hero_sliders', '[{\"id\":106549,\"sub_title\":\"Genuine 100% Organic Products\",\"title\":\"Online Fresh Grocery Products\",\"text\":\"Assertively target market-driven intellectual capital with worldwide human capital holistic.\",\"image\":\"39\",\"link\":\"https:\\/\\/www.youtube.com\\/watch?v=mZ77D66ZYtw\"}]', '2023-02-21 04:36:00', '2023-03-02 01:33:57', NULL),
(24, 'top_category_ids', '[\"6\",\"5\",\"4\",\"3\",\"2\"]', '2023-02-26 02:29:10', '2023-02-26 02:29:10', NULL),
(25, 'featured_sub_title', 'Platform mindshare through effective infomediaries Dynamically implement.', '2023-02-26 03:18:46', '2023-02-26 03:18:46', NULL),
(26, 'featured_products_left', '[\"1\",\"2\",\"5\"]', '2023-02-26 03:18:46', '2023-02-26 21:38:23', NULL),
(27, 'featured_products_right', '[\"2\",\"3\",\"4\"]', '2023-02-26 03:18:46', '2023-02-26 05:53:03', NULL),
(28, 'featured_center_banner', '', '2023-02-26 03:18:46', '2023-02-26 04:01:42', NULL),
(29, 'featured_banner_link', 'http://enmart.work/products', '2023-02-26 03:23:47', '2023-02-26 03:23:47', NULL),
(30, 'trending_product_categories', '[\"5\",\"4\",\"3\"]', '2023-02-26 22:35:01', '2023-02-26 22:35:01', NULL),
(31, 'top_trending_products', '[\"1\",\"2\",\"3\",\"4\",\"5\"]', '2023-02-26 22:35:01', '2023-03-09 05:10:00', NULL),
(32, 'banner_section_one_banners', '[]', '2023-02-26 23:44:06', '2023-03-12 19:54:15', NULL),
(33, 'best_deal_end_date', '03/31/2023', '2023-02-27 02:38:19', '2023-02-27 02:44:19', NULL),
(34, 'weekly_best_deals', '[\"1\",\"2\",\"4\",\"5\"]', '2023-02-27 02:38:19', '2023-02-27 02:53:35', NULL),
(35, 'best_deal_banner', '', '2023-02-27 02:38:19', '2023-02-27 02:38:19', NULL),
(36, 'best_deal_banner_link', NULL, '2023-02-27 02:38:19', '2023-02-27 02:38:19', NULL),
(37, 'banner_section_two_banner_one_link', NULL, '2023-02-27 03:11:59', '2023-02-27 03:11:59', NULL),
(38, 'banner_section_two_banner_one', '49', '2023-02-27 03:11:59', '2023-02-27 03:11:59', NULL),
(39, 'banner_section_two_banner_two_link', NULL, '2023-02-27 03:11:59', '2023-02-27 03:11:59', NULL),
(40, 'banner_section_two_banner_two', '50', '2023-02-27 03:11:59', '2023-02-27 03:11:59', NULL),
(41, 'client_feedback', '[{\"id\":854463,\"name\":\"Lawrence Schroth\",\"heading\":\"Fantastic Way to cut Your Writing\",\"designation\":\"Managing Director\",\"rating\":\"5\",\"review\":\"I can\\u2019t imagine my life without WriteBot It has changed the game for me. I can put in a sentence or two of a generic idea and WriteBot takes it in and in 30 seconds or less generates more every time I hit enter...\",\"image\":\"28\"},{\"id\":652109,\"name\":\"Bernard\",\"heading\":\"WriteBot is my Trusted Copy Friend\",\"designation\":\"Business Owner\",\"rating\":\"5\",\"review\":\"I\'ve used WriteBot for several months now, along with a half dozen other paid AI copy tools and this has outperformed all of them. They have more specialized tools than anyone else.\",\"image\":\"29\"},{\"id\":199682,\"name\":\"Patrick\",\"heading\":\"Great quality of output\",\"designation\":\"SEO Content Writer\",\"rating\":\"5\",\"review\":\"WriteBot is THE best!!! Been using it for copywriting especially for blog posts. Saves me so much time and mental energy. It\'s a worthwhile investment! Great quality of output better than any other tool.\",\"image\":\"31\"},{\"id\":494645,\"name\":\"Candy Roy\",\"heading\":\"You Love to Outsource to AI - it\\u2019s perfect!\",\"designation\":\"Social Media Manager\",\"rating\":\"5\",\"review\":\"Wouldn\'t you love to outsource (no pun intended) your copywriting to an AI - I do and did! with WriteBot. It will give your phenomenal content with the ultimate edge by using lots of scientific copywriting formulas.\",\"image\":\"30\"},{\"id\":624097,\"name\":\"Jesse Stoddard\",\"heading\":\"I find WriteBot to be an excellent tool\\u2026\",\"designation\":\"Content Marketer & Blogger\",\"rating\":\"5\",\"review\":\"I find WriteBot to be an excellent tool for speeding up our copywriting service. Far from \\\"replacing\\\" myself or any of my writers, WriteBot provides an essential tool for better assemble the finished product faster.\",\"image\":\"27\"}]', '2023-02-27 06:16:47', '2023-05-30 01:37:14', NULL),
(42, 'best_selling_products', '[\"1\",\"2\",\"3\"]', '2023-02-27 23:01:19', '2023-02-27 23:01:19', NULL),
(43, 'best_selling_banner', '', '2023-02-27 23:01:19', '2023-02-27 23:11:30', NULL),
(44, 'best_selling_banner_link', NULL, '2023-02-27 23:01:19', '2023-02-27 23:01:19', NULL),
(45, 'product_listing_categories', '[\"6\",\"5\",\"4\",\"3\",\"2\"]', '2023-02-27 23:47:35', '2023-02-27 23:47:35', NULL),
(46, 'footer_categories', NULL, '2023-03-01 21:33:33', '2023-03-12 19:59:31', NULL),
(47, 'quick_links', '[\"1\"]', '2023-03-01 21:33:33', '2023-05-30 02:19:32', NULL),
(48, 'footer_logo', '2', '2023-03-01 21:33:33', '2023-03-12 20:05:55', NULL),
(49, 'accepted_payment_banner', '3', '2023-03-01 21:33:33', '2023-03-12 20:05:55', NULL),
(50, 'copyright_text', '<p>© All Designed, Developed <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFXSURBVHgBjZE9S8NQGIXPexsdBGkXF6d0qHSopYKuUqUO4uA/UMFZOjqK7g79AaLi4CquLRIHBydTFbVoaVZBoRKQfiT39TZDLWma9EyXc+9zz/tBiNBrOq9PTmhFhqzatrxKTGv7LOC0284JRcH17FoDYN3vE8MIhRu5vC6l1gi6c5k/RRicNA0LjO+gO43oPhTuiRmHASaTcIpe2e+ZQl4QttTxp9N1Sq0WmvF4bJclMgy+VS91lXLgceBuDGI7+Vi+pI/51R0icdr/FPhSw7BAWPwPohvV5QWBNqWgo1S18tDzqZ4t9A45RMgVtDBnls1BT1WLWYwhcjjh94RkvIzBQtMcawgOnOZQLJ95a/PDqeeKoQZyPppkS5AbGODtOd753VO9mwFgU7C7HpTah2dqd7Za+oraYWkwEUzLySfjDaO68RtWrrDRlVhy21PH6dq1jRD9AULxiBLD039WAAAAAElFTkSuQmCC\" data-filename=\"love.png\" style=\"width: 15px;\"> by <b><font color=\"#ff9c00\">WriterCert</font></b></p>', '2023-03-01 21:49:42', '2025-05-03 23:18:30', NULL),
(51, 'product_page_widgets', '[]', '2023-03-02 01:35:08', '2023-03-12 19:56:25', NULL),
(52, 'product_page_banner_link', NULL, '2023-03-02 02:20:50', '2023-03-02 02:20:50', NULL),
(53, 'product_page_banner', '59', '2023-03-02 02:20:50', '2023-03-02 02:20:50', NULL),
(54, 'facebook_link', 'https://www.facebook.com/', '2023-03-02 02:45:01', '2023-03-02 02:45:01', NULL),
(55, 'twitter_link', 'https://twitter.com/', '2023-03-02 02:45:01', '2023-03-02 02:45:01', NULL),
(56, 'linkedin_link', 'https://www.linkedin.com/', '2023-03-02 02:45:01', '2023-03-02 02:45:01', NULL),
(57, 'youtube_link', 'https://www.youtube.com/', '2023-03-02 02:45:01', '2023-03-02 02:45:01', NULL),
(58, 'about_us', 'Explain to you how all this mistaken denouncing pleasure and praising pain was born and we will give you a complete account of the system, and expound the actual teachings.\r\n                    \r\n                    Mistaken denouncing pleasure and praising pain was born and we will give you complete account of the system expound.', '2023-03-02 02:46:33', '2023-03-02 02:46:33', NULL),
(59, 'about_intro_sub_title', '100% Organic Food Provide', '2023-03-04 21:54:12', '2023-03-04 21:54:12', NULL),
(60, 'about_intro_title', 'Be healthy & <br> eat fresh organic food', '2023-03-04 21:54:12', '2023-03-11 22:49:49', NULL),
(61, 'about_intro_text', 'Assertively target market lorem ipsum is simply free text available dolor sit amet, consectetur notted adipisicing elit sed do eiusmod tempor incididunt simply freeutation labore et dolore.', '2023-03-04 21:54:12', '2023-03-04 21:54:12', NULL),
(62, 'about_intro_mission', 'Continually transform virtual meta- methodologies. leverage existing alignments.', '2023-03-04 21:54:12', '2023-03-04 21:54:12', NULL),
(63, 'about_intro_vision', 'Continually transform virtual meta- methodologies. leverage existing alignments.', '2023-03-04 21:54:12', '2023-03-04 21:54:12', NULL),
(64, 'about_intro_quote', 'Assertively target market Lorem ipsum is simply free consectetur notted elit sed do eiusmod', '2023-03-04 21:54:12', '2023-03-04 21:54:12', NULL),
(65, 'about_intro_quote_by', 'George Scholll', '2023-03-04 21:54:12', '2023-03-04 21:54:12', NULL),
(66, 'about_intro_image', '60', '2023-03-04 21:54:12', '2023-03-04 21:54:12', NULL),
(67, 'about_popular_brand_ids', '[\"1\",\"2\"]', '2023-03-04 22:16:59', '2023-03-04 22:16:59', NULL),
(68, 'about_features_title', 'Our Working Ability', '2023-03-04 22:49:27', '2023-03-04 22:49:27', NULL),
(69, 'about_features_sub_title', 'Assertively target market lorem ipsum is simply free text available dolor incididunt simply free ut labore et dolore.', '2023-03-04 22:49:27', '2023-03-04 22:49:27', NULL),
(70, 'about_us_features', '[]', '2023-03-04 22:59:50', '2023-03-12 19:57:12', NULL),
(71, 'about_why_choose_sub_title', 'Why Choose Us', '2023-03-04 23:59:45', '2023-03-04 23:59:45', NULL),
(72, 'about_why_choose_title', 'We do not Buy from the <br> Open Market', '2023-03-04 23:59:45', '2023-03-04 23:59:45', NULL),
(73, 'about_why_choose_text', 'Compellingly fashion intermandated opportunities and multimedia based fnsparent e-business.', '2023-03-04 23:59:45', '2023-03-04 23:59:45', NULL),
(74, 'about_why_choose_banner', '62', '2023-03-04 23:59:45', '2023-03-04 23:59:45', NULL),
(75, 'about_us_why_choose_us', '[]', '2023-03-05 00:05:13', '2023-03-12 19:57:43', NULL),
(76, 'admin_panel_logo', '17', '2023-03-05 02:37:03', '2023-05-29 23:36:34', NULL),
(77, 'favicon', '13', '2023-03-05 02:37:03', '2023-05-30 03:43:38', NULL),
(78, 'invoice_thanksgiving', 'Thank you for purchase. it is really awesome to have you as one of our paid users. We hope that you will be happy with Qlearly, if you ever have any questions, suggestions or concerns please do not hesitate to contact us.', '2023-03-08 00:04:15', '2023-03-08 00:09:20', NULL),
(79, 'navbar_logo_white', '15', '2023-05-29 23:34:46', '2023-05-29 23:34:46', NULL),
(80, 'navbar_logo_dark', '14', '2023-05-29 23:34:46', '2023-05-29 23:34:46', NULL),
(81, 'navbar_template_groups', '[\"1\",\"2\",\"3\",\"4\",\"5\",\"7\"]', '2023-05-29 23:34:46', '2023-05-29 23:35:25', NULL),
(82, 'contact_email', 'support@writercert.com', '2023-05-29 23:36:34', '2025-05-03 14:33:08', NULL),
(83, 'contact_phone', '540-907-0453', '2023-05-29 23:36:34', '2023-05-30 01:20:02', NULL),
(84, 'enable_maintenance_mode', '0', '2023-05-29 23:36:34', '2023-05-29 23:36:34', NULL),
(85, 'global_meta_title', 'WriterCert – AI Writing Tools, Blog Wizard & Auto Publishing Platform', '2023-05-29 23:36:34', '2025-05-03 14:27:05', NULL),
(86, 'global_meta_description', 'Boost your content creation with WriterCert – an AI-powered writing suite offering blog wizards, text generators, plagiarism detection, and auto-posting to WordPress, Medium & more. Create smarter, publish faster.', '2023-05-29 23:36:34', '2025-05-03 14:27:05', NULL),
(87, 'global_meta_keywords', 'AI writing tools, AI blog wizard, content generator, AI writer, auto content posting, AI copywriting, publish to WordPress, Medium auto poster, AI content automation, AI-powered writing assistant', '2023-05-29 23:36:34', '2025-05-03 14:27:05', NULL),
(88, 'global_meta_image', NULL, '2023-05-29 23:36:34', '2023-05-29 23:36:34', NULL),
(89, 'hero_title', 'Whatever You Need, Just Ask', '2023-05-29 23:47:17', '2023-05-29 23:49:47', NULL),
(90, 'hero_colorful_title', 'WriteBot  Has The Answers', '2023-05-29 23:47:17', '2023-05-29 23:47:17', NULL),
(91, 'hero_sub_title', 'Tell us what you want our WriteBot AI will create the marketing copy for you, It\'s that simple. AI blog writer that gives you more time to focus on the things you love.', '2023-05-29 23:47:17', '2023-05-29 23:56:23', NULL),
(92, 'hero_background_image', '8', '2023-05-29 23:47:17', '2023-05-29 23:47:17', NULL),
(93, 'hero_animated_image', '9', '2023-05-29 23:47:17', '2023-05-29 23:47:17', NULL),
(94, 'homepage_trusted_by_title', 'Trusted & Used by 1,245+ Companies', '2023-05-30 00:01:27', '2023-05-30 00:01:44', NULL),
(95, 'homepage_trusted_by_images', '22,21,20,19,18,26,23,24,25', '2023-05-30 00:01:27', '2023-05-30 00:01:27', NULL),
(96, 'how_it_works_1_title', 'Select Template', '2023-05-30 00:05:33', '2023-05-30 00:05:33', NULL),
(97, 'how_it_works_1_sub_title', 'Select template first that you want to generate content', '2023-05-30 00:05:33', '2023-05-30 00:05:33', NULL),
(98, 'how_it_works_1_short_description', 'Learn why businesses everywhere are leveraging AI to create sales and marketing campaigns for faster, more sustainable growth.', '2023-05-30 00:05:33', '2023-05-30 00:19:49', NULL),
(99, 'how_it_works_1_features', 'Select the personalized template,\r\n          Write the prompt or context that you want to generate,\r\n          Generate product descriptions', '2023-05-30 00:05:33', '2023-05-30 00:20:51', NULL),
(100, 'how_it_works_1_btn_title', 'Select Your Template', '2023-05-30 00:05:33', '2023-05-30 00:05:33', NULL),
(101, 'how_it_works_1_btn_link', 'https://writebot.themetags.com/dashboard/templates', '2023-05-30 00:05:33', '2023-05-30 00:05:33', NULL),
(102, 'how_it_works_1_image', '11', '2023-05-30 00:05:33', '2023-05-30 00:05:33', NULL),
(103, 'how_it_works_2_title', 'Write Your Prompt or Context', '2023-05-30 00:05:33', '2023-05-30 00:07:49', NULL),
(104, 'how_it_works_2_sub_title', 'Enter a few sentences about your brand and products', '2023-05-30 00:05:33', '2023-05-30 00:07:49', NULL),
(105, 'how_it_works_2_short_description', 'Increase the quality of your output by working with Chat by WriteBot prebuilt prompts. This helps you guide our software to better content and Choose from emails, social posts, long-form blog posts, and more!', '2023-05-30 00:05:33', '2023-05-30 00:28:43', NULL),
(106, 'how_it_works_2_features', 'Write or select WriteBot prebuilt prompts, \r\n          Prompts include helpful commands for generateing purfect content,\r\n          Generate personalized copy for sales outreach', '2023-05-30 00:05:33', '2023-05-30 00:25:49', NULL),
(107, 'how_it_works_2_btn_title', 'Write Prompts', '2023-05-30 00:05:33', '2023-05-30 00:07:49', NULL),
(108, 'how_it_works_2_btn_link', 'https://writebot.themetags.com/dashboard/templates/blog-section', '2023-05-30 00:05:33', '2023-05-30 00:07:49', NULL),
(109, 'how_it_works_2_image', '12', '2023-05-30 00:05:33', '2023-05-30 00:07:49', NULL),
(110, 'how_it_works_3_title', 'Select Advance Option & Generate', '2023-05-30 00:05:33', '2023-05-30 00:13:27', NULL),
(111, 'how_it_works_3_sub_title', 'Multiple options for each campaign that you’re working on', '2023-05-30 00:05:33', '2023-05-30 00:12:29', NULL),
(112, 'how_it_works_3_short_description', 'Experience the full power of an AI content generator that delivers premium results in seconds. Get better results in a fraction of the time.', '2023-05-30 00:05:33', '2023-05-30 00:29:31', NULL),
(113, 'how_it_works_3_features', 'Scrape websites for public data,\r\n          Generate personalized copy for sales outreach,\r\n          Summarize YouTube videos into key bullet points', '2023-05-30 00:05:33', '2023-05-30 00:30:22', NULL),
(114, 'how_it_works_3_btn_title', 'Chose Advance Options', '2023-05-30 00:05:33', '2023-05-30 00:11:40', NULL),
(115, 'how_it_works_3_btn_link', 'https://writebot.themetags.com/dashboard/templates/blog-section', '2023-05-30 00:05:33', '2023-05-30 00:11:40', NULL),
(116, 'how_it_works_3_image', '10', '2023-05-30 00:05:33', '2023-05-30 00:11:40', NULL),
(117, 'how_it_works_4_title', 'Edit, Polish, and Publish', '2023-05-30 00:05:33', '2023-05-30 00:13:27', NULL),
(118, 'how_it_works_4_sub_title', 'Just copy and paste the work into your CMS for publishing', '2023-05-30 00:05:33', '2023-05-30 00:11:40', NULL),
(119, 'how_it_works_4_short_description', 'Use WriteBot editor to rewrite paragraphs and polish up sentences. Then, just copy and paste the work into your CMS for publishing.', '2023-05-30 00:05:33', '2023-05-30 00:34:10', NULL),
(120, 'how_it_works_4_features', 'Edit Polish  and Publish with Ease using WriteBot,\r\n          Generate high-converting copy for all your campaigns,\r\n          No software can be a silver-bullet solution for any business', '2023-05-30 00:05:33', '2023-05-30 00:35:20', NULL),
(121, 'how_it_works_4_btn_title', 'Copy and Publish', '2023-05-30 00:05:33', '2023-05-30 00:15:12', NULL),
(122, 'how_it_works_4_btn_link', 'https://writebot.themetags.com/dashboard/templates/blog-section', '2023-05-30 00:05:33', '2023-05-30 00:15:12', NULL),
(123, 'how_it_works_4_image', '2', '2023-05-30 00:05:33', '2023-05-30 00:11:40', NULL),
(124, 'feature_image_1_title', 'We Provide Useful Template that Helps Your Business', '2023-05-30 00:40:57', '2023-05-30 00:40:57', NULL),
(125, 'feature_image_1_short_description', 'This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.', '2023-05-30 00:40:57', '2023-05-30 00:40:57', NULL),
(126, 'feature_image_1_image', '7', '2023-05-30 00:40:57', '2023-05-30 00:40:57', NULL),
(127, 'feature_image_2_title', 'Write Content', '2023-05-30 00:40:57', '2023-05-30 00:42:30', NULL),
(128, 'feature_image_2_image', '5', '2023-05-30 00:40:57', '2023-05-30 00:42:30', NULL),
(129, 'feature_image_3_title', 'Generate AI Images', '2023-05-30 00:40:57', '2023-05-30 00:42:30', NULL),
(130, 'feature_image_3_image', '4', '2023-05-30 00:40:57', '2023-05-30 00:42:30', NULL),
(131, 'feature_image_4_title', 'Generate Code', '2023-05-30 00:40:57', '2023-05-30 00:42:30', NULL),
(132, 'feature_image_4_image', '3', '2023-05-30 00:40:57', '2023-05-30 00:42:30', NULL),
(133, 'feature_image_5_title', 'Speech to Text Generate', '2023-05-30 00:40:57', '2023-05-30 00:42:30', NULL),
(134, 'feature_image_5_image', '6', '2023-05-30 00:40:57', '2023-05-30 00:42:30', NULL),
(135, 'cta_colored_title', 'Let\'s Try! Ready to level-up?', '2023-05-30 01:11:00', '2023-05-30 01:13:34', NULL),
(136, 'cta_heading_title', 'Start Your 30-Day Free Trial', '2023-05-30 01:11:00', '2023-05-30 01:11:00', NULL),
(137, 'cta_short_description', 'Write 10x faster, engage your audience, & never struggle with the blank page again.', '2023-05-30 01:11:00', '2023-05-30 01:11:00', NULL),
(138, 'cta_btn_title', 'Get Started - It\'s Free', '2023-05-30 01:11:00', '2023-05-30 01:11:00', NULL),
(139, 'cta_btn_link', NULL, '2023-05-30 01:11:00', '2023-05-30 01:11:00', NULL),
(140, 'cta_features', '2000 free words per month, \r\n          No credit card is required,\r\n          90+ content types to explore', '2023-05-30 01:11:00', '2023-05-30 01:12:15', NULL),
(141, 'login_leftbar_title', 'Check Out What Our Customers are <br> Saying', '2023-05-30 03:26:10', '2023-05-30 04:15:21', NULL),
(142, 'login_leftbar_colored_title', '(10,000+ 5 Star Reviews)', '2023-05-30 03:26:10', '2023-05-30 04:15:21', NULL),
(143, 'login_rightbar_title', 'Get Started with 10,000 Free Words', '2023-05-30 03:26:10', '2023-05-30 04:15:21', NULL),
(144, 'login_rightbar_sub_title', 'No credit card required!', '2023-05-30 03:26:10', '2023-05-30 04:15:21', NULL),
(145, 'enable_recaptcha', '1', '2023-05-30 03:26:10', '2025-05-13 15:17:50', NULL),
(146, 'enable_paypal', '1', '2023-05-30 04:50:42', '2023-05-30 04:50:42', NULL),
(147, 'paypal_sandbox', '1', '2023-05-30 04:50:42', '2023-05-30 04:50:42', NULL),
(148, 'enable_stripe', '1', '2023-05-30 04:50:42', '2023-05-30 04:50:42', NULL),
(149, 'enable_paytm', '1', '2023-05-30 04:50:42', '2023-05-30 04:50:42', NULL),
(150, 'enable_razorpay', '1', '2023-05-30 04:50:42', '2023-05-30 04:50:42', NULL),
(151, 'enable_iyzico', '1', '2023-05-30 04:50:42', '2023-05-30 04:50:42', NULL),
(152, 'iyzico_sandbox', '1', '2023-05-30 04:50:42', '2023-05-30 04:50:42', NULL),
(153, 'facebook_login', '1', '2023-05-30 05:11:19', '2023-05-30 05:11:19', NULL),
(154, 'software_version', '4.8.0', '2025-04-21 16:31:51', '2023-05-30 05:11:19', NULL),
(155, 'last_update', '2025-04-21 11:31:51', '2023-05-30 05:11:19', '2023-05-30 05:11:19', NULL),
(156, 'generate_image', '1', '2023-05-30 05:11:19', '2023-05-30 05:11:19', NULL),
(157, 'image_stable_diffusion_engine', 'stable-diffusion-v1-6', '2023-05-30 05:11:19', '2023-05-30 05:11:19', NULL),
(158, 'default_voiceover', 'open_ai_tts', '2023-05-30 05:11:19', '2023-05-30 05:11:19', NULL),
(159, 'hero_video', 'public/wirtebot-video.mp4', '2023-05-30 05:11:19', '2023-05-30 05:11:19', NULL),
(160, 'feature_integration_1_image', '44', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(161, 'feature_integration_1_title', 'Social Login Configurations', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(162, 'feature_integration_1_short_description', 'We are using Google and Facebook for Sign in & Sign up', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(163, 'feature_integration_2_image', '42', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(164, 'feature_integration_2_title', 'AWS Storage Management', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(165, 'feature_integration_2_short_description', 'Amazon AWS S3 storage management for Image & contents', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(166, 'feature_integration_3_image', '45', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(167, 'feature_integration_3_title', 'Two-factor Authentication', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(168, 'feature_integration_3_short_description', 'Two-factor authentication protection for your Twilio account.', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(169, 'feature_integration_4_image', '40', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(170, 'feature_integration_4_title', 'Google & Microsoft Azure TTS', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(171, 'feature_integration_4_short_description', 'Microsoft Azure and Google for Text to Speech Features', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(172, 'ai_image_section_1_image', '56', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(173, 'ai_image_section_1_title', 'Dall-E 2 Image Generator', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(174, 'ai_image_section_1_short_description', 'Generate Image using OpenAi dall-e 2 Features', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(175, 'ai_image_section_2_image', '54', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(176, 'ai_image_section_2_title', 'Stable Diffusion', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(177, 'ai_image_section_2_short_description', 'Stable Diffusion is a deep learning, text-to-image model released in 2022 based on diffusion techniques.', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(178, 'ai_image_section_3_image', '55', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(179, 'ai_image_section_3_title', 'Dall-E 3 Image Generator', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(180, 'ai_image_section_3_short_description', 'Generate High Quality Image using OpenAi dall-e 3 Features', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(181, 'feature_tools_1_image', '44', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(182, 'feature_tools_1_short_description', 'AI-powered translation tools Save per day on ad management', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(183, 'feature_tools_2_image', '71', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(184, 'feature_tools_2_title', 'Affiliate marketing', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(185, 'feature_tools_2_short_description', 'We have included Affiliate marketing system', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(186, 'feature_tools_3_image', '66', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(187, 'feature_tools_3_title', 'Multilingual Support', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(188, 'feature_tools_3_short_description', 'Writebot supported all language, you need to just add your language', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(189, 'feature_tools_4_image', '65', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(190, 'feature_tools_4_title', '12+ Payment Gateway Included', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(191, 'feature_tools_4_short_description', 'Writebot integrate 12+ Payment gateway', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(192, 'feature_tools_5_image', '45', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(193, 'feature_tools_5_title', 'Two factor Authentication', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(194, 'feature_tools_5_short_description', 'Two-factor authentication protection for your Twilio account. You will be required to enter in the code available', '2025-04-21 16:31:52', '2025-04-21 16:31:52', NULL),
(195, 'default_creativity', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(196, 'default_tone', 'Friendly', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(197, 'default_number_of_results', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(198, 'default_max_result_length', '1', '2025-04-21 17:20:11', '2025-04-21 17:34:00', NULL),
(199, 'default_max_result_length_blog_wizard', '1', '2025-04-21 17:20:11', '2025-04-21 17:35:53', NULL),
(200, 'ai_filter_bad_words', NULL, '2025-04-21 17:20:11', '2025-05-03 22:36:53', NULL),
(201, 'image_chat_model', NULL, '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(202, 'generate_image_option', 'dall_e_2', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(203, 'default_open_ai_model', 'gpt-4', '2025-04-21 17:20:11', '2025-04-21 17:35:53', NULL),
(204, 'ai_blog_wizard_model', 'gpt-4', '2025-04-21 17:20:11', '2025-04-21 17:35:54', NULL),
(205, 'ai_chat_model', 'gpt-4-turbo', '2025-04-21 17:20:11', '2025-04-21 17:35:55', NULL),
(206, 'max_tokens', NULL, '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(207, 'api_key_use', 'main', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(208, 'sd_api_key_use', 'main', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(209, 'image_upscaler_engine', 'esrgan-v1-x2plus', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(210, 'serper_api_key', 'bfce1ba10e03d7686a5f53c9af06755dedcab996', '2025-04-21 17:20:11', '2025-04-21 17:33:26', NULL),
(211, 'enable_ai_chat', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(212, 'enable_ai_detector', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(213, 'enable_ai_plagiarism', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(214, 'enable_ai_rewriter', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(215, 'enable_ai_pdf_chat', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(216, 'enable_ai_vision', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(217, 'enable_ai_image_chat', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(218, 'enable_built_in_templates', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(219, 'enable_custom_templates', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(220, 'enable_blog_wizard', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(221, 'enable_speech_to_text', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(222, 'enable_text_to_speech', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(223, 'enable_eleven_labs', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(224, 'enable_ai_images', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(225, 'enable_ai_code', '1', '2025-04-21 17:20:11', '2025-04-21 17:20:11', NULL),
(226, 'enable_offline', '1', '2025-04-21 18:38:49', '2025-04-21 18:38:49', NULL),
(227, 'offline_image', NULL, '2025-04-21 18:38:49', '2025-04-21 18:38:49', NULL),
(228, 'affiliate_commission', '10', '2025-04-21 22:45:02', '2025-04-21 22:45:02', NULL),
(229, 'minimum_withdrawal_amount', '10', '2025-04-21 22:45:03', '2025-04-21 22:45:03', NULL),
(230, 'enable_affiliate_continuous_commission', '1', '2025-04-21 22:45:03', '2025-04-21 22:45:03', NULL),
(231, 'affiliate_payout_payment_methods', '[\"paypal\"]', '2025-04-21 22:45:03', '2025-04-21 22:45:03', NULL),
(232, 'enable_affiliate_system', '1', '2025-04-21 22:45:03', '2025-04-21 22:45:03', NULL),
(233, 'scrol_to_top_image', NULL, '2025-04-22 13:42:43', '2025-04-22 13:42:43', NULL),
(234, 'enable_preloader', NULL, '2025-04-22 13:43:01', '2025-04-22 13:43:01', NULL),
(235, 'admin_panel_logo_dark', NULL, '2025-04-22 13:43:01', '2025-04-22 13:43:01', NULL),
(236, 'enable_frontend', 'yes', '2025-04-22 13:43:01', '2025-04-22 13:43:01', NULL),
(237, 'enable_cookie_consent', NULL, '2025-04-22 13:43:01', '2025-04-22 13:43:01', NULL),
(238, 'cookie_consent_text', NULL, '2025-04-22 13:43:01', '2025-04-22 13:43:01', NULL),
(239, 'header_custom_scripts', '', '2025-04-22 13:47:23', '2025-04-22 13:47:23', NULL),
(240, 'footer_custom_scripts', '', '2025-04-22 13:47:23', '2025-05-13 15:46:09', NULL),
(241, 'header_custom_css', '', '2025-04-22 13:47:23', '2025-04-22 13:47:23', NULL),
(242, 'aboutUsContents', '<h3 data-start=\"173\" data-end=\"246\" class=\"\">Welcome to WriterCert — Where Smart Content Meets Seamless Publishing</h3><p data-start=\"248\" data-end=\"557\" class=\"\">At <strong data-start=\"251\" data-end=\"269\">WriterCert.com</strong>, we believe that great content should be easy to create and effortless to share. That’s why we’ve built an AI-powered writing and publishing platform that helps individuals, marketers, bloggers, and businesses save time, increase productivity, and stay ahead in the digital content game.</p><p data-start=\"559\" data-end=\"903\" class=\"\">Whether you\'re crafting SEO-optimized blog posts, marketing copy, emails, or custom content — <strong data-start=\"653\" data-end=\"667\">WriterCert</strong> provides certified-quality writing tools driven by the latest in artificial intelligence. With just a few clicks, your content is not only generated — it’s also <strong data-start=\"829\" data-end=\"853\">automatically posted</strong> to platforms like WordPress, Medium, and Blogger.</p><hr data-start=\"905\" data-end=\"908\" class=\"\"><h3 data-start=\"910\" data-end=\"925\" class=\"\">Our Mission</h3><p data-start=\"927\" data-end=\"1096\" class=\"\">To empower content creators and businesses with intelligent tools that simplify the writing process and streamline publishing — so you can focus on ideas, not logistics.</p><hr data-start=\"1098\" data-end=\"1101\" class=\"\"><h3 data-start=\"1103\" data-end=\"1120\" class=\"\">What We Offer</h3><ul data-start=\"1122\" data-end=\"1561\">\r\n<li data-start=\"1122\" data-end=\"1188\" class=\"\">\r\n<p data-start=\"1124\" data-end=\"1188\" class=\"\"><strong data-start=\"1124\" data-end=\"1144\">AI Writing Tools</strong> – Generate high-quality content instantly</p>\r\n</li>\r\n<li data-start=\"1189\" data-end=\"1258\" class=\"\">\r\n<p data-start=\"1191\" data-end=\"1258\" class=\"\"><strong data-start=\"1191\" data-end=\"1207\">Auto Posting</strong> – Schedule or auto-publish to multiple platforms</p>\r\n</li>\r\n<li data-start=\"1259\" data-end=\"1337\" class=\"\">\r\n<p data-start=\"1261\" data-end=\"1337\" class=\"\"><strong data-start=\"1261\" data-end=\"1274\">Templates</strong> – Ready-to-use content formats for blogs, ads, emails &amp; more</p>\r\n</li>\r\n<li data-start=\"1338\" data-end=\"1415\" class=\"\">\r\n<p data-start=\"1340\" data-end=\"1415\" class=\"\"><strong data-start=\"1340\" data-end=\"1377\">Plagiarism Checker &amp; AI Detection</strong> – Ensure originality and compliance</p>\r\n</li>\r\n<li data-start=\"1416\" data-end=\"1481\" class=\"\">\r\n<p data-start=\"1418\" data-end=\"1481\" class=\"\"><strong data-start=\"1418\" data-end=\"1453\">Text-to-Speech &amp; Speech-to-Text</strong> – Create content your way</p>\r\n</li>\r\n<li data-start=\"1482\" data-end=\"1561\" class=\"\">\r\n<p data-start=\"1484\" data-end=\"1561\" class=\"\"><strong data-start=\"1484\" data-end=\"1508\">Multi-format Support</strong> – PDF chat, AI images, rewriters, and coding tools</p>\r\n</li>\r\n</ul><hr data-start=\"1563\" data-end=\"1566\" class=\"\"><h3 data-start=\"1568\" data-end=\"1584\" class=\"\">Who We Serve</h3><ul data-start=\"1586\" data-end=\"1828\">\r\n<li data-start=\"1586\" data-end=\"1635\" class=\"\">\r\n<p data-start=\"1588\" data-end=\"1635\" class=\"\">Bloggers and writers looking to scale content</p>\r\n</li>\r\n<li data-start=\"1636\" data-end=\"1683\" class=\"\">\r\n<p data-start=\"1638\" data-end=\"1683\" class=\"\">Agencies managing multiple clients or blogs</p>\r\n</li>\r\n<li data-start=\"1684\" data-end=\"1718\" class=\"\">\r\n<p data-start=\"1686\" data-end=\"1718\" class=\"\">Entrepreneurs building a brand</p>\r\n</li>\r\n<li data-start=\"1719\" data-end=\"1764\" class=\"\">\r\n<p data-start=\"1721\" data-end=\"1764\" class=\"\">Affiliate marketers and SEO professionals</p>\r\n</li>\r\n<li data-start=\"1765\" data-end=\"1828\" class=\"\">\r\n<p data-start=\"1767\" data-end=\"1828\" class=\"\">Anyone who wants to save time while producing smarter content</p>\r\n</li>\r\n</ul><hr data-start=\"1830\" data-end=\"1833\" class=\"\"><h3 data-start=\"1835\" data-end=\"1854\" class=\"\">Why WriterCert?</h3><p data-start=\"1856\" data-end=\"2067\" class=\"\">Because we don’t just help you write — we help you <strong data-start=\"1907\" data-end=\"1957\">write with purpose and publish with confidence</strong>. From AI-powered creativity to smart distribution, WriterCert is your certified assistant for the modern web.</p><hr data-start=\"2069\" data-end=\"2072\" class=\"\"><p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p><p data-start=\"2074\" data-end=\"2196\" class=\"\"><strong data-start=\"2074\" data-end=\"2196\">Join thousands of creators embracing the future of content.<br data-start=\"2135\" data-end=\"2138\">\r\nStart writing. Get certified. Go live — with WriterCert.</strong></p>', '2025-05-04 13:21:00', '2025-05-04 13:21:00', NULL),
(243, 'welcome_email', '1', '2025-05-04 13:39:47', '2025-05-04 13:39:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` bigint UNSIGNED NOT NULL,
  `template_group_id` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `fields` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `icon` bigint DEFAULT NULL,
  `total_words_generated` bigint DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id`, `template_group_id`, `name`, `slug`, `code`, `description`, `fields`, `icon`, `total_words_generated`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Blog Section', 'blog-section', 'blog-section', 'Write a blog section with the key points of your article', '\"[{        \\\"label\\\": \\\"Title of the blog\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"        }},{        \\\"label\\\": \\\"What are the main points you want to cover?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"key_points\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. dosa, biriyani, tandoori chicken\\\"        }}]\"', NULL, 88, 1, '2025-04-21 16:31:51', '2025-04-22 13:53:22', NULL),
(2, 1, 'Blog Ideas', 'blog-ideas', 'blog-ideas', 'Generate blog ideas for your next post', '\"[{\\t\\\"label\\\": \\\"About what is your blog post?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(3, 1, 'Blog Title', 'blog-title', 'blog-title', 'Generate blog title for your next post', '\"[{\\t\\\"label\\\": \\\"About what is your blog post?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(4, 1, 'Blog Intro', 'blog-intro', 'blog-intro', 'Generate blog intro for your next post', '\"[{        \\\"label\\\": \\\"Title of the blog\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"        }},{        \\\"label\\\": \\\"About what is your blog post?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(5, 1, 'Blog Conclusion', 'blog-conclusion', 'blog-conclusion', 'Generate blog conclusion for your next post', '\"[{        \\\"label\\\": \\\"Title of the blog\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"        }},{        \\\"label\\\": \\\"About what is your blog post?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(6, 1, 'Blog Tags', 'blog-tags', 'blog-tags', 'Generate blog tags for your next post', '\"[{        \\\"label\\\": \\\"About what is your blog post?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(7, 1, 'Blog Summary', 'blog-summary', 'blog-summary', 'Generate blog summary for your next post', '\"[{        \\\"label\\\": \\\"About what is your blog post?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(8, 2, 'Confirmation Email', 'confirmation-email', 'confirmation-email', NULL, '\"[{        \\\"label\\\": \\\"What is recipient name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"name\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Ryan Toland\\\"        }},{        \\\"label\\\": \\\"About what is your email?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. Signing up to a web app\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(9, 2, 'Discount Email', 'discount-email', 'discount-email', NULL, '\"[{\\t\\\"label\\\": \\\"About what is your email?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Get discount on first purchase (of product name\\/from company name)\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(10, 2, 'Testimonial Email', 'testimonial-email', 'testimonial-email', NULL, '\"[{\\t\\\"label\\\": \\\"What is recipient name?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"name\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Ryan Toland\\\"\\t}},{\\t\\\"label\\\": \\\"About what is your email?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. For serving the company with sincerity\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(11, 2, 'Promotional Email', 'promotional-email', 'promotional-email', NULL, '\"[{\\t\\\"label\\\": \\\"What is recipient name?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"name\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Ryan Toland\\\"\\t}},{\\t\\\"label\\\": \\\"About what is your email?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. For serving the company with sincerity\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(12, 2, 'Follow Up Email', 'follow-up-email', 'follow-up-email', NULL, '\"[{\\t\\\"label\\\": \\\"About what is your email?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Following up after an interview\\\"\\t}}]\"', NULL, 632, 1, '2025-04-21 16:31:51', '2025-05-03 18:31:44', NULL),
(13, 3, 'Twitter Post', 'twitter-post', 'twitter-post', NULL, '\"[{        \\\"label\\\": \\\"About what is your post?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. Going to watch the champions league final\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(14, 3, 'Discount Promotion', 'discount-promotion', 'discount-promotion', NULL, '\"[{\\t\\\"label\\\": \\\"What is title for the promotion?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"title\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Get exclusive discounts on Eid occasion\\\"\\t}},{\\t\\\"label\\\": \\\"About what is the discount?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Get discount on first purchase (of product name\\/from company name)\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(15, 3, 'Social Media Bio', 'social-media-bio', 'social-media-bio', NULL, '\"[{\\t\\\"label\\\": \\\"What are the main points you want to cover?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"key_points\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Entrepreneur, Writer, Photographer\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(16, 3, 'Facebook Ads', 'facebook-ads', 'facebook-ads', NULL, '\"[{        \\\"label\\\": \\\"Who is your targetted audiences?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"audience\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Children, Couple\\\"        }},{        \\\"label\\\": \\\"What is the name of the product?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"name\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. iPhone 14 Pro\\\"        }},{        \\\"label\\\": \\\"Product Description\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"description\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type product description\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(17, 3, 'Instagram Captions', 'instagram-captions', 'instagram-captions', NULL, '\"[{        \\\"label\\\": \\\"About what is your instagram post?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. Travelling the world\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(18, 3, 'Social Media Post', 'social-media-post', 'social-media-post', NULL, '\"[{\\t\\\"label\\\": \\\"About what is your post?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Travelling the world\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(19, 3, 'Event Promotion', 'event-promotion', 'event-promotion', NULL, '\"[{        \\\"label\\\": \\\"Title of the event\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Celebration of victory day\\\"        }},{        \\\"label\\\": \\\"About what is your event?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type short description about the event\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(20, 3, 'Google Ads Headlines', 'google-ads-headlines', 'google-ads-headlines', NULL, '\"[{\\t\\\"label\\\": \\\"Who is your targetted audience?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"audience\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Children, Couple\\\"\\t}},{\\t\\\"label\\\": \\\"What is the name of the product?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"name\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. iPhone 14 Pro\\\"\\t}},{\\t\\\"label\\\": \\\"Product Description\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"description\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type product description\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(21, 3, 'Google Ads Description', 'google-ads-description', 'google-ads-description', NULL, '\"[{\\t\\\"label\\\": \\\"Who is your targetted audience?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"audience\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Children, Couple\\\"\\t}},{\\t\\\"label\\\": \\\"What is the name of the product?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"name\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. iPhone 14 Pro\\\"\\t}},{\\t\\\"label\\\": \\\"Product Description\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"description\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type product description\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(22, 4, 'Youtube Video Title', 'youtube-video-title', 'youtube-video-title', NULL, '\"[{        \\\"label\\\": \\\"About what is the video?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type description of the video\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(23, 4, 'Youtube Video Description', 'youtube-video-description', 'youtube-video-description', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the video?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the video\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(24, 4, 'Youtube Video Tag Generator', 'youtube-video-tag-generator', 'youtube-video-tag-generator', NULL, '\"[{        \\\"label\\\": \\\"About what is the video?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type description of the video\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(25, 5, 'Website FAQ', 'website-faq', 'website-faq', NULL, '\"[{        \\\"label\\\": \\\"About what is the FAQ?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(26, 5, 'Website FAQ Answers', 'website-faq-answers', 'website-faq-answers', NULL, '\"[{\\t\\\"label\\\": \\\"What is the question?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"question\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Do we provide support for 24\\/7?\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(27, 5, 'Website Review', 'website-review', 'website-review', NULL, '\"[{\\t\\\"label\\\": \\\"What is the name of the product?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"name\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. iPhone 14 Pro\\\"\\t}},{\\t\\\"label\\\": \\\"Product Description\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"description\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type product description\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(28, 5, 'Website Title', 'website-title', 'website-title', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the website?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the website\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(29, 5, 'Website Meta Tags', 'website-meta-tags', 'website-meta-tags', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the website?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the website\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(30, 5, 'Website Meta Description', 'website-meta-description', 'website-meta-description', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the website?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the website\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(31, 5, 'Website About Us', 'website-about-us', 'website-about-us', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the website?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the website\\\"\\t}}]\"', NULL, 105, 1, '2025-04-21 16:31:51', '2025-04-21 23:11:45', NULL),
(32, 5, 'Website Terms And Conditions', 'website-terms-and-conditions', 'website-terms-and-conditions', NULL, '\"[{        \\\"label\\\": \\\"What is your website title?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"Type title of the website\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(33, 5, 'Website Privacy Policy', 'website-privacy-policy', 'website-privacy-policy', NULL, '\"[{        \\\"label\\\": \\\"What is your website title?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"Type title of the website\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(34, 5, 'Vision of the Company', 'vision-of-the-company', 'vision-of-the-company', NULL, '\"[{        \\\"label\\\": \\\"What is your company name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"Type name of the company\\\"        }},{        \\\"label\\\": \\\"What is your company about?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"Type about of the company\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(35, 5, 'Mission of the Company', 'mission-of-the-company', 'mission-of-the-company', NULL, '\"[{        \\\"label\\\": \\\"What is your company name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"Type name of the company\\\"        }},{        \\\"label\\\": \\\"What is your company about?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"Type about of the company\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(36, 6, 'Academic Essay', 'academic-essay', 'academic-essay', NULL, '\"[{        \\\"label\\\": \\\"Title of the essay\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. The Newspaper\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(37, 6, 'Article Generator', 'article-generator', 'article-generator', NULL, '\"[{        \\\"label\\\": \\\"Title of the article\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"        }},{        \\\"label\\\": \\\"What are the main points you want to cover?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"key_points\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. dosa, biriyani, tandoori chicken\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(38, 6, 'Paragraph Generator', 'paragraph-generator', 'paragraph-generator', NULL, '\"[{\\t\\\"label\\\": \\\"Title of the paragraph\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"title\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. best restaurants in LA to eat indian foods\\\"\\t}},{\\t\\\"label\\\": \\\"What are the main points you want to cover?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"key_points\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. dosa, biriyani, tandoori chicken\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(39, 6, 'Content Rewriter', 'content-rewriter', 'content-rewriter', NULL, '\"[{        \\\"label\\\": \\\"What would you like to rewrite?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"contents\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type your content here to rewrite\\\"        }},{        \\\"label\\\": \\\"What are the main points you want to cover?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"key_points\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. key point 1, key point 2\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(40, 6, 'Product Description', 'product-description', 'product-description', NULL, '\"[{\\t\\\"label\\\": \\\"What is the name of the product?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"name\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. iPhone 14 Pro\\\"\\t}}]\"', NULL, 662, 1, '2025-04-21 16:31:51', '2025-05-03 23:21:14', NULL),
(41, 6, 'Product Name Generator', 'product-name-generator', 'product-name-generator', NULL, '\"[{\\t\\\"label\\\": \\\"Product Description\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"description\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type product description\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(42, 6, 'Product Summarize Text', 'product-summarize-text', 'product-summarize-text', NULL, '\"[{\\t\\\"label\\\": \\\"What is the name of the product?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"name\\\",\\t\\t\\\"type\\\": \\\"text\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. iPhone 14 Pro\\\"\\t}},{\\t\\\"label\\\": \\\"Product Description\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"description\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type product description\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(43, 6, 'Grammar Checker', 'grammar-checker', 'grammar-checker', NULL, '\"[{        \\\"label\\\": \\\"Type content you would like to check grammar\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"contents\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type your content here to check grammar\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(44, 6, 'Creative Story', 'creative-story', 'creative-story', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(45, 6, 'Startup Name Generator', 'startup-name-generator', 'startup-name-generator', NULL, '\"[{\\t\\\"label\\\": \\\"Start Up Description\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"description\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type start up description\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(46, 6, 'Pros & Cons', 'pros-cons', 'pros-cons', NULL, '\"[{        \\\"label\\\": \\\"What is the topic?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"topic\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Using mobile phone\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(47, 6, 'Job Description', 'job-description', 'job-description', NULL, '\"[{        \\\"label\\\": \\\"What is the job position?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"position\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. What is the position of the job?\\\"        }},{        \\\"label\\\": \\\"What are the core requirements?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"requirements\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type requirements for the position\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(48, 6, 'Rejection Letter', 'rejection-letter', 'rejection-letter', NULL, '\"[{        \\\"label\\\": \\\"What is recipient name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"name\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Ryan Toland\\\"        }},{        \\\"label\\\": \\\"About what is the rejection letter?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. Rejection letter of the job application for the position of software engineer\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(49, 6, 'Offer Letter', 'offer-letter', 'offer-letter', NULL, '\"[{        \\\"label\\\": \\\"What is recipient name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"name\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Ryan Toland\\\"        }},{        \\\"label\\\": \\\"About what is the offer letter?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. Offer letter of the job for the position of software engineer\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(50, 6, 'Promotion Letter', 'promotion-letter', 'promotion-letter', NULL, '\"[{        \\\"label\\\": \\\"What is recipient name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"name\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Ryan Toland\\\"        }},{        \\\"label\\\": \\\"What was the previous position?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"previous_position\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Junior executive\\\"        }},{        \\\"label\\\": \\\"What is the new position?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"new_position\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Executive\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(51, 7, 'Motivational Quote', 'motivational-quote', 'motivational-quote', NULL, '\"[{        \\\"label\\\": \\\"About what you want to generate motivational quote?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. Emotional breakdown, economical breakdown, career issue\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(52, 7, 'Song Lyrics', 'song-lyrics', 'song-lyrics', NULL, '\"[{        \\\"label\\\": \\\"Title of the song and name of the singer\\/writer\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. 500 miles by Hedy West\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(53, 7, 'Short Story', 'short-story', 'short-story', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(54, 7, 'Wedding Quote', 'wedding-quote', 'wedding-quote', NULL, '\"[{        \\\"label\\\": \\\"What are the key points?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"key_points\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. Love, Forever, Soulmate\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(55, 7, 'Birthday Wish Quote', 'birthday-wish-quote', 'birthday-wish-quote', NULL, '\"[{\\t\\\"label\\\": \\\"What are the key points?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"key_points\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Long live, happy\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(56, 8, 'Story Outline', 'story-outline', 'story-outline', NULL, '\"[{        \\\"label\\\": \\\"About what is the story?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type description of the story\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(57, 8, 'Story Title & Subtitle', 'story-title-subtitle', 'story-title-subtitle', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 40, 1, '2025-04-21 16:31:51', '2025-04-25 05:07:06', NULL),
(58, 8, 'Story Ideas', 'story-ideas', 'story-ideas', NULL, '\"[{        \\\"label\\\": \\\"What are the key points?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"key_points\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"e.g. Benefit of new AI technologies\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(59, 9, 'TikTok Video Script', 'tiktok-video-script', 'tiktok-video-script', NULL, '\"[{\\t\\\"label\\\": \\\"What are the key points?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"key_points\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Fun, prank, popular tune\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(60, 9, 'TikTok Video Caption', 'tiktok-video-caption', 'tiktok-video-caption', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the video?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the video\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(61, 9, 'Video Ideas', 'video-ideas', 'video-ideas', NULL, '\"[{\\t\\\"label\\\": \\\"What are the key points?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"key_points\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"e.g. Fun, prank, popular tune\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(62, 10, 'Instagram Story Ideas', 'instagram-story-ideas', 'instagram-story-ideas', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(63, 10, 'Instagram Post Ideas', 'instagram-post-ideas', 'instagram-post-ideas', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(64, 10, 'Instagram Reel Ideas', 'instagram-reel-ideas', 'instagram-reel-ideas', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(65, 11, 'Career', 'career', 'career', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(66, 11, 'Business', 'business', 'business', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(67, 11, 'Start up', 'start-up', 'start-up', NULL, '\"[{\\t\\\"label\\\": \\\"About what is the story?\\\",\\t\\\"is_required\\\": true,\\t\\\"field\\\":\\t{\\t\\t\\\"name\\\": \\\"about\\\",\\t\\t\\\"type\\\": \\\"textarea\\\",\\t\\t\\\"placeholder\\\": \\\"Type description of the story\\\"\\t}}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(68, 11, 'Matrimonial Website', 'matrimonial-website', 'matrimonial-website', NULL, '\"[{        \\\"label\\\": \\\"What are partners name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"name\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"e.g. Bride: Tanu, Bridegroom: Manu\\\"        }},{        \\\"label\\\": \\\"Description of their journey\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"about\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type description of the story\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(69, 12, 'Blog Post SEO Meta Description', 'blog-post-seo-meta-description', 'blog-post-seo-meta-description', NULL, '\"[{        \\\"label\\\": \\\"What is your blog title?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"title\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"\\\"        }},{        \\\"label\\\": \\\"Description of your blog\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"description\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type description of the blog\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(70, 12, 'Home Page SEO Meta Description', 'home-page-seo-meta-description', 'home-page-seo-meta-description', NULL, '\"[{        \\\"label\\\": \\\"What is your website branding name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"name\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"\\\"        }},{        \\\"label\\\": \\\"Description of your website\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"description\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type description of the website\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(71, 12, 'Product Page SEO Meta Description', 'product-page-seo-meta-description', 'product-page-seo-meta-description', NULL, '\"[{        \\\"label\\\": \\\"What is your product name?\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"name\\\",                \\\"type\\\": \\\"text\\\",                \\\"placeholder\\\": \\\"\\\"        }},{        \\\"label\\\": \\\"Description of your product\\\",        \\\"is_required\\\": true,        \\\"field\\\":        {                \\\"name\\\": \\\"description\\\",                \\\"type\\\": \\\"textarea\\\",                \\\"placeholder\\\": \\\"Type description of the product\\\"        }}]\"', NULL, 0, 1, '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `template_groups`
--

CREATE TABLE `template_groups` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `icon` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `template_groups`
--

INSERT INTO `template_groups` (`id`, `name`, `slug`, `icon`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Blog Contents', 'blog-contents', 'book-open', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(2, 'Email Templates', 'email-templates', 'mail', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(3, 'Social Media', 'social-media', 'share-2', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(4, 'Videos', 'videos', 'video', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(5, 'Website Contents', 'website-contents', 'monitor', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(6, 'General Contents', 'general-contents', 'file-text', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(7, 'Fun or Quote', 'fun-or-quote', 'tv', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(8, 'Medium', 'medium', 'code', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(9, 'TikTok', 'tiktok', 'film', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(10, 'Instagram', 'instagram', 'instagram', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(11, 'Success Story', 'success-story', 'smile', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL),
(12, 'SEO Tools', 'seo-tools', 'file-text', '2025-04-21 16:31:51', '2025-04-21 16:31:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `template_localizations`
--

CREATE TABLE `template_localizations` (
  `id` bigint UNSIGNED NOT NULL,
  `template_id` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `lang_key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_usages`
--

CREATE TABLE `template_usages` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `template_id` int NOT NULL,
  `custom_template_id` int DEFAULT NULL,
  `total_used_words` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `template_usages`
--

INSERT INTO `template_usages` (`id`, `user_id`, `template_id`, `custom_template_id`, `total_used_words`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 31, NULL, 35, '2025-04-21 23:11:03', '2025-04-21 23:11:03', NULL),
(2, 1, 31, NULL, 35, '2025-04-21 23:11:41', '2025-04-21 23:11:41', NULL),
(3, 1, 31, NULL, 35, '2025-04-21 23:11:45', '2025-04-21 23:11:45', NULL),
(4, 1, 1, NULL, 42, '2025-04-22 13:36:35', '2025-04-22 13:36:35', NULL),
(5, 3, 1, NULL, 46, '2025-04-22 13:53:22', '2025-04-22 13:53:22', NULL),
(6, 1, 0, 2, 368, '2025-04-22 15:41:09', '2025-04-22 15:41:09', NULL),
(7, 3, 57, NULL, 40, '2025-04-25 05:07:06', '2025-04-25 05:07:06', NULL),
(8, 1, 12, NULL, 35, '2025-05-03 18:31:10', '2025-05-03 18:31:10', NULL),
(9, 1, 12, NULL, 597, '2025-05-03 18:31:44', '2025-05-03 18:31:44', NULL),
(10, 1, 40, NULL, 662, '2025-05-03 23:21:14', '2025-05-03 23:21:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `text_to_speeches`
--

CREATE TABLE `text_to_speeches` (
  `id` bigint UNSIGNED NOT NULL,
  `language` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `voice` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `speed` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `break` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `slug` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `text` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `response` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `speech` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `file_path` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `hash` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `credits` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `words` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `storage_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'local',
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `text_to_speeches`
--

INSERT INTO `text_to_speeches` (`id`, `language`, `voice`, `speed`, `break`, `title`, `slug`, `text`, `response`, `speech`, `file_path`, `hash`, `credits`, `words`, `created_by`, `updated_by`, `created_at`, `updated_at`, `storage_type`, `type`) VALUES
(1, NULL, '9BWtsMINqrJLrRacOk9x', NULL, NULL, 'Welcome to our future', 'yn0eiq132kX16JvVOtG2welcome-to-our-future', '\"Welcome to the future of technology—where voices come alive with the power of artificial intelligence. Whether you\'re creating a podcast, narrating a story, or building the next generation of apps, Eleven Labs gives your words a voice. Start transforming your text into lifelike speech today.\"', NULL, 'forid_mondolgRgzMfS4jr.mp3', '/storage/forid_mondolgRgzMfS4jr.mp3', 'UsddYhHTKy2xWJD7oe90YxoOIkVaOhFBntWo0g35Pp9hT6Lcab2LlS3Xl9A6patt9ivOlARfGicqrAvIywS3eMHjujMSNtDFqN7Rf8yVlvWFXQCRYUR2cJi4MxoogxXJefh24B4li6jFueQQoOsbUlyz55OGT73fWsvRoIvQkgVtbmCW4qLCHb1WH5uI7VYE3fc7mDdeiRV1bi4uNWdA4r54DD5DGa6wgobIN5a87jeQrNRAWMfppiXEY1vgR3Sp', '296', '296', 1, NULL, '2025-05-11 17:14:11', '2025-05-11 17:14:11', 'local', 'eleven_labs'),
(2, NULL, 'bIHbv24MWmeRgasZH58o', NULL, NULL, 'Welcome to MsKeyDeals.com', 'lRZsiYLfSqQ656DVNoL0welcome-to-mskeydealscom', 'Welcome to MsKeyDeals.com — your trusted source for affordable, genuine software licenses and digital keys.\r\n\r\nWe make it easy and secure to buy activation keys for Windows, Microsoft Office, antivirus software, and even gaming platforms like Steam and Xbox.\r\n\r\nAt MsKeyDeals, we believe premium software shouldn\'t break the bank. That’s why we work directly with verified suppliers to bring you authentic keys at unbeatable prices — instantly delivered to your inbox.\r\n\r\nSecure payments. Instant delivery. 24/7 support. We’ve got everything you need to buy with confidence.\r\n\r\nWith thousands of happy customers and growing daily, MsKeyDeals is quickly becoming the go-to destination for budget-conscious buyers and power users alike.\r\n\r\nAre you a reseller or IT manager? We offer bulk licensing and custom deals for businesses, schools, and startups. Just reach out — we’re here to help.\r\n\r\nSo whether you’re upgrading your PC, securing your systems, or powering up your team…\r\nChoose MsKeyDeals.com – the smarter way to save on software.\r\n\r\nMsKeyDeals.com – Real Keys. Real Deals. Right Now.', NULL, 'forid_mondolso97qvqYnL.mp3', '/storage/forid_mondolso97qvqYnL.mp3', 'nOJmyrs9KnBGwYzRVY9WqThhGZ1xvVjWHAAlLflFTwtU3SgDnQ3RRHhWlZYEzcG7BPrtIAp0sNR9gU8ZBmj9EqxHaWjzKC4pyDa8FqbtVh2WTTCNcLxyJKyPZvT7DCBk7P9P98UbNoxkHXCdqvRXerxognj728V3Zc5Hk0oaoeWcgjrNQPvclTD8bj7kGrSF3xMIvx3RxkC0j01O4ZR08A0hnrvv2xHdoe9DPjCvQMX4UUjfxFRqdCRaBmSJAnJy', '1113', '1113', 1, NULL, '2025-05-11 17:20:16', '2025-05-11 17:20:16', 'local', 'eleven_labs'),
(3, NULL, 'EXAVITQu4vr4xnSDxMaL', NULL, NULL, 'Welcome to MsKeyDeals.com', 'A7fBoMauvisV0vWgEOFhwelcome-to-mskeydealscom', 'Welcome to MsKeyDeals.com — your trusted source for affordable, genuine software licenses and digital keys.\r\n\r\nWe make it easy and secure to buy activation keys for Windows, Microsoft Office, antivirus software, and even gaming platforms like Steam and Xbox.', NULL, 'forid_mondolD1ZcyC7mb2.mp3', '/storage/forid_mondolD1ZcyC7mb2.mp3', 'VQKboSQJwmWvCu6QzSLtaP83MyIZ4nHEtPtYHcSUIe7cz0WtL34Q7fLKLsP6bZU4o2SyucVyRhNQx1ePPNsu3S0zMZ6yW3DBev37Ko3U2SRCfrg6Z0BHQRRqs1vz9N2jvpkUZGOSWtk8T887OGEaXO1mylvZYAbTPHASGFVpxeJmSWLDdWFGgVZ7hqzR1o1gbwMoKooHGhLq6XB3fGskE3k818YRzWBLbzCGxHR3oCJaYGfA4ZaFgoiYOUuZg32u', '260', '260', 1, NULL, '2025-05-11 17:30:26', '2025-05-11 17:30:26', 'local', 'eleven_labs'),
(4, NULL, 'alloy', '1', NULL, 'Welcome to MsKeyDeals.com', '35UcREPz4ltrxwIaKW41welcome-to-mskeydealscom', 'your trusted source for affordable, genuine software licenses and digital keys.\r\n\r\nWe make it easy and secure to buy activation keys for Windows, Microsoft Office, antivirus software, and even gaming platforms like Steam and Xbox.\r\n\r\nAt MsKeyDeals, we believe premium software shouldn\'t break the bank. That’s why we work directly with verified suppliers to bring you authentic keys at unbeatable prices — instantly delivered to your inbox.', '', 'forid_mondolTRDUUEraC6.mp3', '/storage/forid_mondolTRDUUEraC6.mp3', 'BXQyW2m9fAP96qMAMiBMS4qCGg59tP028TnD5ee80lHGZuJuvD0JLNBLmbGpZFSo7nBfdCkQUqUh3iKPMIrEH69Q6MJS8s9zYXcceP6PeBfR0s6baWz5nWbNmnm9O9yJOrkEYInGDE81EHMtNtO41LQ54L1V7ZZFwgTnGLoQJHxmZzkRCWauTskrydCO9sRgNZFwxicKVtNkmJN3cwKtnZaCEVjZiPiFp0YGRwIWFkvg83q2fA9dE70kTpAFssuk', '444', '444', 1, NULL, '2025-05-11 17:33:33', '2025-05-11 17:33:33', 'local', 'open_ai_tts'),
(5, NULL, 'alloy', '1', NULL, 'Welcome to Microsoftprokey.com', 'jZdQHqVaEkog8JIY5GI7welcome-to-microsoftprokeycom', 'Welcome to Microsoftprokey.com — your trusted source for affordable, genuine software licenses and digital keys.\r\n\r\nWe make it easy and secure to buy activation keys for Windows, Microsoft Office, antivirus software, and even gaming platforms like Steam and Xbox.\r\n\r\nAt Microsoftprokey, we believe premium software shouldn\'t break the bank. That’s why we work directly with verified suppliers to bring you authentic keys at unbeatable prices — instantly delivered to your inbox.\r\n\r\nSecure payments. Instant delivery. 24/7 support. We’ve got everything you need to buy with confidence.\r\n\r\nWith thousands of happy customers and growing daily, Microsoftprokey is quickly becoming the go-to destination for budget-conscious buyers and power users alike.\r\n\r\nAre you a reseller or IT manager? We offer bulk licensing and custom deals for businesses, schools, and startups. Just reach out — we’re here to help.\r\n\r\nSo whether you’re upgrading your PC, securing your systems, or powering up your team…\r\nChoose MsKeyDeals.com – the smarter way to save on software.\r\n\r\nMicrosoftprokey.com – Real Keys. Real Deals. Right Now.', '', 'forid_mondolooW9WeUBLR.mp3', '/storage/forid_mondolooW9WeUBLR.mp3', 'hHGazOHpnVBOE4REgWpXUJoYSYa58XeeAkr2dmryawV8mYTjdRTKmgpO0BZujvwYEBXwGwv5ccmGykff8vg0W5xknjBBOMouOtgZbkJoneUcjd3Jiasxq0qnRKaBmbC55fvrRa9gdcHPEuawwlQAApmyWU0hotEUoNN2Sc1jqyLhG8DA8pX61Lfgr5ZFfHMA3y64ceL2KVkQ6sHbki2BKEidbQIzYuX0o4f9jUCCibrcb0y3kznCpoepvyJThtZs', '1133', '1133', 1, NULL, '2025-05-11 17:35:30', '2025-05-11 17:35:30', 'local', 'open_ai_tts');

-- --------------------------------------------------------

--
-- Table structure for table `text_to_speech_settings`
--

CREATE TABLE `text_to_speech_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `file_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `path` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `project_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `project_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `key` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `value` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `region` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `maximum_character` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `text_to_speech_settings`
--

INSERT INTO `text_to_speech_settings` (`id`, `file_name`, `path`, `project_id`, `project_name`, `is_active`, `key`, `type`, `value`, `region`, `created_by`, `updated_by`, `created_at`, `updated_at`, `maximum_character`) VALUES
(1, NULL, NULL, NULL, NULL, 1, NULL, 'open_ai_tts', NULL, NULL, NULL, NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45', 4096),
(2, NULL, NULL, NULL, NULL, 1, 'sk_8966abfe7093d03bbfaa31520cb567a2870786d8c586fcca', 'eleven_labs', NULL, NULL, 1, NULL, '2025-05-11 17:07:33', '2025-05-11 17:07:33', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `is_default` tinyint NOT NULL DEFAULT '1',
  `preview_image` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `full_image` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_by` int DEFAULT '1',
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `name`, `slug`, `code`, `is_active`, `is_default`, `preview_image`, `full_image`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Default', 'default', 'default', 1, 1, 'theme-default.jpg', NULL, 1, NULL, '2025-04-21 16:31:46', '2025-04-21 16:31:46'),
(2, 'Theme 1', 'theme 1', 'theme1', 1, 0, 'theme-1.jpg', NULL, 1, NULL, '2025-04-21 16:31:46', '2025-04-21 16:31:46');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `category_id` int DEFAULT NULL,
  `priority_id` int DEFAULT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_by` int DEFAULT NULL,
  `assign_by` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_files`
--

CREATE TABLE `ticket_files` (
  `id` bigint UNSIGNED NOT NULL,
  `ticket_id` int NOT NULL,
  `replied_id` int DEFAULT NULL,
  `file_path` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `role_id` int DEFAULT NULL,
  `user_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'customer',
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `phone` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email_or_otp_verified` tinyint NOT NULL DEFAULT '0',
  `verification_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `new_email_verification_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `remember_token` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `provider_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `user_balance` double NOT NULL DEFAULT '0',
  `referral_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `num_of_clicks` int NOT NULL DEFAULT '0',
  `referred_by` int DEFAULT NULL,
  `is_commission_calculated` tinyint NOT NULL DEFAULT '1',
  `subscription_package_id` int DEFAULT NULL,
  `is_banned` tinyint NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `stripe_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `pm_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `pm_last_four` varchar(4) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `user_type`, `name`, `email`, `phone`, `email_or_otp_verified`, `verification_code`, `new_email_verification_code`, `password`, `remember_token`, `provider_id`, `avatar`, `postal_code`, `user_balance`, `referral_code`, `num_of_clicks`, `referred_by`, `is_commission_calculated`, `subscription_package_id`, `is_banned`, `email_verified_at`, `created_at`, `updated_at`, `deleted_at`, `stripe_id`, `pm_type`, `pm_last_four`, `trial_ends_at`, `created_by`, `updated_by`) VALUES
(1, NULL, 'admin', 'Forid Mondol', 'admin@tic.com.bd', NULL, 0, NULL, NULL, '$2y$10$2m/r8HsWn2/WIaGk8SBHmOHOgtSUC.emFk0cIYiRUYEeAR/htri5.', NULL, NULL, '6', NULL, 0, NULL, 0, NULL, 1, NULL, 0, '2025-04-21 16:04:19', NULL, '2025-04-21 16:32:19', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, 'customer', 'F', 'forid@tic.com.bd', '', 1, NULL, NULL, '$2y$10$mYmHjOc8u/hETbcNI2EeVOsto/jzmoQWb2HEgH5AyuWvhcn7iou9C', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, NULL, 0, '2025-04-21 18:25:29', '2025-04-21 18:25:29', '2025-04-21 18:25:29', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, NULL, 'customer', 'Hello Sir', 'q3rana@gmail.com', '01723874221', 1, NULL, NULL, '$2y$10$dlXwRhozW.tSNnGYYnm7EOaBW0k7ir8BfEIPzAlcSYVzZSeoPKbA2', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 1, 0, '2025-04-22 13:50:43', '2025-04-22 13:50:43', '2025-04-22 13:50:43', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, NULL, 'customer', 'fatema khatun', 'ticfatema@gmail.com', '+8801615401133', 1, NULL, NULL, '$2y$10$SoUAD66Cf7L1QTK4kX0IVO.y44APy5/tqdExfwAnNkjZC.xnHuTYS', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 1, 0, '2025-05-04 13:19:46', '2025-05-04 13:19:44', '2025-05-04 13:19:46', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, NULL, 'customer', 'Asib Srabon', 'asibsrabon.ticltd@gmail.com', '', 1, NULL, NULL, '$2y$10$oKflx03BpEdYISPrKAKEaeYQCN5kkZHnYWun7VP02UnKKkIn8QNYG', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 1, 0, '2025-05-04 14:34:25', '2025-05-04 14:34:25', '2025-05-04 14:34:25', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, NULL, 'customer', 'Lavillscets', 'revers711@1ti.ru', '83273564337', 1, NULL, NULL, '$2y$10$MQNEx0uMOUCuLhf.tcjfse8Ep6vYPdXWfUGXuoJ/Wqb7.gv6l8Qii', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 1, 0, '2025-05-08 21:47:04', '2025-05-08 21:47:04', '2025-05-08 21:47:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, NULL, 'customer', 'Mim parvin', 'mimparvin602@gmail.com', '01775767365', 1, NULL, NULL, '$2y$10$Q6fdOWbV9cvF2eUVQ81CvO6BQs8SjLiiOZMXGTDhii1.qgTBg/vBS', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 1, 0, '2025-05-11 15:58:23', '2025-05-11 15:58:23', '2025-05-11 15:58:23', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, NULL, 'customer', 'Azharul Islam', 'azharulislamokokok@gmail.com', '+8801785456250', 1, NULL, NULL, '$2y$10$m5Q3BvcaUv9XV0i78Pk0F.KV1jVn/alkvaRsxvLkV0JL67x8JvBXi', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 1, 0, '2025-05-11 16:23:46', '2025-05-11 16:23:46', '2025-05-11 16:23:47', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, NULL, 'customer', 'Nazmul Haque', 'php673500@gmail.com', '+8801714673500', 1, NULL, NULL, '$2y$10$4SPQEvRe046icOls/b9z4uYb1CsvwOnyYq87.LNCu9uH/lIRFh0IC', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 1, 0, '2025-05-12 01:33:52', '2025-05-12 01:33:52', '2025-05-12 01:33:52', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, NULL, 'customer', 'Tamanna Rezvi', 'tamannarezvi73@gmail.com', '01764898389', 1, NULL, NULL, '$2y$10$zHRym.fVlH0hK.fNYi8mT.PS48WNZGr/CdjByTs84nALdYVM2J6hO', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 1, 0, '2025-05-12 14:39:32', '2025-05-12 14:39:32', '2025-05-12 14:39:32', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `voice_languages`
--

CREATE TABLE `voice_languages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `flag` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `voice_language_details`
--

CREATE TABLE `voice_language_details` (
  `id` bigint UNSIGNED NOT NULL,
  `language` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `language_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `voice_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `voice` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `gender` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `method` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'google, azure, aws',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `avatar_url` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `voice_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'standard' COMMENT 'standard|neural',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `webhook_histories`
--

CREATE TABLE `webhook_histories` (
  `id` bigint UNSIGNED NOT NULL,
  `gateway` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `webhook_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `create_time` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `resource_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `event_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `summary` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `resource_id` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `resource_state` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `parent_payment` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `amount_total` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `amount_currency` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `incoming_json` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `status` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `writebot_modules`
--

CREATE TABLE `writebot_modules` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `is_paid` tinyint(1) DEFAULT '0',
  `is_verified` tinyint(1) DEFAULT '0',
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `purchase_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `domain` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `writebot_modules`
--

INSERT INTO `writebot_modules` (`id`, `name`, `is_default`, `is_paid`, `is_verified`, `description`, `purchase_code`, `domain`, `created_at`, `updated_at`) VALUES
(1, 'Support', 1, 0, 0, NULL, NULL, NULL, '2025-04-21 16:31:45', '2025-04-21 16:31:45');

-- --------------------------------------------------------

--
-- Table structure for table `wr_notifications`
--

CREATE TABLE `wr_notifications` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `role_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `url` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_read` tinyint DEFAULT '0',
  `user_role` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `wr_notifications`
--

INSERT INTO `wr_notifications` (`id`, `title`, `role_id`, `user_id`, `url`, `is_read`, `user_role`, `type`, `description`, `created_at`, `updated_at`) VALUES
(1, 'New User Register', NULL, NULL, 'dashboard/customers', 0, 'admin', NULL, NULL, '2025-04-21 18:25:29', '2025-04-21 18:25:29'),
(2, 'Offline Payment Request', NULL, NULL, 'dashboard/payment-request', 0, 'admin', NULL, NULL, '2025-04-21 22:50:06', '2025-04-21 22:50:06'),
(3, 'Admin Approved Payment', NULL, 2, NULL, 0, 'customer', NULL, NULL, '2025-04-21 22:51:10', '2025-04-21 22:51:10'),
(4, 'Admin Approved Payment', NULL, 2, NULL, 0, 'customer', NULL, NULL, '2025-04-21 22:51:18', '2025-04-21 22:51:18'),
(5, 'New User Register', NULL, NULL, 'dashboard/customers', 1, 'admin', NULL, NULL, '2025-04-22 13:50:43', '2025-05-03 23:17:23'),
(6, 'New User Register', NULL, NULL, 'dashboard/customers', 0, 'admin', NULL, NULL, '2025-05-04 13:19:46', '2025-05-04 13:19:46'),
(7, 'Admin Assign Package For You', NULL, 4, 'dashboard/subscriptions', 0, 'customer', NULL, NULL, '2025-05-04 13:48:43', '2025-05-04 13:48:43'),
(8, 'New User Register', NULL, NULL, 'dashboard/customers', 0, 'admin', NULL, NULL, '2025-05-04 14:34:25', '2025-05-04 14:34:25'),
(9, 'Offline Payment Request', NULL, NULL, 'dashboard/payment-request', 0, 'admin', NULL, NULL, '2025-05-04 14:39:15', '2025-05-04 14:39:15'),
(10, 'New User Register', NULL, NULL, 'dashboard/customers', 0, 'admin', NULL, NULL, '2025-05-08 21:47:04', '2025-05-08 21:47:04'),
(11, 'New User Register', NULL, NULL, 'dashboard/customers', 1, 'admin', NULL, NULL, '2025-05-11 15:58:23', '2025-05-12 01:36:10'),
(12, 'Offline Payment Request', NULL, NULL, 'dashboard/payment-request', 1, 'admin', NULL, NULL, '2025-05-11 15:59:24', '2025-05-11 16:01:51'),
(13, 'Admin Approved Payment', NULL, 7, NULL, 0, 'customer', NULL, NULL, '2025-05-11 16:02:18', '2025-05-11 16:02:18'),
(14, 'Admin Approved Payment', NULL, 5, NULL, 1, 'customer', NULL, NULL, '2025-05-11 16:02:33', '2025-05-13 10:37:58'),
(15, 'New User Register', NULL, NULL, 'dashboard/customers', 1, 'admin', NULL, NULL, '2025-05-11 16:23:47', '2025-05-12 01:33:11'),
(16, 'New User Register', NULL, NULL, 'dashboard/customers', 1, 'admin', NULL, NULL, '2025-05-12 01:33:52', '2025-05-12 01:34:18'),
(17, 'Admin Assign Package For You', NULL, 9, 'dashboard/subscriptions', 1, 'customer', NULL, NULL, '2025-05-12 01:34:47', '2025-05-12 01:45:56'),
(18, 'Admin Assign Package For You', NULL, 8, 'dashboard/subscriptions', 0, 'customer', NULL, NULL, '2025-05-12 01:35:39', '2025-05-12 01:35:39'),
(19, 'New User Register', NULL, NULL, 'dashboard/customers', 1, 'admin', NULL, NULL, '2025-05-12 14:39:32', '2025-05-13 16:02:45'),
(20, 'Admin Assign Package For You', NULL, 10, 'dashboard/subscriptions', 0, 'customer', NULL, NULL, '2025-05-13 16:03:17', '2025-05-13 16:03:17'),
(21, 'Admin Assign Package For You', NULL, 8, 'dashboard/subscriptions', 0, 'customer', NULL, NULL, '2025-05-13 16:03:50', '2025-05-13 16:03:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ad_senses`
--
ALTER TABLE `ad_senses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_sense_localizations`
--
ALTER TABLE `ad_sense_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `affiliate_earnings`
--
ALTER TABLE `affiliate_earnings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `affiliate_payments`
--
ALTER TABLE `affiliate_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `affiliate_payout_accounts`
--
ALTER TABLE `affiliate_payout_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_blog_wizards`
--
ALTER TABLE `ai_blog_wizards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ai_blog_wizards_subscription_history_id_index` (`subscription_history_id`);

--
-- Indexes for table `ai_blog_wizard_articles`
--
ALTER TABLE `ai_blog_wizard_articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_blog_wizard_article_logs`
--
ALTER TABLE `ai_blog_wizard_article_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ai_blog_wizard_article_logs_user_id_index` (`user_id`),
  ADD KEY `ai_blog_wizard_article_logs_ai_blog_wizard_id_index` (`ai_blog_wizard_id`),
  ADD KEY `ai_blog_wizard_article_logs_ai_blog_wizard_article_id_index` (`ai_blog_wizard_article_id`),
  ADD KEY `ai_blog_wizard_article_logs_subscription_history_id_index` (`subscription_history_id`);

--
-- Indexes for table `ai_blog_wizard_images`
--
ALTER TABLE `ai_blog_wizard_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_blog_wizard_key_words`
--
ALTER TABLE `ai_blog_wizard_key_words`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_blog_wizard_outlines`
--
ALTER TABLE `ai_blog_wizard_outlines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_blog_wizard_titles`
--
ALTER TABLE `ai_blog_wizard_titles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_chats`
--
ALTER TABLE `ai_chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_chat_categories`
--
ALTER TABLE `ai_chat_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_chat_messages`
--
ALTER TABLE `ai_chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_chat_prompts`
--
ALTER TABLE `ai_chat_prompts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_chat_prompt_groups`
--
ALTER TABLE `ai_chat_prompt_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_content_detectors`
--
ALTER TABLE `ai_content_detectors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ai_response_logs`
--
ALTER TABLE `ai_response_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `application_versions`
--
ALTER TABLE `application_versions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assign_tickets`
--
ALTER TABLE `assign_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_localizations`
--
ALTER TABLE `blog_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_tags`
--
ALTER TABLE `blog_tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us_messages`
--
ALTER TABLE `contact_us_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_settings`
--
ALTER TABLE `customer_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_templates`
--
ALTER TABLE `custom_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_template_categories`
--
ALTER TABLE `custom_template_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_template_category_localizations`
--
ALTER TABLE `custom_template_category_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_template_localizations`
--
ALTER TABLE `custom_template_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eleven_labs_models`
--
ALTER TABLE `eleven_labs_models`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eleven_labs_model_voices`
--
ALTER TABLE `eleven_labs_model_voices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_mail_settings`
--
ALTER TABLE `e_mail_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq_localizations`
--
ALTER TABLE `faq_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favorite_templates`
--
ALTER TABLE `favorite_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature_categories`
--
ALTER TABLE `feature_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature_category_details`
--
ALTER TABLE `feature_category_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature_category_detail_localizations`
--
ALTER TABLE `feature_category_detail_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature_category_localizations`
--
ALTER TABLE `feature_category_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fine_tunes`
--
ALTER TABLE `fine_tunes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fine_tunes_user_id_foreign` (`user_id`);

--
-- Indexes for table `fine_tune_histories`
--
ALTER TABLE `fine_tune_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fine_tune_histories_fine_tune_id_foreign` (`fine_tune_id`);

--
-- Indexes for table `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_setup_localizations`
--
ALTER TABLE `general_setup_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grass_period_payments`
--
ALTER TABLE `grass_period_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `licenses`
--
ALTER TABLE `licenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `localizations`
--
ALTER TABLE `localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media_managers`
--
ALTER TABLE `media_managers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `offline_payment_methods`
--
ALTER TABLE `offline_payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `old_payment_gateway_products`
--
ALTER TABLE `old_payment_gateway_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `open_ai_keys`
--
ALTER TABLE `open_ai_keys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `open_ai_models`
--
ALTER TABLE `open_ai_models`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_localizations`
--
ALTER TABLE `page_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `paymentgateway_product_histories`
--
ALTER TABLE `paymentgateway_product_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_gateway_details`
--
ALTER TABLE `payment_gateway_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_gateway_products`
--
ALTER TABLE `payment_gateway_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pdf_chats`
--
ALTER TABLE `pdf_chats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pdf_chats_chat_code_unique` (`chat_code`),
  ADD KEY `pdf_chats_user_id_foreign` (`user_id`);

--
-- Indexes for table `pdf_chat_conversations`
--
ALTER TABLE `pdf_chat_conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pdf_chat_conversations_user_id_foreign` (`user_id`),
  ADD KEY `pdf_chat_conversations_pdf_chat_id_foreign` (`pdf_chat_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `plagiarism_settings`
--
ALTER TABLE `plagiarism_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `priorities`
--
ALTER TABLE `priorities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_logs`
--
ALTER TABLE `project_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_logs_user_id_index` (`user_id`),
  ADD KEY `project_logs_project_id_index` (`project_id`),
  ADD KEY `project_logs_subscription_history_id_index` (`subscription_history_id`),
  ADD KEY `project_logs_subscription_package_id_index` (`subscription_package_id`),
  ADD KEY `project_logs_content_type_index` (`content_type`);

--
-- Indexes for table `prompts`
--
ALTER TABLE `prompts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `p_w_a_settings`
--
ALTER TABLE `p_w_a_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reply_tickets`
--
ALTER TABLE `reply_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `storage_managers`
--
ALTER TABLE `storage_managers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribed_users`
--
ALTER TABLE `subscribed_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subscriptions_stripe_id_unique` (`stripe_id`),
  ADD KEY `subscriptions_user_id_stripe_status_index` (`user_id`,`stripe_status`);

--
-- Indexes for table `subscription_auto_payments`
--
ALTER TABLE `subscription_auto_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_histories`
--
ALTER TABLE `subscription_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_items`
--
ALTER TABLE `subscription_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subscription_items_subscription_id_stripe_price_unique` (`subscription_id`,`stripe_price`),
  ADD UNIQUE KEY `subscription_items_stripe_id_unique` (`stripe_id`);

--
-- Indexes for table `subscription_logs`
--
ALTER TABLE `subscription_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_packages`
--
ALTER TABLE `subscription_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_package_templates`
--
ALTER TABLE `subscription_package_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_recurring_payments`
--
ALTER TABLE `subscription_recurring_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `template_groups`
--
ALTER TABLE `template_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `template_localizations`
--
ALTER TABLE `template_localizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `template_usages`
--
ALTER TABLE `template_usages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `text_to_speeches`
--
ALTER TABLE `text_to_speeches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `text_to_speech_settings`
--
ALTER TABLE `text_to_speech_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket_files`
--
ALTER TABLE `ticket_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_stripe_id_index` (`stripe_id`);

--
-- Indexes for table `voice_languages`
--
ALTER TABLE `voice_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voice_language_details`
--
ALTER TABLE `voice_language_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webhook_histories`
--
ALTER TABLE `webhook_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `writebot_modules`
--
ALTER TABLE `writebot_modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wr_notifications`
--
ALTER TABLE `wr_notifications`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ad_senses`
--
ALTER TABLE `ad_senses`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ad_sense_localizations`
--
ALTER TABLE `ad_sense_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `affiliate_earnings`
--
ALTER TABLE `affiliate_earnings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `affiliate_payments`
--
ALTER TABLE `affiliate_payments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `affiliate_payout_accounts`
--
ALTER TABLE `affiliate_payout_accounts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ai_blog_wizards`
--
ALTER TABLE `ai_blog_wizards`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `ai_blog_wizard_articles`
--
ALTER TABLE `ai_blog_wizard_articles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ai_blog_wizard_article_logs`
--
ALTER TABLE `ai_blog_wizard_article_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ai_blog_wizard_images`
--
ALTER TABLE `ai_blog_wizard_images`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ai_blog_wizard_key_words`
--
ALTER TABLE `ai_blog_wizard_key_words`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `ai_blog_wizard_outlines`
--
ALTER TABLE `ai_blog_wizard_outlines`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `ai_blog_wizard_titles`
--
ALTER TABLE `ai_blog_wizard_titles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `ai_chats`
--
ALTER TABLE `ai_chats`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ai_chat_categories`
--
ALTER TABLE `ai_chat_categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `ai_chat_messages`
--
ALTER TABLE `ai_chat_messages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `ai_chat_prompts`
--
ALTER TABLE `ai_chat_prompts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ai_chat_prompt_groups`
--
ALTER TABLE `ai_chat_prompt_groups`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ai_content_detectors`
--
ALTER TABLE `ai_content_detectors`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ai_response_logs`
--
ALTER TABLE `ai_response_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `application_versions`
--
ALTER TABLE `application_versions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `assign_tickets`
--
ALTER TABLE `assign_tickets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_localizations`
--
ALTER TABLE `blog_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_tags`
--
ALTER TABLE `blog_tags`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_us_messages`
--
ALTER TABLE `contact_us_messages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_settings`
--
ALTER TABLE `customer_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_templates`
--
ALTER TABLE `custom_templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `custom_template_categories`
--
ALTER TABLE `custom_template_categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `custom_template_category_localizations`
--
ALTER TABLE `custom_template_category_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_template_localizations`
--
ALTER TABLE `custom_template_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eleven_labs_models`
--
ALTER TABLE `eleven_labs_models`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `eleven_labs_model_voices`
--
ALTER TABLE `eleven_labs_model_voices`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `e_mail_settings`
--
ALTER TABLE `e_mail_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faq_localizations`
--
ALTER TABLE `faq_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `favorite_templates`
--
ALTER TABLE `favorite_templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feature_categories`
--
ALTER TABLE `feature_categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feature_category_details`
--
ALTER TABLE `feature_category_details`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `feature_category_detail_localizations`
--
ALTER TABLE `feature_category_detail_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `feature_category_localizations`
--
ALTER TABLE `feature_category_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `fine_tunes`
--
ALTER TABLE `fine_tunes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fine_tune_histories`
--
ALTER TABLE `fine_tune_histories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `folders`
--
ALTER TABLE `folders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `general_setup_localizations`
--
ALTER TABLE `general_setup_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `grass_period_payments`
--
ALTER TABLE `grass_period_payments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `licenses`
--
ALTER TABLE `licenses`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `localizations`
--
ALTER TABLE `localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1437;

--
-- AUTO_INCREMENT for table `media_managers`
--
ALTER TABLE `media_managers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `offline_payment_methods`
--
ALTER TABLE `offline_payment_methods`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `old_payment_gateway_products`
--
ALTER TABLE `old_payment_gateway_products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `open_ai_keys`
--
ALTER TABLE `open_ai_keys`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `open_ai_models`
--
ALTER TABLE `open_ai_models`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `page_localizations`
--
ALTER TABLE `page_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `paymentgateway_product_histories`
--
ALTER TABLE `paymentgateway_product_histories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `payment_gateway_details`
--
ALTER TABLE `payment_gateway_details`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `payment_gateway_products`
--
ALTER TABLE `payment_gateway_products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pdf_chats`
--
ALTER TABLE `pdf_chats`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pdf_chat_conversations`
--
ALTER TABLE `pdf_chat_conversations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plagiarism_settings`
--
ALTER TABLE `plagiarism_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priorities`
--
ALTER TABLE `priorities`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `project_logs`
--
ALTER TABLE `project_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `prompts`
--
ALTER TABLE `prompts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p_w_a_settings`
--
ALTER TABLE `p_w_a_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reply_tickets`
--
ALTER TABLE `reply_tickets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `storage_managers`
--
ALTER TABLE `storage_managers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subscribed_users`
--
ALTER TABLE `subscribed_users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_auto_payments`
--
ALTER TABLE `subscription_auto_payments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_histories`
--
ALTER TABLE `subscription_histories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `subscription_items`
--
ALTER TABLE `subscription_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_logs`
--
ALTER TABLE `subscription_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_packages`
--
ALTER TABLE `subscription_packages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subscription_package_templates`
--
ALTER TABLE `subscription_package_templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=498;

--
-- AUTO_INCREMENT for table `subscription_recurring_payments`
--
ALTER TABLE `subscription_recurring_payments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `template_groups`
--
ALTER TABLE `template_groups`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `template_localizations`
--
ALTER TABLE `template_localizations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `template_usages`
--
ALTER TABLE `template_usages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `text_to_speeches`
--
ALTER TABLE `text_to_speeches`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `text_to_speech_settings`
--
ALTER TABLE `text_to_speech_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_files`
--
ALTER TABLE `ticket_files`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `voice_languages`
--
ALTER TABLE `voice_languages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `voice_language_details`
--
ALTER TABLE `voice_language_details`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `webhook_histories`
--
ALTER TABLE `webhook_histories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `writebot_modules`
--
ALTER TABLE `writebot_modules`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wr_notifications`
--
ALTER TABLE `wr_notifications`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fine_tunes`
--
ALTER TABLE `fine_tunes`
  ADD CONSTRAINT `fine_tunes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `fine_tune_histories`
--
ALTER TABLE `fine_tune_histories`
  ADD CONSTRAINT `fine_tune_histories_fine_tune_id_foreign` FOREIGN KEY (`fine_tune_id`) REFERENCES `fine_tunes` (`id`);

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pdf_chats`
--
ALTER TABLE `pdf_chats`
  ADD CONSTRAINT `pdf_chats_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `pdf_chat_conversations`
--
ALTER TABLE `pdf_chat_conversations`
  ADD CONSTRAINT `pdf_chat_conversations_pdf_chat_id_foreign` FOREIGN KEY (`pdf_chat_id`) REFERENCES `pdf_chats` (`id`),
  ADD CONSTRAINT `pdf_chat_conversations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
