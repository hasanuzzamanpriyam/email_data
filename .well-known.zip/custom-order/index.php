<?php
 header('Location:https://bookyourdata.io/tool/business');